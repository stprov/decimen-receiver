#!/bin/bash

#Описание работы entrypoint.sh
#Указанные ниже переменные передаются из Openshift и скрипт entrypoint.sh включает ожидание старта соответствующих сервиса и gracefull выключение
#Эти переменные не должны переопределяться в Dockerfile.

#LOOP_DELAY	    Задержка между проверками sidecar сервисов в секундах
#MAX_TIMEOUT	Максимальное время ожидания, в секундах, готовности sidecars сервисов. При превышении, скрипт завершается с ошибкой
#CMD	        Команда для исполнения, которая будет выполнена внутри entrypoint (Обязательный)
#IS_VAULT_FILE	/vault/secrets/token	При появлении этого файла в системе, считается, что сервис Vault стартовал
#HELM_NAME		Если переменная задана и имеет значение cron, скрипт пытается корректно завершить Istio и Vault, если те включены. 
#               Это настройка подходит для Cronjob,в случае Deployment, эта переменная должна быть задана и равна deployment


#IS_VAULT	Если задана, то включается ожидание появления файла секрета. 
#           Ожидаемый файл определяется переменной окружения IS_VAULT_FILE, описанной ниже.
#           Если задана переменная окружения HELM_NAME==cron, то, при выходе, производится отправления сигнала завершения на sidecar Vault

#IS_ISTIO	Если задана, то включается ожидание ответа от sidecar контейнера Istio.
#           Если задана переменная окружения HELM_NAME==cron, то, при выходе, производится отправления сигнала завершения на sidecar Istio

MAX_TIMEOUT=${MAX_TIMEOUT-300} # exit fail if time exeed defined number of seconds. Default=300  (5min)
LOOP_DELAY=${LOOP_DELAY-5} # delay between startup checks in  seconds. Default=5
HELM_NAME="${HELM_NAME-deployment}" # доступные варианты "cron|deployment"
if [ -z "${CMD}" ]; then
  CMD="${1-echo "Warning. Отсутствуют параметры запуска. Нечего делать."}"
  [ -n "${1}" ] && shift
else
  CMD="${CMD}"
fi
 
################# PLZ DON'T CHANGE THE CODE BELOW THE LINE #######################
START=$(date +%s)
   
function on_err() {
  ex_code=$?
  # trap - ERR
  echo "Failed with error code ${ex_code} in ${1}:> ${2}" >&2
  exit $ex_code
}
   
function on_exit() {
  ex_code=$?
  trap - EXIT
  if [ -n  "$svc_str" -a "$HELM_NAME" == "cron" ]; then
    echo -e "Gracefull shutdown for ${svc_str}"
    [ -n "${IS_VAULT}" ] && curl -fsI -X POST http://127.0.0.1:8200/agent/v1/quit
    [ -n "${IS_ISTIO}" ] && curl -fsI -X POST http://localhost:15020/quitquitquit
  fi
  if [ "$ex_code" -eq 0 ]; then
    echo "Done successfully"
  else
    echo "Exit with error: ${ex_code}"
  fi
  exit $ex_code
}
 
trap 'on_err ${LINENO} "$BASH_COMMAND"' ERR 2
trap on_exit EXIT
   
function wait_start() {
  # start loop
  svc_str="$([ -n "${IS_VAULT}" ]&& echo -n "Vault")$([ -n "${IS_VAULT}" -a -n "${IS_ISTIO}" ]&& echo -n " and ")$([ -n "${IS_ISTIO}" ]&& echo -n "Istio" )"
  echo "${svc_str}"
  if [ -n  "$svc_str" ]; then
    echo -e "Waiting for: \"${svc_str}\"" >&2
    until [ -n "$vault_done" -a -n "$istio_done" ]; do
      vault_done=; istio_done=
      [ -z "${IS_VAULT}" ] && vault_done=1
      [ -n "${IS_VAULT}" ] && [ -f ${IS_VAULT_FILE-/vault/secrets/token} ] && sleep 2 && vault_done=1
      [ -z "${IS_ISTIO}" ] && istio_done=1
      [ -n "${IS_ISTIO}" ] && [ $(curl -fsI http://localhost:15020/healthz/ready >/dev/null 2>&1; echo $?) == "0" ] && istio_done=1
      if [[ $(($(date +%s) - $START)) -gt $MAX_TIMEOUT ]]; then
        echo -e "ERROR: Timeout ${MAX_TIMEOUT} exceeded waiting starting: ${svc_str}. Exiting with error" >&2
        exit 1
      fi
      printf "." >&2; sleep $LOOP_DELAY;
    done
    echo -e "\tOK...\tvault ready" >&2
  fi
}
svc_str=$(wait_start)
 
eval $CMD $@