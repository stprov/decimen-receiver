# GIGACODE.md — gmap2-vux-ecm

## О проекте

Spring Boot 4.0.7 приложение (Java 21) для обработки и управления документами/заявлениями ВЭД (gmap2-vux-ecm). Мульти-модульный Maven-проект:

- **`service`** — основной модуль с бизнес-логикой

## Стек

| Компонент        | Версия     | Примечание                            |
|-------------------|------------|---------------------------------------|
| Spring Boot       | 4.0.7      | Обновлён в рамках МПР                 |
| Java              | 21         | —                                     |
| MapStruct         | 1.6.3      | Маппинг объектов                      |
| Lombok            | —          | + lombok-mapstruct-binding 0.2.0      |
| Spring Cloud      | 2025.1.2   |                                       |
| Spring Cloud OpenFeign | 5.0.2 | Клиент-прокси к внешним API          |
| PostgreSQL        | 42.7.12    | JDBC драйвер                          |
| iText             | 9.3.0 / 6.2.1 | Генерация PDF                      |
| Apache Tika       | 3.2.2      | Определение типов файлов              |
| AWS SDK S3        | 2.45.0     | Хранилище файлов                      |
| Netty (fix)       | 4.2.16.Final | Патч уязвимостей                     |
| jackson-databind  | 3.1.7      | Устранение уязвимостей               |

## Команды

```bash
# Сборка
mvn clean package -DskipTests

# Сборка с тестами
mvn clean package

# Запуск сервиса
mvn spring-boot:run -pl service
```

## Структура

```
.
├── pom.xml                 # Родительский POM (dependencyManagement, build plugins)
├── service/
│   ├── pom.xml             # Модуль приложения
│   └── src/main/
│       ├── java/           # Java-источники (ru.sbrf.gmap.vux.*)
│       └── resources/      # application.yml, XSD-схемы (jaxb)
├── distrib/                # Архивация дистрибутива
├── docs/                   # Документация
└── openspec/               # OpenSpec артефакты изменений
```

## Build-плагины

- **spring-boot-maven-plugin** — упаковка executable JAR (Lombok исключён из exclude-ла)
- **jaxb-maven-plugin** — генерация Java-классов из XSD (`src/main/resources/xsd`) → `target/generated-sources/tfs`
- **build-helper-maven-plugin** — подключение сгенерированных источников к компиляции
- **maven-compiler-plugin** — annotation processors: Lombok, lombok-mapstruct-binding, mapstruct-processor

## Конвенции

- Пакетная структура: `ru.sbrf.gmap.vux.*`
- Код-стили настроены в `.idea/codestyles/`
- Коммит-сообщения: тикет-префикс + описание на русском (см. `user/commit-language.md` в памяти)
- XSD-схемы в `src/main/resources/xsd/`, автоматически генерируют JAXB-классы

## Безопасность

- SPRUT MCP доступен для скана зависимостей (`sprut_scan_project`, `sprut_check_dependency`)
- После обновления Netty/jackson — уязвимости должны быть закрыты
