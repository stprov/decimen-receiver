Необходимо добавить rest endpoint для этого сервиса. После вызова этого эндпоинта происходит сохранение файла через сервис @UploadDocumentService и метод
uploadDocumentViaTfs, с тем отличием, что в этом методе не передается массив байт файла, а только ссылка в s3. Эндпоинт должен принимать
String s3Path, String filename,DocumentTypeEnum documentType, String slice_id, String task_id, должен возращать rqUid который формируется при отправке документа на сохранение.

1. После формирования и вызова функции сохранения в ECM необходимо вызвать процедуру fn_ecm_request_create(p_request_id varchar, p_subsystem varchar, p_subsystem_id varchar),
передав ей параметры: 
- prequest_id -> сформированный rquid для запроса в ЕСМ
- p_subsystem -> xbrl-csv (всегда такое значение)
- p_subsystem_id -> slice_id
1.2. Если при сохранении возникла ошибка, то вызвать функцию:
  create or replace function fn_ecm_request_set_error(p_request_id varchar, p_error_text varchar);
  p_request_id -- rqUUID
  p_error_text -- текст ошибки

2. случае получения ответной квитанции, то полученный rquid проверяется на его наличие в v_vux_ecm_queue.
2.1. Если такого rquid нет, то квитанция обрабатывается по легаси-байтовому сценарию (fn_flow_set_ecm_id): существующие байтовые загрузки в очереди не регистрируются
2.2. Если такой rquid есть, то вызывается процедура fn_ecm_request_set_ecm_id(p_request_id varchar, p_ecm_id varchar, p_ecm_date timestamp default current_timestamp);
   p_request_id -- requestId
   p_ecm_id - присвоенный ЕСМ-ом uuid
2.3 Если в квитанции вернулась ошибка, то необходимо вызвать процедуру: fn_ecm_request_set_error(p_request_id varchar, p_error_text varchar).

Если возникают вопросы по постановке, то задавай вопросы, ничего не придумывай сам



