CREATE OR REPLACE FUNCTION **fn_flow_xbrl_csv_ecm_set_status**(p_slice_id varchar, p_request_id varchar, p_request_status varchar, p_ecm_id varchar)
RETURNS text

CREATE OR REPLACE FUNCTION s_grnplm_as_cib_gm_vux.fn_ecm_request_create(p_subsystem varchar, p_subsystem_id varchar)
RETURNS uuid

CREATE OR REPLACE FUNCTION s_grnplm_as_cib_gm_vux.fn_ecm_request_create(p_request_id varchar, p_subsystem varchar, p_subsystem_id varchar)
RETURNS text
p_request_id             varchar   -- uuid_ecm
p_subsystem              varchar  -- xbrl-csv
p_subsystem_id           varchar   -- slice_id

create or replace function fn_ecm_request_set_ecm_id(p_request_id varchar, p_ecm_id varchar, p_ecm_date timestamp default current_timestamp);
p_request_id             varchar   -- uuid_ecm
p_ecm_id              varchar  -- присвоенный ЕСМ-ом uuid

create or replace function fn_ecm_request_set_error(p_request_id varchar, p_error_text varchar);
p_request_id -- rqUUID
p_error_text -- текст ошибки