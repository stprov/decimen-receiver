## Why

В протоколе проверки в блоке «Найдены серьезные ошибки!» сейчас выводится:
```
Найдены серьезные ошибки!
Всего ошибок: <size списка objects>
```
где `<size списка objects>` — это количество записей в таблице ошибок, которое может быть меньше общего числа ошибок из‑за ограничения `LIMIT totalSet` в запросе `getResultsForDocWithRnLimit`. Аналогичная проблема для предупреждений.

Необходимо показывать реальное общее количество ошибок (сумму `countingDeviation` из `checksList`, где `checkResult == "Выявлено"`), а не просто размер отфильтрованного списка.

Требуется также различать, относится ли запись `ProtocolCheckRecordDto` к ошибке или к предупреждению, чтобы корректно суммировать общее количество только для ошибок и только для предупреждений.

## What Changes

- Добавить поле `ruleType` (RuleTypeEnum) в `ProtocolCheckRecordDto` — для дифференциации error / warning.
- Дополнить `ProtocolModelDto` полями `totalErrorCount` и `totalWarningCount` (int / long), которые будут содержать сумму `countingDeviation` по записям `checksList` с соответствующим `ruleType`.
- Изменить FreeMarker-шаблон `xbrl_protocol.ftl`:
  - В блоке «Найдены серьезные ошибки!» выводить:
    ```
    Показано <количество показано> из <totalErrorCount>
    ```
  - В блоке «Обнаружены предупреждения:» выводить:
    ```
    Показано <количество показано> из <totalWarningCount>
    ```
- В `OrchestratorService.createProtocolModelDto(...)` рассчитывать `totalErrorCount` и `totalWarningCount` на основе списка `checksList` **без дополнительных запросов в БД**.
- Тесты: обновить существующие и добавить новые тесты `OutputFormingServiceIntegrationTest`.

## Capabilities

### New Capabilities
- `count-display`: Корректное отображение количества ошибок и предупреждений в протоколе проверки — «Показано N из M», где M — общее количество ошибок из checksList.

### Modified Capabilities
*(нет изменений требований на уровне спецификаций)*

## Impact

- **DTO**: `ProtocolCheckRecordDto` — новое поле `ruleType`.
- **DTO**: `ProtocolModelDto` — новые поля `totalErrorCount`, `totalWarningCount`.
- **Шаблон**: `xbrl_protocol.ftl` — изменена логика вывода баннеров ошибок и предупреждений.
- **Сервис**: `OrchestratorService.createProtocolModelDto()` — расчёт totalCount-полей.
- **Тесты**: `OutputFormingServiceIntegrationTest` — обновление ожидаемых значений в проверках шаблона.