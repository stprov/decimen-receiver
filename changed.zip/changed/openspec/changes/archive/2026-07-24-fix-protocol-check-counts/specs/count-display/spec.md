## ADDED Requirements

### Requirement: Protocol displays total error and warning counts from checksList

The system SHALL display the total count of errors and warnings in the protocol HTML using aggregate values from `checksList`, rather than just the size of the filtered `objects`/`warnings` lists.

The system SHALL add a `ruleType` field (RuleTypeEnum) to `ProtocolCheckRecordDto` to distinguish error records from warning records.

The system SHALL add `totalErrorCount` and `totalWarningCount` fields to `ProtocolModelDto`, calculated by summing `countingDeviation` from `checksList` entries with matching `ruleType`.

The calculation SHALL use only data already loaded in memory (no additional database queries).

The protocol banner SHALL display:
- For errors: `Показано <shown> из <totalErrorCount>`
- For warnings: `Показано <shown> из <totalWarningCount>`

#### Scenario: Error banner shows shown/total counts

- **WHEN** the protocol has 3 error rows displayed but `checksList` totals 10 errors
- **THEN** the error banner shows `Показано 3 из 10`

#### Scenario: Warning banner shows shown/total counts

- **WHEN** the protocol has 2 warning rows displayed but `checksList` totals 5 warnings
- **THEN** the warning banner shows `Показано 2 из 5`

#### Scenario: Empty objects list does not show error banner

- **WHEN** the `objects` list is empty
- **THEN** the error banner is hidden entirely

#### Scenario: Empty warnings list does not show warning banner

- **WHEN** the `warnings` list is empty
- **THEN** the warning banner is hidden entirely

#### Scenario: totalErrorCount is sum of countingDeviation for errors

- **WHEN** checksList contains entries with `ruleType == E` and countingDeviation values "3", "7", "2"
- **THEN** totalErrorCount SHALL equal 12

#### Scenario: Parsing failure for countingDeviation defaults to zero

- **WHEN** `countingDeviation` contains a non-numeric string
- **THEN** that entry contributes 0 to the sum and the system logs a warning