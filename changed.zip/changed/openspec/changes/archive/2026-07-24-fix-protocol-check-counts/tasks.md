## 1. DTO changes

- [x] 1.1 Add `ruleType` (RuleTypeEnum) field to `ProtocolCheckRecordDto`
- [x] 1.2 Add `totalErrorCount` and `totalWarningCount` (long) fields to `ProtocolModelDto`

## 2. Mapper update

- [x] 2.1 Update `VuxDocumentValidationLogEnityMapper` to map `ruleType` from `VuxDocumentValidationLogEntity` to `ProtocolCheckRecordDto`

## 3. Service logic

- [x] 3.1 In `OrchestratorService.createProtocolModelDto()`, calculate `totalErrorCount` and `totalWarningCount` from `checksList` after mapping, using safe numeric parsing with fallback to 0
- [x] 3.2 Apply same calculation in `OrchestratorService.createProtocolWithAdditionalErrorsModelDto()` (which also receives a `checks` list)

## 4. Template update

- [x] 4.1 Change error banner in `xbrl_protocol.ftl` from `Всего ошибок: ${objects?size}` to `Показано ${objects?size} из ${totalErrorCount}`
- [x] 4.2 Change warning banner in `xbrl_protocol.ftl` from `Всего предупреждений: ${warnings?size}` to `Показано ${warnings?size} из ${totalWarningCount}`

## 5. Tests

- [x] 5.1 Update `OutputFormingServiceIntegrationTest` — fix expected strings in banner assertions to match new format
- [x] 5.2 Add test in `OutputFormingServiceIntegrationTest` verifying banner shows `Показано N из M` format with known check list values
- [x] 5.3 Add unit test for safe numeric parsing (non-numeric countingDeviation falls back to 0)