## Context

В протоколе проверки HTML (FreeMarker-шаблон `xbrl_protocol.ftl`) отображаются два блока:

1. **«Найдены серьезные ошибки!»** — баннер с надписью `Всего ошибок: ${objects?size}`, где `objects` — список `ProtocolTableRecordDto` с `ruleType == E`, полученный из `getResultsForDocWithRnLimit()`. Этот запрос имеет `LIMIT totalSet` (по умолчанию 200) и фильтр `rn <= errorSet` (30). Таким образом, `objects?size` показывает **только то, что попало в лимит**, а не реальное общее количество.

2. **«Обнаружены предупреждения:»** — аналогичная проблема для `warnings`.

Одновременно в протоколе есть таблица **«Результат проверки»** с колонкой «Количество» (`countingDeviation`), которая берётся из `ProtocolCheckRecordDto`. Эти записи хранятся в таблице `s_grnplm_as_cib_gm_vux.v_vux_document_validation_log` и содержат `errorCount` — количество записей с данным кодом ошибки. Однако `ProtocolCheckRecordDto` **не содержит информацию о том, ошибка это или предупреждение**, поэтому агрегировать общее количество только ошибок или только предупреждений из checksList невозможно.

Требование: не делать дополнительных запросов в БД — считать только на основе данных, уже полученных от `getResultsForDocWithRnLimit()` и `vuxDocumentValidationLogRepository.findAllByDocIdOrderByErrorCountDesc()`.

## Goals / Non-Goals

**Goals:**
- Добавить в `ProtocolCheckRecordDto` поле `ruleType` (RuleTypeEnum) для дифференциации ошибок и предупреждений.
- Добавить в `ProtocolModelDto` поля `totalErrorCount` и `totalWarningCount` — суммарное количество ошибок и предупреждений на основе `checksList`.
- Изменить шаблон: выводить «Показано N из M» в блоках ошибок и предупреждений.
- Использовать только уже загруженные данные — **без дополнительных запросов в БД**.

**Non-Goals:**
- Изменение SQL-запросов к БД.
- Изменение пагинации или лимитов запросов.
- Изменение других шаблонов, кроме `xbrl_protocol.ftl`.
- Изменение логики подсчёта `countingDeviation` (значения берутся как есть).

## Decisions

### 1. Тип поля ruleType в ProtocolCheckRecordDto

**Решение:** Использовать `RuleTypeEnum` (существующий enum: `E` — Error, `W` — Warning).

**Обоснование:**
- Enum уже используется в `ProtocolTableRecordDto.ruleType`.
- MapStruct-маппер (`VuxDocumentValidationLogEnityMapper`) уже маппит `VuxDocumentValidationLogEntity` → `ProtocolCheckRecordDto`; нужно дополнить маппинг поля `ruleType`.
- Типобезопасность при сравнении в Java-коде: `ruleType == RuleTypeEnum.E`.

**Альтернатива:** Строковое поле `isError` (boolean) — проще, но неконсистентно с `ProtocolTableRecordDto`.

### 2. Расчёт totalErrorCount / totalWarningCount

**Решение:** В методе `OrchestratorService.createProtocolModelDto()` после маппинга `checksList` пройти по нему стримом:

```java
long totalErrorCount = listProtocolCheckRecordDto.stream()
    .filter(c -> c.getRuleType() == RuleTypeEnum.E)
    .mapToLong(c -> Long.parseLong(c.getCountingDeviation()))
    .sum();

long totalWarningCount = listProtocolCheckRecordDto.stream()
    .filter(c -> c.getRuleType() == RuleTypeEnum.W)
    .mapToLong(c -> Long.parseLong(c.getCountingDeviation()))
    .sum();
```

**Обоснование:**
- Нет дополнительных запросов в БД.
- `countingDeviation` хранит число как строку (исторически), поэтому парсинг.
- Если парсинг упадёт — `NumberFormatException` пробросится в вызывающий код; для надёжности можно завести статический хелпер-метод.

**Альтернатива:** Суммировать на стороне маппера — неоправданно усложняет маппер.

### 3. Вывод в шаблоне

**Решение:**
```
<#if objects?has_content>
    <div class="error-banner">
        Найдены серьезные ошибки!<br/>
        Показано ${objects?size} из ${totalErrorCount}
    </div>
</#if>

<#if warnings?has_content>
    <div class="warning-banner">
        Обнаружены предупреждения:<br/>
        Показано ${warnings?size} из ${totalWarningCount}
    </div>
</#if>
```

### 4. Маппинг ruleType в VuxDocumentValidationLogEnityMapper

**Решение:** В `VuxDocumentValidationLogEntity` уже есть поле `ruleType`. MapStruct-маппер нужно дополнить:

```java
@Mapping(source = "ruleType", target = "ruleType")
```

(а можно и не явно — если имена полей совпадают, MapStruct подхватит автоматически)

## Risks / Trade-offs

- **`NumberFormatException` при парсинге `countingDeviation`**: поле исторически `String`, может содержать некорректные данные. → Добавить `try/catch` с `log.warn` и `0` по умолчанию.
- **Новые поля в DTO могут затронуть сериализацию в JSON/XML**: `totalErrorCount` и `totalWarningCount` появятся в JSON-представлении `ProtocolModelDto`. Сейчас JSON не используется для этого DTO (только FreeMarker), риск минимален.
- **Консистентность данных**: `countingDeviation` в `checksList` может не совпадать с реальным количеством записей в БД — это legacy-данные, мы их не меняем.