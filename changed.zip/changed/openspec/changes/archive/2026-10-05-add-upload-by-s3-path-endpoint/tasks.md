## 1. Скачивание файла из S3

- [x] 1.1 Добавить в `EcmS3Service` метод скачивания файла из S3 (`downloadFileFromS3(String s3Path)`), возвращающий `byte[]`, с обработкой ошибок через `EcmException`/`ErrorCode` по паттерну существующего `uploadFileToS3`
- [x] 1.2 Проверить доступность S3-клиента и свойств (`IntegrationEcmTfsProps.s3()`) для корректного формирования `GetObjectRequest` (бакет, ключ/путь от `s3Path`)

## 2. Вызов процедур очереди ECM (репозиторий)

- [x] 2.1 Добавить в JPA-репозиторий методы вызова хранимых процедур через `@NativeQuery` (по паттерну `flowSetEcmId`):
  - `fn_ecm_request_create(p_request_id, p_subsystem, p_subsystem_id)`
  - `fn_ecm_request_set_ecm_id(p_request_id, p_ecm_id, p_ecm_date)`
  - `fn_ecm_request_set_error(p_request_id, p_error_text)`
- [x] 2.2 Добавить запрос проверки наличия/статуса `rqUid` в `v_vux_ecm_queue` (метод, возвращающий признак наличия записи)
- [x] 2.3 Уточнить фактическую сигнатуру процедур и структуру view `v_vux_ecm_queue` (схема вне сервиса) и при необходимости скорректировать SQL-запросы

## 3. Метод загрузки документа по `s3Path` в `UploadDocumentService`

- [x] 3.1 Добавить метод (перегрузку) загрузки документа по `s3Path`, принимающий параметры `s3Path`, `filename`, `documentType`, `sliceId` и возвращающий `rqUid`
- [x] 3.2 Внутри метода: скачать файл из S3 через `EcmS3Service.downloadFileFromS3` и переиспользовать логику существующего `uploadDocumentViaTfs` (подпись при необходимости, MD5, MIME, формирование TFS-запроса, отправка в Kafka-топик) на основе полученных байт
- [x] 3.3 Зарегистрировать запрос в очереди ECM до скачивания файла из S3 и отправки TFS-запроса: вызвать `fn_ecm_request_create(p_request_id=rqUid, p_subsystem='xbrl-csv', p_subsystem_id=sliceId)`, чтобы запись существовала на любом пути (обработка квитанции или фиксация ошибки через `fn_ecm_request_set_error`)
- [x] 3.4 При ошибке сохранения вызвать `fn_ecm_request_set_error(p_request_id=rqUid, p_error_text=<текст ошибки>)`
- [x] 3.5 Вернуть сформированный `rqUid` наружу (в контроллер)

## 4. REST-контроллер и DTO

- [x] 4.1 Создать пакет `controller` и REST-контроллер с эндпоинтом `POST`, принимающим параметры `s3Path`, `filename`, `documentType`, `sliceId`
- [x] 4.2 Создать DTO запроса (поля `s3Path`, `filename`, `documentType`, `sliceId`); тело ответа — «голый» `rqUid` (UUID) без обёрточного DTO: вызывающий контур читает uuid напрямую из тела ответа
- [x] 4.3 Реализовать конвертацию `documentType` (строка → `DocumentTypeEnum`) с валидацией и обработкой некорректного значения
- [x] 4.4 Прокинуть вызов нового метода сервиса в контроллер; при необходимости согласовать и использовать существующую обработку ошибок (`@ControllerAdvice`, RFC 7807)

## 5. Обработка квитанции в `TfsResponseListener`

- [x] 5.1 В `processResponse`(или соответствующем месте обработки квитанции) добавить проверку `v_vux_ecm_queue` по полученному `rqUid`
- [x] 5.2 Если `rqUid` отсутствует в очереди — обработать квитанцию по легаси-байтовому сценарию (`extractAttrIntBusinessAttribute`/`flowSetEcmId`), не прекращая обработку (существующие байтовые загрузки в очереди не регистрируются)
- [x] 5.3 Если в квитанции вернулась ошибка — вызвать `fn_ecm_request_set_error(p_request_id=rqUid, p_error_text=<текст ошибки>)`
- [x] 5.4 При успешной загрузке — вызвать `fn_ecm_request_set_ecm_id(p_request_id=rqUid, p_ecm_id=<ecmId>, p_ecm_date=<по умолчанию current_timestamp>)`
- [x] 5.5 Сохранить существующую обработку байтового сценария (`extractAttrIntBusinessAttribute`/`flowSetEcmId`), не ломая обратную совместимость

## 6. Тестирование

- [x] 6.1 Написать unit-тест `EcmS3Service.downloadFileFromS3` (успех, ошибка S3)
- [x] 6.2 Написать unit-тест нового метода загрузки в `UploadDocumentService` (скачивание из S3, вызов `fn_ecm_request_create`, вызов `fn_ecm_request_set_error` при ошибке, возврат `rqUid`)
- [x] 6.3 Написать тест контроллера (`@WebMvcTest`, MockMvc): успешный вызов, некорректный `documentType`
- [x] 6.4 Дополнить/написать тест `TfsResponseListener` для веток: `rqUid` отсутствует в очереди, успех (`fn_ecm_request_set_ecm_id`), ошибка квитанции (`fn_ecm_request_set_error`)
- [x] 6.5 Запустить сборку (`mvn clean install -DskipTests`) и тесты (`mvn test`)