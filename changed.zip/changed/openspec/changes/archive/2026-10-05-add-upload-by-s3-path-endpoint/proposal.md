## Why

Внешний контур (контур обработки XBRL-CSV) должен сохранять документы в ECM, не передавая в поток загрузки тело файла (массив байт), а только ссылку на уже загруженный в S3 объект. Текущий способ загрузки (`uploadDocumentViaTfs`) требует передачу байт, что не подходит для данного сценария. Дополнительно требуется регистрировать запрос в очереди ECM (`v_vux_ecm_queue`) и обрабатывать квитанции по возвращаемому `rqUid`.

## What Changes

- Добавить REST-эндпоинт, принимающий входные параметры: `s3Path` (String), `filename` (String), `documentType` (`DocumentTypeEnum`), `sliceId` (String) и возвращающий сформированный `rqUid`.
- Загрузка документа в ECM выполняется через `UploadDocumentService`/метод, аналогичный `uploadDocumentViaTfs`, с тем отличием, что вместо массива байт передаётся ссылка на объект в S3 (`s3Path`). Файл скачивается из S3, дальнейший поток (вычисление контрольной суммы MD5, определение MIME, при необходимости подпись через АС ОКЭЙ, формирование и отправка TFS-запроса в Kafka-топик) выполняется по существующей логике.
- Зарегистрировать запрос в очереди ECM до скачивания файла из S3 и формирования/отправки TFS-запроса — вызвать процедуру `fn_ecm_request_create(p_request_id, p_subsystem, p_subsystem_id)`, чтобы запись существовала на любом пути (для обработки квитанции и фиксации ошибки):
  - `p_request_id` = сформированный `rqUid` запроса в ЕСМ
  - `p_subsystem` = `xbrl-csv` (всегда это значение)
  - `p_subsystem_id` = `sliceId`
- При ошибке сохранения вызвать процедуру `fn_ecm_request_set_error(p_request_id, p_error_text)` (`p_request_id` = `rqUid`, `p_error_text` = текст ошибки).
- Дополнить обработку квитанции (ответа ECM) в существующем `TfsResponseListener`:
  - полученный `rqUid` проверяется на наличие в `v_vux_ecm_queue`;
  - если такого `rqUid` нет — квитанция обрабатывается по легаси-байтовому сценарию (`fn_flow_set_ecm_id`), так как существующие байтовые загрузки в очереди не регистрируются;
  - если он есть — вызывается процедура `fn_ecm_request_set_ecm_id(p_request_id, p_ecm_id, p_ecm_date)` (`p_request_id` = `rqUid`, `p_ecm_id` = присвоенный ЕСМ-ом uuid);
  - если в квитанции вернулась ошибка — вызвать `fn_ecm_request_set_error(p_request_id, p_error_text)`.

## Capabilities

### New Capabilities

- `upload-document-by-s3-path`: Возможность загрузки документа в ECM по ссылке на объект в S3 через новый REST-эндпоинт, с регистрацией запроса в очереди ECM и обработкой ответной квитанции.

### Modified Capabilities

*(нет изменений требований на уровне существующих specs — новых spec-файлов в `openspec/specs/` нет, поэтому изменяемые capabilities не выделяются)*

## Impact

- `controller` (новый пакет) — новый REST-контроллер и DTO запроса/ответа
- `UploadDocumentService` — новый метод/перегрузка для загрузки по `s3Path` (скачивание из S3 + существующий TFS-поток)
- `EcmS3Service` — добавление метода скачивания файла из S3 (сейчас есть только `uploadFileToS3`)
- `EcmRqResolverService` — при необходимости адаптация формирования TFS-запроса при загрузке по S3 (контрольная сумма, MIME вычисляются по скачанным байтам)
- `TfsResponseListener` — добавление проверки `v_vux_ecm_queue` и вызова процедур `fn_ecm_request_set_ecm_id` / `fn_ecm_request_set_error`
- `repository` — добавление методов вызова процедур `fn_ecm_request_create`, `fn_ecm_request_set_ecm_id`, `fn_ecm_request_set_error` (по паттерну существующих `@NativeQuery` в репозиториях) и запросов к `v_vux_ecm_queue`
- Тесты (JUnit 5 + Mockito)