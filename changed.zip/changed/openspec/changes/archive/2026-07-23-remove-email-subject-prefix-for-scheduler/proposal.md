## Why

Письма-уведомления о начале подготовки документации, отправляемые через `EmailSchedulerService`, содержат префикс темы "Stand: PROD. gmap2-vux-ecm: ", который не требуется для данного типа писем. Требуется убрать этот префикс исключительно для этих уведомлений, сохранив его во всех остальных типах email-рассылок (например, при валидации отчётности через `OrchestratorService`).

## What Changes

- Добавить в `MailService` перегруженный метод `sendMail` с параметром, управляющим добавлением префикса "Stand: ..." к теме письма
- В `EmailSchedulerService` вызывать sendMail без префикса (передавать флаг `false`)
- Во всех остальных местах вызова `sendMail` поведение не меняется (префикс добавляется по умолчанию)

## Capabilities

### New Capabilities

- `email-subject-without-stand-prefix`: Возможность отправлять email без стандартного префикса "Stand: <stand>.<app>: " в теме письма

### Modified Capabilities

*(нет изменений требований на уровне specs — только реализация)*

## Impact

- `MailService.java` — добавление нового метода (обратно совместимо)
- `EmailSchedulerService.java` — изменение вызова `mailService.sendMail()`
- Другие сервисы, вызывающие `mailService.sendMail()` — без изменений