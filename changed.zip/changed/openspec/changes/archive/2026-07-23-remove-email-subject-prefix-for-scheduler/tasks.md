## 1. MailService — Добавить перегруженный метод с флагом `addPrefix`

- [x] 1.1 Добавить метод-перегрузку `sendMail(subject, htmlBody, recipients, cc, boolean addPrefix)` в `MailService.java`:
  - Если `addPrefix == true` → формировать `fullSubject` с префиксом (как сейчас)
  - Если `addPrefix == false` → использовать `subject` как есть
- [x] 1.2 Существующий метод `sendMail(subject, htmlBody, recipients, cc)` должен делегировать новому с `addPrefix = true` (обратная совместимость)

## 2. EmailSchedulerService — Отправлять письма без префикса

- [x] 2.1 В `EmailSchedulerService.processRecord()` изменить вызов `mailService.sendMail()`:
  - Передать `addPrefix = false` для писем-уведомлений о начале подготовки документации

## 3. Тестирование

- [x] 3.1 Написать/дополнить unit-тест для `MailService`:
  - Проверить, что при `addPrefix = false` тема не содержит префикс
  - Проверить, что при `addPrefix = true` (или старом методе) префикс присутствует
- [x] 3.2 Проверить, что все другие вызовы `MailService.sendMail()` в проекте не изменились (префикс остаётся)