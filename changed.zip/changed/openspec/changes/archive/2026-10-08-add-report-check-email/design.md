# Design: add-report-check-email (VUXPCAP-1448)

## Context

Сейчас рассылка информационных писем реализована одним типом (о начале подготовки, шаблон `mail_reminder.ftl`):

- `EmailSchedulerService` по cron (`config.mail-sheduled-sender.cron`, feature-toggle `config.feature-toggles.scheduled-email`) выбирает записи запросом `findRecordsUpToNow(now, now-7дн.)` **из базовой таблицы** `t_vux_info_email_shedule` (условия `send_time <= now`, `send_time >= now-7дн`, `mail_time IS NULL` дублируются в JPQL);
- поле `info_email_type` в entity отсутствует — сервису всё равно, какой тип письма лежит в записи;
- после отправки фиксируется факт через хранимую процедуру `fn_flow_info_email_send(id)` (`VuxDocumentValidationResultViewRepository`);
- получатели To/Cc парсятся из `receivers_list`/`copy_list` (разделители `,`/`;`).

Постановка VUXPCAP-1448 добавляет письмо «о проверке готовности» (`info_email_type = 0`, свой шаблон, срок отправки 10:00 за 2 дня до `deadline_date`) и требует перевести весь процесс на витрину `v_vux_info_email_shedule`, которая сама содержит условия «не обработано» (`e.mail_time IS NULL`) и «созрело» (`now() >= s.send_time`).

Ограничения: текст письма «хардкодом» (решение VUXPCAP-774, вариант 2); тип письма оперировать только через Enum; прод-объекты (`v_vux_info_email_shedule`, `fn_flow_info_email_send`) уже существуют в БД — миграции прод-схемы не требуются.

## Goals / Non-Goals

**Goals:**
- Отправка письма «о проверке» (`info_email_type = 0`): тема `Напоминание о проверке готовности отчетных форм ВУИКС: {reporting_type} за {report_dt}`, тело со статическими блоками-чеклистами и контактами, параметры из витрины.
- Единый механизм выборки обоих типов из витрины `v_vux_info_email_shedule`; устранение дублей условий «не отправлено»/«созрело» из Java-кода.
- Тип письма везде выражен Enum `InfoEmailTypeEnum` (`0` — проверка, `1` — начало подготовки), без магических чисел.
- Сохранение поведения типа 1: та же тема, тот же шаблон `mail_reminder.ftl`, те же адресаты и фиксация отправки.

**Non-Goals:**
- Настраиваемый конструктор писем (вариант 1 из §6 постановки) — отклонён заказчиком.
- Расчёт `send_time` сервисом: правило «10:00:00 за 2 дня до deadline_date» выполняется на стороне данных (расписание Excel → `t_vux_info_email_shedule`), витрина лишь отбирает созревшие записи. Для типа 1 то же самое (правило «10:00, первый рабочий день / день сдачи» уже лежит в данных).
- Изменения `MailService`, feature-toggle, cron, процедуры `fn_flow_info_email_send`.
- Миграции прод-схемы БД.

## Decisions

### D1. Источник записей — витрина, entity маппится на неё
`@Table(name = "v_vux_info_email_shedule")` + `@Immutable` (entity `EmailInfoScheduleEntity`). Поле `mail_time` удаляется — его нет в витрине.

*Альтернативы:* продолжать читать `t_vux_info_email_shedule` и повторять условия витрины в JPQL — отклонено (дублирование фильтров в двух местах, прямое требование постановки перейти на view); нативные запросы — не нужны, Spring Data JPA умеет маппить read-only view (приоритет проекта: Query Methods → JPQL → Native SQL).

### D2. Enum `InfoEmailTypeEnum` + AttributeConverter
`ru.sbrf.gmap.vux.entity.enums.InfoEmailTypeEnum`:
- `VERIFICATION(0)` — письмо о проверке готовности отчётности;
- `PREPARATION(1)` — письмо о начале подготовки отчётности.

Конвертер `InfoEmailTypeConverter implements AttributeConverter<InfoEmailTypeEnum, Integer>` по образцу существующего `DocumentTypeEnumConverter`, вешается явно (`@Convert` на поле, `autoApply = false`). Значения 0/1 фиксированы постановкой. Неизвестное значение кода конвертер трактовает как null (в отличие от `DocumentTypeEnumConverter`, который бросает исключение) — пропуск «мусорной» записи решается на уровне сервиса с `log.warn`.

*Альтернатива:* `@Enumerated(EnumType.ORDINAL)` — отклонено (ordinal завязан на порядок констант, неявная семантика; постановка требует явный Enum).

### D3. Репозиторий — Spring Data Query Method
```java
List<EmailInfoScheduleEntity> findByInfoEmailTypeAndSendTimeGreaterThanEqualOrderByIdAsc(
        InfoEmailTypeEnum type, LocalDateTime sendTimeFrom);
```
Условия созревания (`now() >= send_time`) и необработанности (`mail_time IS NULL`) в запрос не добавляются — их обеспечивает витрина (постановка, §4: «дополнительной проверки … проводить не надо»). Окно давности см. D8. Сортировка по `id` — детерминированный порядок обработки.

`findRecordsUpToNow(...)` удаляется вместе со старым JPQL.

### D4. Маршрутизация по типу в сервисе
`run()` обрабатывает оба типа независимо: `processRecord(record)` диспетчеризует по `record.getInfoEmailType()`:

| | `VERIFICATION` (0) | `PREPARATION` (1) |
|---|---|---|
| Тема | `Напоминание о проверке готовности отчетных форм ВУИКС: %s за %s` | `Напоминание о подготовке отчетных форм ВУИКС: %s за %s` (без изменений) |
| Шаблон | `templates/mail_check_reminder.ftl` (новый) | `templates/mail_reminder.ftl` (без изменений) |
| Параметры | `reportingType`, `reportDt` (текст как есть), `deadlineDate` (dd.MM.yyyy), `forms` (список строк) | как сейчас: `reportingType`, `reportDt`, `startDate`, `deadlineDate`, `taxonomy`, `converterVersion` |
| Отправка | `mailService.sendMail(subject, body, to, cc, false)` + `fnFlowInfoEmalSend(id)` | без изменений |

Оба шаблона загружаются один раз в `@PostConstruct` в `Map<InfoEmailTypeEnum, Template>` (fail-fast при отсутствии ресурса). Ошибки изолируются по записи (текущее поведение: catch на каждую запись, цикл не прерывается).

Неизвестное/NULL значение `info_email_type`: запись пропускается с `log.warn` — не валим шедулер на «мусорной» строке витрины.

### D5. Новый шаблон `mail_check_reminder.ftl`
Структура (HTML-письмо, стиль и CSS-подход — как в `mail_reminder.ftl`):
1. «Добрый день!»;
2. Напоминание о завершении этапа подготовки со сроком **{deadline_date}** и необходимости проверки пакетов в рамках **{reporting_type}** отчётности за **{report_dt}** в соответствии с СОП;
3. Таблица форм `{forms}` — каждая форма отдельной строкой таблицы (решение открытого вопроса №3: строка `forms` разбивается по `,`/`;`, элементы триммуются);
4. Чек-лист 1-й руки (7 пунктов, статические) + путь `\\Inter232.sigma.sbrf.ru\vol3\Diasoft-Clearing-XBRL\Final\Методология\Материалы для подготовки отчетности\Чек-лист для подготовки отчет`;
5. Чек-лист 2-й руки (6 пунктов, статические) + путь `...\Чек-лист второй руки`, раскрытый до полного пути той же папки (см. Open Questions);
6. Контакты: Кожевникова Екатерина (EALukicheva@sberbank.ru), Ширнин Степан (SSeShirnin@sberbank.ru).

Формат дат (открытый вопрос №2): `deadlineDate` → `dd.MM.yyyy` (переиспользуется `DATE_FORMATTER`), `reportDt` → вставляется текстом как есть («май 2026 г.»).

### D6. Тестовая схема Liquibase (append-only)
Тестовый ченджсет содержит только `t_vux_info_email_shedule` — витрину и таблицу отправок надо добавить. Новые changesets в `service/src/test/resources/db/changelog/1.00/`:
- `t_vux_info_email_shedule-add-info-email-type.xml` — `addColumn info_email_type SMALLINT` (default `1`);
- `t_vux_info_email_sent-create.xml` — `t_vux_info_email_sent` (`id BIGINT PK`, `mail_time TIMESTAMP`) по DDL, который подразумевает витрина;
- `v_vux_info_email_shedule-create.xml` — `createView` c SQL из постановки (§4);
- включение трёх файлов в `cummulative_changeset.xml`.

Существующие changesets не редактируются (append-only).

### D7. Тесты
- Новый unit-тест `EmailSchedulerServiceTest` (JUnit 5 + Mockito, без Spring-контекста, по образцу `MailServiceTest`):
  - маршрутизация: запись типа 0 → тема «о проверке…», тело содержит чеклисты, deadline в формате dd.MM.yyyy, каждую форму отдельной строкой; тип 1 → прежняя тема/параметры;
  - пустая выборка → ни отправки, ни вызова `fnFlowInfoEmalSend`;
  - `fnFlowInfoEmalSend(id)` вызывается после успешной `sendMail` с идентификатором записи;
  - записи с неизвестным типом пропускаются (warn, без отправки);
  - ошибка одной записи не останавливает обработку остальных;
  - окно давности: в репозиторий передаётся порог `now - max-past-days`, глубина окна читается из конфига.
- `InfoEmailTypeConverterTest`: код ↔ Enum, неизвестный код → null без исключения.
- `EmailSchedulerServiceIntegrationTest` обновляется под новый API репозитория — флаг `@Disabled` сохраняется.

### D8. Окно давности записей (config.mail-sheduled-sender.max-past-days)
Витрина возвращает **все** неотправленные созревшие записи без ограничения по возрасту. Чтобы зависшие письма прошлых периодов не уходили «залпом», выборка ограничивается окном: записи с `send_time < now - N дней` не обрабатываются.

- Параметр: `config.mail-sheduled-sender.max-past-days`, значение по умолчанию — **7** (`application.yml` + `@DefaultValue("7")` в props).
- Props-класс `config/MailSheduledSenderProps` (record + `@ConfigurationProperties`) по образцу `MailProps`, регистрируется в `@EnableConfigurationProperties` (`VuxApplication`).
- Фильтрация выполняется в запросе к витрине (`sendTimeFrom = now.minusDays(N)`, условие `send_time >= sendTimeFrom`), а не в Java-цикле: срезаем на уровне БД.
- Отличие от старого кода: раньше окно вычислялось в JPQL вместе с дублями условий витрины; теперь условия витрины убраны, а окно оставлено как самостоятельная защита (см. Risks).

*Альтернативы:* фильтровать в сервисе после выборки — отклонено (лишние строки из БД); убирать окно совсем, полагаясь только на операционную проверку стенда — отклонено (защита должна работать и в проде без ручных процедур).

## Risks / Trade-offs

- [Перезапуск старых писем при переходе на витрину] Витрина возвращает все неотправленные записи с `now() >= send_time` без ограничения по возрасту: зависшие в расписании письма прошлых периодов ушли бы разовым залпом после деплоя. → Кодовое окно давности `config.mail-sheduled-sender.max-past-days` (D8, default 7): записи со `send_time` глубже окна не выбираются вовсе; операционная проверка «хвостов» перед включением toggle остаётся дополнительной мерой.
- [Разрыв между sendMail и fn_flow_info_email_send] Падение процесса между отправкой и фиксацией приведёт к повторной отправке на следующем цикле. → Порядок операций сохранён как в текущем коде (fn сразу после sendMail); окно минимально; `MailService` проглатывает ошибки отправки, так что фактически фиксация почти всегда следует за попыткой отправки.
- [DDL витрины в постановке противоречит открытому вопросу №2] §4 задаёт `report_dt DATE`, а открытый вопрос №2 говорит, что `report_dt` — текст («май 2026 г.»), иначе текущее письмо типа 1 не могло бы рендерить месяц словом. → Entity оставляет `String reportDt` и `LocalDateTime deadlineDate` как в работающем коде; тестовая схема остаётся `VARCHAR`/`TIMESTAMP`. Перед приёмкой сверить фактические типы колонок витрины (см. Open Questions).
- [Объекты БД отсутствуют в среде] Если в целевой схеме нет `v_vux_info_email_shedule`/`fn_flow_info_email_send`, шедулер будет логировать ошибку каждый цикл. → Объекты созданы постановщиком (DDL в документе); ошибки изолированы per-record/cycle, сервис не падает.

## Migration Plan

1. Деплой сервиса на стенд при **выключенном** toggle `config.feature-toggles.scheduled-email` (или холодный старт без последствий — шедулер просто ничего не найдёт).
2. Операционная проверка витрины: отсутствие зависших неотправленных записей прошлых периодов (риск «залпа»).
3. Включение toggle; контроль первого цикла в логах (`Found N record(s) to process`).
4. Rollback: выключить toggle; откат на предыдущую версию сервиса безопасен — базовая таблица `t_vux_info_email_shedule` не менялась, прод-объекты БД не изменяются.

## Open Questions

- **Часовой пояс** `send_time` (открытый вопрос №4 постановки): сравнение выполняется СУБД (`now()` в витрине); для ECM-очереди ранее зафиксировано московское время — считать расписание в МСК на стороне данных, в код ничего не выносим.
- **Путь чек-листа 2-й руки**: в постановке усечён (`...\Чек-лист второй руки`); в шаблоне раскрываем до полного пути той же папки, что и у чек-листа 1-й руки — подтвердить у аналитиков (VUXPCAP-1414).
- **Фактический тип `report_dt`** в витрине: строка или `DATE` — влияет только на формат отображения; принять перед приёмкой (см. Risks).
