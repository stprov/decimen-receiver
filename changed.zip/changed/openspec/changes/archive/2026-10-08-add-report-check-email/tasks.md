# Tasks: add-report-check-email (VUXPCAP-1448)

## 1. Доменная модель: тип письма

- [x] 1.1 Создать `entity/enums/InfoEmailTypeEnum`: `VERIFICATION(0)` — письмо о проверке, `PREPARATION(1)` — письмо о начале подготовки; int-код в постановке фиксирован (0/1); javadoc со ссылкой на VUXPCAP-1448
- [x] 1.2 Создать `entity/converter/InfoEmailTypeConverter implements AttributeConverter<InfoEmailTypeEnum, Integer>` по образцу `DocumentTypeEnumConverter`; в конвертере `convertToEntityAttribute` неизвестное значение трактовать как NULL (не бросать исключение — пропуск записи решается на уровне сервиса)

## 2. Сущность и репозиторий (переход на витрину)

- [x] 2.1 В `EmailInfoScheduleEntity`: `@Table(name = "v_vux_info_email_shedule")` (оставить `@Immutable`, `@Data`); добавить поле `infoEmailType` с `@Convert(converter = InfoEmailTypeConverter.class)`; удалить поле `mailTime` (в витрине отсутствует); javadoc заменить упоминание таблицы на витрину
- [x] 2.2 В `EmailInfoScheduleRepository`: добавить `List<EmailInfoScheduleEntity> findByInfoEmailTypeOrderByIdAsc(InfoEmailTypeEnum type)` (Spring Data Query Method, без условий по `send_time`/`mail_time` — их обеспечивает витрина); удалить `findRecordsUpToNow(...)`

## 3. Шаблон письма о проверке

- [x] 3.1 Создать `service/src/main/resources/templates/mail_check_reminder.ftl` по design.md §D5: обращение; напоминание с `{deadlineDate}` (dd.MM.yyyy), `{reportingType}`, `{reportDt}`; таблица форм из списка `forms` (каждая форма — отдельной строкой `<tr>`); чек-лист «1-я рука» (7 пунктов) с путём `\\Inter232.sigma.sbrf.ru\vol3\Diasoft-Clearing-XBRL\Final\Методология\Материалы для подготовки отчетности\Чек-лист для подготовки отчет`; чек-лист «2-я рука» (6 пунктов) с полным путём той же папки; контакты Кожевникова Екатерина / Ширнин Степан; CSS-подход — как в `mail_reminder.ftl`

## 4. Сервис рассылки

- [x] 4.1 В `EmailSchedulerService`: в `@PostConstruct` загрузить оба шаблона (`mail_reminder.ftl`, `mail_check_reminder.ftl`) в `Map<InfoEmailTypeEnum, Template>` (fail-fast при отсутствии ресурса)
- [x] 4.2 Переработать `run()`: выборка записей через `findByInfoEmailTypeOrderByIdAsc(VERIFICATION)` и `findByInfoEmailTypeOrderByIdAsc(PREPARATION)`; удалить константу `DAYS_DEPTH`; общее логирование цикла сохранить (сообщения на английском)
- [x] 4.3 Переработать `processRecord(record)`: диспетчеризация по `record.getInfoEmailType()`; тема — по типу (`Напоминание о проверке готовности отчетных форм ВУИКС: %s за %s` / прежняя для `PREPARATION`); параметры шаблона — по типу (для `VERIFICATION`: `reportingType`, `reportDt` как есть, `deadlineDate` dd.MM.yyyy, `forms` списком строк с разбором по `,`/`;`); при NULL/неизвестном типе — `log.warn` и пропуск записи; отправка `mailService.sendMail(subject, html, to, cc, false)` + `fnFlowInfoEmalSend(id)` после успешной отправки; изоляция ошибок по записи сохраняется

## 5. Тестовая схема БД (Liquibase, append-only)

- [x] 5.1 Создать `service/src/test/resources/db/changelog/1.00/t_vux_info_email_shedule-add-info-email-type.xml`: changeset `addColumn info_email_type SMALLINT` (defaultValueNumeric `1`) к `S_GRNPLM_AS_CIB_GM_VUX.t_vux_info_email_shedule`
- [x] 5.2 Создать `t_vux_info_email_sent-create.xml`: таблица `S_GRNPLM_AS_CIB_GM_VUX.t_vux_info_email_sent` (`id BIGINT PK`, `mail_time TIMESTAMP`)
- [x] 5.3 Создать `v_vux_info_email_shedule-create.xml`: `createView` по SQL из постановки (`docs/notification-service/notification-xbrl.md` §4: LEFT JOIN `t_vux_info_email_sent`, условия `e.mail_time IS NULL AND now() >= s.send_time`)
- [x] 5.4 Включить три новых changeset-файла в `cummulative_changeset.xml` (существующие include-строки не менять)

## 6. Тесты

- [x] 6.1 Создать unit-тест `service/src/test/java/ru/sbrf/gmap/vux/service/EmailSchedulerServiceTest.java` (JUnit 5 + Mockito, без Spring-контекста): маршрутизация типов (тема/тело/шаблон по спеке); `forms` → отдельные строки; формат deadline `dd.MM.yyyy`; To/Cc парсятся из `receivers_list`/`copy_list`; фиксация `fnFlowInfoEmalSend(id)` после отправки; пустая выборка — без отправок и вызовов процедуры; NULL/неизвестный тип пропускается с warn; ошибка одной записи не останавливает остальные
- [x] 6.2 Обновить `EmailSchedulerServiceIntegrationTest`: моки перевести на `findByInfoEmailTypeOrderByIdAsc`, данные в фикстурах дополнить `infoEmailType`; флаг `@Disabled` сохранить

## 7. Верификация

- [x] 7.1 Собрать проект: `mvn clean install -DskipTests`
- [x] 7.2 Прогнать тесты: `mvn test` (включая новый `EmailSchedulerServiceTest`) — все зелёные
- [x] 7.3 Сверить реализацию со спекой `specs/scheduled-info-emails/spec.md` (все сценарии покрыты тестами или код-ревью) и подготовить итоги для задач VUXPCAP-1448 / связанной VUXPCAP-1414

## 8. Окно давности send_time (защита от «залпа» старыми письмами)

- [x] 8.1 Создать `config/MailSheduledSenderProps` (record + `@ConfigurationProperties(prefix = "config.mail-sheduled-sender")`, поле `maxPastDays` с `@DefaultValue("7")`), зарегистрировать в `@EnableConfigurationProperties` (`VuxApplication`)
- [x] 8.2 Вынести параметр в `application.yml`: `config.mail-sheduled-sender.max-past-days: 7` (с комментарием о семантике)
- [x] 8.3 Репозиторий: метод `findByInfoEmailTypeOrderByIdAsc` заменить на `findByInfoEmailTypeAndSendTimeGreaterThanEqualOrderByIdAsc(type, sendTimeFrom)` — окно давности на уровне запроса; условия витрины не дублировать
- [x] 8.4 Сервис: в `run()` рассчитывать порог `now.minusDays(maxPastDays)` из props и передавать в выборку обоих типов
- [x] 8.5 Тесты: стабы на новую сигнатуру; новые проверки — порог `now - maxPastDays` уходит в репозиторий (default 7) и настраиваемое значение (3 дня); прогон `mvn test`
- [x] 8.6 Синхронизировать артефакты: spec (ADDED «Окно давности» + MODIFIED «Выборка писем»), design (D3, D8, Risks), проверка `openspec validate`
