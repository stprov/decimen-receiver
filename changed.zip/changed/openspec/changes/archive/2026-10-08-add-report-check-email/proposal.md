# Proposal: add-report-check-email (VUXPCAP-1448)

## Why

Нужно новое информационное письмо — «Напоминание о проверке готовности отчётных форм ВУИКС» перед сдачей отчётности в Банк России (тип `info_email_type = 0` в расписании рассылок). Аналог существующего письма о начале подготовки (`info_email_type = 1`), но со своим шаблоном и правилом срока отправки (10:00:00, за 2 дня до `deadline_date`).

Дополнительно постановка требует перевести уже работающий процесс рассылки (тип 1) с чтения базовой таблицы `t_vux_info_email_shedule` на витрину `v_vux_info_email_shedule`, которая сама отбрасывает обработанные (`mail_time IS NULL`) и ещё не созревшие (`now() >= send_time`) записи.

## What Changes

- Добавлен тип письма «о проверке» (`info_email_type = 0`):
  - тема: `Напоминание о проверке готовности отчетных форм ВУИКС: {reporting_type} за {report_dt}`;
  - тело — статический текст с плейсхолдерами `{deadline_date}`, `{reporting_type}`, `{report_dt}`, `{forms}` + статические блоки-чеклисты «1-я рука» (7 пунктов) и «2-я рука» (6 пунктов) + контакты (Кожевникова Екатерина, Ширнин Степан);
  - список адресов To/Cc — из `receivers_list` / `copy_list` записи, как для типа 1.
- Заведён Enum типа информационного письма (`0` — проверка, `1` — начало подготовки); в коде тип оперируется только значениями Enum, без «магических чисел».
- **BREAKING (внутреннее поведение):** `EmailSchedulerService` читает записи из витрины `v_vux_info_email_shedule` вместо таблицы `t_vux_info_email_shedule`. Ручные условия «не отправлено» и «send_time <= now» из Java-запроса убираются — их обеспечивает сама витрина; окно «глубиной 7 дней» упраздняется.
- Сущность расписания маппится на витрину и дополняется полем `info_email_type`.
- Выбор записей разбивается по типу письма: каждый тип обрабатывается своим шаблоном (FreeMarker):
  - тип 1 — текущий шаблон `mail_reminder.ftl`, логика отправки сохраняется;
  - тип 0 — новый шаблон `mail_check_reminder.ftl` (текст «хардкодом» в шаблоне, параметры из витрины).
- После успешной отправки факт фиксируется вызовом хранимой процедуры `fn_flow_info_email_send(id)` — как в текущем процессе.

## Capabilities

### New Capabilities
- `scheduled-info-emails`: шедулерная рассылка информационных писем по расписанию из витрины `v_vux_info_email_shedule` — маршрутизация по `info_email_type` (0 = письмо о проверке, 1 = письмо о начале подготовки), формирование темы/тела по шаблону типа письма, разовая доставка (без повторной отправки обработанных записей).

### Modified Capabilities
- *(нет — спека на рассылку создаётся впервые; изменение источника данных (таблица → витрина) входит в новую capability)*

## Impact

- **Код (`service`):**
  - `service/EmailSchedulerService` — выборка по типам через витрину, маршрутизация шаблонов;
  - `entity/EmailInfoScheduleEntity` — `@Table` → витрина `v_vux_info_email_shedule`, поле `info_email_type` (конвертер Enum↔smallint по образцу `DocumentTypeEnumConverter`), поле `mail_time` у витрины отсутствует — удалить;
  - `repository/EmailInfoScheduleRepository` — запрос к витрине по типу письма;
  - новый `entity/enums/InfoEmailTypeEnum`;
  - новые ресурсы: `templates/mail_check_reminder.ftl`.
- **БД:** производственные объекты `v_vux_info_email_shedule` и `fn_flow_info_email_send` существуют (DDL в постановке/TFS), миграции не требуются; обновляются тестовые Liquibase-changesets (`service/src/test/resources/db/changelog/1.00/`) — витрина должна экспонировать `info_email_type`.
- **Конфигурация:** без изменений (feature-toggle `config.feature-toggles.scheduled-email`, cron `config.mail-sheduled-sender.cron` — как раньше).
- **Открытые вопросы постановки закрыты решениями в design.md** (формат дат, вывод нескольких форм, часовой пояс, адресаты).

## Источники

- Постановка: `docs/notification-service/notification-xbrl.md` (VUXPCAP-1448).
- Аналог процесса и шаблон: `EmailSchedulerService`, `templates/mail_reminder.ftl`.
- Смежные задачи: VUXPCAP-1414 (аналитика новых уведомлений, Open), VUXPCAP-774 (MVP-решение о хардкоде, Resolved).
