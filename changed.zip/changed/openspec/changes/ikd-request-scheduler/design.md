# Design

## Context

В сервисе `gmap2-vux-ecm` уже есть рабочий механизм расписания — `EmailSchedulerService` и `OrchestratorService` с аннотацией `@Scheduled`. Также в ECM действует механизм вызова хранимых процедур PostgreSQL через Spring Data JPA `@NativeQuery`: репозиторий `VuxDocumentValidationResultViewRepository` уже содержит методы `fnLoadShedule()`, `processSchedule()`, `flowResolveShedule()` и другие, которые вызывают процедуры схемы `s_grnplm_as_cib_gm_vux` без параметров или с параметрами.

Задача VUXPCAP-1410 — добавить вызов процедуры `fn_load_request` ежемесячно 16-го числа в 00:00 для расчёта метрик ИКД и регистрации входящих обращений от ЦБ. Процедура записывает данные в таблицы `s_grnplm_as_cib_gm_vux.t_vux_request_data` и `s_grnplm_as_cib_gm_vux.t_vux_request`, имеет собственное логирование через стандартные функции БД (сохранять output не нужно, передавать параметры не нужно). В ECM все вызовы процедур идут напрямую через Spring Data JPA репозитории на стороне PostgreSQL.

## Goals / Non-Goals

**Goals:**

- Добавить метод `fnLoadRequest()` в репозиторий `VuxDocumentValidationResultViewRepository` через `@NativeQuery`.
- Создать сервис `IkdCalculationSchedulerService` (`@Service`) с методом `@Scheduled(cron)`, который вызывает репозиторий и логирует результат.
- Параметризируемое расписание (`cron`) и часовой пояс (`timezone`) из внешней конфигурации окружения с fallback-значениями в аннотации `@Scheduled`.
- Настраиваемый тайм-аут транзакции процедуры (`config.ikd-calculation-scheduler.timeout`, по умолчанию 3600 с) вместо захардкоженного в аннотации репозитория.
- Включение расписания только явным feature-toggle `config.feature-toggles.scheduled-ikd-calculation=true`.
- Сбои не пробрасываются наружу, не влияют на health приложения и следующее расписание; при сбое транзакция откатывается.

**Non-Goals:**

- Не создаём отдельный Feign-клиент или DTO-обёртку для вызова процедуры.
- Не изменяем существующие методы `VuxDocumentValidationResultViewRepository` и другие репозитории.
- Не передаём параметры в `fn_load_request` — процедура вызывается без аргументов.
- Не сохраняем результат вызова (процедура работает внутри БД, output не нужен).
- Не добавляем retry-логику на уровне шедулера.
- Не дублируем значения расписания в `service/src/main/resources/application.yml` — значения поставляет конфигурация окружения. Класс свойств при этом заведён (см. D5/D8): он покрывает только тайм-аут транзакции, а не расписание.

## Decisions

### D1. Spring Data JPA @NativeQuery

Используем Spring Data JPA `@NativeQuery` (как `fnLoadShedule()`, `processSchedule()`). **Почему:** ECM уже использует этот подход для всех хранимых процедур `s_grnplm_as_cib_gm_vux`. Процедура `fn_load_request` работает внутри схемы БД PostgreSQL — JDBC-драйвер PostgresSQL 42.7.12 уже подключён.

### D2. Метод в существующем репозитории vs новый репозиторий

Добавляем метод в существующий `VuxDocumentValidationResultViewRepository`. **Почему:** в этом репозитории уже собраны все методы для вызовов процедур схемы `s_grnplm_as_cib_gm_vux` (`fnLoadShedule()`, `fnFlowInfoEmalSend()`, `fnEcmRequestCreate()` и др.). Создание отдельного репозитория разрушит эту логическую группировку.

### D3. @Scheduled в @Service vs @Component

Используем `@Service` вместо `@Component`. **Почему:** соответствует конвенции ECM — `EmailSchedulerService` и `OrchestratorService` также используют `@Service`; семантически шедулер — бизнес-сервис, а не инфраструктурный компонент.

### D4. Условная регистрация @ConditionalOnProperty — opt-in

Компонент регистрируется только при явном `config.feature-toggles.scheduled-ikd-calculation=true`; `matchIfMissing = false`. **Почему:** это ровно паттерн `EmailSchedulerService`, где `@ConditionalOnProperty(value = "config.feature-toggles.scheduled-email", havingValue = "true")` указан без `matchIfMissing`, то есть расписание рассылки тоже включается явно. Первичный вариант с `matchIfMissing = true` регистрировал бы компонент сразу после выката сборки, до того как расписание согласовано и проверено на стенде. Отключение без удаления кода сохраняется: `=false` либо отсутствие ключа.

### D5. Плоская конфигурация через плейсхолдеры + record свойств для тайм-аута

Параметры `cron` и `timezone` читаются плейсхолдерами `config.ikd-calculation-scheduler.*` прямо в `@Scheduled`, с fallback-значениями `0 0 0 16 * ?` и `Europe/Moscow`. Значения поставляет внешнее окружение (Vault `/vault/secrets/env_secret.properties` через `SecretConfig`, переменные окружения стенда), а не `service/src/main/resources/application.yml`. Тайм-аут транзакции читается не плейсхолдером, а через record `IkdCalculationProps` (`@ConfigurationProperties(prefix = "config.ikd-calculation-scheduler")`, `@DefaultValue("3600") int timeout`), зарегистрированный в `@EnableConfigurationProperties` на `VuxApplication`. **Почему:** конвенция проекта — свойства расписаний живут в префиксе `config.` (`config.mail-sheduled-sender.cron`, `config.feature-toggles.scheduled-email`) и читаются плейсхолдерами; `IkdCalculationProps` повторяет уже принятый формат `MailSheduledSenderProps` (record + `@DefaultValue` + регистрация в `@EnableConfigurationProperties`). Fallback в `@Scheduled` оставляет расписание работоспособным при непрокинутых свойствах стенда, а отсутствие fallback у `timeout` компенсируется `@DefaultValue("3600")`.

### D6. Вызов через Optional<Void> метод репозитория

Метод репозитория возвращает `Optional<Void>` (как `fnLoadShedule()`, `processSchedule()`). **Почему:** процедура `SELECT FROM procedure()` возвращает `void`/`NULL`; Spring Data JPA маппит это на пустой `Optional`; шедулеру не нужно проверять результат — факт отсутствия исключения = успех.

### D7. Точечный уровень логирования не задаётся

`logging.level` для `ru.sbrf.gmap.vux.service.IkdCalculationSchedulerService` не настраивается. **Почему:** класс пишет только INFO (старт/успех) и ERROR (сбой), DEBUG-записей нет; root-уровень и уровень приложения уже задаются внешним параметром `LOG_VUX_ECM_COMMON_LEVEL` (по умолчанию `DEBUG`) в `logback-spring.xml`. Локальная переопределённая запись только затемнила бы реальную настройку уровня на стенде.

### D8. Тайм-аут транзакции через TransactionTemplate в шедулере

Вызов процедуры оборачивается в `TransactionTemplate` (`new TransactionTemplate(transactionManager)`, `setTimeout(ikdCalculationProps.timeout())`, `executeWithoutResult(...)`), а метод репозитория помечен просто `@Transactional` без тайм-аута. **Почему:** `@Transactional(timeout = …)` принимает только compile-time константу (первичный вариант `@Transactional(timeout = 3600)` в репозитории не позволял менять тайм-аут конфигурацией) и «приклеивал» бы тайм-аут к методу репозитория для всех будущих вызывающих, тогда как длительность нужна именно прогону шедулера. `TransactionTemplate` задаёт тайм-аут на прогон, явно читается из `IkdCalculationProps` и проверяется тестом через мок `PlatformTransactionManager` (`ArgumentCaptor<TransactionDefinition>.getTimeout()`); при исключении из процедуры шаблон выполняет rollback, что тоже закрыто тестом.

## Risks / Trade-offs

- **Расписание молча не активировано**: компонент opt-in (см. D4), поэтому без явного `config.feature-toggles.scheduled-ikd-calculation=true` метрики ИКД за месяц не рассчитываются, а старт приложения об этом не сигнализирует. Митигация: флаг заводится на стенде/Vault до выката; факт регистрации бина подтверждается при приёмке (INFO-лог прогона).
- **Fallback-значения cron/timezone**: при непрокинутых свойствах стенда применяются `0 0 0 16 * ?` и `Europe/Moscow` из аннотации `@Scheduled`, старт не падает. Расхождение между стендом и ожидаемыми значениями становится невидимым. Митигация: свойства заводятся на стенде до выката; fallback совпадает с целевым значением, поэтому риск ограничивается case'ом «нужен другой график».
- **Отсутствие idempotency**: если scheduler запустится дважды (при рестарте), процедура вызовется дважды. Проблема снимается тем, что процедура `fn_load_request` имеет внутреннюю защиту от дублей на уровне БД.
- **Жёсткий cron `0 0 0 16 * ?`**: в месяцах с <31 днями 16-е число всё равно существует. Если потребуется смещение к концу месяца — достаточно обновления cron-выражения в конфигурации стенда без изменения кода.
- **Нет retry на уровне приложения**: если БД недоступна во время прогона, ошибка логируется ERROR и следующее расписание работает штатно. Потеря прогона возможна — если `fn_load_request` критична для отчётности, требуется доработка (отложенно).
- **Длительная транзакция процедуры**: вызов идёт в транзакции `TransactionTemplate` с тайм-аутом `config.ikd-calculation-scheduler.timeout` (по умолчанию 3600 с). Превышение даёт rollback и ERROR-запись прогона, следующее расписание не страдает. Если 3600 с мало для объёмов данных — тайм-аут поднимается конфигурацией стенда без изменения кода; таймауты пула подключений настраиваются отдельно (вне этого change).

## Migration Plan

1. Добавить метод `fnLoadRequest()` в `VuxDocumentValidationResultViewRepository`.
2. Создать `IkdCalculationSchedulerService` в пакете `ru.sbrf.gmap.vux.service` и record `IkdCalculationProps` в `ru.sbrf.gmap.vux.config`, зарегистрировав его в `@EnableConfigurationProperties` на `VuxApplication`.
3. Завести во внешней конфигурации стенда/Vault свойства `config.ikd-calculation-scheduler.cron` (`0 0 0 16 * ?`) и `config.ikd-calculation-scheduler.timezone` (`Europe/Moscow`) до выката сборки; `config.ikd-calculation-scheduler.timeout` прокидывается только при необходимости отойти от `@DefaultValue("3600")`.
4. Деплой безопасен по умолчанию: без `config.feature-toggles.scheduled-ikd-calculation=true` компонент не регистрируется и расписание не выполняется (см. D4); включение — явным свойством стенда после проверки. Откат: снять флаг или установить `false` (компонент не регистрируется) либо revert коммита.

## Open Questions

- ~~Нужно ли добавить валидацию ответа после вызова?~~ **Решено:** нет. Процедура `fn_load_request` не возвращает данных. Факт успешного выполнения = отсутствие исключения.
- ~~Требуется ли мониторинг/метрики длительности выполнения?~~ **Решено:** нет. Это может быть добавлено в отдельный change как improvement.
