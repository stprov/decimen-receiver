# Spec Delta

## Purpose

Периодический вызов процедуры `fn_load_request` для расчёта метрик ИКД и регистрации входящих обращений от ЦБ — ежемесячно 16-го числа в 00:00 через Spring Data JPA репозиторий `VuxDocumentValidationResultViewRepository`. Процедура записывает данные в таблицы `s_grnplm_as_cib_gm_vux.t_vux_request_data` и `s_grnplm_as_cib_gm_vux.t_vux_request`, имеет собственное логирование через стандартные функции БД — сохранение результата не требуется. Задача: [VUXPCAP-1410](https://jira.delta.sbrf.ru/browse/VUXPCAP-1410).

## ADDED Requirements

### Requirement: Периодический вызов процедуры fn_load_request
Система ДОЛЖНА (MUST) ежемесячно вызывать процедуру `fn_load_request` через репозиторий `VuxDocumentValidationResultViewRepository` по расписанию `config.ikd-calculation-scheduler.cron` (целевое значение `0 0 0 16 * ?`) в поясе `config.ikd-calculation-scheduler.timezone`. Вызов без параметров, без сохранения результата. Компонент регистрируется только при явном `config.feature-toggles.scheduled-ikd-calculation=true` (`matchIfMissing = false`): при `false` и при отсутствии ключа бина в контексте нет.

#### Scenario: Плановый прогон выполняется по cron-расписанию
- **WHEN** системное время в поясе `config.ikd-calculation-scheduler.timezone` соответствует значению `config.ikd-calculation-scheduler.cron`
- **THEN** шедулер выполняет ровно один вызов `VuxDocumentValidationResultViewRepository.fnLoadRequest()`

#### Scenario: Расписание задаётся вне репозитория
- **WHEN** сервис разворачивается на стенде, где `config.ikd-calculation-scheduler.cron` и `.timezone` заданы внешней конфигурацией (Vault `/vault/secrets/env_secret.properties`, переменные окружения), а не `service/src/main/resources/application.yml`
- **THEN** расписание и часовой пояс берутся из значений окружения без изменения кода и файлов репозитория

#### Scenario: Свойства расписания не заданы
- **WHEN** `config.ikd-calculation-scheduler.cron` или `config.ikd-calculation-scheduler.timezone` отсутствуют в конфигурации окружения
- **THEN** применяются fallback-значения аннотации `@Scheduled` — `0 0 0 16 * ?` и `Europe/Moscow`; старт контекста не завершается ошибкой

#### Scenario: Флаг расписания не задан
- **WHEN** ключ `config.feature-toggles.scheduled-ikd-calculation` отсутствует в конфигурации
- **THEN** `IkdCalculationSchedulerService` в контексте не регистрируется и процедура не вызывается

#### Scenario: Процедура записывает данные в целевые таблицы
- **WHEN** процедура `fn_load_request` успешно выполняется
- **THEN** данные записываются в таблицы `t_vux_request_data` и `t_vux_request` схемы `s_grnplm_as_cib_gm_vux`
- **AND** процедура ведёт собственное логирование через стандартные функции БД

#### Scenario: Вызов через @NativeQuery
- **WHEN** шедулер вызывает метод репозитория `fnLoadRequest()`
- **THEN** вызов выполняется через `@NativeQuery("SELECT FROM s_grnplm_as_cib_gm_vux.fn_load_request()")` без дополнительной настройки подключения

### Requirement: Форма запроса к процедуре
Каждый прогон ДОЛЖЕН (MUST) генерировать уникальный UUID для отслеживания (`executionId`) и передавать его в логи. Уникальность обеспечивается `UUID.randomUUID()` — каждый прогон получает новый идентификатор.

#### Scenario: Идентификатор прогона уникален
- **WHEN** выполняются два соседних прогона подряд
- **THEN** их UUID различаются, и каждый попадает в лог как `executionId`

### Requirement: Успешный прогон логируется
При успешном вызове процедуры система ОБЯЗАНА (SHALL) записать в лог запись уровня INFO, содержащую `executionId` (сгенерированный UUID) и имя процедуры `fn_load_request`. Сообщения лога пишутся на английском языке; тела ответов, персональные данные и секреты в лог НЕ ПОПАДАЮТ (MUST NOT).

#### Scenario: Ответ процедуры принят
- **WHEN** `VuxDocumentValidationResultViewRepository.fnLoadRequest()` вернул значение без исключения для процедуры `fn_load_request`
- **THEN** в логе есть INFO-запись о завершении вызова с полями `executionId='<uuid>'` и `procedure=fn_load_request`

### Requirement: Неуспешный прогон логируется и не прерывает расписание
При неуспешном прогоне система ОБЯЗАНА (SHALL) записать в лог запись уровня ERROR, содержащую `executionId`, имя процедуры и причину отказа (`error='<текст>'`). Исключение не пробрасывается наружу.

#### Scenario: Сбой процедуры фиксируется в логе
- **WHEN** вызов процедуры завершился исключением (PostgreSQL error, constraint violation, etc.)
- **THEN** в логе есть ERROR-запись прогона с полями `executionId`, `procedure=fn_load_request` и причиной отказа

### Requirement: Точечный уровень логирования не настраивается
Система НЕ ДОЛЖНА (MUST NOT) задавать отдельный уровень логирования для класса шедулера в файлах репозитория: класс пишет только INFO и ERROR, а root-уровень уже определён внешним параметром `LOG_VUX_ECM_COMMON_LEVEL` в `logback-spring.xml`.

#### Scenario: Уровень наследуется от root-логгера
- **WHEN** сервис запускается без явного `logging.level` для `ru.sbrf.gmap.vux.service.IkdCalculationSchedulerService`
- **THEN** записи класса пишутся с уровнем, унаследованным от root-логгера, и/INFO/ERROR-записи прогона видны в логе

### Requirement: Без избыточного кода в реализации шедулера
Реализация шедулера НЕ ДОЛЖНА (MUST NOT) содержать неиспользуемые абстракции (интерфейсы, фабрики) и собственные метрики. Единственный новый класс конфигурации — record свойств `IkdCalculationProps`; иных классов конфигурации, фабрик и обёрток change не вводит. Код, используемый в классе однократно, НЕ ВЫНОСИТСЯ в отдельный метод.

#### Scenario: Однократная логика остаётся в методе
- **WHEN** логика генерации UUID, оборачивания вызова в транзакцию и логирования используется только в методе шедулера
- **THEN** весь код остаётся внутри метода `@Scheduled` без выноса в приватные методы

### Requirement: Повторные попытки выполняет Spring Data / JDBC
Шедулер НЕ ДОЛЖЕН (MUST NOT) выполнять собственные повторы обращения к процедуре: за один прогон выполняется ровно один вызов `VuxDocumentValidationResultViewRepository.fnLoadRequest()`. Повторные попытки (если конфигурируются на уровне Hibernate/JDBC или пула соединений) не управляются шедулером.

#### Scenario: Один вызов репозитория за прогон
- **WHEN** прогон завершился успешно или с ошибкой
- **THEN** `fnLoadRequest()` за этот прогон вызван ровно один раз на уровне Java-кода шедулера

### Requirement: Тайм-аут транзакции процедуры задаётся конфигурацией
Система ДОЛЖНА (MUST) выполнять вызов процедуры внутри транзакции, тайм-аут которой берётся из `config.ikd-calculation-scheduler.timeout` (в секундах, по умолчанию 3600) и задаётся на прогон через `TransactionTemplate`. Значение тайм-аута НЕ ДОЛЖНО (MUST NOT) захардкоживаться в аннотации метода репозитория.

#### Scenario: Тайм-аут берётся из свойства
- **WHEN** в конфигурации задан `config.ikd-calculation-scheduler.timeout=120`
- **THEN** транзакция прогона создаётся с тайм-аутом 120 секунд

#### Scenario: Свойство тайм-аута не задано
- **WHEN** `config.ikd-calculation-scheduler.timeout` отсутствует в конфигурации окружения
- **THEN** применяется default-значение `3600` секунд из `IkdCalculationProps`, старт контекста не завершается ошибкой

#### Scenario: Сбой процедуры откатывает транзакцию
- **WHEN** выполнение процедуры внутри транзакции завершилось исключением
- **THEN** транзакция откатывается и не фиксируется частично записанных данных, исключение не пробрасывается наружу шедулера
