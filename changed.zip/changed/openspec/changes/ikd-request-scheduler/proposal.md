# Proposal: ikd-request-scheduler

## Why

Для расчёта метрик ИКД и регистрации входящих обращений от ЦБ необходимо ежемесячно вызывать процедуру `fn_load_request` схемы `s_grnplm_as_cib_gm_vux` (16-го числа в 00:00). Процедура записывает данные в таблицы `t_vux_request_data` и `t_vux_request` — без параметров, без сохранения результата (внутри процедуры реализовано собственное логирование через стандартные функции БД). В сервисе `gmap2-vux-ecm` уже есть механизм вызова хранимых процедур через Spring Data JPA `@NativeQuery` (например, `fnLoadShedule()`, `processSchedule()` в `VuxDocumentValidationResultViewRepository`) и примеры компонентного расписания (`EmailSchedulerService`, `OrchestratorService`). Задача описана в [VUXPCAP-1410](https://jira.delta.sbrf.ru/browse/VUXPCAP-1410).

## What Changes

- Добавляется метод `fnLoadRequest()` в репозиторий `VuxDocumentValidationResultViewRepository` с `@NativeQuery("SELECT FROM s_grnplm_as_cib_gm_vux.fn_load_request()")` — для вызова хранимой процедуры без параметров.
- Создаётся сервис `IkdCalculationSchedulerService` (`@Service`, `@ConditionalOnProperty`) с методом `@Scheduled(cron = "${config.ikd-calculation-scheduler.cron:0 0 0 16 * ?}", zone = "${config.ikd-calculation-scheduler.timezone:Europe/Moscow}")`: формирует UUID для `executionId`, выполняет `repository.fnLoadRequest()` внутри `TransactionTemplate` с настраиваемым тайм-аутом, логирует INFO при успехе или ERROR при сбое (с `executionId`, именем процедуры и причиной). Исключения не пробрасываются наружу; при сбое транзакция откатывается.
- Расписание и часовой пояс задаются свойствами `config.ikd-calculation-scheduler.cron` и `config.ikd-calculation-scheduler.timezone` во внешней конфигурации окружения (Vault `/vault/secrets/env_secret.properties`, переменные окружения стенда); в аннотации `@Scheduled` остаются fallback-значения `0 0 0 16 * ?` и `Europe/Moscow`. Компонент включается только явным `config.feature-toggles.scheduled-ikd-calculation=true` (`matchIfMissing = false`) — как в `EmailSchedulerService`, где флаг также указан без `matchIfMissing`.
- Добавляется record `IkdCalculationProps` с `@ConfigurationProperties(prefix = "config.ikd-calculation-scheduler")` и параметром `timeout` (`@DefaultValue("3600")`) — тайм-аут транзакции процедуры в секундах. Прописан в `@EnableConfigurationProperties` на `VuxApplication`; по стилю повторяет `MailSheduledSenderProps`. Тайм-аут нельзя задать свойством через `@Transactional(timeout = …)` — атрибут аннотации требует compile-time константу, поэтому применяется `TransactionTemplate`.
- Логирование на английском языке. Точечный `logging.level` для класса не задаётся: сервис пишет только INFO и ERROR, root-уровень уже определён внешним параметром `LOG_VUX_ECM_COMMON_LEVEL` в `logback-spring.xml`.

## Capabilities

### New Capabilities
- `scheduled-procedures`: вызов хранимых процедур базы данных по расписанию через Spring Data JPA репозитории и компонентный сервис `@Scheduled` — логирование исхода, устойчивое к сбоям, параметризируемое расписание.

### Modified Capabilities

_(нет — существующие спецификации `scheduled-info-emails` и `upload-document-by-s3-path` не меняются)._

## Impact

- **Новый код**: `ru.sbrf.gmap.vux.service.IkdCalculationSchedulerService` (`@Service`, `@Scheduled`, `@ConditionalOnProperty`); record `ru.sbrf.gmap.vux.config.IkdCalculationProps` с тайм-аутом транзакции; метод `fnLoadRequest()` в `VuxDocumentValidationResultViewRepository`.
- **Конфигурация**: `service/src/main/resources/application.yml` остаётся без блока расписания, `application-local.yml` не создаётся. Свойства `config.ikd-calculation-scheduler.{cron,timezone,timeout}` и флаг `config.feature-toggles.scheduled-ikd-calculation` поставляет стенд/Vault; `timeout` опционален благодаря `@DefaultValue("3600")`. Изменён `VuxApplication.java`: `IkdCalculationProps` добавлен в `@EnableConfigurationProperties`.
- **Риск деплоя**: opt-in флаг означает, что при непрокинутом `config.feature-toggles.scheduled-ikd-calculation=true` расписание молча не работает и старт об этом не сигнализирует; непрокинутые cron/timezone дают fallback `0 0 0 16 * ?` / `Europe/Moscow` вместо ошибки разрешения плейсхолдера. Митигация: флаг и свойства заводятся на стенде до выката, регистрация бина подтверждается при приёмке.
- **Транзакции**: `fnLoadRequest()` больше не несёт тайм-аут в аннотации — он задаётся на прогон через `TransactionTemplate`. Побочных эффектов нет: в основном коде метод вызывается только шедулером.
- **Тесты**: unit-тесты `IkdCalculationSchedulerServiceTest` — успешный прогон логируется INFO с `executionId`; сбой логируется ERROR с причиной; исключение не пробрасывается наружу; уникальность `executionId`; тайм-аут транзакции берётся из свойства (`ArgumentCaptor<TransactionDefinition>`); rollback при сбое процедуры; условная регистрация по `config.feature-toggles.scheduled-ikd-calculation`.
- **Зависимости**: новые не требуются; используются Spring Boot, PostgreSQL JDBC драйвер (PostGIS), Lombok, существующие репозитории.
- **Затронутый код**: `VuxDocumentValidationResultViewRepository`, `IkdCalculationSchedulerService`, `VuxApplication` (`@EnableConfigurationProperties`), новый `config/IkdCalculationProps.java`.
