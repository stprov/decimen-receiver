# Tasks: ikd-request-scheduler

> Задача: [VUXPCAP-1410](https://jira.delta.sbrf.ru/browse/VUXPCAP-1410). Процедура `fn_load_request` записывает данные в `s_grnplm_as_cib_gm_vux.t_vux_request_data` и `t_vux_request`, без параметров и сохранения результата. Свойства расписания поставляет внешняя конфигурация окружения (стенд/Vault), а не `application.yml`.

## 1. Метод репозитория

- [x] 1.1 Добавить метод `Optional<Void> fnLoadRequest()` в `VuxDocumentValidationResultViewRepository` с аннотацией `@Transactional @NativeQuery("SELECT FROM s_grnplm_as_cib_gm_vux.fn_load_request()")` (без тайм-аута в аннотации — он задаётся шедулером); сборкой `mvn clean install` подтверждено, что Spring Data JPA принимает интерфейс без ошибок компиляции и создания прокси

## 2. Сервис IkdCalculationSchedulerService

- [x] 2.1 Создать класс `ru.sbrf.gmap.vux.service.IkdCalculationSchedulerService`: `@Service`, `@RequiredArgsConstructor`, `@Slf4j`, `@ConditionalOnProperty(name = "config.feature-toggles.scheduled-ikd-calculation", havingValue = "true", matchIfMissing = false)` — оптим включается только явным свойством стенда (как `EmailSchedulerService`, где `matchIfMissing` не указан); зависимости — `VuxDocumentValidationResultViewRepository`, `PlatformTransactionManager`, `IkdCalculationProps`
- [x] 2.2 Реализовать публичный метод `@Scheduled(cron = "${config.ikd-calculation-scheduler.cron:0 0 0 16 * ?}", zone = "${config.ikd-calculation-scheduler.timezone:Europe/Moscow}") run()`: генерация `UUID executionId = UUID.randomUUID()`, вызов `repository.fnLoadRequest()` внутри транзакции, INFO-лог при успехе (`"executionId={}, procedure=fn_load_request", executionId`) и ERROR-лог при сбое (с Throwable), catch всех исключений; код UUID генерации/транзакции/лога остаётся inline в методе `@Scheduled` без выноса в приватные методы; значения cron и timezone задаются конфигурацией окружения, в аннотации остаются fallback-значения
- [x] 2.3 Проверить лаконичность: участок UUID генерации/вызова/лога не выносится в отдельный приватный метод, поскольку используется один раз
- [x] 2.4 Задать тайм-аут транзакции прогона через `TransactionTemplate` (`setTimeout(ikdCalculationProps.timeout())`, `executeWithoutResult`), убрав `@Transactional(timeout = 3600)` с метода репозитория: атрибут аннотации принимает только compile-time константу и привязывал бы тайм-аут ко всем вызывающим; при исключении из процедуры шаблон выполняет rollback
- [x] 2.5 Создать record `ru.sbrf.gmap.vux.config.IkdCalculationProps` (`@ConfigurationProperties(prefix = "config.ikd-calculation-scheduler")`, `@DefaultValue("3600") int timeout`) и зарегистрировать его в `@EnableConfigurationProperties` на `VuxApplication`; формат повторяет `MailSheduledSenderProps`

## 3. Конфигурация

- [ ] 3.1 Завести во внешней конфигурации окружения (Vault `/vault/secrets/env_secret.properties` или переменные окружения стенда) флаг `config.feature-toggles.scheduled-ikd-calculation=true` и свойства `config.ikd-calculation-scheduler.cron` (`0 0 0 16 * ?`), `config.ikd-calculation-scheduler.timezone` (`Europe/Moscow`) до выката сборки. Блок расписания в `service/src/main/resources/application.yml` отсутствует намеренно; в `@Scheduled` есть fallback-значения, поэтому без свойств расписание поедет по fallback, а без флага бин не зарегистрируется вовсе. `config.ikd-calculation-scheduler.timeout` прокидывается только при необходимости отойти от `@DefaultValue("3600")`
- [x] 3.2 Локальное переопределение не требуется: файла `service/src/main/resources/application-local.yml` в проекте нет, отключение расписания выполняется внешним свойством `config.feature-toggles.scheduled-ikd-calculation=false`
- [x] 3.3 Точечный `logging.level` для `ru.sbrf.gmap.vux.service.IkdCalculationSchedulerService` не задаётся: в классе нет DEBUG-записей (только INFO и ERROR), root-уровень уже определяется параметром `LOG_VUX_ECM_COMMON_LEVEL` в `logback-spring.xml`

## 4. Тесты

- [x] 4.1 Привести `IkdCalculationSchedulerServiceTest` к каноническому ключу: проверки условной регистрации используют `config.feature-toggles.scheduled-ikd-calculation`, плейсхолдеры cron/timezone задаются через `withPropertyValues`. Сохранены проверки: INFO с `executionId` и `procedure=fn_load_request`, ERROR с `executionId` и причиной (`ThrowableProxy`), исключение не пробрасывается наружу, уникальность `executionId`
- [x] 4.2 Покрыть транзакцию: `ArgumentCaptor<TransactionDefinition>` проверяет `getTimeout() == config.ikd-calculation-scheduler.timeout` и `commit(...)` при успехе; `rollback(...)` и `never().commit(...)` при `DataAccessResourceFailureException`
- [x] 4.3 Гипотеза о невалидных conditional-тестах не подтвердилась: `mvn clean install` с тестами прошёл зелёным, включая `serviceAbsentWhenFlagDisabled` и `serviceAbsentWhenFlagMissing` (`doesNotHaveBean`) — условная регистрация с `matchIfMissing = false` в тесте фактически проверяется, перевод регистрации на `withUserConfigurations` не требуется

## 5. Verification и сборка

- [x] 5.1 Выполнить `mvn clean install` — BUILD SUCCESS, без предупреждений о дублирующихся бинах
- [x] 5.2 Все тесты зелёные, новые тесты из `IkdCalculationSchedulerServiceTest` (в том числе на тайм-аут и rollback) включены в итоговый счётчик — подтверждено прогоном `mvn clean install` с тестами
- [ ] 5.3 Проверка запуска с внешней конфигурацией: при `config.feature-toggles.scheduled-ikd-calculation=true` и заданных cron/timezone приложение поднимается и `IkdCalculationSchedulerService` присутствует в контексте; при `false` или отсутствии ключа бин не регистрируется; при отсутствии cron/timezone применяются fallback `0 0 0 16 * ?` / `Europe/Moscow`

## Workflow follow-up

- Archive the change after the project's review requirements are satisfied.
- Verify the archived result.
