#### VUX app minimum MVP for Release
