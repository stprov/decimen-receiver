package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.test.util.ReflectionTestUtils;
import ru.sbrf.gmap.vux.dto.response.CreateContentsResponse;
import ru.sbrf.gmap.vux.dto.response.ResponseResult;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.facade.EcmDocumentFacade;
import ru.sbrf.gmap.vux.facade.supz.SupzTaskFacade;
import ru.sbrf.gmap.vux.model.jsonrpc.SupzTaskResponseWrapper;
import ru.sbrf.gmap.vux.model.supz.response.SupzTaskResponse;
import ru.sbrf.gmap.vux.model.supz.response.SupzTaskResponseData;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

/**
 * Протокол в ECM, письмо об ошибках, задача СУПЗ (аналитика, 9.1, 9.2, D-14, D-39).
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("PostUploadActionsService")
class PostUploadActionsServiceTest {

    private static final int DOC_ID = 100;

    @Mock
    private VuxDocumentValidationResultViewRepository viewRepository;
    @Mock
    private OutputFormingService outputFormingService;
    @Mock
    private MailService mailService;
    @Mock
    private SupzTaskFacade supzTaskFacade;
    @Mock
    private EcmDocumentFacade ecmDocumentFacade;
    @Mock
    private ProtocolBuildingService protocolBuildingService;

    private PostUploadActionsService service;
    private final ProtocolModelDto protocol = ProtocolModelDto.builder().documentDate("2026-10-31").build();

    @BeforeEach
    void setUp() {
        service = new PostUploadActionsService(viewRepository, outputFormingService, mailService, supzTaskFacade,
                ecmDocumentFacade, protocolBuildingService, new RetryExecutor());
        ReflectionTestUtils.setField(service, "ecmMaxAttempts", 2);
        ReflectionTestUtils.setField(service, "ecmRetryDelayMs", 0L);
        when(protocolBuildingService.generateProtocolName(any())).thenReturn("protocol.pdf");
        when(outputFormingService.createPdf(any())).thenReturn(new byte[]{1});
        when(outputFormingService.createHtml(any())).thenReturn("<html/>");
    }

    private static VuxDocumentScheduleViewEntity record() {
        VuxDocumentScheduleViewEntity record = new VuxDocumentScheduleViewEntity();
        record.setScheduleId(1);
        record.setResultDocumentId(DOC_ID);
        record.setDocTypeCode("0420415.1.3");
        record.setMailReceiversList("a@test.ru; b@test.ru");
        record.setMailCopyList("c@test.ru");
        return record;
    }

    // ===================== Протокол =====================

    @Test
    @DisplayName("Протокол загружен — id сохранён через fn_flow_set_ecm_id")
    void uploadProtocol_success() {
        CreateContentsResponse.CreateContentsDocument doc = new CreateContentsResponse.CreateContentsDocument(
                "ecm-1", null, null, List.of(), new ResponseResult("OK", null));
        when(ecmDocumentFacade.uploadSignedDocument(any(), anyString(), any(), anyList()))
                .thenReturn(Optional.of(new CreateContentsResponse(List.of(doc))));

        Optional<String> result = service.uploadProtocol(record(), protocol);

        assertThat(result).contains("ecm-1");
        verify(viewRepository).flowSetEcmId(DOC_ID, "ecm-1", "OK");
    }

    @Test
    @DisplayName("ECM не ответил после всех попыток — пусто, fn_flow_set_ecm_id не вызывается")
    void uploadProtocol_failedAfterRetries() {
        when(ecmDocumentFacade.uploadSignedDocument(any(), anyString(), any(), anyList())).thenReturn(Optional.empty());

        assertThat(service.uploadProtocol(record(), protocol)).isEmpty();
        verify(ecmDocumentFacade, times(2)).uploadSignedDocument(any(), anyString(), any(), anyList());
        verify(viewRepository, never()).flowSetEcmId(any(), any(), any());
    }

    @Test
    @DisplayName("Сбой формирования PDF — пусто, ECM не вызывается")
    void uploadProtocol_pdfFailure() {
        when(outputFormingService.createPdf(any())).thenThrow(new IllegalStateException("pdf"));

        assertThat(service.uploadProtocol(record(), protocol)).isEmpty();
        verifyNoInteractions(ecmDocumentFacade);
    }

    @Test
    @DisplayName("Сбой fn_flow_set_ecm_id — пусто (протокол будет загружен повторно)")
    void uploadProtocol_setEcmIdFailure() {
        CreateContentsResponse.CreateContentsDocument doc = new CreateContentsResponse.CreateContentsDocument(
                "ecm-1", null, null, List.of(), new ResponseResult("OK", null));
        when(ecmDocumentFacade.uploadSignedDocument(any(), anyString(), any(), anyList()))
                .thenReturn(Optional.of(new CreateContentsResponse(List.of(doc))));
        when(viewRepository.flowSetEcmId(any(), any(), any())).thenThrow(new IllegalStateException("db"));

        assertThat(service.uploadProtocol(record(), protocol)).isEmpty();
    }

    // ===================== Почта =====================

    @Test
    @DisplayName("D-39: письмо отправлено — фиксируется с кодом ERROR")
    void sendErrorMail_success() {
        when(mailService.sendMail(anyString(), anyString(), anyList(), anyList())).thenReturn(true);

        assertThat(service.sendErrorMail(record(), protocol)).isTrue();
        verify(mailService).sendMail(anyString(), eq("<html/>"), eq(List.of("a@test.ru", "b@test.ru")), eq(List.of("c@test.ru")));
        verify(viewRepository).flowSetMailStatus(eq(DOC_ID), anyString(), anyString(), eq("<html/>"), eq("ERROR"));
    }

    @Test
    @DisplayName("DEF-13: сбой отправки — факт отправки не фиксируется")
    void sendErrorMail_failure() {
        when(mailService.sendMail(anyString(), anyString(), anyList(), anyList())).thenReturn(false);

        assertThat(service.sendErrorMail(record(), protocol)).isFalse();
        verify(viewRepository, never()).flowSetMailStatus(any(), any(), any(), any(), any());
    }

    @Test
    @DisplayName("D-34: отправленное письмо определяется по t_vux_mail")
    void isErrorMailSent() {
        when(viewRepository.existsErrorMail(100L)).thenReturn(true);

        assertThat(service.isErrorMailSent(record())).isTrue();
    }

    // ===================== СУПЗ =====================

    @Test
    @DisplayName("supz_task_id заполнен — задача не создаётся, результат успешный")
    void createSupzTask_alreadySet() {
        VuxDocumentScheduleViewEntity record = record();
        record.setSupzTaskId("1");

        assertThat(service.createSupzTask(record, List.of("x"), "r")).isTrue();
        verifyNoInteractions(supzTaskFacade);
    }

    @Test
    @DisplayName("Задача создана — fn_flow_set_supz_id")
    void createSupzTask_success() {
        UUID taskId = UUID.randomUUID();
        SupzTaskResponseData data = mock(SupzTaskResponseData.class);
        when(data.taskId()).thenReturn(taskId);
        when(data.status()).thenReturn("NEW");
        SupzTaskResponse response = mock(SupzTaskResponse.class);
        when(response.data()).thenReturn(data);
        when(supzTaskFacade.createTask(any(), any())).thenReturn(new SupzTaskResponseWrapper(response, "{raw}"));

        assertThat(service.createSupzTask(record(), List.of("a", "b"), "r")).isTrue();
        verify(supzTaskFacade).buildSupzCreateTaskRequest(any(), eq(List.of("a", "b")), any());
        verify(viewRepository).flowSetSupzId(DOC_ID, taskId.toString(), "NEW", "{raw}");
    }

    @Test
    @DisplayName("T-11: сбой СУПЗ — false, fn_flow_set_supz_id не вызывается")
    void createSupzTask_failure() {
        when(supzTaskFacade.createTask(any(), any())).thenThrow(new IllegalStateException("supz"));

        assertThat(service.createSupzTask(record(), List.of("a"), "r")).isFalse();
        verify(viewRepository, never()).flowSetSupzId(any(), any(), any(), any());
    }

    @Test
    @DisplayName("Сбой fn_flow_set_supz_id после создания задачи — false (риск дубля, Q-1)")
    void createSupzTask_setSupzIdFailure() {
        SupzTaskResponseData data = mock(SupzTaskResponseData.class);
        when(data.taskId()).thenReturn(UUID.randomUUID());
        SupzTaskResponse response = mock(SupzTaskResponse.class);
        when(response.data()).thenReturn(data);
        when(supzTaskFacade.createTask(any(), any())).thenReturn(new SupzTaskResponseWrapper(response, "{raw}"));
        when(viewRepository.flowSetSupzId(any(), any(), any(), any())).thenThrow(new IllegalStateException("db"));

        assertThat(service.createSupzTask(record(), List.of("a"), "r")).isFalse();
    }

    @Test
    @DisplayName("Текст результата протокола по числу предупреждений (DEF-7: %d подставляется)")
    void protocolResultText() {
        assertThat(service.protocolResultText(0)).isEqualTo("Данные витрины корректны. Можно формировать отчет.");
        assertThat(service.protocolResultText(5)).contains("Количество: 5.");
    }

    @Test
    @DisplayName("Ошибки в протоколе — письмо вместо задачи СУПЗ")
    void handlePostUploadActions_errors_sendsMail() {
        when(mailService.sendMail(anyString(), anyString(), anyList(), anyList())).thenReturn(true);
        ProtocolModelDto withErrors = ProtocolModelDto.builder()
                .objects(List.of(ru.sbrf.gmap.vux.dto.templates.ProtocolTableRecordDto.builder()
                        .ruleType(ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum.E).build()))
                .build();

        assertThat(service.handlePostUploadActions(record(), withErrors, List.of("p"))).isTrue();
        verify(mailService).sendMail(anyString(), anyString(), anyList(), anyList());
        verifyNoInteractions(supzTaskFacade);
        verify(mailService, never()).sendMail(anyString(), anyString(), anyList(), anyList(), anyBoolean());
    }
}
