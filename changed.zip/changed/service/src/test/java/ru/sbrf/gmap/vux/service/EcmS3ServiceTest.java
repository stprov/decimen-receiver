package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sbrf.gmap.vux.IntegrationEcmTfsProps;
import ru.sbrf.gmap.vux.exception.ecm.EcmException;
import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.core.sync.ResponseTransformer;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.S3Exception;
import software.amazon.awssdk.services.s3.model.S3Object;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("EcmS3Service")
class EcmS3ServiceTest {

    @Mock
    private S3Client ecmS3;
    @Mock
    private IntegrationEcmTfsProps integrationEcmTfsProps;
    @Mock
    private IntegrationEcmTfsProps.EcmS3Properties s3Props;

    private EcmS3Service ecmS3Service;

    @BeforeEach
    void setUp() {
        when(integrationEcmTfsProps.s3()).thenReturn(s3Props);
        when(s3Props.bucket()).thenReturn("test-bucket");
        ecmS3Service = new EcmS3Service(ecmS3, integrationEcmTfsProps);
    }

    @Test
    @DisplayName("downloadFileFromS3 успешно скачивает файл")
    void downloadFileFromS3_success_returnsBytes() {
        S3Object s3Object = S3Object.builder().build();
        ResponseBytes<S3Object> responseBytes = ResponseBytes.fromByteArray(
                s3Object,
                new byte[]{1, 2, 3, 4, 5}
        );
        when(ecmS3.getObject(any(GetObjectRequest.class), any(ResponseTransformer.class))).thenReturn(responseBytes);

        byte[] content = ecmS3Service.downloadFileFromS3("folder/file.pdf");

        assertThat(content).isEqualTo(new byte[]{1, 2, 3, 4, 5});
    }

    @Test
    @DisplayName("downloadFileFromS3 при ошибке S3 бросает EcmException")
    void downloadFileFromS3_s3Error_throwsEcmException() {
        when(ecmS3.getObject(any(GetObjectRequest.class), any(ResponseTransformer.class)))
                .thenThrow(S3Exception.builder().message("boom").build());

        assertThatThrownBy(() -> ecmS3Service.downloadFileFromS3("folder/file.pdf"))
                .isInstanceOf(EcmException.class)
                .hasMessageContaining("test-bucket");
    }
}