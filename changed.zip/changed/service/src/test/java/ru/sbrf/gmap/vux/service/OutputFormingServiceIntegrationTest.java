package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import ru.sbrf.gmap.vux.VuxApplicationTests;
import ru.sbrf.gmap.vux.dto.templates.ProtocolCheckRecordDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolTableRecordDto;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Интеграционные тесты для OutputFormingService с проверкой формирования PDF файлов.
 * Проверяет поведение при различных комбинациях входных данных.
 */

class OutputFormingServiceIntegrationTest extends VuxApplicationTests {

    @Autowired
    private OutputFormingService outputFormingService;

    @Autowired
    private FreemarkerResolverService freemarkerResolverService;

    private static final String TEST_PDFS_DIR = "target/test-pdfs/test-protocols-manual-check";
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    private static final DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

    @BeforeEach
    void setUp() throws IOException {
        // Создаем директорию для сохранения тестовых PDF файлов
        Path testDir = Paths.get(TEST_PDFS_DIR);
        if (!Files.exists(testDir)) {
            Files.createDirectories(testDir);
        }
    }

    /**
     * Тест: Полные данные - все поля заполнены
     */
    @Test
    @DisplayName("Полные данные - все поля заполнены")
    void testCreatePdfWithAllFieldsFilled() throws IOException {
        // Given
        ProtocolModelDto dto = createFullProtocolModelDto();

        // When
        byte[] pdfBytes = outputFormingService.createPdf(dto);
        String htmlContent = outputFormingService.createHtml(dto);

        // Then
        assertNotNull(pdfBytes, "PDF байты не должны быть null");
        assertTrue(pdfBytes.length > 0, "PDF файл не должен быть пустым");
        assertTrue(pdfBytes.length > 1000, "PDF файл должен иметь разумный размер");

        // Сохраняем PDF для ручной проверки
        savePdfToFile(pdfBytes, "test_all_fields_filled.pdf");

        // Проверяем HTML содержимое
        assertNotNull(htmlContent, "HTML содержимое не должно быть null");
        assertTrue(htmlContent.contains("Протокол проверки № 12345"), "HTML должен содержать номер документа");
        assertTrue(htmlContent.contains(LocalDate.now().format(DATE_FORMATTER)), "HTML должен содержать дату отчетности");
        assertTrue(htmlContent.contains("Форма 0420415"), "HTML должен содержать тип отчетности");
        assertTrue(htmlContent.contains("Найдены серьезные ошибки!"), "HTML должен содержать баннер об ошибках");
        assertTrue(htmlContent.contains("Обнаружены предупреждения:"), "HTML должен содержать баннер о предупреждениях");
    }

    /**
     * Тест: Пустые списки ошибок и предупреждений - только checksList
     */
    @Test
    @DisplayName("Пустые списки ошибок и предупреждений - только checksList")
    void testCreatePdfWithOnlyChecksList() throws IOException {
        // Given
        ProtocolModelDto dto = ProtocolModelDto.builder()
                .documentNumber("67890")
                .documentDate(LocalDate.now().format(DATE_FORMATTER))
                .checkDate(LocalDateTime.now().format(DATETIME_FORMATTER))
                .reportType("Форма 0420416")
                .objects(List.of()) // Пустой список ошибок
                .warnings(List.of()) // Пустой список предупреждений
                .checksList(List.of(
                        ProtocolCheckRecordDto.builder()
                                .checkType("Проверка баланса")
                                .checkResult("Выявлено")
                                .countingDeviation("5")
                                .build(),
                        ProtocolCheckRecordDto.builder()
                                .checkType("Проверка проводок")
                                .checkResult("Не выявлено")
                                .countingDeviation("0")
                                .build()
                ))
                .build();

        // When
        byte[] pdfBytes = outputFormingService.createPdf(dto);
        String htmlContent = outputFormingService.createHtml(dto);

        // Then
        assertNotNull(pdfBytes, "PDF байты не должны быть null");
        assertTrue(pdfBytes.length > 0, "PDF файл не должен быть пустым");

        // Сохраняем PDF для ручной проверки
        savePdfToFile(pdfBytes, "test_only_checks_list.pdf");

        // Проверяем HTML содержимое
        assertTrue(htmlContent.contains("Результат проверки:"), "HTML должен содержать заголовок результата");
        assertTrue(htmlContent.contains("Ошибок и предупреждений не найдено"), "HTML должен содержать сообщение об отсутствии ошибок");
        assertFalse(htmlContent.contains("Найдены серьезные ошибки!"), "HTML не должен содержать баннер об ошибках");
        assertFalse(htmlContent.contains("Обнаружены предупреждения:"), "HTML не должен содержать баннер о предупреждениях");
    }

    /**
     * Тест: Только ошибки (без предупреждений)
     */
    @Test
    @DisplayName("Только ошибки (без предупреждений)")
    void testCreatePdfWithOnlyErrors() throws IOException {
        // Given
        ProtocolModelDto dto = ProtocolModelDto.builder()
                .documentNumber("11111")
                .documentDate(LocalDate.now().format(DATE_FORMATTER))
                .checkDate(LocalDateTime.now().format(DATETIME_FORMATTER))
                .reportType("Форма 0420417")
                .objects(List.of(
                        ProtocolTableRecordDto.builder()
                                .objectName("Активы")
                                .isinNumber("RU0000000001")
                                .objectNumber("1")
                                .errorCode("E001")
                                .errorMessage("Несоответствие баланса")
                                .ruleType(RuleTypeEnum.E)
                                .build(),
                        ProtocolTableRecordDto.builder()
                                .objectName("Обязательства")
                                .isinNumber("RU0000000002")
                                .objectNumber("2")
                                .errorCode("E002")
                                .errorMessage("Отсутствует проводка")
                                .ruleType(RuleTypeEnum.E)
                                .build()
                ))
                .warnings(List.of()) // Пустой список
                .checksList(List.of())
                .build();

        // When
        byte[] pdfBytes = outputFormingService.createPdf(dto);
        String htmlContent = outputFormingService.createHtml(dto);

        // Then
        assertNotNull(pdfBytes, "PDF байты не должны быть null");
        assertTrue(pdfBytes.length > 0, "PDF файл не должен быть пустым");

        // Сохраняем PDF для ручной проверки
        savePdfToFile(pdfBytes, "test_only_errors.pdf");

        // Проверяем HTML содержимое
        assertTrue(htmlContent.contains("Найдены серьезные ошибки!"), "HTML должен содержать баннер об ошибках");
        assertTrue(htmlContent.contains("Показано 2 из 0"), "HTML должен содержать количество ошибок в новом формате");
        assertTrue(htmlContent.contains("Список ошибок"), "HTML должен содержать раздел ошибок");
        assertFalse(htmlContent.contains("Обнаружены предупреждения:"), "HTML не должен содержать баннер о предупреждениях");
        assertFalse(htmlContent.contains("Список предупреждений"), "HTML не должен содержать раздел предупреждений");
    }

    /**
     * Тест: Только предупреждения (без ошибок)
     */
    @Test
    @DisplayName("Только предупреждения (без ошибок)")
    void testCreatePdfWithOnlyWarnings() throws IOException {
        // Given
        ProtocolModelDto dto = ProtocolModelDto.builder()
                .documentNumber("22222")
                .documentDate(LocalDate.now().format(DATE_FORMATTER))
                .checkDate(LocalDateTime.now().format(DATETIME_FORMATTER))
                .reportType("Форма 0420418")
                .objects(List.of()) // Пустой список
                .warnings(List.of(
                        ProtocolTableRecordDto.builder()
                                .objectName("Доходы")
                                .isinNumber("RU0000000003")
                                .objectNumber("3")
                                .errorCode("W001")
                                .errorMessage("Небольшое отклонение")
                                .ruleType(RuleTypeEnum.W)
                                .build(),
                        ProtocolTableRecordDto.builder()
                                .objectName("Расходы")
                                .isinNumber("RU0000000004")
                                .objectNumber("4")
                                .errorCode("W002")
                                .errorMessage("Требуется уточнение")
                                .ruleType(RuleTypeEnum.W)
                                .build()
                ))
                .checksList(List.of())
                .build();

        // When
        byte[] pdfBytes = outputFormingService.createPdf(dto);
        String htmlContent = outputFormingService.createHtml(dto);

        // Then
        assertNotNull(pdfBytes, "PDF байты не должны быть null");
        assertTrue(pdfBytes.length > 0, "PDF файл не должен быть пустым");

        // Сохраняем PDF для ручной проверки
        savePdfToFile(pdfBytes, "test_only_warnings.pdf");

        // Проверяем HTML содержимое
        assertTrue(htmlContent.contains("Обнаружены предупреждения:"), "HTML должен содержать баннер о предупреждениях");
        assertTrue(htmlContent.contains("Показано 2 из 0"), "HTML должен содержать количество предупреждений в новом формате");
        assertTrue(htmlContent.contains("Список предупреждений"), "HTML должен содержать раздел предупреждений");
        assertFalse(htmlContent.contains("Найдены серьезные ошибки!"), "HTML не должен содержать баннер об ошибках");
        assertFalse(htmlContent.contains("Список ошибок"), "HTML не должен содержать раздел ошибок");
    }

    /**
     * Тест: Null значения в списках
     */
    @Test
    @DisplayName("Null значения в списках")
    void testCreatePdfWithNullLists() throws IOException {
        // Given - передаем null вместо пустых списков
        ProtocolModelDto dto = ProtocolModelDto.builder()
                .documentNumber("44444")
                .documentDate(LocalDate.now().format(DATE_FORMATTER))
                .checkDate(LocalDateTime.now().format(DATETIME_FORMATTER))
                .reportType("Форма 0420420")
                .objects(null)
                .warnings(null)
                .checksList(null)
                .build();

        // When
        assertDoesNotThrow(() -> {
            byte[] pdfBytes = outputFormingService.createPdf(dto);
            String htmlContent = outputFormingService.createHtml(dto);
            assertNotNull(pdfBytes);
            assertNotNull(htmlContent);
        }, "Метод должен обрабатывать null списки без исключений");

        // Сохраняем PDF для ручной проверки
        savePdfToFile(outputFormingService.createPdf(dto), "test_null_lists.pdf");
    }

    /**
     * Тест: Частично заполненные объекты
     */
//    @Test
//    @DisplayName("Частично заполненные объекты")
    void testCreatePdfWithPartiallyFilledObjects() throws IOException {
        // Given - объекты с отсутствующими полями
        ProtocolTableRecordDto error1 = ProtocolTableRecordDto.builder()
                .objectName("Активы")
                .errorCode("E001")
                .errorMessage("Ошибка в активе")
                .ruleType(RuleTypeEnum.E)
                .build();

        ProtocolTableRecordDto warning1 = ProtocolTableRecordDto.builder()
                .objectName("Пассивы")
                .errorCode("W001")
                .ruleType(RuleTypeEnum.W)
                .build();

        ProtocolModelDto dto = ProtocolModelDto.builder()
                .documentNumber("55555")
                .documentDate(LocalDate.now().format(DATE_FORMATTER))
                .checkDate(LocalDateTime.now().format(DATETIME_FORMATTER))
                .reportType("Форма 0420421")
                .objects(List.of(error1))
                .warnings(List.of(warning1))
                .checksList(List.of())
                .build();

        // When
        byte[] pdfBytes = outputFormingService.createPdf(dto);
        String htmlContent = outputFormingService.createHtml(dto);

        // Then
        assertNotNull(pdfBytes, "PDF байты не должны быть null");
        assertTrue(pdfBytes.length > 0, "PDF файл не должен быть пустым");

        // Сохраняем PDF для ручной проверки
        savePdfToFile(pdfBytes, "test_partially_filled_objects.pdf");

        // Проверяем HTML содержимое
        assertTrue(htmlContent.contains("Активы"), "HTML должен содержать имя объекта");
        assertTrue(htmlContent.contains("Пассивы"), "HTML должен содержать имя объекта");
    }

    /**
     * Тест: Пустые строки в полях
     */
    @Test
    @DisplayName("Пустые строки в полях")
    void testCreatePdfWithEmptyStrings() throws IOException {
        // Given - пустые строки вместо null
        ProtocolModelDto dto = ProtocolModelDto.builder()
                .documentNumber("")
                .documentDate("")
                .checkDate("")
                .reportType("")
                .objects(List.of())
                .warnings(List.of())
                .checksList(List.of())
                .build();

        // When
        assertDoesNotThrow(() -> {
            byte[] pdfBytes = outputFormingService.createPdf(dto);
            String htmlContent = outputFormingService.createHtml(dto);
            assertNotNull(pdfBytes);
            assertNotNull(htmlContent);
        }, "Метод должен обрабатывать пустые строки без исключений");

        // Сохраняем PDF для ручной проверки
        savePdfToFile(outputFormingService.createPdf(dto), "test_empty_strings.pdf");
    }

    /**
     * Тест: Большие списки данных
     */
    @Test
    @DisplayName("Большие списки данных")
    void testCreatePdfWithLargeLists() throws IOException {
        // Given - большие списки
        List<ProtocolTableRecordDto> largeErrors = List.of(
                ProtocolTableRecordDto.builder().objectName("Ошибка 1").errorCode("E001").errorMessage("Сообщение 1").ruleType(RuleTypeEnum.E).build(),
                ProtocolTableRecordDto.builder().objectName("Ошибка 2").errorCode("E002").errorMessage("Сообщение 2").ruleType(RuleTypeEnum.E).build(),
                ProtocolTableRecordDto.builder().objectName("Ошибка 3").errorCode("E003").errorMessage("Сообщение 3").ruleType(RuleTypeEnum.E).build(),
                ProtocolTableRecordDto.builder().objectName("Ошибка 4").errorCode("E004").errorMessage("Сообщение 4").ruleType(RuleTypeEnum.E).build(),
                ProtocolTableRecordDto.builder().objectName("Ошибка 5").errorCode("E005").errorMessage("Сообщение 5").ruleType(RuleTypeEnum.E).build()
        );

        ProtocolModelDto dto = ProtocolModelDto.builder()
                .documentNumber("66666")
                .documentDate(LocalDate.now().format(DATE_FORMATTER))
                .checkDate(LocalDateTime.now().format(DATETIME_FORMATTER))
                .reportType("Форма 0420422")
                .objects(largeErrors)
                .warnings(List.of())
                .checksList(List.of())
                .build();

        // When
        byte[] pdfBytes = outputFormingService.createPdf(dto);
        String htmlContent = outputFormingService.createHtml(dto);

        // Then
        assertNotNull(pdfBytes, "PDF байты не должны быть null");
        assertTrue(pdfBytes.length > 0, "PDF файл не должен быть пустым");

        // Сохраняем PDF для ручной проверки
        savePdfToFile(pdfBytes, "test_large_lists.pdf");

        // Проверяем HTML содержимое
        assertTrue(htmlContent.contains("Показано 5 из 0"), "HTML должен содержать правильное количество ошибок");
    }

    /**
     * Тест: Баннер ошибок с checksList — проверка формата Показано N из M
     */
    @Test
    @DisplayName("Баннер ошибок с checksList")
    void testErrorBannerWithChecksListCounts() throws IOException {
        // Given — objects с 2 ошибками, warnings с 1 предупреждением,
        //          checksList с 2 записями ошибок (ruleType=E) суммарно 12 и 1 записью предупреждения (ruleType=W) со значением 3
        ProtocolModelDto dto = ProtocolModelDto.builder()
                .documentNumber("99999")
                .documentDate(LocalDate.now().format(DATE_FORMATTER))
                .checkDate(LocalDateTime.now().format(DATETIME_FORMATTER))
                .reportType("Форма 0420422")
                .objects(List.of(
                        ProtocolTableRecordDto.builder().objectName("Активы").errorCode("E001").errorMessage("Ошибка 1").ruleType(RuleTypeEnum.E).build(),
                        ProtocolTableRecordDto.builder().objectName("Пассивы").errorCode("E002").errorMessage("Ошибка 2").ruleType(RuleTypeEnum.E).build()
                ))
                .warnings(List.of(
                        ProtocolTableRecordDto.builder().objectName("Доходы").errorCode("W001").errorMessage("Предупреждение 1").ruleType(RuleTypeEnum.W).build()
                ))
                .checksList(List.of(
                        ProtocolCheckRecordDto.builder()
                                .checkType("Проверка баланса")
                                .checkResult("Выявлено")
                                .countingDeviation("5")
                                .ruleType(RuleTypeEnum.E)
                                .build(),
                        ProtocolCheckRecordDto.builder()
                                .checkType("Проверка проводок")
                                .checkResult("Выявлено")
                                .countingDeviation("7")
                                .ruleType(RuleTypeEnum.E)
                                .build(),
                        ProtocolCheckRecordDto.builder()
                                .checkType("Проверка отчета")
                                .checkResult("Выявлено")
                                .countingDeviation("3")
                                .ruleType(RuleTypeEnum.W)
                                .build()
                ))
                .totalErrorCount(12)
                .totalWarningCount(3)
                .build();

        // When
        String htmlContent = outputFormingService.createHtml(dto);

        // Then
        assertTrue(htmlContent.contains("Показано 2 из 12"), "Баннер ошибок: должно быть 'Показано 2 из 12'");
        assertTrue(htmlContent.contains("Показано 1 из 3"), "Баннер предупреждений: должно быть 'Показано 1 из 3'");
        assertTrue(htmlContent.contains("Найдены серьезные ошибки!"), "HTML должен содержать баннер об ошибках");
        assertTrue(htmlContent.contains("Обнаружены предупреждения:"), "HTML должен содержать баннер о предупреждениях");
    }

    /**
     * Тест: Специальные символы в данных
     */
    @Test
    @DisplayName("Специальные символы в данных")
    void testCreatePdfWithSpecialCharacters() throws IOException {
        // Given - специальные символы
        ProtocolModelDto dto = ProtocolModelDto.builder()
                .documentNumber("77777 <>&\"'")
                .documentDate(LocalDate.now().format(DATE_FORMATTER))
                .checkDate(LocalDateTime.now().format(DATETIME_FORMATTER))
                .reportType("Форма 0420423 <>&\"'")
                .objects(List.of(
                        ProtocolTableRecordDto.builder()
                                .objectName("Тест <>&\"'")
                                .errorCode("E001")
                                .errorMessage("Сообщение с <>&\"' символами")
                                .ruleType(RuleTypeEnum.E)
                                .build()
                ))
                .warnings(List.of())
                .checksList(List.of())
                .build();

        // When
        assertDoesNotThrow(() -> {
            byte[] pdfBytes = outputFormingService.createPdf(dto);
            String htmlContent = outputFormingService.createHtml(dto);
            assertNotNull(pdfBytes);
            assertNotNull(htmlContent);
        }, "Метод должен обрабатывать специальные символы без исключений");

        // Сохраняем PDF для ручной проверки
        savePdfToFile(outputFormingService.createPdf(dto), "test_special_characters.pdf");
    }

    /**
     * Тест: Проверка формирования HTML через FreemarkerResolverService напрямую
     */
    @Test
    @DisplayName("Проверка формирования HTML через FreemarkerResolverService")
    void testHtmlGenerationDirectly() {
        // Given
        ProtocolModelDto dto = createFullProtocolModelDto();

        // When
        String htmlContent = freemarkerResolverService.resolve(dto);

        // Then
        assertNotNull(htmlContent, "HTML содержимое не должно быть null");
        assertTrue(htmlContent.contains("<!DOCTYPE html>"), "HTML должен содержать DOCTYPE");
        assertTrue(htmlContent.contains("<html"), "HTML должен содержать тег html");
        assertTrue(htmlContent.contains("</html>"), "HTML должен закрываться тегом html");
    }

    /**
     * Вспомогательный метод: создание полной модели протокола
     */
    private ProtocolModelDto createFullProtocolModelDto() {
        return ProtocolModelDto.builder()
                .documentNumber("12345")
                .documentDate(LocalDate.now().format(DATE_FORMATTER))
                .checkDate(LocalDateTime.now().format(DATETIME_FORMATTER))
                .reportType("Форма 0420415")
                .objects(List.of(
                        ProtocolTableRecordDto.builder()
                                .objectName("Активы")
                                .isinNumber("RU0000000001")
                                .objectNumber("1")
                                .errorCode("E001")
                                .errorMessage("Несоответствие баланса активов")
                                .ruleType(RuleTypeEnum.E)
                                .build(),
                        ProtocolTableRecordDto.builder()
                                .objectName("Обязательства")
                                .isinNumber("RU0000000002")
                                .objectNumber("2")
                                .errorCode("E002")
                                .errorMessage("Несоответствие баланса обязательств")
                                .ruleType(RuleTypeEnum.E)
                                .build()
                ))
                .warnings(List.of(
                        ProtocolTableRecordDto.builder()
                                .objectName("Доходы")
                                .isinNumber("RU0000000003")
                                .objectNumber("3")
                                .errorCode("W001")
                                .errorMessage("Небольшое отклонение доходов")
                                .ruleType(RuleTypeEnum.W)
                                .build(),
                        ProtocolTableRecordDto.builder()
                                .objectName("Расходы")
                                .isinNumber("RU0000000004")
                                .objectNumber("4")
                                .errorCode("W002")
                                .errorMessage("Требуется уточнение расходов")
                                .ruleType(RuleTypeEnum.W)
                                .build()
                ))
                .checksList(List.of(
                        ProtocolCheckRecordDto.builder()
                                .checkType("Проверка баланса")
                                .checkResult("Выявлено")
                                .countingDeviation("5")
                                .build(),
                        ProtocolCheckRecordDto.builder()
                                .checkType("Проверка проводок")
                                .checkResult("Не выявлено")
                                .countingDeviation("0")
                                .build()
                ))
                .build();
    }

    /**
     * Вспомогательный метод: сохранение PDF файла
     */
    private void savePdfToFile(byte[] pdfBytes, String fileName) throws IOException {
        Path filePath = Paths.get(TEST_PDFS_DIR, fileName);
        Files.write(filePath, pdfBytes);
        System.out.println("PDF сохранен: " + filePath.toAbsolutePath());
    }
}
