package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import ru.sbrf.gmap.vux.config.FeatureToogleConfig;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationResultViewEntity;
import ru.sbrf.gmap.vux.service.checks.DataContextProvider;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Фаза 2 — существующий документ (аналитика cuv-csv-ecm-supz-flow, 7.3, 7.5; сценарии раздела 11).
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("ExistingDocumentProcessingService — фаза 2 и legacy-путь")
class ExistingDocumentProcessingServiceTest {

    private static final int DOC_ID = 100;
    private static final String FORM = "0420415.1.3";
    private static final String PROTOCOL_ECM_ID = "protocol-ecm-id";
    private static final List<String> CSV_ECM_IDS = List.of("ctx-ecm", "unit-ecm", "value-ecm");

    @Mock
    private ProtocolBuildingService protocolBuildingService;
    @Mock
    private ValidationDefectsService validationDefectsService;
    @Mock
    private PostUploadActionsService postUploadActionsService;
    @Mock
    private DocumentEcmExportService documentEcmExportService;
    @Mock
    private DataContextProvider provider;

    private final ProtocolModelDto protocol = ProtocolModelDto.builder().build();

    @BeforeEach
    void setUp() {
        when(provider.supportedDocTypeCode()).thenReturn(FORM);
        when(validationDefectsService.getResultsForDocWithRnLimit(DOC_ID)).thenReturn(List.of());
        when(validationDefectsService.getErrorsList(anyList())).thenReturn(List.of());
        when(validationDefectsService.getWarningsList(anyList())).thenReturn(List.of());
        when(validationDefectsService.getChecksByDocId(DOC_ID)).thenReturn(List.of());
        when(validationDefectsService.getCuvErrors(DOC_ID)).thenReturn(List.of());
        when(protocolBuildingService.createProtocolModelDto(anyList(), anyList(), anyList(), any())).thenReturn(protocol);
        when(protocolBuildingService.createCuvErrorProtocol(any(), anyList(), anyList(), anyList(), anyList())).thenReturn(protocol);
        when(documentEcmExportService.evaluateCuvCsvExport(DOC_ID))
                .thenReturn(new DocumentEcmExportService.ExportState(true, CSV_ECM_IDS));
        when(postUploadActionsService.protocolResultText(anyLong())).thenReturn("result");
        when(postUploadActionsService.createSupzTask(any(), anyList(), anyString())).thenReturn(true);
        when(postUploadActionsService.sendErrorMail(any(), any())).thenReturn(true);
        when(postUploadActionsService.isErrorMailSent(any())).thenReturn(false);
        when(postUploadActionsService.handlePostUploadActions(any(), any(), anyList())).thenReturn(true);
    }

    private ExistingDocumentProcessingService service(boolean cuvEnabled) {
        return new ExistingDocumentProcessingService(new FeatureToogleConfig(cuvEnabled), protocolBuildingService,
                validationDefectsService, postUploadActionsService, documentEcmExportService, List.of(provider));
    }

    private static VuxDocumentScheduleViewEntity record(String checkMode, String ecmId) {
        VuxDocumentScheduleViewEntity record = new VuxDocumentScheduleViewEntity();
        record.setScheduleId(10);
        record.setResultDocumentId(DOC_ID);
        record.setDocTypeCode(FORM);
        record.setCheckMode(checkMode);
        record.setEcmId(ecmId);
        record.setWarningCount(3L);
        return record;
    }

    private void viewErrors() {
        when(validationDefectsService.getErrorsList(anyList()))
                .thenReturn(List.of(mock(VuxDocumentValidationResultViewEntity.class)));
    }

    private void cuvErrors() {
        when(validationDefectsService.getCuvErrors(DOC_ID))
                .thenReturn(List.of(new ValidationErrorDto("t", "DCUV_0420415_1_3_005", "m")));
    }

    @Test
    @DisplayName("supports: только записи с ecm_id")
    void supports_onlyWithEcmId() {
        assertThat(service(true).supports(record("cuv", PROTOCOL_ECM_ID))).isTrue();
        assertThat(service(true).supports(record("cuv", null))).isFalse();
    }

    @Test
    @DisplayName("T-6: все CSV готовы — задача СУПЗ: CSV context, unit, value, затем протокол; закрытие")
    void allCsvReady_createsSupzTask() {
        VuxDocumentScheduleViewEntity record = record("cuv", PROTOCOL_ECM_ID);

        ProcessingResult result = service(true).processDocument(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(postUploadActionsService).protocolResultText(3L);
        verify(postUploadActionsService).createSupzTask(record,
                List.of("ctx-ecm", "unit-ecm", "value-ecm", PROTOCOL_ECM_ID), "result");
    }

    @Test
    @DisplayName("T-7, T-8: CSV не готовы (ожидание или окончательный отказ) — без СУПЗ, расписание открыто")
    void csvNotReady_pending() {
        when(documentEcmExportService.evaluateCuvCsvExport(DOC_ID))
                .thenReturn(new DocumentEcmExportService.ExportState(false, List.of()));

        ProcessingResult result = service(true).processDocument(record("cuv", PROTOCOL_ECM_ID));

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(postUploadActionsService, never()).createSupzTask(any(), anyList(), anyString());
    }

    @Test
    @DisplayName("T-11: сбой СУПЗ — расписание открыто")
    void supzFailed_pending() {
        when(postUploadActionsService.createSupzTask(any(), anyList(), anyString())).thenReturn(false);

        assertThat(service(true).processDocument(record("cuv", PROTOCOL_ECM_ID))).isEqualTo(ProcessingResult.PENDING);
    }

    @Test
    @DisplayName("T-10: supz_task_id заполнен (задача создана или флаг U) — закрытие без СУПЗ и без чтения выгрузки")
    void supzTaskAlreadySet_resolves() {
        VuxDocumentScheduleViewEntity record = record("cuv", PROTOCOL_ECM_ID);
        record.setSupzTaskId("1");

        ProcessingResult result = service(true).processDocument(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(documentEcmExportService, never()).evaluateCuvCsvExport(any());
        verify(postUploadActionsService, never()).createSupzTask(any(), anyList(), anyString());
    }

    @Test
    @DisplayName("T-15: ошибки CUV, письма нет — письмо с CUV-ошибками, закрытие; без выгрузки и СУПЗ")
    void cuvErrors_noMail_sendsMail() {
        cuvErrors();
        VuxDocumentScheduleViewEntity record = record("cuv", PROTOCOL_ECM_ID);

        ProcessingResult result = service(true).processDocument(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(protocolBuildingService).createCuvErrorProtocol(eq(record), anyList(), anyList(), anyList(), anyList());
        verify(postUploadActionsService).sendErrorMail(record, protocol);
        verify(documentEcmExportService, never()).evaluateCuvCsvExport(any());
        verify(postUploadActionsService, never()).createSupzTask(any(), anyList(), anyString());
    }

    @Test
    @DisplayName("T-16: только ошибки view, письма нет — протокол view, письмо, закрытие")
    void viewErrors_noMail_sendsMail() {
        viewErrors();
        VuxDocumentScheduleViewEntity record = record("cuv", PROTOCOL_ECM_ID);

        ProcessingResult result = service(true).processDocument(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(protocolBuildingService).createProtocolModelDto(anyList(), anyList(), anyList(), eq(record));
        verify(protocolBuildingService, never()).createCuvErrorProtocol(any(), anyList(), anyList(), anyList(), anyList());
        verify(postUploadActionsService).sendErrorMail(record, protocol);
    }

    @Test
    @DisplayName("T-17: ошибки есть, письмо уже в t_vux_mail — закрытие без письма")
    void errors_mailAlreadySent_resolvesWithoutMail() {
        cuvErrors();
        when(postUploadActionsService.isErrorMailSent(any())).thenReturn(true);

        ProcessingResult result = service(true).processDocument(record("cuv", PROTOCOL_ECM_ID));

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(postUploadActionsService, never()).sendErrorMail(any(), any());
    }

    @Test
    @DisplayName("T-18: ошибки есть, сбой отправки письма — расписание открыто")
    void errors_mailFailed_pending() {
        viewErrors();
        when(postUploadActionsService.sendErrorMail(any(), any())).thenReturn(false);

        assertThat(service(true).processDocument(record("cuv", PROTOCOL_ECM_ID))).isEqualTo(ProcessingResult.PENDING);
    }

    @Test
    @DisplayName("T-20: флаг U и ошибки — письмо всё равно отправляется")
    void flagU_withErrors_sendsMail() {
        cuvErrors();
        VuxDocumentScheduleViewEntity record = record("cuv", PROTOCOL_ECM_ID);
        record.setSupzTaskId("1");

        ProcessingResult result = service(true).processDocument(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(postUploadActionsService).sendErrorMail(record, protocol);
    }

    @Test
    @DisplayName("T-13, T-14: ecm_id = '-1' — legacy-путь (D-27), вложение '-1', без выгрузки")
    void ecmIdMinusOne_legacy() {
        VuxDocumentScheduleViewEntity record = record("cuv", "-1");

        ProcessingResult result = service(true).processDocument(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(postUploadActionsService).handlePostUploadActions(record, protocol, List.of("-1"));
        verify(documentEcmExportService, never()).evaluateCuvCsvExport(any());
        verify(validationDefectsService, never()).getCuvErrors(any());
    }

    @Test
    @DisplayName("Фича-флаг выключен — legacy-путь (D-18)")
    void toggleOff_legacy() {
        VuxDocumentScheduleViewEntity record = record("cuv", PROTOCOL_ECM_ID);

        service(false).processDocument(record);

        verify(postUploadActionsService).handlePostUploadActions(record, protocol, List.of(PROTOCOL_ECM_ID));
        verify(documentEcmExportService, never()).evaluateCuvCsvExport(any());
    }

    @Test
    @DisplayName("Нет провайдера формы — legacy-путь (D-41)")
    void noProvider_legacy() {
        VuxDocumentScheduleViewEntity record = record("cuv", PROTOCOL_ECM_ID);
        record.setDocTypeCode("0420415.3");

        service(true).processDocument(record);

        verify(postUploadActionsService).handlePostUploadActions(record, protocol, List.of(PROTOCOL_ECM_ID));
        verify(documentEcmExportService, never()).evaluateCuvCsvExport(any());
    }

    @Test
    @DisplayName("T-12: check_mode = null — legacy-путь, сбой пост-обработки оставляет расписание открытым")
    void checkModeNull_legacy() {
        when(postUploadActionsService.handlePostUploadActions(any(), any(), anyList())).thenReturn(false);

        ProcessingResult result = service(true).processDocument(record(null, PROTOCOL_ECM_ID));

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(documentEcmExportService, never()).evaluateCuvCsvExport(any());
    }

    @Test
    @DisplayName("Неожиданное исключение — расписание открыто")
    void unexpectedException_pending() {
        when(validationDefectsService.getResultsForDocWithRnLimit(DOC_ID)).thenThrow(new IllegalStateException("boom"));

        assertThat(service(true).processDocument(record("cuv", PROTOCOL_ECM_ID))).isEqualTo(ProcessingResult.PENDING);
    }
}
