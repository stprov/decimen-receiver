package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import ru.sbrf.gmap.vux.VuxApplicationTests;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ContextDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13UnitDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;
import ru.sbrf.gmap.vux.dto.response.CreateContentsResponse;
import ru.sbrf.gmap.vux.dto.response.CreateContentsResponse.CreateContentsDocument;
import ru.sbrf.gmap.vux.dto.response.ResponseResult;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolTableRecordDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolCheckRecordDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationLogEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationResultViewEntity;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V13ContextEntity;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;
import ru.sbrf.gmap.vux.facade.EcmDocumentFacade;
import ru.sbrf.gmap.vux.facade.supz.SupzTaskFacade;
import ru.sbrf.gmap.vux.model.DocumentTypeEnum;
import ru.sbrf.gmap.vux.model.jsonrpc.SupzTaskResponseWrapper;
import ru.sbrf.gmap.vux.model.supz.request.SupzRequest;
import ru.sbrf.gmap.vux.model.supz.request.SupzTaskDataRequest;
import ru.sbrf.gmap.vux.model.supz.response.SupzTaskResponse;
import ru.sbrf.gmap.vux.model.supz.response.SupzTaskResponseData;
import ru.sbrf.gmap.vux.repository.VuxDocumentScheduleViewRepository;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationLogRepository;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;
import ru.sbrf.gmap.vux.repository.VuxForm0420415V13ContextRepository;
import ru.sbrf.gmap.vux.repository.VuxForm0420415V13UnitRepository;
import ru.sbrf.gmap.vux.repository.VuxForm0420415V13ValueRepository;
import ru.sbrf.gmap.vux.repository.VuxForm0420415V13DataRepository;
import ru.sbrf.gmap.vux.repository.VuxDataXbrlLinkRepository;
import ru.sbrf.gmap.vux.repository.AdmXbrlEnumValuesRepository;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@DisplayName("Интеграционный тест OrchestratorService")
@SpringBootTest
@ActiveProfiles("test")
@Disabled // TODO вместо 10 проверки выведен mock
class OrchestratorServiceIntegrationTest extends VuxApplicationTests {

    @Autowired
    private OrchestratorService orchestratorService;

    @MockitoBean
    private VuxDocumentScheduleViewRepository scheduleViewRepository;

    @MockitoBean
    private VuxDocumentValidationResultViewRepository validationResultViewRepository;

    @MockitoBean
    private VuxDocumentValidationLogRepository validationLogRepository;

    @Autowired
    private OutputFormingService outputFormingService;

    @MockitoBean
    private MailService mailService;

    @MockitoBean
    private SupzTaskFacade supzTaskFacade;

    @MockitoBean
    private VuxForm0420415V13ContextRepository vuxForm0420415V13ContextRepository;

    @MockitoBean
    private VuxForm0420415V13UnitRepository vuxForm0420415V13UnitRepository;

    @MockitoBean
    private VuxForm0420415V13ValueRepository vuxForm0420415V13ValueRepository;

    @MockitoBean
    private VuxForm0420415V13DataRepository vuxForm0420415V13DataRepository;

    @MockitoBean
    private VuxDataXbrlLinkRepository vuxDataXbrlLinkRepository;

    @MockitoBean
    private AdmXbrlEnumValuesRepository admXbrlEnumValuesRepository;

    @MockitoBean
    private ValidationDataService validationDataService;


    @MockitoBean
    private EcmDocumentFacade ecmDocumentFacade;

    private static final String TEST_OUTPUT_DIR = "target/test-outputs";

    private static final Integer errorSet = 30;

    private static final Integer totalSet = 200;

    @BeforeEach
    void setUp() throws Exception {
        // Очистка данных перед каждым тестом
        // Не вызываем deleteAll, так как репозиторий мокированный

        // Создание тестовой директории для выходных файлов
        Path testDir = Path.of(TEST_OUTPUT_DIR);
        if (!Files.exists(testDir)) {
            Files.createDirectories(testDir);
        }

        // Мокируем.findAll для получения пустого списка по умолчанию
        when(scheduleViewRepository.findAll()).thenReturn(List.of());
        when(validationResultViewRepository.processSchedule()).thenReturn(Optional.empty());
    }

    @Test
    @DisplayName("Тест обработки нового документа с ошибками - должен отправить письмо")
    void testProcessNewDocumentWithErrors() {
        // given
        Integer resultDocId = 1001;
        Integer scheduleId = 2001;
        String docNumber = "DOC-2025-001";
        String docTypeName = "Баланс";
        String docTypeCode = "BAL";
        String ecmClassName = "XBRL_VUX_RFVP_DOCUMENT";

        // Создаем запись без ecmId (новый документ)
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, docNumber, docTypeName, docTypeCode, ecmClassName, null
        );

        // Создаем ошибки валидации
        VuxDocumentValidationResultViewEntity error1 = createValidationResult(
                1, resultDocId, "Активы", "RU0000000001", 1L, "ERR001", "Ошибка в строке 1", RuleTypeEnum.E
        );
        VuxDocumentValidationResultViewEntity error2 = createValidationResult(
                2, resultDocId, "Пассивы", "RU0000000002", 2L, "ERR002", "Ошибка в строке 2", RuleTypeEnum.E
        );
        validationResultViewRepository.saveAll(List.of(error1, error2));

        // Создаем лог проверки
        VuxDocumentValidationLogEntity logEntry = createValidationLog(1, resultDocId, "Проверка баланса", 2, "Выявлено");

        // Мокируем загрузку документа в ECM с подписью
        CreateContentsResponse response = new CreateContentsResponse(
                List.of(new CreateContentsDocument("doc-id-123", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
        );
        when(ecmDocumentFacade.uploadSignedDocument(any(byte[].class), anyString(), any(), anyList()))
                .thenReturn(Optional.of(response));
        // Мокируем saveAll для saveAll
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        // Мокируем flowSetEcmId
        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString())).thenReturn(Optional.empty());
        // Мокируем flowSetMailStatus
        when(validationResultViewRepository.flowSetMailStatus(anyInt(), anyString(), anyString(), anyString(), anyString())).thenReturn(Optional.empty());
        // Мокируем flowResolveShedule
        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());
        // Мокируем findAll для получения записей
        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        // Мокируем findAllByDocIdOrderByErrorCode
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(resultDocId)).thenReturn(List.of(logEntry));
        // Мокируем saveAll для saveAll
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        // Мокируем findById
        when(scheduleViewRepository.findById(scheduleId)).thenReturn(Optional.of(scheduleEntity));
        // Мокируем findByDocIdWithRnLimit с правильными аргументами (errorSet, totalSet)
        when(validationResultViewRepository.findByDocIdWithRnLimit(eq(resultDocId), eq(errorSet), eq(totalSet))).thenReturn(List.of(error1, error2));

        // when
        orchestratorService.run();

        // then
        verify(mailService, times(1)).sendMail(anyString(), anyString(), anyList(), anyList());
        verify(supzTaskFacade, never()).createTask(any(), any());

        // Проверяем, что ecmId был установлен
        verify(validationResultViewRepository, times(1)).flowSetEcmId(any(), any(), any());
        // Проверяем, что PDF был сгенерирован и отправлен в ECM с подписью
        verify(ecmDocumentFacade, times(1)).uploadSignedDocument(any(byte[].class), anyString(), any(), anyList());
        verify(supzTaskFacade, never()).createTask(any(), any());
    }

    @Test
    @DisplayName("Тест обработки нового документа без ошибок - должен создать задачу в SUPZ")
    void testProcessNewDocumentWithoutErrors() {
        // given
        Integer resultDocId = 1002;
        Integer scheduleId = 2002;
        String docNumber = "DOC-2025-002";
        String docTypeName = "Отчет о прибылях";
        String docTypeCode = "PROF";
        String ecmClassName = "XBRL_VUX_RFVP_DOCUMENT";

        // Создаем запись без ecmId (новый документ)
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, docNumber, docTypeName, docTypeCode, ecmClassName, null
        );

        // Создаем пустой список ошибок (без ошибок)
        // Создаем лог проверки без ошибок
        VuxDocumentValidationLogEntity logEntry = createValidationLog(1, resultDocId, "Проверка прибыли", 0, "Не выявлено");

        // Мокируем загрузку документа в ECM с подписью
        CreateContentsResponse response = new CreateContentsResponse(
                List.of(new CreateContentsDocument("doc-id-456", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
        );
        when(ecmDocumentFacade.uploadSignedDocument(any(byte[].class), anyString(), any(), anyList()))
                .thenReturn(Optional.of(response));
        // Мокируем flowSetEcmId
        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString())).thenReturn(Optional.empty());
        // Мокируем flowSetSupzId
        when(validationResultViewRepository.flowSetSupzId(anyInt(), anyString(), anyString(), anyString())).thenReturn(Optional.empty());
        // Мокируем flowResolveShedule
        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());
        // Мокируем findAll для получения записей
        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        // Мокируем findAllByDocIdOrderByErrorCode
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(resultDocId)).thenReturn(List.of(logEntry));
        // Мокируем saveAll для saveAll
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        // Мокируем findByDocIdWithRnLimit с правильными аргументами (errorSet, totalSet)
        when(validationResultViewRepository.findByDocIdWithRnLimit(eq(resultDocId), eq(errorSet), eq(totalSet))).thenReturn(List.of());

        // Мокируем ответ от SUPZ
        SupzTaskResponseData supzTaskData = new SupzTaskResponseData(
                UUID.randomUUID(),
                "srcId",
                "created",
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null
        );
        SupzTaskResponse supzTaskResponse = new SupzTaskResponse(
                supzTaskData,
                null,
                null,
                "success",
                null,
                null,
                null
        );
        SupzTaskResponseWrapper supzResponse = new SupzTaskResponseWrapper(supzTaskResponse, "{\"result\": \"success\"}");
        when(supzTaskFacade.createTask(any(), any())).thenReturn(supzResponse);
        // Мокируем flowSetSupzId
        when(validationResultViewRepository.flowSetSupzId(anyInt(), anyString(), anyString(), anyString())).thenReturn(Optional.empty());

        // when
        orchestratorService.run();

        // then
        verify(mailService, never()).sendMail(anyString(), anyString(), anyList(), anyList());
        verify(supzTaskFacade, times(1)).createTask(any(), any());

    }

    @Test
    @DisplayName("Тест обработки нового документа с только предупреждениями - должен создать задачу в SUPZ, но не отправить письмо")
    void testProcessNewDocumentWithOnlyWarnings() {
        // given
        Integer resultDocId = 1005;
        Integer scheduleId = 2005;
        String docNumber = "DOC-2025-005";
        String docTypeName = "Отчет о прибылях";
        String docTypeCode = "PROF";
        String ecmClassName = "XBRL_VUX_RFVP_DOCUMENT";

        // Создаем запись без ecmId (новый документ)
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, docNumber, docTypeName, docTypeCode, ecmClassName, null
        );

        // Создаем только предупреждения (без ошибок)
        VuxDocumentValidationResultViewEntity warning1 = createValidationResult(
                1, resultDocId, "Активы", "RU0000000001", 1L, "WARN001", "Предупреждение в активе", RuleTypeEnum.W
        );
        VuxDocumentValidationResultViewEntity warning2 = createValidationResult(
                2, resultDocId, "Пассивы", "RU0000000002", 2L, "WARN002", "Предупреждение в пассиве", RuleTypeEnum.W
        );
        validationResultViewRepository.saveAll(List.of(warning1, warning2));

        // Создаем лог проверки с предупреждениями
        VuxDocumentValidationLogEntity logEntry = createValidationLog(1, resultDocId, "Проверка прибыли", 2, "Выявлено");

        // Мокируем загрузку документа в ECM с подписью
        CreateContentsResponse response = new CreateContentsResponse(
                List.of(new CreateContentsDocument("doc-id-789", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
        );
        when(ecmDocumentFacade.uploadSignedDocument(any(byte[].class), anyString(), any(), anyList()))
                .thenReturn(Optional.of(response));
        // Мокируем flowSetEcmId
        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString())).thenReturn(Optional.empty());
        // Мокируем flowSetSupzId
        when(validationResultViewRepository.flowSetSupzId(anyInt(), anyString(), anyString(), anyString())).thenReturn(Optional.empty());
        // Мокируем flowResolveShedule
        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());
        // Мокируем findAll для получения записей
        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        // Мокируем findAllByDocIdOrderByErrorCode
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(resultDocId)).thenReturn(List.of(logEntry));
        // Мокируем saveAll для saveAll
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        // Мокируем findByDocIdWithRnLimit с правильными аргументами (errorSet, totalSet)
        when(validationResultViewRepository.findByDocIdWithRnLimit(eq(resultDocId), eq(errorSet), eq(totalSet))).thenReturn(List.of(warning1, warning2));

        // Мокируем ответ от SUPZ
        SupzTaskResponseData supzTaskData = new SupzTaskResponseData(
                UUID.randomUUID(),
                "srcId",
                "created",
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null
        );
        SupzTaskResponse supzTaskResponse = new SupzTaskResponse(
                supzTaskData,
                null,
                null,
                "success",
                null,
                null,
                null
        );
        SupzTaskResponseWrapper supzResponse = new SupzTaskResponseWrapper(supzTaskResponse, "{\"result\": \"success\"}");
        when(supzTaskFacade.createTask(any(), any())).thenReturn(supzResponse);
        // Мокируем flowSetSupzId
        when(validationResultViewRepository.flowSetSupzId(anyInt(), anyString(), anyString(), anyString())).thenReturn(Optional.empty());

        // when
        orchestratorService.run();

        // then
        // При наличии только предупреждений письмо не отправляется
        verify(mailService, never()).sendMail(anyString(), anyString(), anyList(), anyList());
        // А создается задача в SUPZ
        verify(supzTaskFacade, times(1)).createTask(any(), any());
    }

    @Test
    @DisplayName("Тест обработки существующего документа с ошибками")
    void testProcessExistingDocumentWithErrors() {
        // given
        Integer resultDocId = 1003;
        Integer scheduleId = 2003;
        String docNumber = "DOC-2025-003";
        String docTypeName = "Движение денежных средств";
        String docTypeCode = "CASH";
        String ecmClassName = "XBRL_VUX_RFVP_DOCUMENT";
        String existingEcmId = "existing-doc-id-789";

        // Создаем запись с ecmId (существующий документ)
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, docNumber, docTypeName, docTypeCode, ecmClassName, existingEcmId
        );

        // Создаем ошибки валидации
        VuxDocumentValidationResultViewEntity error = createValidationResult(
                1, resultDocId, "Денежные средства", "RU0000000003", 1L, "ERR003", "Ошибка в движении ДС", RuleTypeEnum.E
        );

        // Мокируем вызов processSchedule
        when(validationResultViewRepository.processSchedule()).thenReturn(Optional.empty());
        // Мокируем findAll для получения записей
        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        // Мокируем findByDocIdWithRnLimit
        when(validationResultViewRepository.findByDocIdWithRnLimit(eq(resultDocId), anyInt(), anyInt())).thenReturn(List.of(error));
        // Мокируем flowSetMailStatus
        when(validationResultViewRepository.flowSetMailStatus(anyInt(), anyString(), anyString(), anyString(), anyString())).thenReturn(Optional.empty());
        // Мокируем flowResolveShedule
        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());
        // Мокируем findAllByDocIdOrderByErrorCode
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(resultDocId)).thenReturn(List.of());
        // Мокируем saveAll для saveAll
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        // Мокируем findByDocIdWithRnLimit с правильными аргументами (errorSet, totalSet)
        when(validationResultViewRepository.findByDocIdWithRnLimit(eq(resultDocId), eq(errorSet), eq(totalSet))).thenReturn(List.of(error));

        // when
        orchestratorService.run();

        // then
        verify(mailService, times(1)).sendMail(anyString(), anyString(), anyList(), anyList());
        verify(supzTaskFacade, never()).createTask(any(), any());

    }


    @Test
    @DisplayName("Тест генерации имени протокола")
    void testProtocolNameGeneration() {
        // given
        String docTypeCode = "BAL";

        // when
        // Использем рефлексию для вызова приватного метода
        String protocolName = generateProtocolName(orchestratorService, docTypeCode);

        // then
        assertNotNull(protocolName);
        assertTrue(protocolName.startsWith("Протокол проверки"), "Protocol name should start with 'Протокол проверки'");
        assertTrue(protocolName.contains(docTypeCode), "Protocol name should contain doc type code");
        assertTrue(protocolName.endsWith(".pdf"), "Protocol name should end with .pdf");

        // Проверяем формат даты
        String today = LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        assertTrue(protocolName.contains(today), "Protocol name should contain current date");
    }

    @Test
    @DisplayName("Тест обработки пустого списка документов")
    void testProcessEmptyDocumentList() {
        // given - нет документов в базе

        // Мокируем вызов processSchedule
        when(validationResultViewRepository.processSchedule()).thenReturn(Optional.empty());
        // Мокируем findAll для получения пустого списка
        when(scheduleViewRepository.findAll()).thenReturn(List.of());

        // when
        orchestratorService.run();

        // then - не должно быть вызовов мокованных сервисов
        verify(mailService, never()).sendMail(anyString(), anyString(), anyList(), anyList());
        verify(supzTaskFacade, never()).createTask(any(), any());
        verify(ecmDocumentFacade, never()).uploadSignedDocument(any(), any(), any(), any());
    }

    @Test
    @DisplayName("Тест формирования модели протокола")
    void testProtocolModelDtoCreation() {
        // given
        Integer resultDocId = 1004;
        Integer scheduleId = 2004;
        String docNumber = "DOC-2025-004";
        String docTypeName = "Отчет о прибылях";
        String docTypeCode = "PROF";
        String ecmClassName = "XBRL_VUX_RFVP_DOCUMENT";

        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, docNumber, docTypeName, docTypeCode, ecmClassName, null
        );

        VuxDocumentValidationResultViewEntity error = createValidationResult(
                1, resultDocId, "Активы", "RU0000000001", 1L, "ERR001", "Ошибка в активе", RuleTypeEnum.E
        );
        VuxDocumentValidationResultViewEntity warning = createValidationResult(
                1, resultDocId, "Пассивы", "RU0000000002", 2L, "WARN001", "Предупреждение в пассиве", RuleTypeEnum.W
        );

        VuxDocumentValidationLogEntity logEntry = createValidationLog(1, resultDocId, "Проверка баланса", 1, "Выявлено");

        // Мокируем вызов processSchedule
        when(validationResultViewRepository.processSchedule()).thenReturn(Optional.empty());
        // Мокируем findAll для получения записей
        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        // Мокируем findByDocIdWithRnLimit
        when(validationResultViewRepository.findByDocIdWithRnLimit(eq(resultDocId), anyInt(), anyInt())).thenReturn(List.of(error, warning));
        // Мокируем flowSetMailStatus
        when(validationResultViewRepository.flowSetMailStatus(anyInt(), anyString(), anyString(), anyString(), anyString())).thenReturn(Optional.empty());
        // Мокируем flowResolveShedule
        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());
        // Мокируем findAllByDocIdOrderByErrorCode
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(resultDocId)).thenReturn(List.of(logEntry));
        // Мокируем загрузку документа в ECM
        CreateContentsResponse response = new CreateContentsResponse(
                List.of(new CreateContentsDocument("doc-id-123", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
        );
        // Мокируем загрузку документа в ECM с подписью
        when(ecmDocumentFacade.uploadSignedDocument(any(byte[].class), anyString(), any(), anyList()))
                .thenReturn(Optional.of(response));

        orchestratorService.run();

        // then
        // Проверяем, что письмо было отправлено (есть ошибки)
        verify(mailService, times(1)).sendMail(anyString(), anyString(), anyList(), anyList());

        // Проверяем содержимое письма
        ArgumentCaptor<String> subjectCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> bodyCaptor = ArgumentCaptor.forClass(String.class);
        verify(mailService).sendMail(subjectCaptor.capture(), bodyCaptor.capture(), anyList(), anyList());

        String subject = subjectCaptor.getValue();
        String body = bodyCaptor.getValue();

        assertNotNull(subject);
        assertTrue(subject.contains("Ошибки на отчетную дату"), "Subject should contain error date info");
        assertTrue(subject.contains(docTypeCode), "Subject should contain doc type code");

        assertNotNull(body);
        assertTrue(body.contains("Протокол проверки"), "Body should contain protocol title");
        assertTrue(body.contains("Найдены серьезные ошибки"), "Body should contain error banner");
        assertTrue(body.contains("Обнаружены предупреждения"), "Body should contain warning banner");
    }

    @Test
    @DisplayName("Тест обработки документа с уже заданным supz_task_id - не должен создавать задачу в СУПЗ")
    void testProcessWithSupzTaskIdAlreadySet() {
        // given
        Integer resultDocId = 1006;
        Integer scheduleId = 2006;
        String docNumber = "DOC-2025-006";
        String docTypeName = "Отчет о прибылях";
        String docTypeCode = "PROF";
        String ecmClassName = "XBRL_VUX_RFVP_DOCUMENT";
        String existingEcmId = "existing-doc-id-999";
        String existingSupzTaskId = "supz-task-12345";

        // Создаем запись с ecmId и уже заданным supz_task_id
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, docNumber, docTypeName, docTypeCode, ecmClassName, existingEcmId, existingSupzTaskId
        );

        // Создаем ошибки валидации (чтобы проверить, что они игнорируются)
        VuxDocumentValidationResultViewEntity error = createValidationResult(
                1, resultDocId, "Активы", "RU0000000001", 1L, "ERR001", "Ошибка в активе", RuleTypeEnum.E
        );

        // Мокируем вызов processSchedule
        when(validationResultViewRepository.processSchedule()).thenReturn(Optional.empty());
        // Мокируем findAll для получения записей
        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        // Мокируем findByDocIdWithRnLimit
        when(validationResultViewRepository.findByDocIdWithRnLimit(eq(resultDocId), anyInt(), anyInt())).thenReturn(Collections.emptyList());
        // Мокируем flowSetEcmId
        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString())).thenReturn(Optional.empty());
        // Мокируем flowSetMailStatus
        when(validationResultViewRepository.flowSetMailStatus(anyInt(), anyString(), anyString(), anyString(), anyString())).thenReturn(Optional.empty());
        // Мокируем flowResolveShedule
        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());
        // Мокируем findAllByDocIdOrderByErrorCountDesc
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(resultDocId)).thenReturn(List.of());
        // Мокируем загрузку документа в ECM
        CreateContentsResponse response = new CreateContentsResponse(
                List.of(new CreateContentsDocument("doc-id-999", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
        );
        when(ecmDocumentFacade.uploadSignedDocument(any(byte[].class), anyString(), any(DocumentTypeEnum.class), any()))
                .thenReturn(Optional.of(response));
        // Мокируем saveAll
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // when
        orchestratorService.run();

        // then
        // Проверяем, что задача в SUPZ не была создана (так как supz_task_id уже задан)
        verify(supzTaskFacade, never()).createTask(any(), any());
        // Проверяем, что письмо не отправлено (есть ошибки)
        verify(mailService, never()).sendMail(anyString(), anyString(), anyList(), anyList());
    }

    // Вспомогательные методы

    private VuxDocumentScheduleViewEntity createScheduleEntity(
            Integer scheduleId,
            Integer resultDocId,
            String docNumber,
            String docTypeName,
            String docTypeCode,
            String ecmClassName,
            String ecmId) {
        return createScheduleEntity(scheduleId, resultDocId, docNumber, docTypeName, docTypeCode, ecmClassName, ecmId, null);
    }

    private VuxDocumentScheduleViewEntity createScheduleEntity(
            Integer scheduleId,
            Integer resultDocId,
            String docNumber,
            String docTypeName,
            String docTypeCode,
            String ecmClassName,
            String ecmId,
            String supzTaskId) {
        VuxDocumentScheduleViewEntity entity = new VuxDocumentScheduleViewEntity();
        entity.setScheduleId(scheduleId);
        entity.setResultDocumentId(resultDocId);
        entity.setDocNumber(docNumber);
        entity.setDocTypeName(docTypeName);
        entity.setDocTypeCode(docTypeCode);
        entity.setEcmClassName(DocumentTypeEnum.valueOf(ecmClassName));
        entity.setEcmId(ecmId);
        entity.setSupzTaskId(supzTaskId);
        entity.setReportDate(Date.valueOf(LocalDate.now()));
        entity.setMailReceiversList("test@test.com");
        entity.setMailCopyList("cc@test.com");
        entity.setMailType(ru.sbrf.gmap.vux.entity.enums.MailType.SUCCESS);
        return entity;
    }

    private VuxDocumentValidationResultViewEntity createValidationResult(
            long id,
            Integer docId,
            String idLabel,
            String idText,
            Long line,
            String errorCode,
            String errorMessage,
            RuleTypeEnum ruleType) {
        return VuxDocumentValidationResultViewEntity.builder()
                .id(id)
                .docId(docId)
                .ruleId(1)
                .objectType("Balance")
                .line(line)
                .idText(idText)
                .idLabel(idLabel)
                .errorMessage(errorMessage)
                .errorCode(errorCode)
                .importantLevel(1)
                .ruleType(ruleType)
                .build();
    }

    private VuxDocumentValidationLogEntity createValidationLog(
            int id,
            Integer docId,
            String ruleType,
            Integer errorCount,
            String checkResult) {
        return new VuxDocumentValidationLogEntity(
                id, docId, 1, ruleType, "ERR", "Description", null, errorCount, checkResult
        );
    }

    private ProtocolModelDto createProtocolModelDto() {
        return ProtocolModelDto.builder()
                .documentNumber("DOC-2025-001")
                .documentDate(LocalDate.now().toString())
                .checkDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")))
                .reportType("Баланс")
                .objects(List.of(
                        ProtocolTableRecordDto.builder()
                                .objectName("Активы")
                                .isinNumber("RU0000000001")
                                .objectNumber("1")
                                .errorCode("ERR001")
                                .errorMessage("Ошибка в строке 1")
                                .ruleType(RuleTypeEnum.E)
                                .build(),
                        ProtocolTableRecordDto.builder()
                                .objectName("Пассивы")
                                .isinNumber("RU0000000002")
                                .objectNumber("2")
                                .errorCode("ERR002")
                                .errorMessage("Ошибка в строке 2")
                                .ruleType(RuleTypeEnum.E)
                                .build()
                ))
                .warnings(List.of(
                        ProtocolTableRecordDto.builder()
                                .objectName("Доходы")
                                .isinNumber("RU0000000003")
                                .objectNumber("3")
                                .errorCode("WARN001")
                                .errorMessage("Предупреждение в доходах")
                                .ruleType(RuleTypeEnum.W)
                                .build()
                ))
                .checksList(List.of(
                        ProtocolCheckRecordDto.builder()
                                .checkType("Проверка баланса")
                                .checkResult("Выявлено")
                                .countingDeviation("2")
                                .build()
                ))
                .build();
    }

    // ========================================================================
    // TC-CUV: CUV-тесты
    // ========================================================================

    @Test
    @DisplayName("TC-CUV-01: Стандартный пропуск — не CUV-форма")
    void testCuv01_StandardPass_NotCuvForm() {
        // given
        Integer resultDocId = 1101;
        Integer scheduleId = 2101;
        // docTypeCode не входит в CUV_FORM_DOC_TYPES (Set.of("0420415.1.3"))
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, "DOC-CUV-TC01", "Не CUV форма",
                "0420415.1.4", "XBRL_VUX_RFVP_DOCUMENT", null
        );

        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        when(validationResultViewRepository.findByDocIdWithRnLimit(anyInt(), anyInt(), anyInt())).thenReturn(List.of());
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(anyInt())).thenReturn(List.of());
        when(ecmDocumentFacade.uploadSignedDocument(any(), any(), any(), any()))
                .thenReturn(Optional.of(new CreateContentsResponse(
                        List.of(new CreateContentsDocument("ecm-id-cuv01", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
                )));
        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString())).thenReturn(Optional.empty());
        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // when
        orchestratorService.run();

        // then
        // CUV-блок не выполняется — CUV-репозитории не вызваны
        verify(vuxForm0420415V13ContextRepository, never()).findAll();
        // Стандартный путь — ECM загрузка должна быть
        verify(ecmDocumentFacade, atLeast(1)).uploadSignedDocument(any(), any(), any(), any());
    }

    @Test
    @Disabled // TODO вместо 10 проверки выведен mock
    @DisplayName("TC-CUV-02: CUV-форма — нет записей context")
    void testCuv02_CuvForm_NoContextRecords() {
        // given
        Integer resultDocId = 1102;
        Integer scheduleId = 2102;
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, "DOC-CUV-TC02", "CUV форма",
                "0420415.1.3", "XBRL_VUX_RFVP_DOCUMENT", null
        );

        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        // context-репозиторий возвращает пустой список
        when(vuxForm0420415V13ContextRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        // Остальные CUV-репозитории — не должны вызываться, но на всякий случай замокаем
        when(vuxForm0420415V13UnitRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13ValueRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13DataRepository.findByWorkflowRunId(anyInt())).thenReturn(List.of());
        when(vuxDataXbrlLinkRepository.findAll()).thenReturn(List.of());
        when(admXbrlEnumValuesRepository.findAll()).thenReturn(List.of());

        // when
        orchestratorService.run();

        // then
        // buildCheckDataContext логирует "No context records found for docId={}" и возвращает null
        // processCuvFormValidation() логирует "Failed to build CheckDataContext..."
        // Дальнейшая обработка пропускается
        verify(vuxForm0420415V13ContextRepository, times(1)).findByWorkflowRunId(anyLong());
        verify(validationDataService, never()).validate(any());
        // flowCuvSetError / flowResolveShedule НЕ вызываются для CUV-шага
        // resolveShedule всё равно вызывается в run() после processNewDocument
        verify(validationResultViewRepository, times(1)).flowResolveShedule(anyInt());
        // Никаких ECM-загрузок, писем, SUPZ
        verify(ecmDocumentFacade, never()).uploadSignedDocument(any(), any(), any(), any());
        verify(mailService, never()).sendMail(anyString(), anyString(), anyList(), anyList());
        verify(supzTaskFacade, never()).createTask(any(), any());
    }

    @Test
    @Disabled // TODO вместо 10 проверки выведен mock
    @DisplayName("TC-CUV-03: CUV-форма — нет записей context для docId")
    void testCuv03_CuvForm_NoContextForDocId() {
        // given
        Integer resultDocId = 1103;
        Integer scheduleId = 2103;
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, "DOC-CUV-TC03", "CUV форма",
                "0420415.1.3", "XBRL_VUX_RFVP_DOCUMENT", null
        );

        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        // findByWorkflowRunId возвращает пустой список (нет контекстов для данного docId)
        when(vuxForm0420415V13ContextRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13UnitRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13ValueRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13DataRepository.findByWorkflowRunId(anyInt())).thenReturn(List.of());
        when(vuxDataXbrlLinkRepository.findAll()).thenReturn(List.of());
        when(admXbrlEnumValuesRepository.findAll()).thenReturn(List.of());

        // when
        orchestratorService.run();

        // then
        verify(vuxForm0420415V13ContextRepository, times(1)).findByWorkflowRunId(anyLong());
        // Пустой контекст => buildCheckDataContext возвращает null
        verify(validationDataService, never()).validate(any());
        // Дальнейшая обработка прерывается
        verify(ecmDocumentFacade, never()).uploadSignedDocument(any(), any(), any(), any());
        verify(mailService, never()).sendMail(anyString(), anyString(), anyList(), anyList());
        verify(supzTaskFacade, never()).createTask(any(), any());
    }

    @Test
    @Disabled // TODO вместо 10 проверки выведен mock
    @DisplayName("TC-CUV-04: CUV — успех (без ошибок, без предупреждений)")
    void testCuv04_CuvForm_SuccessNoErrorsNoWarnings() {
        // given
        Integer resultDocId = 1104;
        Integer scheduleId = 2104;
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, "DOC-CUV-TC04", "CUV форма",
                "0420415.1.3", "XBRL_VUX_RFVP_DOCUMENT", null
        );

        // Создаём context с workflowRunId
        VuxForm0420415V13ContextEntity contextEntity = new VuxForm0420415V13ContextEntity();
        contextEntity.setWorkflowRunId(9999L);

        // Подготавливаем DTO для CSV
        VuxForm0420415V13ContextDto contextDto = VuxForm0420415V13ContextDto.builder()
                .uid(UUID.randomUUID())
                .contextId("ctx-1")
                .build();
        VuxForm0420415V13UnitDto unitDto = VuxForm0420415V13UnitDto.builder()
                .uid(UUID.randomUUID())
                .unitId("unit-1")
                .build();
        VuxForm0420415V13ValueDto valueDto = VuxForm0420415V13ValueDto.builder()
                .uid(UUID.randomUUID())
                .elementName("elem-1")
                .build();

        // Мок репозиториев
        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        when(vuxForm0420415V13ContextRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of(contextEntity));
        when(vuxForm0420415V13UnitRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13ValueRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13DataRepository.findByWorkflowRunId(anyInt())).thenReturn(List.of());
        when(vuxDataXbrlLinkRepository.findAll()).thenReturn(List.of());
        when(admXbrlEnumValuesRepository.findAll()).thenReturn(List.of());

        // validationDataService возвращает пустой список (нет CUV-ошибок)
        when(validationDataService.validate(any())).thenReturn(List.of());

        // Мок CSV-генерации
        byte[] dummyCsv = "dummy,csv,content".getBytes();

        // Мок загрузки в ECM для CSV (3 CSV + 1 протокол)
        when(ecmDocumentFacade.uploadSignedDocument(any(byte[].class), anyString(), any(DocumentTypeEnum.class), any()))
                .thenReturn(Optional.of(new CreateContentsResponse(
                        List.of(new CreateContentsDocument("ecm-csv-1", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
                )));

        // Мок flowSetEcmId — используем isNull для результата
        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString())).thenReturn(Optional.empty());
        // Мок flowSetSupzId
        when(validationResultViewRepository.flowSetSupzId(anyInt(), anyString(), anyString(), anyString())).thenReturn(Optional.empty());
        // Мок flowResolveShedule
        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());
        // Мок validationLogRepository для checksList
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(anyInt())).thenReturn(List.of());
        // Мок findByDocIdWithRnLimit — пустой список (нет view-дефектов)
        when(validationResultViewRepository.findByDocIdWithRnLimit(anyInt(), anyInt(), anyInt())).thenReturn(List.of());
        // Мок saveAll
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // Мок buildSupzCreateTaskRequest — возвращаем корректный запрос
        SupzTaskDataRequest taskData = SupzTaskDataRequest.builder()
                .taskSrcId(UUID.randomUUID())
                .srcStatus("created")
                .build();
        when(supzTaskFacade.buildSupzCreateTaskRequest(any(), any(), any()))
                .thenReturn(SupzRequest.<SupzTaskDataRequest>builder()
                        .apiVersion("1.0")
                        .type("createTask")
                        .time(java.time.ZonedDateTime.now())
                        .srcId("gmap2-vux-ecm")
                        .destId("supz")
                        .data(taskData)
                        .build());
        // Мок createTask — возвращаем успешный ответ
        when(supzTaskFacade.createTask(any(), any()))
                .thenReturn(new SupzTaskResponseWrapper(
                        new SupzTaskResponse(
                                new SupzTaskResponseData(
                                        UUID.randomUUID(), "srcId", "created",
                                        null, null, null, null, null, null,
                                        null, null, null, null, null, null
                                ),
                                null, null, "success", null, null, null
                        ),
                        "{\"result\": \"success\"}"
                ));

        // when
        orchestratorService.run();

        // then
        // Мапперы вызваны по 1 разу (entityToDto)
        verify(vuxForm0420415V13ContextRepository, atLeast(1)).findByWorkflowRunId(anyLong());

        // CSV-генерация — 3 вызова

        // Загрузка CSV в ECM — 3 вызова
        verify(ecmDocumentFacade, atLeast(3)).uploadSignedDocument(
                any(byte[].class), anyString(), eq(DocumentTypeEnum.XBRL_VUX_RFVP_DOCUMENT), any()
        );


        // Протокол сформирован (ecm upload для протокола)
        verify(validationResultViewRepository, atLeast(1)).flowSetEcmId(anyInt(), anyString(), nullable(String.class));

        // Пост-обработка — SUPZ (ошибок нет)
        verify(supzTaskFacade, times(1)).createTask(any(), any());
        verify(mailService, never()).sendMail(anyString(), anyString(), anyList(), anyList());

        // validationDataService вызван
        verify(validationDataService, times(1)).validate(any());
    }

    @Test
    @Disabled // TODO вместо 10 проверки выведен mock
    @DisplayName("TC-CUV-05: CUV — успех, но есть стандартные ошибки из view")
    void testCuv05_CuvForm_Success_WithViewErrors() {
        // given
        Integer resultDocId = 1105;
        Integer scheduleId = 2105;
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, "DOC-CUV-TC05", "CUV форма",
                "0420415.1.3", "XBRL_VUX_RFVP_DOCUMENT", null
        );

        // Создаём context с workflowRunId (необходим для handleCuvFormSuccess)
        VuxForm0420415V13ContextEntity contextEntity = new VuxForm0420415V13ContextEntity();
        contextEntity.setWorkflowRunId(9999L);

        // Мок: scheduleView возвращает запись
        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        // contextRepository — есть записи (workflowRunId найден)
        when(vuxForm0420415V13ContextRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of(contextEntity));
        // unitRepository / valueRepository — есть данные для CSV
        when(vuxForm0420415V13UnitRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13ValueRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13DataRepository.findByWorkflowRunId(anyInt())).thenReturn(List.of());
        when(vuxDataXbrlLinkRepository.findAll()).thenReturn(List.of());
        when(admXbrlEnumValuesRepository.findAll()).thenReturn(List.of());

        // validationDataService — пустой список (нет CUV-ошибок)
        when(validationDataService.validate(any())).thenReturn(List.of());

        // view-дефекты: есть E-ошибки из view
        VuxDocumentValidationResultViewEntity viewError = createValidationResult(
                1, resultDocId, "Активы", "RU0000000001", 1L, "ERR001", "Ошибка в строке 1", RuleTypeEnum.E
        );
        when(validationResultViewRepository.findByDocIdWithRnLimit(
                eq(resultDocId), eq(errorSet), eq(totalSet)
        )).thenReturn(List.of(viewError));

        // validationLogRepository — пустой (без лога)
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(anyInt())).thenReturn(List.of());

        // Мок CSV-генерации
        byte[] dummyCsv = "dummy,csv,content".getBytes();

        // Мок загрузки CSV в ECM
        when(ecmDocumentFacade.uploadSignedDocument(
                any(byte[].class), anyString(), any(DocumentTypeEnum.class), any()
        )).thenReturn(Optional.of(new CreateContentsResponse(
                List.of(new CreateContentsDocument("ecm-csv-1", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
        )));


        // Мок flowSetEcmId (для протокола)
        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString()))
                .thenReturn(Optional.empty());

        // Мок flowSetSupzId
        when(validationResultViewRepository.flowSetSupzId(anyInt(), anyString(), anyString(), anyString()))
                .thenReturn(Optional.empty());

        // Мок flowResolveShedule
        when(validationResultViewRepository.flowResolveShedule(anyInt()))
                .thenReturn(Optional.empty());

        // Мок saveAll
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // when
        orchestratorService.run();

        // then
        // 1. CSV генерируется (несмотря на ошибки — текущая реализация с TODO)

        // 2. Загрузка CSV в ECM — 3 вызова (для CSV) + 1 (для протокола) = 4
        verify(ecmDocumentFacade, times(4)).uploadSignedDocument(
                any(byte[].class), anyString(), eq(DocumentTypeEnum.XBRL_VUX_RFVP_DOCUMENT), any()
        );


        // 4. Протокол сформирован — flowSetEcmId (для протокола)
        verify(validationResultViewRepository, atLeast(1)).flowSetEcmId(
                anyInt(), anyString(), nullable(String.class)
        );

        // 5. PostUploadActions: есть ошибки E → sendHtmlMail
        verify(mailService, times(1)).sendMail(anyString(), anyString(), anyList(), anyList());

        // 6. SUPZ НЕ создаётся (т.к. есть ошибки E)
        verify(supzTaskFacade, never()).createTask(any(), any());
    }

    @Test
    @Disabled // TODO вместо 10 проверки выведен mock
    @DisplayName("TC-CUV-06: CUV — ошибки валидации (CUV-ошибки)")
    void testCuv06_CuvForm_ValidationErrors() {
        // given
        Integer resultDocId = 1106;
        Integer scheduleId = 2106;
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, "DOC-CUV-TC06", "CUV форма",
                "0420415.1.3", "XBRL_VUX_RFVP_DOCUMENT", null
        );

        // Создаём context — необходим для построения CheckDataContext
        VuxForm0420415V13ContextEntity contextEntity = new VuxForm0420415V13ContextEntity();
        contextEntity.setWorkflowRunId(7777L);

        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        when(vuxForm0420415V13ContextRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of(contextEntity));
        when(vuxForm0420415V13UnitRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13ValueRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13DataRepository.findByWorkflowRunId(anyInt())).thenReturn(List.of());
        when(vuxDataXbrlLinkRepository.findAll()).thenReturn(List.of());
        when(admXbrlEnumValuesRepository.findAll()).thenReturn(List.of());

        // validationDataService возвращает 1+ ошибку
        when(validationDataService.validate(any()))
                .thenReturn(List.of(
                        new ValidationErrorDto("Title", "CUV_ERR_001", "CUV ошибка: поле обязательно"),
                        new ValidationErrorDto("Title", "CUV_ERR_002", "CUV ошибка: формат неверный")
                ));

        // Мок flowCuvSetError — для сохранения CUV-ошибок в БД
        when(validationResultViewRepository.flowCuvSetError(
                anyLong(), anyString(), anyString()
        )).thenReturn(Optional.empty());

        // Мок view-дефектов: пустой (для handleCuvFormErrors)
        when(validationResultViewRepository.findByDocIdWithRnLimit(
                eq(resultDocId), eq(errorSet), eq(totalSet)
        )).thenReturn(List.of());

        // Мок validationLogRepository
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(anyInt())).thenReturn(List.of());

        // Мок flowSetEcmId — для протокола
        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString()))
                .thenReturn(Optional.empty());

        // Мок uploadDocumentToEcm — для протокола
        when(ecmDocumentFacade.uploadSignedDocument(
                any(byte[].class), anyString(), any(DocumentTypeEnum.class), any()
        )).thenReturn(Optional.of(new CreateContentsResponse(
                List.of(new CreateContentsDocument("ecm-protocol-cuv06", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
        )));

        // Мок flowResolveShedule
        when(validationResultViewRepository.flowResolveShedule(anyInt()))
                .thenReturn(Optional.empty());

        // Мок saveAll
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // when
        orchestratorService.run();

        // then
        // 1. validationDataService.validate вызван
        verify(validationDataService, times(1)).validate(any());

        // 2. flowCuvSetError — по 1 разу на каждую CUV-ошибку
        verify(validationResultViewRepository, times(2)).flowCuvSetError(
                anyLong(), anyString(), anyString()
        );

        // 3. Протокол сформирован — verify(flowSetEcmId)
        verify(validationResultViewRepository, atLeast(1)).flowSetEcmId(
                anyInt(), anyString(), nullable(String.class)
        );

        // 4. ECM-загрузка — через uploadDocumentToEcm
        verify(ecmDocumentFacade, atLeast(1)).uploadSignedDocument(
                any(byte[].class), anyString(), any(DocumentTypeEnum.class), any()
        );

        // 5. PostUploadActions: есть ошибки E → sendHtmlMail
        verify(mailService, times(1)).sendMail(anyString(), anyString(), anyList(), anyList());

        // 6. CSV НЕ генерируется (для CUV-ошибок путь — handleCuvFormErrors)

        // 7. SUPZ НЕ создаётся
        verify(supzTaskFacade, never()).createTask(any(), any());
    }

    @Test
    @Disabled // TODO вместо 10 проверки выведен mock
    @DisplayName("TC-CUV-07: CUV — ошибки + предупреждения из view")
    void testCuv07_CuvForm_ErrorsAndWarningsFromView() {
        // given
        Integer resultDocId = 1107;
        Integer scheduleId = 2107;
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, "DOC-CUV-TC07", "CUV форма",
                "0420415.1.3", "XBRL_VUX_RFVP_DOCUMENT", null
        );

        // Контекст с workflowRunId
        VuxForm0420415V13ContextEntity contextEntity = new VuxForm0420415V13ContextEntity();
        contextEntity.setWorkflowRunId(6666L);

        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        when(vuxForm0420415V13ContextRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of(contextEntity));
        when(vuxForm0420415V13UnitRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13ValueRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13DataRepository.findByWorkflowRunId(anyInt())).thenReturn(List.of());
        when(vuxDataXbrlLinkRepository.findAll()).thenReturn(List.of());
        when(admXbrlEnumValuesRepository.findAll()).thenReturn(List.of());

        // CUV-ошибки: 2+
        when(validationDataService.validate(any()))
                .thenReturn(List.of(
                        new ValidationErrorDto("Title", "CUV_ERR_A", "CUV ошибка A"),
                        new ValidationErrorDto("Title", "CUV_ERR_B", "CUV ошибка B")
                ));

        // view-дефекты: E + W
        VuxDocumentValidationResultViewEntity viewError = createValidationResult(
                1, resultDocId, "Активы", "RU0000000001", 1L, "ERR001", "Ошибка", RuleTypeEnum.E
        );
        VuxDocumentValidationResultViewEntity viewWarning = createValidationResult(
                2, resultDocId, "Пассивы", "RU0000000002", 2L, "WARN001", "Предупреждение", RuleTypeEnum.W
        );

        when(validationResultViewRepository.findByDocIdWithRnLimit(
                eq(resultDocId), eq(errorSet), eq(totalSet)
        )).thenReturn(List.of(viewError, viewWarning));

        // Мок flowCuvSetError
        when(validationResultViewRepository.flowCuvSetError(
                anyLong(), anyString(), anyString()
        )).thenReturn(Optional.empty());

        // Мок flowSetEcmId
        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString()))
                .thenReturn(Optional.empty());

        // Мок uploadDocumentToEcm
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(anyInt())).thenReturn(List.of());
        when(ecmDocumentFacade.uploadSignedDocument(
                any(byte[].class), anyString(), any(DocumentTypeEnum.class), any()
        )).thenReturn(Optional.of(new CreateContentsResponse(
                List.of(new CreateContentsDocument("ecm-protocol-cuv07", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
        )));

        // Мок flowResolveShedule
        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());

        // Мок saveAll
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // when
        orchestratorService.run();

        // then
        // CUV-ошибки сохранены через flowCuvSetError (2 раза)
        verify(validationResultViewRepository, times(2)).flowCuvSetError(
                anyLong(), anyString(), anyString()
        );

        // Протокол содержит объединённые ошибки (view + CUV)
        // flowSetEcmId — вызывается для протокола
        verify(validationResultViewRepository, atLeast(1)).flowSetEcmId(
                anyInt(), anyString(), nullable(String.class)
        );

        // ECM-загрузка протокола
        verify(ecmDocumentFacade, atLeast(1)).uploadSignedDocument(
                any(byte[].class), anyString(), any(DocumentTypeEnum.class), any()
        );

        // PostUploadActions: есть ошибки → sendHtmlMail
        verify(mailService, times(1)).sendMail(anyString(), anyString(), anyList(), anyList());

        // CSV НЕ генерируется

        // SUPZ НЕ создаётся
        verify(supzTaskFacade, never()).createTask(any(), any());
    }

    @Test
    @Disabled // TODO вместо 10 проверки выведен mock
    @DisplayName("TC-CUV-08: CUV — только предупреждения (CUV + view)")
    void testCuv08_CuvForm_OnlyWarnings() {
        // given
        Integer resultDocId = 1108;
        Integer scheduleId = 2108;
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, "DOC-CUV-TC08", "CUV форма",
                "0420415.1.3", "XBRL_VUX_RFVP_DOCUMENT", null
        );

        // Контекст с workflowRunId
        VuxForm0420415V13ContextEntity contextEntity = new VuxForm0420415V13ContextEntity();
        contextEntity.setWorkflowRunId(5555L);

        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        when(vuxForm0420415V13ContextRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of(contextEntity));
        when(vuxForm0420415V13UnitRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13ValueRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13DataRepository.findByWorkflowRunId(anyInt())).thenReturn(List.of());
        when(vuxDataXbrlLinkRepository.findAll()).thenReturn(List.of());
        when(admXbrlEnumValuesRepository.findAll()).thenReturn(List.of());

        // CUV-ошибок нет
        when(validationDataService.validate(any())).thenReturn(List.of());

        // View только W (нет E)
        VuxDocumentValidationResultViewEntity viewWarning = createValidationResult(
                1, resultDocId, "Пассивы", "RU0000000002", 1L, "WARN001", "Предупреждение", RuleTypeEnum.W
        );
        when(validationResultViewRepository.findByDocIdWithRnLimit(
                eq(resultDocId), eq(errorSet), eq(totalSet)
        )).thenReturn(List.of(viewWarning));

        // Мок CSV-генерации
        byte[] dummyCsv = "dummy,csv,content".getBytes();

        // Мок загрузки CSV в ECM
        when(ecmDocumentFacade.uploadSignedDocument(
                any(byte[].class), anyString(), any(DocumentTypeEnum.class), any()
        )).thenReturn(Optional.of(new CreateContentsResponse(
                List.of(new CreateContentsDocument("ecm-csv-1", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
        )));


        // Мок flowSetEcmId (для протокола)
        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString()))
                .thenReturn(Optional.empty());

        // Мок flowSetSupzId
        when(validationResultViewRepository.flowSetSupzId(anyInt(), anyString(), anyString(), anyString()))
                .thenReturn(Optional.empty());

        // Мок flowResolveShedule
        when(validationResultViewRepository.flowResolveShedule(anyInt()))
                .thenReturn(Optional.empty());

        // Мок validationLogRepository — для проверки лога
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(anyInt())).thenReturn(List.of());

        // Мок saveAll
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // when
        orchestratorService.run();

        // then
        // CSV генерируется (ошибок нет)

        // Загрузка CSV в ECM — 3 + 1 (протокол) = 4
        verify(ecmDocumentFacade, times(4)).uploadSignedDocument(
                any(byte[].class), anyString(), eq(DocumentTypeEnum.XBRL_VUX_RFVP_DOCUMENT), any()
        );


        // flowSetEcmId — для протокола (1 раз)
        verify(validationResultViewRepository, atLeast(1)).flowSetEcmId(
                anyInt(), anyString(), nullable(String.class)
        );

        // PostUploadActions: Нет ошибок E, только W → SUPZ создаётся
        verify(supzTaskFacade, times(1)).createTask(any(), any());

        // Письмо НЕ отправляется (нет ошибок E)
        verify(mailService, never()).sendMail(
                anyString(), anyString(), anyList(), anyList()
        );
    }

    // ========================================================================
    // TC-CUV-09 — TC-CUV-16
    // ========================================================================

    @Test
    @Disabled // TODO вместо 10 проверки выведен mock
    @DisplayName("TC-CUV-09: CUV — ошибка ECM-загрузки (CSV)")
    void testCuv09_CuvForm_EcmUploadCsvFailed() {
        // given
        Integer resultDocId = 1109;
        Integer scheduleId = 2109;
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, "DOC-CUV-TC09", "CUV форма",
                "0420415.1.3", "XBRL_VUX_RFVP_DOCUMENT", null
        );

        VuxForm0420415V13ContextEntity contextEntity = new VuxForm0420415V13ContextEntity();
        contextEntity.setWorkflowRunId(9998L);

        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        when(vuxForm0420415V13ContextRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of(contextEntity));
        when(vuxForm0420415V13UnitRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13ValueRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13DataRepository.findByWorkflowRunId(anyInt())).thenReturn(List.of());
        when(vuxDataXbrlLinkRepository.findAll()).thenReturn(List.of());
        when(admXbrlEnumValuesRepository.findAll()).thenReturn(List.of());

        when(validationDataService.validate(any())).thenReturn(List.of());

        byte[] dummyCsv = "dummy,csv,content".getBytes();

        // Первые два вызова ECM — успех, третий (VALUE) — ошибка (ECM недоступен)
        when(ecmDocumentFacade.uploadSignedDocument(
                any(byte[].class), anyString(), any(DocumentTypeEnum.class), any()
        ))
                .thenReturn(Optional.of(new CreateContentsResponse(
                        List.of(new CreateContentsDocument("ecm-csv-ok", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
                )))
                .thenReturn(Optional.of(new CreateContentsResponse(
                        List.of(new CreateContentsDocument("ecm-csv-ok2", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
                )))
                .thenReturn(Optional.empty())  // третий CSV — VALUE, ошибка ECM
                .thenReturn(Optional.of(new CreateContentsResponse(  // протокол
                        List.of(new CreateContentsDocument("ecm-protocol", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
                )));

        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString()))
                .thenReturn(Optional.empty());
        when(validationResultViewRepository.flowSetSupzId(anyInt(), anyString(), anyString(), anyString()))
                .thenReturn(Optional.empty());
        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(anyInt())).thenReturn(List.of());
        when(validationResultViewRepository.findByDocIdWithRnLimit(anyInt(), anyInt(), anyInt())).thenReturn(List.of());
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // when
        orchestratorService.run();

        // then
        // CSV сгенерирован (3 вызова)

        // uploadDocumentByType вызван 4 раза: 3 CSV + 1 протокол
        verify(ecmDocumentFacade, times(4)).uploadSignedDocument(
                any(byte[].class), anyString(), eq(DocumentTypeEnum.XBRL_VUX_RFVP_DOCUMENT), any()
        );


        // Протокол всё ещё формируется (error нефатальна)
        verify(validationResultViewRepository, atLeast(1)).flowSetEcmId(anyInt(), anyString(), nullable(String.class));

        // PostUploadActions выполняется (SUPZ, т.к. ошибок E нет)
        verify(supzTaskFacade, times(1)).createTask(any(), any());
        verify(mailService, never()).sendMail(anyString(), anyString(), anyList(), anyList());
    }

    @Test
    @Disabled // TODO вместо 10 проверки выведен mock
    @DisplayName("TC-CUV-10: CUV — ошибка ECM-загрузки (протокол)")
    void testCuv10_CuvForm_EcmUploadProtocolFailed() {
        // given
        Integer resultDocId = 1110;
        Integer scheduleId = 2110;
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, "DOC-CUV-TC10", "CUV форма",
                "0420415.1.3", "XBRL_VUX_RFVP_DOCUMENT", null
        );

        VuxForm0420415V13ContextEntity contextEntity = new VuxForm0420415V13ContextEntity();
        contextEntity.setWorkflowRunId(9997L);

        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        when(vuxForm0420415V13ContextRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of(contextEntity));
        when(vuxForm0420415V13UnitRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13ValueRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13DataRepository.findByWorkflowRunId(anyInt())).thenReturn(List.of());
        when(vuxDataXbrlLinkRepository.findAll()).thenReturn(List.of());
        when(admXbrlEnumValuesRepository.findAll()).thenReturn(List.of());

        when(validationDataService.validate(any())).thenReturn(List.of());

        byte[] dummyCsv = "dummy,csv,content".getBytes();

        // CSV — успех (3 раза), протокол — ошибка (ECM не отвечает)
        when(ecmDocumentFacade.uploadSignedDocument(
                any(byte[].class), anyString(), any(DocumentTypeEnum.class), any()
        ))
                .thenReturn(Optional.of(new CreateContentsResponse(
                        List.of(new CreateContentsDocument("ecm-csv-1", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
                )))
                .thenReturn(Optional.of(new CreateContentsResponse(
                        List.of(new CreateContentsDocument("ecm-csv-2", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
                )))
                .thenReturn(Optional.of(new CreateContentsResponse(
                        List.of(new CreateContentsDocument("ecm-csv-3", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
                )))
                .thenReturn(Optional.empty());  // протокол — ошибка

        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString()))
                .thenReturn(Optional.empty());
        when(validationResultViewRepository.flowSetSupzId(anyInt(), anyString(), anyString(), anyString()))
                .thenReturn(Optional.empty());
        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(anyInt())).thenReturn(List.of());
        when(validationResultViewRepository.findByDocIdWithRnLimit(anyInt(), anyInt(), anyInt())).thenReturn(List.of());
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // when
        orchestratorService.run();

        // then
        // CSV сгенерирован (3 вызова)

        // uploadDocumentByType вызван 4 раза: 3 CSV (успешно) + 1 протокол (ошибка)
        verify(ecmDocumentFacade, times(4)).uploadSignedDocument(
                any(byte[].class), anyString(), eq(DocumentTypeEnum.XBRL_VUX_RFVP_DOCUMENT), any()
        );


        // flowSetEcmId НЕ вызывается (протокол не загружен)
        verify(validationResultViewRepository, never()).flowSetEcmId(anyInt(), anyString(), anyString());

        // resolveShedule всё равно вызывается в run() после processNewDocument
        verify(validationResultViewRepository, times(1)).flowResolveShedule(anyInt());

        // PostUploadActions НЕ выполняется (uploadProtocolToEcmAndResolve вернул empty)
        verify(supzTaskFacade, never()).createTask(any(), any());
        verify(mailService, never()).sendMail(anyString(), anyString(), anyList(), anyList());
    }

    @Test
    @Disabled // TODO вместо 10 проверки выведен mock
    @DisplayName("TC-CUV-11: CUV — создание задачи в УПЗ (успех)")
    void testCuv11_CuvForm_SupzCreateTaskSuccess() {
        // given
        Integer resultDocId = 1111;
        Integer scheduleId = 2111;
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, "DOC-CUV-TC11", "CUV форма",
                "0420415.1.3", "XBRL_VUX_RFVP_DOCUMENT", null
        );

        VuxForm0420415V13ContextEntity contextEntity = new VuxForm0420415V13ContextEntity();
        contextEntity.setWorkflowRunId(9996L);

        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        when(vuxForm0420415V13ContextRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of(contextEntity));
        when(vuxForm0420415V13UnitRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13ValueRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13DataRepository.findByWorkflowRunId(anyInt())).thenReturn(List.of());
        when(vuxDataXbrlLinkRepository.findAll()).thenReturn(List.of());
        when(admXbrlEnumValuesRepository.findAll()).thenReturn(List.of());

        when(validationDataService.validate(any())).thenReturn(List.of());

        byte[] dummyCsv = "dummy,csv,content".getBytes();

        when(ecmDocumentFacade.uploadSignedDocument(
                any(byte[].class), anyString(), any(DocumentTypeEnum.class), any()
        )).thenReturn(Optional.of(new CreateContentsResponse(
                List.of(new CreateContentsDocument("ecm-doc-1111", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
        )));

        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString()))
                .thenReturn(Optional.empty());
        when(validationResultViewRepository.flowSetSupzId(anyInt(), anyString(), anyString(), anyString()))
                .thenReturn(Optional.empty());
        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(anyInt())).thenReturn(List.of());
        when(validationResultViewRepository.findByDocIdWithRnLimit(anyInt(), anyInt(), anyInt())).thenReturn(List.of());
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // Мок SUPZ — успешный ответ
        when(supzTaskFacade.buildSupzCreateTaskRequest(any(), any(), any()))
                .thenReturn(SupzRequest.<SupzTaskDataRequest>builder()
                        .apiVersion("1.0")
                        .type("createTask")
                        .time(java.time.ZonedDateTime.now())
                        .srcId("gmap2-vux-ecm")
                        .destId("supz")
                        .data(SupzTaskDataRequest.builder()
                                .taskSrcId(UUID.randomUUID())
                                .srcStatus("created")
                                .build())
                        .build());

        SupzTaskResponseData supzTaskData = new SupzTaskResponseData(
                UUID.randomUUID(), "srcId", "created",
                null, null, null, null, null, null,
                null, null, null, null, null, null
        );
        SupzTaskResponse supzTaskResponse = new SupzTaskResponse(
                supzTaskData, null, null, "success", null, null, null
        );
        SupzTaskResponseWrapper supzResponse = new SupzTaskResponseWrapper(supzTaskResponse, "{\"result\": \"success\"}");
        when(supzTaskFacade.createTask(any(), any())).thenReturn(supzResponse);

        // when
        orchestratorService.run();

        // then
        verify(supzTaskFacade, times(1)).buildSupzCreateTaskRequest(any(), any(), any());
        verify(supzTaskFacade, times(1)).createTask(any(), any());
        verify(validationResultViewRepository, times(1)).flowSetSupzId(
                eq(resultDocId), anyString(), eq("created"), anyString()
        );
        verify(mailService, never()).sendMail(anyString(), anyString(), anyList(), anyList());
    }

    @Test
    @Disabled // TODO вместо 10 проверки выведен mock
    @DisplayName("TC-CUV-12: CUV — создание задачи в УПЗ (предупреждения)")
    void testCuv12_CuvForm_SupzCreateTaskWithWarnings() {
        // given
        Integer resultDocId = 1112;
        Integer scheduleId = 2112;
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, "DOC-CUV-TC12", "CUV форма",
                "0420415.1.3", "XBRL_VUX_RFVP_DOCUMENT", null
        );

        VuxForm0420415V13ContextEntity contextEntity = new VuxForm0420415V13ContextEntity();
        contextEntity.setWorkflowRunId(9995L);

        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        when(vuxForm0420415V13ContextRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of(contextEntity));
        when(vuxForm0420415V13UnitRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13ValueRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13DataRepository.findByWorkflowRunId(anyInt())).thenReturn(List.of());
        when(vuxDataXbrlLinkRepository.findAll()).thenReturn(List.of());
        when(admXbrlEnumValuesRepository.findAll()).thenReturn(List.of());

        when(validationDataService.validate(any())).thenReturn(List.of());

        byte[] dummyCsv = "dummy,csv,content".getBytes();

        when(ecmDocumentFacade.uploadSignedDocument(
                any(byte[].class), anyString(), any(DocumentTypeEnum.class), any()
        )).thenReturn(Optional.of(new CreateContentsResponse(
                List.of(new CreateContentsDocument("ecm-doc-1112", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
        )));

        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString()))
                .thenReturn(Optional.empty());
        when(validationResultViewRepository.flowSetSupzId(anyInt(), anyString(), anyString(), anyString()))
                .thenReturn(Optional.empty());
        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(anyInt())).thenReturn(List.of());
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // Только W (предупреждения) из view — без E
        VuxDocumentValidationResultViewEntity viewWarning = createValidationResult(
                1, resultDocId, "Пассивы", "RU0000000002", 1L, "WARN001", "Предупреждение", RuleTypeEnum.W
        );
        when(validationResultViewRepository.findByDocIdWithRnLimit(
                eq(resultDocId), eq(errorSet), eq(totalSet)
        )).thenReturn(List.of(viewWarning));

        // Мок SUPZ
        when(supzTaskFacade.buildSupzCreateTaskRequest(any(), any(), any()))
                .thenReturn(SupzRequest.<SupzTaskDataRequest>builder()
                        .apiVersion("1.0")
                        .type("createTask")
                        .time(java.time.ZonedDateTime.now())
                        .srcId("gmap2-vux-ecm")
                        .destId("supz")
                        .data(SupzTaskDataRequest.builder()
                                .taskSrcId(UUID.randomUUID())
                                .srcStatus("created")
                                .build())
                        .build());

        SupzTaskResponseData supzTaskData = new SupzTaskResponseData(
                UUID.randomUUID(), "srcId", "created",
                null, null, null, null, null, null,
                null, null, null, null, null, null
        );
        SupzTaskResponse supzTaskResponse = new SupzTaskResponse(
                supzTaskData, null, null, "success", null, null, null
        );
        SupzTaskResponseWrapper supzResponse = new SupzTaskResponseWrapper(supzTaskResponse, "{\"result\": \"success\"}");
        when(supzTaskFacade.createTask(any(), any())).thenReturn(supzResponse);

        // when
        orchestratorService.run();

        // then
        verify(supzTaskFacade, times(1)).createTask(any(), any());
        verify(validationResultViewRepository, times(1)).flowSetSupzId(
                eq(resultDocId), anyString(), anyString(), anyString()
        );
        // Письмо не отправляется (нет ошибок E)
        verify(mailService, never()).sendMail(anyString(), anyString(), anyList(), anyList());
    }

    @Test
    @Disabled // TODO вместо 10 проверки выведен mock
    @DisplayName("TC-CUV-13: CUV — создание задачи в УПЗ (ошибка)")
    void testCuv13_CuvForm_SupzCreateTaskError() {
        // given
        Integer resultDocId = 1113;
        Integer scheduleId = 2113;
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, "DOC-CUV-TC13", "CUV форма",
                "0420415.1.3", "XBRL_VUX_RFVP_DOCUMENT", null
        );

        VuxForm0420415V13ContextEntity contextEntity = new VuxForm0420415V13ContextEntity();
        contextEntity.setWorkflowRunId(9994L);

        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        when(vuxForm0420415V13ContextRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of(contextEntity));
        when(vuxForm0420415V13UnitRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13ValueRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13DataRepository.findByWorkflowRunId(anyInt())).thenReturn(List.of());
        when(vuxDataXbrlLinkRepository.findAll()).thenReturn(List.of());
        when(admXbrlEnumValuesRepository.findAll()).thenReturn(List.of());

        when(validationDataService.validate(any())).thenReturn(List.of());

        byte[] dummyCsv = "dummy,csv,content".getBytes();

        when(ecmDocumentFacade.uploadSignedDocument(
                any(byte[].class), anyString(), any(DocumentTypeEnum.class), any()
        )).thenReturn(Optional.of(new CreateContentsResponse(
                List.of(new CreateContentsDocument("ecm-doc-1113", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
        )));

        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString()))
                .thenReturn(Optional.empty());
        when(validationResultViewRepository.flowSetSupzId(anyInt(), anyString(), anyString(), anyString()))
                .thenReturn(Optional.empty());
        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());
        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(anyInt())).thenReturn(List.of());
        when(validationResultViewRepository.findByDocIdWithRnLimit(anyInt(), anyInt(), anyInt())).thenReturn(List.of());
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // SUPZ недоступен — createTask бросает исключение
        when(supzTaskFacade.createTask(any(), any())).thenThrow(new RuntimeException("SUPZ service unavailable"));

        // when
        orchestratorService.run();

        // then
        verify(supzTaskFacade, times(1)).createTask(any(), any());
        // flowSetSupzId НЕ вызывается (SUPZ error)
        verify(validationResultViewRepository, never()).flowSetSupzId(
                anyInt(), anyString(), anyString(), anyString()
        );
        // Письмо НЕ отправляется (нет ошибок E)
        verify(mailService, never()).sendMail(anyString(), anyString(), anyList(), anyList());
    }

    @Test
    @Disabled // TODO вместо 10 проверки выведен mock
    @DisplayName("TC-CUV-14: CUV — отправка email (с ошибками)")
    void testCuv14_CuvForm_SendEmailWithErrors() {
        // given
        Integer resultDocId = 1114;
        Integer scheduleId = 2114;
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, "DOC-CUV-TC14", "CUV форма",
                "0420415.1.3", "XBRL_VUX_RFVP_DOCUMENT", null
        );

        VuxForm0420415V13ContextEntity contextEntity = new VuxForm0420415V13ContextEntity();
        contextEntity.setWorkflowRunId(9993L);

        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        when(vuxForm0420415V13ContextRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of(contextEntity));
        when(vuxForm0420415V13UnitRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13ValueRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13DataRepository.findByWorkflowRunId(anyInt())).thenReturn(List.of());
        when(vuxDataXbrlLinkRepository.findAll()).thenReturn(List.of());
        when(admXbrlEnumValuesRepository.findAll()).thenReturn(List.of());

        // CUV-ошибки
        when(validationDataService.validate(any()))
                .thenReturn(List.of(
                        new ValidationErrorDto("Title", "CUV_ERR_X", "CUV ошибка X")
                ));

        when(validationResultViewRepository.flowCuvSetError(anyLong(), anyString(), anyString()))
                .thenReturn(Optional.empty());

        // view-дефекты: только E (для handleCuvFormErrors)
        VuxDocumentValidationResultViewEntity viewError = createValidationResult(
                1, resultDocId, "Активы", "RU0000000001", 1L, "ERR001", "Ошибка", RuleTypeEnum.E
        );
        when(validationResultViewRepository.findByDocIdWithRnLimit(
                eq(resultDocId), eq(errorSet), eq(totalSet)
        )).thenReturn(List.of(viewError));

        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(anyInt())).thenReturn(List.of());
        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString()))
                .thenReturn(Optional.empty());

        when(ecmDocumentFacade.uploadSignedDocument(
                any(byte[].class), anyString(), any(DocumentTypeEnum.class), any()
        )).thenReturn(Optional.of(new CreateContentsResponse(
                List.of(new CreateContentsDocument("ecm-doc-1114", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
        )));

        when(validationResultViewRepository.flowSetMailStatus(anyInt(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(Optional.empty());
        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // when
        orchestratorService.run();

        // then
        verify(mailService, times(1)).sendMail(anyString(), anyString(), anyList(), anyList());

        ArgumentCaptor<String> subjectCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> bodyCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<List<String>> recipientsCaptor = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<List<String>> ccCaptor = ArgumentCaptor.forClass(List.class);

        verify(mailService).sendMail(subjectCaptor.capture(), bodyCaptor.capture(),
                recipientsCaptor.capture(), ccCaptor.capture());

        String subject = subjectCaptor.getValue();
        assertNotNull(subject);
        assertTrue(subject.contains("0420415.1.3"), "Subject should contain form code");
        assertTrue(subject.contains("Ошибки на отчетную дату"), "Subject should contain error date phrase");

        // Получатели из createScheduleEntity: test@test.com
        List<String> recipients = recipientsCaptor.getValue();
        assertNotNull(recipients);
        assertFalse(recipients.isEmpty());
        assertTrue(recipients.contains("test@test.com"), "Recipients should contain test@test.com");

        // CC
        List<String> ccList = ccCaptor.getValue();
        assertNotNull(ccList);
        assertFalse(ccList.isEmpty());

        // flowSetMailStatus
        verify(validationResultViewRepository, times(1)).flowSetMailStatus(
                eq(resultDocId), anyString(), anyString(), anyString(), anyString()
        );

        // SUPZ НЕ создаётся (есть ошибки E)
        verify(supzTaskFacade, never()).createTask(any(), any());
    }

    @Test
    @Disabled // TODO вместо 10 проверки выведен mock
    @DisplayName("TC-CUV-15: CUV — пустой список получателей")
    void testCuv15_CuvForm_EmptyRecipientsList() {
        // given
        Integer resultDocId = 1115;
        Integer scheduleId = 2115;
        // Создаём entity с null mailReceiversList
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, "DOC-CUV-TC15", "CUV форма",
                "0420415.1.3", "XBRL_VUX_RFVP_DOCUMENT", null
        );
        scheduleEntity.setMailReceiversList(null);  // пустой список получателей

        VuxForm0420415V13ContextEntity contextEntity = new VuxForm0420415V13ContextEntity();
        contextEntity.setWorkflowRunId(9992L);

        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        when(vuxForm0420415V13ContextRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of(contextEntity));
        when(vuxForm0420415V13UnitRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13ValueRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13DataRepository.findByWorkflowRunId(anyInt())).thenReturn(List.of());
        when(vuxDataXbrlLinkRepository.findAll()).thenReturn(List.of());
        when(admXbrlEnumValuesRepository.findAll()).thenReturn(List.of());

        // CUV-ошибки — чтобы путь был handleCuvFormErrors -> sendHtmlMail
        when(validationDataService.validate(any()))
                .thenReturn(List.of(
                        new ValidationErrorDto("Title", "CUV_ERR_Z", "CUV ошибка Z")
                ));

        when(validationResultViewRepository.flowCuvSetError(anyLong(), anyString(), anyString()))
                .thenReturn(Optional.empty());

        when(validationResultViewRepository.findByDocIdWithRnLimit(
                eq(resultDocId), eq(errorSet), eq(totalSet)
        )).thenReturn(List.of());

        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(anyInt())).thenReturn(List.of());
        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString()))
                .thenReturn(Optional.empty());

        when(ecmDocumentFacade.uploadSignedDocument(
                any(byte[].class), anyString(), any(DocumentTypeEnum.class), any()
        )).thenReturn(Optional.of(new CreateContentsResponse(
                List.of(new CreateContentsDocument("ecm-doc-1115", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
        )));

        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // when
        orchestratorService.run();

        // then
        // MailService.sendMail вызывается, но с пустым списком получателей
        verify(mailService, times(1)).sendMail(anyString(), anyString(), anyList(), anyList());

        // flowSetMailStatus вызывается (sendHtmlMail всегда вызывает его)
        verify(validationResultViewRepository, times(1)).flowSetMailStatus(
                anyInt(), anyString(), anyString(), anyString(), anyString()
        );
    }

    @Test
    @DisplayName("TC-CUV-16: CUV — пустой список CC")
    void testCuv16_CuvForm_EmptyCcList() {
        // given
        Integer resultDocId = 1116;
        Integer scheduleId = 2116;
        VuxDocumentScheduleViewEntity scheduleEntity = createScheduleEntity(
                scheduleId, resultDocId, "DOC-CUV-TC16", "CUV форма",
                "0420415.1.3", "XBRL_VUX_RFVP_DOCUMENT", null
        );
        scheduleEntity.setMailCopyList(null);  // пустой CC

        VuxForm0420415V13ContextEntity contextEntity = new VuxForm0420415V13ContextEntity();
        contextEntity.setWorkflowRunId(9991L);

        when(scheduleViewRepository.findAll()).thenReturn(List.of(scheduleEntity));
        when(vuxForm0420415V13ContextRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of(contextEntity));
        when(vuxForm0420415V13UnitRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13ValueRepository.findByWorkflowRunId(anyLong())).thenReturn(List.of());
        when(vuxForm0420415V13DataRepository.findByWorkflowRunId(anyInt())).thenReturn(List.of());
        when(vuxDataXbrlLinkRepository.findAll()).thenReturn(List.of());
        when(admXbrlEnumValuesRepository.findAll()).thenReturn(List.of());

        // CUV-ошибки — путь handleCuvFormErrors -> sendHtmlMail
        when(validationDataService.validate(any()))
                .thenReturn(List.of(
                        new ValidationErrorDto("Title", "CUV_ERR_Y", "CUV ошибка Y")
                ));

        when(validationResultViewRepository.flowCuvSetError(anyLong(), anyString(), anyString()))
                .thenReturn(Optional.empty());

        // view-дефекты: E — чтобы был вызов sendHtmlMail
        VuxDocumentValidationResultViewEntity viewError = createValidationResult(
                1, resultDocId, "Активы", "RU0000000001", 1L, "ERR001", "Ошибка", RuleTypeEnum.E
        );
        when(validationResultViewRepository.findByDocIdWithRnLimit(
                eq(resultDocId), eq(errorSet), eq(totalSet)
        )).thenReturn(List.of(viewError));

        when(validationLogRepository.findAllByDocIdOrderByErrorCountDesc(anyInt())).thenReturn(List.of());
        when(validationResultViewRepository.flowSetEcmId(anyInt(), anyString(), anyString()))
                .thenReturn(Optional.empty());

        when(ecmDocumentFacade.uploadSignedDocument(
                any(byte[].class), anyString(), any(DocumentTypeEnum.class), any()
        )).thenReturn(Optional.of(new CreateContentsResponse(
                List.of(new CreateContentsDocument("ecm-doc-1116", "XBRL_VUX_RFVP_Document", "success", null, new ResponseResult()))
        )));

        when(validationResultViewRepository.flowSetMailStatus(anyInt(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(Optional.empty());
        when(validationResultViewRepository.flowResolveShedule(anyInt())).thenReturn(Optional.empty());
        when(scheduleViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));
        when(validationResultViewRepository.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

        // when
        orchestratorService.run();

        // then
        verify(mailService, times(1)).sendMail(anyString(), anyString(), anyList(), anyList());

        ArgumentCaptor<List<String>> ccCaptor = ArgumentCaptor.forClass(List.class);
        verify(mailService).sendMail(anyString(), anyString(), anyList(), ccCaptor.capture());

        List<String> ccList = ccCaptor.getValue();
        assertNotNull(ccList);
        assertTrue(ccList.isEmpty(), "CC list should be empty when mailCopyList is null");

        // flowSetMailStatus вызывается с пустым cc
        verify(validationResultViewRepository, times(1)).flowSetMailStatus(
                eq(resultDocId), anyString(), anyString(), anyString(), anyString()
        );
    }

    // Рефлексия для вызова приватного метода
    private String generateProtocolName(OrchestratorService service, String docTypeCode) {
        try {
            var method = OrchestratorService.class.getDeclaredMethod("generateProtocolName", String.class);
            method.setAccessible(true);
            return (String) method.invoke(service, docTypeCode);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
