package ru.sbrf.gmap.vux.entity.converter;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.sbrf.gmap.vux.entity.enums.InfoEmailTypeEnum;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNoException;

@DisplayName("InfoEmailTypeConverter")
class InfoEmailTypeConverterTest {

    private final InfoEmailTypeConverter converter = new InfoEmailTypeConverter();

    @Test
    @DisplayName("convertToDatabaseColumn возвращает фиксированный код типа")
    void convertsEnumToCode() {
        assertThat(converter.convertToDatabaseColumn(InfoEmailTypeEnum.VERIFICATION)).isEqualTo(0);
        assertThat(converter.convertToDatabaseColumn(InfoEmailTypeEnum.PREPARATION)).isEqualTo(1);
        assertThat(converter.convertToDatabaseColumn(null)).isNull();
    }

    @Test
    @DisplayName("convertToEntityAttribute читает код в Enum, неизвестный код дает null без исключения")
    void convertsCodeToEnum() {
        assertThat(converter.convertToEntityAttribute(0)).isEqualTo(InfoEmailTypeEnum.VERIFICATION);
        assertThat(converter.convertToEntityAttribute(1)).isEqualTo(InfoEmailTypeEnum.PREPARATION);
        assertThat(converter.convertToEntityAttribute(null)).isNull();

        assertThatNoException().isThrownBy(() -> converter.convertToEntityAttribute(42));
        assertThat(converter.convertToEntityAttribute(42)).isNull();
    }
}
