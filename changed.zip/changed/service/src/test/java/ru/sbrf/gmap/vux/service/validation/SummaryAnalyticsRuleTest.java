package ru.sbrf.gmap.vux.service.validation;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sbrf.gmap.vux.service.checks.DataContext;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ContextDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;
import ru.sbrf.gmap.vux.dto.scenario.full.ExplicitMemberDto;
import ru.sbrf.gmap.vux.dto.scenario.full.FullXmlDto;
import ru.sbrf.gmap.vux.dto.scenario.full.TypedMemberDto;
import ru.sbrf.gmap.vux.entity.VuxDataXbrlLinkEntity;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V13DataEntity;
import ru.sbrf.gmap.vux.service.checks.SummaryAnalyticsRule;
import ru.sbrf.gmap.vux.service.parser.XmlParserException;
import ru.sbrf.gmap.vux.service.parser.XmlParserService;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("SummaryAnalyticsRule")
class SummaryAnalyticsRuleTest {

    @Mock
    private XmlParserService xmlParserService;

    @InjectMocks
    private SummaryAnalyticsRule rule;

    private static final String TAXONOMY = "taxonomy-1";
    private static final String TABLE_NAME = "t_vux_form_0420415_1_3_data";
    private static final String CTX_ID = "ctx-1";

    // ====== Вспомогательные методы ======

    private static VuxDataXbrlLinkEntity.DataXbrlLinkId linkId(String columnName) {
        return new VuxDataXbrlLinkEntity.DataXbrlLinkId(TAXONOMY, TABLE_NAME, columnName);
    }

    private static VuxDataXbrlLinkEntity createMeasureLink(String columnName, String measureId) {
        VuxDataXbrlLinkEntity link = new VuxDataXbrlLinkEntity();
        link.setId(linkId(columnName));
        link.setColumnXbrlType("measure");
        link.setMeasureId(measureId);
        link.setDocTypeId(1);
        return link;
    }

    private static VuxDataXbrlLinkEntity createEnumeratorLink(String columnName, String paramId) {
        VuxDataXbrlLinkEntity link = new VuxDataXbrlLinkEntity();
        link.setId(linkId(columnName));
        link.setColumnXbrlType("enumerator");
        link.setParameterId(paramId);
        link.setDocTypeId(1);
        return link;
    }

    private static VuxForm0420415V13ContextDto createContext(String scenario) {
        return new VuxForm0420415V13ContextDto(
                UUID.randomUUID(),
                CTX_ID,
                "YEAR",
                "2025",
                "id-1",
                "scheme-1",
                "segment-1",
                scenario,
                LocalDate.of(2025, 1, 1),
                LocalDate.of(2025, 12, 31),
                TAXONOMY,
                1L
        );
    }

    private static VuxForm0420415V13DataEntity createDataEntity(String idCzennojbumagi, String idStroki) {
        VuxForm0420415V13DataEntity data = new VuxForm0420415V13DataEntity();
        data.setId(1L);
        data.setIdCzennojbumagi(idCzennojbumagi);
        data.setIdStroki(idStroki);
        data.setKolcprinbuxuch(BigDecimal.valueOf(100));
        return data;
    }

    private static VuxForm0420415V13ValueDto createValue(String elementName, String value, String nil) {
        return new VuxForm0420415V13ValueDto(
                UUID.randomUUID(),
                "label-" + elementName,
                "url-" + elementName,
                elementName,
                value,
                nil,
                CTX_ID,
                "unit-1",
                null,
                null,
                null,
                null,
                null,
                null,
                TAXONOMY,
                1L
        );
    }

    /**
     * Создаёт FullXmlDto с двумя TypedMemberDto (ID_CzennojBumagiTaxis, ID_strokiTaxis).
     * Использует Mockito для создания TypedMemberDto без необходимости
     * реализовывать org.w3c.dom.Element.
     */
    private static FullXmlDto scenarioWithTypedMembers(String idCzen, String idStr) {
        TypedMemberDto czennojMember = mock(TypedMemberDto.class);
        when(czennojMember.getDimension()).thenReturn("dim-int:ID_CzennojBumagiTaxis");
        when(czennojMember.getTypedName()).thenReturn(idCzen);

        TypedMemberDto strokiMember = mock(TypedMemberDto.class);
        when(strokiMember.getDimension()).thenReturn("dim-int:ID_strokiTaxis");
        when(strokiMember.getTypedName()).thenReturn(idStr);

        return FullXmlDto.builder()
                .members(List.of(czennojMember, strokiMember))
                .build();
    }

    // ====== ТК-1: Пустой contextList → Optional.empty() ======
    @Test
    @Disabled
    @DisplayName("Пустой contextList → нет ошибки")
    void validate_emptyContextList_returnsEmpty() {
        DataContext ctx = new DataContext(
                1,
                Collections.emptyList(),
                Collections.emptyList(),
                Collections.emptyList(),
                List.of(createDataEntity("val1", "str1")),
                List.of(createMeasureLink("kolcprinbuxuch", "m1")),
                Collections.emptyMap()
        );

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isEmpty();
    }

    // ====== ТК-2: Пустой dataList → Optional.empty() ======
    @Test
    @Disabled
    @DisplayName("Пустой dataList → нет ошибки")
    void validate_emptyDataList_returnsEmpty() {
        DataContext ctx = new DataContext(
                1,
                List.of(createContext("<scenario/>")),
                Collections.emptyList(),
                Collections.emptyList(),
                Collections.emptyList(),
                List.of(createMeasureLink("kolcprinbuxuch", "m1")),
                Collections.emptyMap()
        );

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isEmpty();
    }

    // ====== ТК-3: Пустой xbrlLinks → Optional.empty() ======
    @Test
    @Disabled
    @DisplayName("Пустой xbrlLinks → нет ошибки")
    void validate_emptyXbrlLinks_returnsEmpty() {
        DataContext ctx = new DataContext(
                1,
                List.of(createContext("<scenario/>")),
                Collections.emptyList(),
                Collections.emptyList(),
                List.of(createDataEntity("val1", "str1")),
                Collections.emptyList(),
                Collections.emptyMap()
        );

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isEmpty();
    }

    // ====== ТК-4: Все данные корректны → Optional.empty() ======
    @Test
    @Disabled
    @DisplayName("Все данные корректны → нет ошибки")
    void validate_allDataMatches_returnsEmpty() {
        String typedIdCzen = "TEST_CZEN_001";
        String typedIdStr = "ID_50104_1";
        String elementName = "m1";

        FullXmlDto scenario = scenarioWithTypedMembers(typedIdCzen, typedIdStr);
        when(xmlParserService.parse(any(), eq(FullXmlDto.class))).thenReturn(scenario);

        VuxForm0420415V13DataEntity data = createDataEntity(typedIdCzen, typedIdStr);
        data.setKolcprinbuxuch(BigDecimal.valueOf(100));

        DataContext ctx = new DataContext(
                1,
                List.of(createContext("<scenario/>")),
                Collections.emptyList(),
                List.of(createValue(elementName, "100", null)),
                List.of(data),
                List.of(createMeasureLink("kolcprinbuxuch", elementName)),
                Collections.emptyMap()
        );

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isEmpty();
    }

    // ====== ТК-5: data не найдена → ошибка ======
    @Test
    @Disabled
    @DisplayName("Data не найдена → ошибка DCUV_0420415_1_3_010")
    void validate_dataNotFound_returnsError() {
        String typedIdCzen = "TEST_CZEN_001";
        String typedIdStr = "ID_50104_1";

        FullXmlDto scenario = scenarioWithTypedMembers(typedIdCzen, typedIdStr);
        when(xmlParserService.parse(any(), eq(FullXmlDto.class))).thenReturn(scenario);

        VuxForm0420415V13DataEntity data = createDataEntity("OTHER_CZEN", "OTHER_STR");

        DataContext ctx = new DataContext(
                1,
                List.of(createContext("<scenario/>")),
                Collections.emptyList(),
                Collections.emptyList(),
                List.of(data),
                List.of(createMeasureLink("kolcprinbuxuch", "m1")),
                Collections.emptyMap()
        );

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isPresent();
        assertThat(result.get().errorCode()).isEqualTo("DCUV_0420415_1_3_010");
        assertThat(result.get().errorMessage()).contains("Не найдена запись");
    }

    // ====== ТК-6: Найдено >1 data записи → ошибка ======
    @Test
    @Disabled
    @DisplayName("Несколько data записей → ошибка")
    void validate_multipleDataRecords_returnsError() {
        String typedIdCzen = "TEST_CZEN_001";
        String typedIdStr = "ID_50104_1";

        FullXmlDto scenario = scenarioWithTypedMembers(typedIdCzen, typedIdStr);
        when(xmlParserService.parse(any(), eq(FullXmlDto.class))).thenReturn(scenario);

        VuxForm0420415V13DataEntity data1 = createDataEntity(typedIdCzen, typedIdStr);
        VuxForm0420415V13DataEntity data2 = createDataEntity(typedIdCzen, typedIdStr);

        DataContext ctx = new DataContext(
                1,
                List.of(createContext("<scenario/>")),
                Collections.emptyList(),
                Collections.emptyList(),
                List.of(data1, data2),
                List.of(createMeasureLink("kolcprinbuxuch", "m1")),
                Collections.emptyMap()
        );

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isPresent();
        assertThat(result.get().errorCode()).isEqualTo("DCUV_0420415_1_3_010");
        assertThat(result.get().errorMessage()).contains("несколько");
    }

    // ====== ТК-7: value не найдено → ошибка ======
    @Test
    @Disabled
    @DisplayName("Value не найдено → ошибка")
    void validate_valueNotFound_returnsError() {
        String typedIdCzen = "TEST_CZEN_001";
        String typedIdStr = "ID_50104_1";
        String elementName = "m1";

        FullXmlDto scenario = scenarioWithTypedMembers(typedIdCzen, typedIdStr);
        when(xmlParserService.parse(any(), eq(FullXmlDto.class))).thenReturn(scenario);

        DataContext ctx = new DataContext(
                1,
                List.of(createContext("<scenario/>")),
                Collections.emptyList(),
                Collections.emptyList(),
                List.of(createDataEntity(typedIdCzen, typedIdStr)),
                List.of(createMeasureLink("kolcprinbuxuch", elementName)),
                Collections.emptyMap()
        );

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isPresent();
        assertThat(result.get().errorCode()).isEqualTo("DCUV_0420415_1_3_010");
        assertThat(result.get().errorMessage()).contains("Не найдено value");
    }

    // ====== ТК-8: value с nil="true" → Optional.empty() ======
    @Test
    @Disabled
    @DisplayName("Value с nil=true → нет ошибки")
    void validate_nilValue_returnsEmpty() {
        String typedIdCzen = "TEST_CZEN_001";
        String typedIdStr = "ID_50104_1";
        String elementName = "m1";

        FullXmlDto scenario = scenarioWithTypedMembers(typedIdCzen, typedIdStr);
        when(xmlParserService.parse(any(), eq(FullXmlDto.class))).thenReturn(scenario);

        DataContext ctx = new DataContext(
                1,
                List.of(createContext("<scenario/>")),
                Collections.emptyList(),
                List.of(createValue(elementName, null, "true")),
                List.of(createDataEntity(typedIdCzen, typedIdStr)),
                List.of(createMeasureLink("kolcprinbuxuch", elementName)),
                Collections.emptyMap()
        );

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isEmpty();
    }

    // ====== ТК-9: Расхождение числового значения (measure) → ошибка ======
    @Test
    @Disabled
    @DisplayName("Расхождение числовых значений → ошибка")
    void validate_measureMismatch_returnsError() {
        String typedIdCzen = "TEST_CZEN_001";
        String typedIdStr = "ID_50104_1";
        String elementName = "m1";

        FullXmlDto scenario = scenarioWithTypedMembers(typedIdCzen, typedIdStr);
        when(xmlParserService.parse(any(), eq(FullXmlDto.class))).thenReturn(scenario);

        VuxForm0420415V13DataEntity data = createDataEntity(typedIdCzen, typedIdStr);
        data.setKolcprinbuxuch(BigDecimal.valueOf(100));

        DataContext ctx = new DataContext(
                1,
                List.of(createContext("<scenario/>")),
                Collections.emptyList(),
                List.of(createValue(elementName, "200", null)),
                List.of(data),
                List.of(createMeasureLink("kolcprinbuxuch", elementName)),
                Collections.emptyMap()
        );

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isPresent();
        assertThat(result.get().errorCode()).isEqualTo("DCUV_0420415_1_3_010");
        assertThat(result.get().errorMessage()).contains("kolcprinbuxuch");
    }

    // ====== ТК-10: analytical_section не совпадает → пропускаем ======
    @Test
    @Disabled
    @DisplayName("Analytical section не совпадает → нет ошибки")
    void validate_analyticalSectionMismatch_returnsEmpty() {
        String typedIdCzen = "TEST_CZEN_001";
        String typedIdStr = "ID_50104_1";
        String elementName = "m1";

        FullXmlDto scenario = scenarioWithTypedMembers(typedIdCzen, typedIdStr);
        when(xmlParserService.parse(any(), eq(FullXmlDto.class)))
                .thenReturn(scenario)
                .thenReturn(FullXmlDto.builder()
                        .members(List.of(
                                ExplicitMemberDto.builder()
                                        .dimension("dim-int:SomeAxis")
                                        .value("SomeValue")
                                        .build()
                        ))
                        .build());

        VuxDataXbrlLinkEntity link = createMeasureLink("kolcprinbuxuch", elementName);
        link.setAnalyticalSection("<analytical_section/>");

        DataContext ctx = new DataContext(
                1,
                List.of(createContext("<scenario/>")),
                Collections.emptyList(),
                List.of(createValue(elementName, "100", null)),
                List.of(createDataEntity(typedIdCzen, typedIdStr)),
                List.of(link),
                Collections.emptyMap()
        );

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isEmpty();
    }

    // ====== ТК-11: scenario == null (не парсится) → пропускаем ======
    @Test
    @Disabled
    @DisplayName("Scenario == null → нет ошибки")
    void validate_nullScenario_returnsEmpty() {
        when(xmlParserService.parse(any(), eq(FullXmlDto.class))).thenReturn(null);

        DataContext ctx = new DataContext(
                1,
                List.of(createContext("<scenario/>")),
                Collections.emptyList(),
                Collections.emptyList(),
                List.of(createDataEntity("val1", "str1")),
                List.of(createMeasureLink("kolcprinbuxuch", "m1")),
                Collections.emptyMap()
        );

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isEmpty();
    }

    // ====== ТК-12: Ошибка парсинга scenario → ошибка ======
    @Test
    @Disabled
    @DisplayName("Ошибка парсинга scenario → ошибка DCUV_0420415_1_3_010")
    void validate_scenarioParseError_returnsError() {
        when(xmlParserService.parse(any(), eq(FullXmlDto.class)))
                .thenThrow(new XmlParserException("Parse error", new Exception()));

        DataContext ctx = new DataContext(
                1,
                List.of(createContext("<broken>scenario")),
                Collections.emptyList(),
                Collections.emptyList(),
                List.of(createDataEntity("val1", "str1")),
                List.of(createMeasureLink("kolcprinbuxuch", "m1")),
                Collections.emptyMap()
        );

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isPresent();
        assertThat(result.get().errorCode()).isEqualTo("DCUV_0420415_1_3_010");
        assertThat(result.get().errorMessage()).contains("Ошибка парсинга scenario");
    }
}