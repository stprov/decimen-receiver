package ru.sbrf.gmap.vux.service.parser;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import org.junit.jupiter.api.Test;
import ru.sbrf.gmap.vux.dto.scenario.full.ExplicitMemberDto;
import ru.sbrf.gmap.vux.dto.scenario.full.FullXmlDto;
import ru.sbrf.gmap.vux.dto.scenario.full.TypedMemberDto;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class XmlParserServiceTest {

    private final XmlParserService parser = new XmlParserService();

    // -----------------------------------------------------------------------
    // ТК-1: Парсинг примера №1 → FullXmlDto
    // -----------------------------------------------------------------------
    private static final String XML_EXAMPLE_1 =
            "<xbrldi:explicitMember dimension=\"dim-int:Tip_czenBum_naPravSobstvAxis\">mem-int:KolCZenBumagPrinadOrgMember</xbrldi:explicitMember>" +
            "<xbrldi:typedMember dimension=\"dim-int:ID_strokiTaxis\"><dim-int:ID_strokiTypedname>ID_50104_1</dim-int:ID_strokiTypedname></xbrldi:typedMember>\n" +
            "    <xbrldi:typedMember dimension=\"dim-int:IDOrgVedUchPravCBTaxis\"><dim-int:ID_FL_YULTypedName>643_7702165310_1027739132563</dim-int:ID_FL_YULTypedName></xbrldi:typedMember>\n" +
            "    <xbrldi:typedMember dimension=\"dim-int:ID_CzennojBumagiTaxis\"><dim-int:ID_CzennojBumagi_TypedName>29021RMFS_RU000A105B11_DBVXFR_29021</dim-int:ID_CzennojBumagi_TypedName></xbrldi:typedMember>";

    @Test
    void parse_example1_returnsFullXmlDto() {
        FullXmlDto result = parser.parse(XML_EXAMPLE_1, FullXmlDto.class);

        assertThat(result.getMembers()).isNotNull();
        assertThat(result.getMembers()).hasSize(4);

        // explicitMember
        assertThat(result.getMembers().get(0))
                .isInstanceOf(ExplicitMemberDto.class);
        ExplicitMemberDto em = (ExplicitMemberDto) result.getMembers().get(0);
        assertThat(em.getDimension())
                .isEqualTo("dim-int:Tip_czenBum_naPravSobstvAxis");
        assertThat(em.getValue())
                .contains("mem-int:KolCZenBumagPrinadOrgMember");

        // typedMember[0] — ID_strokiTaxis
        assertThat(result.getMembers().get(1))
                .isInstanceOf(TypedMemberDto.class);
        TypedMemberDto tm0 = (TypedMemberDto) result.getMembers().get(1);
        assertThat(tm0.getDimension()).isEqualTo("dim-int:ID_strokiTaxis");
        assertThat(tm0.getTypedName()).isEqualTo("ID_50104_1");

        // typedMember[1] — IDOrgVedUchPravCBTaxis
        TypedMemberDto tm1 = (TypedMemberDto) result.getMembers().get(2);
        assertThat(tm1.getDimension()).isEqualTo("dim-int:IDOrgVedUchPravCBTaxis");
        assertThat(tm1.getTypedName()).isEqualTo("643_7702165310_1027739132563");

        // typedMember[2] — ID_CzennojBumagiTaxis
        TypedMemberDto tm2 = (TypedMemberDto) result.getMembers().get(3);
        assertThat(tm2.getDimension()).isEqualTo("dim-int:ID_CzennojBumagiTaxis");
        assertThat(tm2.getTypedName()).isEqualTo("29021RMFS_RU000A105B11_DBVXFR_29021");
    }

    // -----------------------------------------------------------------------
    // ТК-2: Парсинг примера №2 (другой порядок typedMember)
    // -----------------------------------------------------------------------
    private static final String XML_EXAMPLE_2 =
            "<xbrldi:explicitMember dimension=\"dim-int:Tip_czenBum_naPravSobstvAxis\">mem-int:KolCZenBumagPrinadOrgMember</xbrldi:explicitMember>" +
            "<xbrldi:typedMember dimension=\"dim-int:IDOrgVedUchPravCBTaxis\"><dim-int:ID_FL_YULTypedName>643_7702165310_1027739132563</dim-int:ID_FL_YULTypedName></xbrldi:typedMember>\n" +
            "    <xbrldi:typedMember dimension=\"dim-int:ID_strokiTaxis\"><dim-int:ID_strokiTypedname>ID_50104_1</dim-int:ID_strokiTypedname></xbrldi:typedMember>\n" +
            "    <xbrldi:typedMember dimension=\"dim-int:ID_CzennojBumagiTaxis\"><dim-int:ID_CzennojBumagi_TypedName>29024RMFS_RU000A1066D5_DBVXFR_29024</dim-int:ID_CzennojBumagi_TypedName></xbrldi:typedMember>";

    @Test
    void parse_example2_differentTypedMemberOrder() {
        FullXmlDto result = parser.parse(XML_EXAMPLE_2, FullXmlDto.class);

        assertThat(result.getMembers()).hasSize(4);

        // typedMember[0] — IDOrgVedUchPravCBTaxis (первый)
        TypedMemberDto tm0 = (TypedMemberDto) result.getMembers().get(1);
        assertThat(tm0.getDimension()).isEqualTo("dim-int:IDOrgVedUchPravCBTaxis");

        // typedMember[1] — ID_strokiTaxis
        TypedMemberDto tm1 = (TypedMemberDto) result.getMembers().get(2);
        assertThat(tm1.getDimension()).isEqualTo("dim-int:ID_strokiTaxis");

        // typedMember[2] — ID_CzennojBumagiTaxis
        TypedMemberDto tm2 = (TypedMemberDto) result.getMembers().get(3);
        assertThat(tm2.getDimension()).isEqualTo("dim-int:ID_CzennojBumagiTaxis");
        assertThat(tm2.getTypedName()).isEqualTo("29024RMFS_RU000A1066D5_DBVXFR_29024");
    }

    // -----------------------------------------------------------------------
    // ТК-3: Парсинг примера №3 (другой explicitMember)
    // -----------------------------------------------------------------------
    private static final String XML_EXAMPLE_3 =
            "<xbrldi:explicitMember dimension=\"dim-int:Tip_czenBum_naPravSobstvAxis\">mem-int:KolCPrinBuxUchVkachFinVlozhZaIsklVozvrOsnBezPrekrPriznMember</xbrldi:explicitMember>" +
            "<xbrldi:typedMember dimension=\"dim-int:IDOrgVedUchPravCBTaxis\"><dim-int:ID_FL_YULTypedName>643_7702165310_1027739132563</dim-int:ID_FL_YULTypedName></xbrldi:typedMember>\n" +
            "    <xbrldi:typedMember dimension=\"dim-int:ID_strokiTaxis\"><dim-int:ID_strokiTypedname>ID_50106_1</dim-int:ID_strokiTypedname></xbrldi:typedMember>\n" +
            "    <xbrldi:typedMember dimension=\"dim-int:ID_CzennojBumagiTaxis\"><dim-int:ID_CzennojBumagi_TypedName>4B02-448-01481-B-001P_RU000A103216_DBFUFB_SBER-IOS442</dim-int:ID_CzennojBumagi_TypedName></xbrldi:typedMember>";

    @Test
    void parse_example3_differentExplicitMemberValue() {
        FullXmlDto result = parser.parse(XML_EXAMPLE_3, FullXmlDto.class);

        assertThat(result.getMembers()).hasSize(4);

        ExplicitMemberDto em = (ExplicitMemberDto) result.getMembers().get(0);
        assertThat(em.getValue())
                .contains("mem-int:KolCPrinBuxUchVkachFinVlozhZaIsklVozvrOsnBezPrekrPriznMember");

        TypedMemberDto tm1 = (TypedMemberDto) result.getMembers().get(2);
        assertThat(tm1.getTypedName()).isEqualTo("ID_50106_1");

        TypedMemberDto tm2 = (TypedMemberDto) result.getMembers().get(3);
        assertThat(tm2.getTypedName())
                .isEqualTo("4B02-448-01481-B-001P_RU000A103216_DBFUFB_SBER-IOS442");
    }

    // -----------------------------------------------------------------------
    // ТК-4: Парсинг примера №4 (порядок + без отступов)
    // -----------------------------------------------------------------------
    private static final String XML_EXAMPLE_4 =
            "<xbrldi:explicitMember dimension=\"dim-int:Tip_czenBum_naPravSobstvAxis\">mem-int:KolCPrinBuxUchVkachFinVlozhZaIsklVozvrOsnBezPrekrPriznMember</xbrldi:explicitMember>" +
            "<xbrldi:typedMember dimension=\"dim-int:IDOrgVedUchPravCBTaxis\"><dim-int:ID_FL_YULTypedName>643_7702165310_1027739132563</dim-int:ID_FL_YULTypedName></xbrldi:typedMember>\n" +
            "<xbrldi:typedMember dimension=\"dim-int:ID_CzennojBumagiTaxis\"><dim-int:ID_CzennojBumagi_TypedName>1-01-01286-G_RU000A106T36_ESVXFR_ASTR</dim-int:ID_CzennojBumagi_TypedName></xbrldi:typedMember>\n" +
            "<xbrldi:typedMember dimension=\"dim-int:ID_strokiTaxis\"><dim-int:ID_strokiTypedname>ID_50606_1</dim-int:ID_strokiTypedname></xbrldi:typedMember>";

    @Test
    void parse_example4_noIndentationMixedOrder() {
        FullXmlDto result = parser.parse(XML_EXAMPLE_4, FullXmlDto.class);

        assertThat(result.getMembers()).hasSize(4);

        TypedMemberDto tm0 = (TypedMemberDto) result.getMembers().get(1);
        assertThat(tm0.getDimension()).isEqualTo("dim-int:IDOrgVedUchPravCBTaxis");

        TypedMemberDto tm1 = (TypedMemberDto) result.getMembers().get(2);
        assertThat(tm1.getDimension()).isEqualTo("dim-int:ID_CzennojBumagiTaxis");
        assertThat(tm1.getTypedName()).isEqualTo("1-01-01286-G_RU000A106T36_ESVXFR_ASTR");

        TypedMemberDto tm2 = (TypedMemberDto) result.getMembers().get(3);
        assertThat(tm2.getTypedName()).isEqualTo("ID_50606_1");
    }

    // -----------------------------------------------------------------------
    // ТК-5: null / пустая строка
    // -----------------------------------------------------------------------
    @Test
    void parse_null_returnsNull() {
        assertThat(parser.parse(null, FullXmlDto.class)).isNull();
    }

    @Test
    void parse_emptyString_returnsNull() {
        assertThat(parser.parse("", FullXmlDto.class)).isNull();
    }

    @Test
    void parse_blankString_returnsNull() {
        assertThat(parser.parse("   ", FullXmlDto.class)).isNull();
    }

    // -----------------------------------------------------------------------
    // ТК-6: Некорректный XML → XmlParserException
    // -----------------------------------------------------------------------
    @Test
    void parse_brokenXml_throwsXmlParserException() {
        assertThatThrownBy(() -> parser.parse("<broken>xml", FullXmlDto.class))
                .isInstanceOf(XmlParserException.class);
    }

    @Test
    void parse_notXml_throwsXmlParserException() {
        assertThatThrownBy(() -> parser.parse("<<<>>>", FullXmlDto.class))
                .isInstanceOf(XmlParserException.class);
    }

    // -----------------------------------------------------------------------
    // ТК-7: Generic-тип — работа с другим DTO
    // -----------------------------------------------------------------------

    @XmlRootElement(name = "root")
    static class TestDto {
        @XmlElement
        private String name;

        public String getName() {
            return name;
        }
    }

    @Test
    void parse_genericWithCustomDto_works() {
        TestDto result = parser.parse("<name>hello</name>", TestDto.class);

        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo("hello");
    }
}