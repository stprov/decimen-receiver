package ru.sbrf.gmap.vux.service.validation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ContextDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13UnitDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;
import ru.sbrf.gmap.vux.service.checks.DataContext;
import ru.sbrf.gmap.vux.service.checks.MissingUnitDescriptionsRule;
import ru.sbrf.gmap.vux.service.checks.SummaryAnalyticsRule;
import ru.sbrf.gmap.vux.service.checks.TaxonomyMismatchRule;
import ru.sbrf.gmap.vux.service.checks.UnitExistsRule;
import ru.sbrf.gmap.vux.service.checks.ValueExistsRule;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Исправленные CUV-правила (аналитика, раздел 12: DEF-24…DEF-26, D-52).
 */
@DisplayName("CUV-правила: исправления по постановке")
class CuvRulesFixesTest {

    private static final long WF = 42L;

    private static VuxForm0420415V13ContextDto context(String id, String taxonomy) {
        return VuxForm0420415V13ContextDto.builder().contextId(id).taxonomy(taxonomy).workflowRunId(WF).build();
    }

    private static VuxForm0420415V13UnitDto unit(String id) {
        return VuxForm0420415V13UnitDto.builder().unitId(id).taxonomy("7.1").workflowRunId(WF).build();
    }

    private static VuxForm0420415V13ValueDto value(String contextId, String unitId) {
        return VuxForm0420415V13ValueDto.builder().contextId(contextId).unitId(unitId).taxonomy("7.1").workflowRunId(WF).build();
    }

    private static DataContext ctx(List<VuxForm0420415V13ContextDto> contexts, List<VuxForm0420415V13UnitDto> units,
                                   List<VuxForm0420415V13ValueDto> values, Set<String> dataTaxonomies) {
        return new DataContext(1, contexts, units, values, List.of(), List.of(), Map.of(), dataTaxonomies, WF);
    }

    @Test
    @DisplayName("T-24, DEF-25: пустой unit_id не ошибка, код _008, в тексте все unit_id")
    void missingUnits() {
        MissingUnitDescriptionsRule rule = new MissingUnitDescriptionsRule();
        DataContext data = ctx(List.of(context("c1", "7.1")), List.of(unit("u1")),
                List.of(value("c1", null), value("c1", " "), value("c1", "u1"), value("c1", "u3"), value("c1", "u2")),
                Set.of());

        Optional<ValidationErrorDto> error = rule.validate(data);

        assertThat(error).isPresent();
        assertThat(error.get().errorCode()).isEqualTo("DCUV_0420415_1_3_008");
        assertThat(error.get().errorMessage()).contains("u2").contains("u3");
    }

    @Test
    @DisplayName("T-24: только пустые unit_id — ошибки нет")
    void missingUnits_onlyEmpty() {
        DataContext data = ctx(List.of(context("c1", "7.1")), List.of(unit("u1")),
                List.of(value("c1", null), value("c1", "")), Set.of());

        assertThat(new MissingUnitDescriptionsRule().validate(data)).isEmpty();
    }

    @Test
    @DisplayName("DEF-24: таксономия data (xbrlvers) участвует в сравнении")
    void taxonomyIncludesData() {
        TaxonomyMismatchRule rule = new TaxonomyMismatchRule();
        List<VuxForm0420415V13ContextDto> contexts = List.of(context("c1", "7.1"));
        List<VuxForm0420415V13UnitDto> units = List.of(unit("u1"));
        List<VuxForm0420415V13ValueDto> values = List.of(value("c1", "u1"));

        assertThat(rule.validate(ctx(contexts, units, values, Set.of("7.1")))).isEmpty();
        Optional<ValidationErrorDto> mismatch = rule.validate(ctx(contexts, units, values, Set.of("7.2")));
        assertThat(mismatch).isPresent();
        assertThat(mismatch.get().errorCode()).isEqualTo("DCUV_0420415_1_3_009");
        assertThat(mismatch.get().errorMessage()).contains("workflow_run_id = 42");
    }

    @Test
    @DisplayName("DEF-26: тексты ошибок 3 и 4 по постановке")
    void unitAndValueTexts() {
        DataContext empty = DataContext.empty(1, WF);

        assertThat(new UnitExistsRule().validate(empty)).get().extracting(ValidationErrorDto::errorMessage)
                .isEqualTo("По workflow_run_id = 42 НЕ получен набор единиц измерений unit.");
        assertThat(new ValueExistsRule().validate(empty)).get().extracting(ValidationErrorDto::errorMessage)
                .isEqualTo("По workflow_run_id = 42 НЕ получен набор значений value.");
    }

    @Test
    @DisplayName("D-52: проверка 10 выключена")
    void summaryAnalyticsDisabled() {
        assertThat(new SummaryAnalyticsRule(null).isEnabled()).isFalse();
    }
}
