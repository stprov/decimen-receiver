package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;

@DisplayName("RetryExecutor")
class RetryExecutorTest {

    private final RetryExecutor executor = new RetryExecutor();

    @Test
    @DisplayName("Успех с первой попытки — одна попытка")
    void successFirstAttempt() {
        AtomicInteger calls = new AtomicInteger();

        Optional<String> result = executor.execute("op", 3, 0, () -> {
            calls.incrementAndGet();
            return Optional.of("ok");
        });

        assertThat(result).contains("ok");
        assertThat(calls).hasValue(1);
    }

    @Test
    @DisplayName("Пустой результат и исключение — повтор, успех на третьей попытке")
    void retriesUntilSuccess() {
        AtomicInteger calls = new AtomicInteger();

        Optional<String> result = executor.execute("op", 3, 0, () -> {
            int n = calls.incrementAndGet();
            if (n == 1) {
                return Optional.empty();
            }
            if (n == 2) {
                throw new IllegalStateException("fail");
            }
            return Optional.of("ok");
        });

        assertThat(result).contains("ok");
        assertThat(calls).hasValue(3);
    }

    @Test
    @DisplayName("Все попытки неуспешны — пустой результат, число попыток = maxAttempts")
    void allAttemptsFail() {
        AtomicInteger calls = new AtomicInteger();

        Optional<String> result = executor.execute("op", 2, 0, () -> {
            calls.incrementAndGet();
            return null;
        });

        assertThat(result).isEmpty();
        assertThat(calls).hasValue(2);
    }

    @Test
    @DisplayName("maxAttempts < 1 — одна попытка")
    void atLeastOneAttempt() {
        AtomicInteger calls = new AtomicInteger();

        executor.execute("op", 0, 0, () -> {
            calls.incrementAndGet();
            return Optional.empty();
        });

        assertThat(calls).hasValue(1);
    }

    @Test
    @DisplayName("executeBoolean: true — успех, false — неуспех")
    void executeBoolean() {
        assertThat(executor.executeBoolean("op", 2, 0, () -> true)).isTrue();
        assertThat(executor.executeBoolean("op", 2, 0, () -> false)).isFalse();
    }
}
