package ru.sbrf.gmap.vux.service;

import freemarker.template.Configuration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sbrf.gmap.vux.config.MailSheduledSenderProps;
import ru.sbrf.gmap.vux.entity.EmailInfoScheduleEntity;
import ru.sbrf.gmap.vux.entity.enums.InfoEmailTypeEnum;
import ru.sbrf.gmap.vux.repository.EmailInfoScheduleRepository;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.time.LocalDateTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.assertj.core.api.Assertions.within;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("EmailSchedulerService — рассылка информационных писем по типам")
class EmailSchedulerServiceTest {

    @Mock
    private EmailInfoScheduleRepository emailInfoScheduleRepository;
    @Mock
    private MailService mailService;
    @Mock
    private VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;

    private EmailSchedulerService emailSchedulerService;

    @BeforeEach
    void setUp() {
        emailSchedulerService = createService(new MailSheduledSenderProps(7));
        // sendMail возвращает признак успеха (DEF-13): по умолчанию письмо отправлено
        lenient().doReturn(true).when(mailService).sendMail(anyString(), anyString(), anyList(), anyList(), anyBoolean());
    }

    private EmailSchedulerService createService(MailSheduledSenderProps props) {
        Configuration freemarker = new Configuration(Configuration.VERSION_2_3_32);
        freemarker.setClassLoaderForTemplateLoading(getClass().getClassLoader(), "templates");
        freemarker.setDefaultEncoding("UTF-8");

        EmailSchedulerService service = new EmailSchedulerService(
                freemarker, emailInfoScheduleRepository, mailService,
                vuxDocumentValidationResultViewRepository, props);
        service.init();
        return service;
    }

    @Test
    @DisplayName("VERIFICATION: тема, deadline в dd.MM.yyyy, формы отдельными строками, чек-листы, контакты")
    void verificationType_sendsCheckReminderMail() {
        EmailInfoScheduleEntity record = verificationRecord();

        stubRepo(InfoEmailTypeEnum.VERIFICATION, List.of(record));
        stubRepo(InfoEmailTypeEnum.PREPARATION, List.of());

        emailSchedulerService.run();

        ArgumentCaptor<String> subjectCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> bodyCaptor = ArgumentCaptor.forClass(String.class);
        @SuppressWarnings("unchecked")
        ArgumentCaptor<List<String>> toCaptor = ArgumentCaptor.forClass(List.class);
        @SuppressWarnings("unchecked")
        ArgumentCaptor<List<String>> ccCaptor = ArgumentCaptor.forClass(List.class);

        verify(mailService).sendMail(subjectCaptor.capture(), bodyCaptor.capture(),
                toCaptor.capture(), ccCaptor.capture(), eq(false));
        verify(vuxDocumentValidationResultViewRepository).fnFlowInfoEmalSend(1L);

        assertThat(subjectCaptor.getValue())
                .isEqualTo("Напоминание о проверке готовности отчетных форм ВУИКС: 10-дневной ежемесячной за май 2026 г.");

        String body = bodyCaptor.getValue();
        assertThat(body)
                .contains("29.05.2026")
                .contains("<strong>10-дневной ежемесячной</strong>")
                .contains("<strong>май 2026 г.</strong>")
                .contains("<td>0420416</td>")
                .contains("<td>0420459</td>")
                .contains("Чек-лист для подготовки отчетности")
                .contains("Чек-лист второй руки")
                .contains("\\\\Inter232.sigma.sbrf.ru\\vol3\\Diasoft-Clearing-XBRL")
                .contains("7. Ручные контроли")
                .contains("EALukicheva@sberbank.ru")
                .contains("SSeShirnin@sberbank.ru");
        assertThat(toCaptor.getValue()).containsExactly("a@sberbank.ru", "b@sberbank.ru");
        assertThat(ccCaptor.getValue()).containsExactly("c@sberbank.ru");
    }

    @Test
    @DisplayName("PREPARATION: прежняя тема и шаблон mail_reminder, факт отправки фиксируется")
    void preparationType_sendsPreparationMail() {
        EmailInfoScheduleEntity record = preparationRecord();

        stubRepo(InfoEmailTypeEnum.VERIFICATION, List.of());
        stubRepo(InfoEmailTypeEnum.PREPARATION, List.of(record));

        emailSchedulerService.run();

        ArgumentCaptor<String> subjectCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> bodyCaptor = ArgumentCaptor.forClass(String.class);

        verify(mailService).sendMail(subjectCaptor.capture(), bodyCaptor.capture(),
                anyList(), anyList(), eq(false));
        verify(vuxDocumentValidationResultViewRepository).fnFlowInfoEmalSend(2L);

        assertThat(subjectCaptor.getValue())
                .isEqualTo("Напоминание о подготовке отчетных форм ВУИКС: 10-дневной ежемесячной за май 2026 г.");
        assertThat(bodyCaptor.getValue())
                .contains("01.05.2026")
                .contains("30.06.2026")
                .contains("<strong>7.1</strong>")
                .contains("<strong>2.3.3</strong>");
    }

    @Test
    @DisplayName("Окно давности: в репозиторий передаётся порог now - maxPastDays дней (по умолчанию 7)")
    void run_passesThresholdNowMinusMaxPastDays() {
        stubRepo(InfoEmailTypeEnum.VERIFICATION, List.of());
        stubRepo(InfoEmailTypeEnum.PREPARATION, List.of());

        LocalDateTime before = LocalDateTime.now();
        emailSchedulerService.run();
        LocalDateTime after = LocalDateTime.now();

        ArgumentCaptor<LocalDateTime> thresholdCaptor = ArgumentCaptor.forClass(LocalDateTime.class);
        verify(emailInfoScheduleRepository, times(2))
                .findByInfoEmailTypeAndSendTimeGreaterThanEqualOrderByIdAsc(any(), thresholdCaptor.capture());
        // Порог одинаковый для обоих типов в рамках одного цикла
        assertThat(thresholdCaptor.getAllValues())
                .allSatisfy(t -> assertThat(t).isBetween(before.minusDays(7), after.minusDays(7)));
    }

    @Test
    @DisplayName("Ненулевое max-past-days из конфига учитывается при расчёте порога")
    void run_usesConfiguredMaxPastDays() {
        emailSchedulerService = createService(new MailSheduledSenderProps(3));

        stubRepo(InfoEmailTypeEnum.VERIFICATION, List.of());
        stubRepo(InfoEmailTypeEnum.PREPARATION, List.of());

        LocalDateTime before = LocalDateTime.now();
        emailSchedulerService.run();
        LocalDateTime after = LocalDateTime.now();

        ArgumentCaptor<LocalDateTime> thresholdCaptor = ArgumentCaptor.forClass(LocalDateTime.class);
        verify(emailInfoScheduleRepository, times(2))
                .findByInfoEmailTypeAndSendTimeGreaterThanEqualOrderByIdAsc(any(), thresholdCaptor.capture());
        assertThat(thresholdCaptor.getAllValues())
                .allSatisfy(t -> assertThat(t).isBetween(before.minusDays(3), after.minusDays(3)));
    }

    @Test
    @DisplayName("Пустая витрина: ни одной отправки и вызовов процедуры фиксации")
    void emptySchedule_nothingSent() {
        emailSchedulerService.run();

        verifyNoInteractions(mailService);
        verify(vuxDocumentValidationResultViewRepository, never()).fnFlowInfoEmalSend(anyLong());
    }

    @Test
    @DisplayName("Запись с NULL-типом пропускается без отправки и без падения шедулера")
    void nullTypeRecord_skipped() {
        EmailInfoScheduleEntity record = verificationRecord();
        record.setInfoEmailType(null);
        stubRepo(InfoEmailTypeEnum.VERIFICATION, List.of(record));
        stubRepo(InfoEmailTypeEnum.PREPARATION, List.of());

        assertThatNoException().isThrownBy(() -> emailSchedulerService.run());

        verifyNoInteractions(mailService);
        verify(vuxDocumentValidationResultViewRepository, never()).fnFlowInfoEmalSend(anyLong());
    }

    @Test
    @DisplayName("Ошибка при обработке одной записи не останавливает обработку остальных")
    void recordFailure_doesNotStopOtherRecords() {
        EmailInfoScheduleEntity failing = verificationRecord();
        failing.setId(1L);
        EmailInfoScheduleEntity healthy = verificationRecord();
        healthy.setId(3L);

        stubRepo(InfoEmailTypeEnum.VERIFICATION, List.of(failing, healthy));
        stubRepo(InfoEmailTypeEnum.PREPARATION, List.of());
        when(vuxDocumentValidationResultViewRepository.fnFlowInfoEmalSend(1L))
                .thenThrow(new IllegalStateException("db failure"));

        assertThatNoException().isThrownBy(() -> emailSchedulerService.run());

        verify(mailService, times(2)).sendMail(anyString(), anyString(), anyList(), anyList(), eq(false));
        verify(vuxDocumentValidationResultViewRepository).fnFlowInfoEmalSend(3L);
    }

    @Test
    @DisplayName("DEF-13: сбой отправки — факт не фиксируется, запись остаётся до следующего запуска")
    void mailFailure_notMarkedAsSent() {
        EmailInfoScheduleEntity record = preparationRecord();
        stubRepo(InfoEmailTypeEnum.VERIFICATION, List.of());
        stubRepo(InfoEmailTypeEnum.PREPARATION, List.of(record));
        doReturn(false).when(mailService).sendMail(anyString(), anyString(), anyList(), anyList(), anyBoolean());

        assertThatNoException().isThrownBy(() -> emailSchedulerService.run());

        verify(vuxDocumentValidationResultViewRepository, never()).fnFlowInfoEmalSend(anyLong());
    }

    // --- Вспомогательные методы ---

    private void stubRepo(InfoEmailTypeEnum type, List<EmailInfoScheduleEntity> records) {
        when(emailInfoScheduleRepository
                .findByInfoEmailTypeAndSendTimeGreaterThanEqualOrderByIdAsc(eq(type), any(LocalDateTime.class)))
                .thenReturn(records);
    }

    private EmailInfoScheduleEntity verificationRecord() {
        EmailInfoScheduleEntity entity = new EmailInfoScheduleEntity();
        entity.setId(1L);
        entity.setInfoEmailType(InfoEmailTypeEnum.VERIFICATION);
        entity.setSendTime(LocalDateTime.now());
        entity.setReportingType("10-дневной ежемесячной");
        entity.setReportDt("май 2026 г.");
        entity.setForms("0420416, 0420459");
        entity.setDeadlineDate(LocalDateTime.of(2026, 5, 29, 0, 0));
        entity.setReceiversList("a@sberbank.ru; b@sberbank.ru");
        entity.setCopyList("c@sberbank.ru");
        return entity;
    }

    private EmailInfoScheduleEntity preparationRecord() {
        EmailInfoScheduleEntity entity = new EmailInfoScheduleEntity();
        entity.setId(2L);
        entity.setInfoEmailType(InfoEmailTypeEnum.PREPARATION);
        entity.setSendTime(LocalDateTime.now());
        entity.setReportingType("10-дневной ежемесячной");
        entity.setReportDt("май 2026 г.");
        entity.setForms("0420415");
        entity.setStartDate(LocalDateTime.of(2026, 5, 1, 0, 0));
        entity.setDeadlineDate(LocalDateTime.of(2026, 6, 30, 0, 0));
        entity.setTaxonomy("7.1");
        entity.setConverterVersion("2.3.3");
        entity.setReceiversList("user1@sberbank.ru,user2@sberbank.ru");
        entity.setCopyList("manager1@sberbank.ru");
        return entity;
    }
}
