package ru.sbrf.gmap.vux.service.validation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sbrf.gmap.vux.service.checks.DataContext;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ContextDto;
import ru.sbrf.gmap.vux.service.checks.WorkflowRunIdRule;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
@DisplayName("WorkflowRunIdRule")
class WorkflowRunIdRuleTest {

    private final WorkflowRunIdRule rule = new WorkflowRunIdRule();

    @Test
    @DisplayName("validate пустой contextList → ошибка DCUV_0420415_1_3_001")
    void validate_emptyContextList_returnsError() {
        DataContext ctx = new DataContext(
                1,
                Collections.emptyList(),
                Collections.emptyList(),
                Collections.emptyList(),
                Collections.emptyList(),
                Collections.emptyList(),
                Collections.emptyMap()
        );

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isPresent();
        assertThat(result.get().errorCode()).isEqualTo("DCUV_0420415_1_3_001");
        assertThat(result.get().errorMessage())
                .containsIgnoringCase("workflow_run_id")
                .containsIgnoringCase("не заполнен");
    }

    @Test
    @DisplayName("validate workflowRunId = null → ошибка DCUV_0420415_1_3_001")
    void validate_nullWorkflowRunId_returnsError() {
        VuxForm0420415V13ContextDto context = createContext(null);
        DataContext ctx = createCheckDataContext(context);

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isPresent();
        assertThat(result.get().errorCode()).isEqualTo("DCUV_0420415_1_3_001");
    }

    @Test
    @DisplayName("validate workflowRunId = 0 → ошибка DCUV_0420415_1_3_001")
    void validate_zeroWorkflowRunId_returnsError() {
        VuxForm0420415V13ContextDto context = createContext(0L);
        DataContext ctx = createCheckDataContext(context);

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isPresent();
        assertThat(result.get().errorCode()).isEqualTo("DCUV_0420415_1_3_001");
    }

    @Test
    @DisplayName("validate workflowRunId = 1 → успех (нет ошибки)")
    void validate_positiveWorkflowRunId_returnsEmpty() {
        VuxForm0420415V13ContextDto context = createContext(1L);
        DataContext ctx = createCheckDataContext(context);

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isEmpty();
    }

    @Test
    @DisplayName("validate workflowRunId = Long.MAX_VALUE → успех")
    void validate_maxLongWorkflowRunId_returnsEmpty() {
        VuxForm0420415V13ContextDto context = createContext(Long.MAX_VALUE);
        DataContext ctx = createCheckDataContext(context);

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isEmpty();
    }

    @Test
    @DisplayName("validate workflowRunId = 100 → успех")
    void validate_largePositiveWorkflowRunId_returnsEmpty() {
        VuxForm0420415V13ContextDto context = createContext(100L);
        DataContext ctx = createCheckDataContext(context);

        Optional<ValidationErrorDto> result = rule.validate(ctx);

        assertThat(result).isEmpty();
    }

    @Test
    @DisplayName("validate workflow_run_id из view задан, context пуст → успех (это ошибка _002, Q-8 п. 2.1)")
    void validate_workflowRunIdFromView_emptyContext_returnsEmpty() {
        assertThat(rule.validate(DataContext.empty(1, 42L))).isEmpty();
    }

    @Test
    @DisplayName("validate workflow_run_id из view не задан, context пуст → ошибка DCUV_0420415_1_3_001")
    void validate_noWorkflowRunIdFromView_returnsError() {
        Optional<ValidationErrorDto> result = rule.validate(DataContext.empty(1, null));

        assertThat(result).isPresent();
        assertThat(result.get().errorCode()).isEqualTo("DCUV_0420415_1_3_001");
    }

    // Вспомогательные методы
    private static VuxForm0420415V13ContextDto createContext(Long workflowRunId) {
        return new VuxForm0420415V13ContextDto(
                UUID.randomUUID(),
                "ctx-1",
                "YEAR",
                "2025",
                "id-1",
                "scheme-1",
                "segment-1",
                "scenario-1",
                LocalDate.of(2025, 1, 1),
                LocalDate.of(2025, 12, 31),
                "taxonomy-1",
                workflowRunId
        );
    }

    private static DataContext createCheckDataContext(VuxForm0420415V13ContextDto... contexts) {
        return new DataContext(
                1,
                List.of(contexts),
                Collections.emptyList(),
                Collections.emptyList(),
                Collections.emptyList(),
                Collections.emptyList(),
                Collections.emptyMap()
        );
    }
}