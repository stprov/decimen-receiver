package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.repository.VuxDocumentScheduleViewRepository;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

/**
 * Оркестратор: закрытие расписания только при завершённой обработке (аналитика, D-10, D-14, 9.1).
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("OrchestratorService")
class OrchestratorServiceTest {

    @Mock
    private VuxDocumentScheduleViewRepository scheduleRepository;
    @Mock
    private VuxDocumentValidationResultViewRepository viewRepository;
    @Mock
    private DocumentProcessingService newDocuments;
    @Mock
    private DocumentProcessingService existingDocuments;

    private OrchestratorService service() {
        return new OrchestratorService(scheduleRepository, viewRepository, List.of(newDocuments, existingDocuments));
    }

    private static VuxDocumentScheduleViewEntity record(int scheduleId, String ecmId) {
        VuxDocumentScheduleViewEntity record = new VuxDocumentScheduleViewEntity();
        record.setScheduleId(scheduleId);
        record.setResultDocumentId(scheduleId * 10);
        record.setEcmId(ecmId);
        return record;
    }

    private void route(VuxDocumentScheduleViewEntity newRecord, VuxDocumentScheduleViewEntity existingRecord) {
        when(newDocuments.supports(any())).thenAnswer(i -> i.getArgument(0) == newRecord);
        when(existingDocuments.supports(any())).thenAnswer(i -> i.getArgument(0) == existingRecord);
    }

    @Test
    @DisplayName("Пустое расписание — функции загрузки вызваны, стратегии не вызываются")
    void emptySchedule() {
        when(scheduleRepository.findAll()).thenReturn(List.of());

        service().run();

        verify(viewRepository).fnLoadShedule();
        verify(viewRepository).processSchedule();
        verifyNoInteractions(newDocuments, existingDocuments);
    }

    @Test
    @DisplayName("COMPLETED — расписание закрывается, PENDING — нет (FR-1.4, FR-2.7)")
    void resolvesOnlyCompleted() {
        VuxDocumentScheduleViewEntity first = record(1, null);
        VuxDocumentScheduleViewEntity second = record(2, "ecm");
        when(scheduleRepository.findAll()).thenReturn(List.of(first, second));
        route(first, second);
        when(newDocuments.processDocument(first)).thenReturn(ProcessingResult.PENDING);
        when(existingDocuments.processDocument(second)).thenReturn(ProcessingResult.COMPLETED);
        when(viewRepository.flowResolveShedule(2)).thenReturn(Optional.of("3"));

        service().run();

        verify(viewRepository, never()).flowResolveShedule(1);
        verify(viewRepository).flowResolveShedule(2);
        verify(newDocuments, never()).processDocument(second);
        verify(existingDocuments, never()).processDocument(first);
    }

    @Test
    @DisplayName("Сбой закрытия одной записи не прерывает обработку остальных")
    void resolveFailure_doesNotStopCycle() {
        VuxDocumentScheduleViewEntity first = record(1, null);
        VuxDocumentScheduleViewEntity second = record(2, null);
        when(scheduleRepository.findAll()).thenReturn(List.of(first, second));
        when(newDocuments.supports(any())).thenReturn(true);
        when(existingDocuments.supports(any())).thenReturn(false);
        when(newDocuments.processDocument(any())).thenReturn(ProcessingResult.COMPLETED);
        when(viewRepository.flowResolveShedule(1)).thenThrow(new IllegalStateException("db"));
        when(viewRepository.flowResolveShedule(2)).thenReturn(Optional.of("расписание должно быть в статусе 1 или 2"));

        service().run();

        verify(viewRepository).flowResolveShedule(1);
        verify(viewRepository).flowResolveShedule(2);
    }

    @Test
    @DisplayName("Сбой загрузки расписания не выбрасывается наружу")
    void loadFailure_swallowed() {
        when(viewRepository.fnLoadShedule()).thenThrow(new IllegalStateException("db"));

        service().run();

        verifyNoInteractions(newDocuments, existingDocuments);
    }
}
