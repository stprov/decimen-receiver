package ru.sbrf.gmap.vux.service;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.support.Acknowledgment;
import ru.sber.tfs.domain.AttrIntType;
import ru.sber.tfs.domain.BusinessAttrsType;
import ru.sber.tfs.domain.DownloadFileEcmRs;
import ru.sber.tfs.domain.UploadFileEcmRs;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("TfsResponseListener")
class TfsResponseListenerTest {

    @Mock
    private EcmRqRsSerdesService ecmRqRsSerdesService;
    @Mock
    private VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;
    @Mock
    private Acknowledgment ack;

    private TfsResponseListener listener;

    private static final String DASHLESS_RQUID = "123e4567e89b12d3a456426614174000";
    private static final String RQUID = "123e4567-e89b-12d3-a456-426614174000";

    @BeforeEach
    void setUp() {
        listener = new TfsResponseListener(ecmRqRsSerdesService, vuxDocumentValidationResultViewRepository);
    }

    @Test
    @DisplayName("rqUid присутствует в очереди, успех: вызывается fn_ecm_request_set_ecm_id")
    void processResponse_inQueueSuccess_callsSetEcmId() {
        when(ecmRqRsSerdesService.readEcmResponse(any())).thenReturn(buildResponse("ecm-uuid-123", 0));
        when(vuxDocumentValidationResultViewRepository.existsInEcmQueue(RQUID)).thenReturn(true);

        listener.tfsResponseConsumer(record(), ack);

        verify(vuxDocumentValidationResultViewRepository).fnEcmRequestSetEcmId(eq(RQUID), eq("ecm-uuid-123"));
        verify(vuxDocumentValidationResultViewRepository, never()).fnEcmRequestSetError(any(), any());
        verify(ack).acknowledge();
    }

    @Test
    @DisplayName("rqUid присутствует в очереди, ошибка квитанции: вызывается fn_ecm_request_set_error")
    void processResponse_inQueueError_callsSetError() {
        when(ecmRqRsSerdesService.readEcmResponse(any())).thenReturn(buildResponse(null, 1));
        when(vuxDocumentValidationResultViewRepository.existsInEcmQueue(RQUID)).thenReturn(true);

        listener.tfsResponseConsumer(record(), ack);

        verify(vuxDocumentValidationResultViewRepository).fnEcmRequestSetError(eq(RQUID), any());
        verify(vuxDocumentValidationResultViewRepository, never()).fnEcmRequestSetEcmId(any(), any());
        verify(ack).acknowledge();
    }

    @Test
    @DisplayName("rqUid отсутствует в очереди: сохраняется байтовый сценарий (flowSetEcmId)")
    void processResponse_notInQueue_preservesByteScenario() {
        when(vuxDocumentValidationResultViewRepository.existsInEcmQueue(RQUID)).thenReturn(false);

        BusinessAttrsType businessAttrs = new BusinessAttrsType();
        AttrIntType attrInt = new AttrIntType();
        attrInt.withKey("resultDocumentId");
        attrInt.withValue(77);
        businessAttrs.withAttrStrOrAttrListOfStrOrAttrInt(attrInt);
        UploadFileEcmRs uploadFileEcmRs = buildResponse("ecm-uuid-123", 0);
        uploadFileEcmRs.getFile().getFirst().withBusinessAttrs(businessAttrs);
        when(ecmRqRsSerdesService.readEcmResponse(any())).thenReturn(uploadFileEcmRs);

        listener.tfsResponseConsumer(record(), ack);

        verify(vuxDocumentValidationResultViewRepository).flowSetEcmId(eq(77), eq("ecm-uuid-123"), eq("0"));
        verify(vuxDocumentValidationResultViewRepository, never()).fnEcmRequestSetEcmId(any(), any());
        verify(ack).acknowledge();
    }

    private UploadFileEcmRs buildResponse(String newId, int resultCode) {
        UploadFileEcmRs.File file = new UploadFileEcmRs.File();
        DownloadFileEcmRs.File.Status status = new DownloadFileEcmRs.File.Status();
        status.withResultCode(resultCode);
        file.withStatus(status);
        if (newId != null) {
            file.withNewId(newId);
        }
        return new UploadFileEcmRs()
                .withRqUID(DASHLESS_RQUID)
                .withFile(List.of(file));
    }

    private ConsumerRecord<String, String> record() {
        return new ConsumerRecord<>("topic-in", 0, 0L, "key", "<xml/>");
    }
}