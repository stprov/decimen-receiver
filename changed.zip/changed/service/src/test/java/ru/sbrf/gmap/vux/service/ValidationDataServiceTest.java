package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolCheckRecordDto;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;
import ru.sbrf.gmap.vux.service.checks.DataContext;
import ru.sbrf.gmap.vux.service.checks.ValidationRule;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Выполнение CUV-правил по шагам постановки (аналитика 7.7, DEF-22) и строки проверок протокола (D-52, DEF-20).
 */
@DisplayName("ValidationDataService")
class ValidationDataServiceTest {

    private static final DataContext CTX = DataContext.empty(1, 1L);

    /**
     * Правило-заглушка: шаг определяется по коду ({@link ValidationRule#getStage()}).
     */
    private static final class StubRule implements ValidationRule {
        private final String code;
        private final boolean fails;
        private final boolean enabled;
        private int calls;

        StubRule(int number, boolean fails) {
            this(number, fails, true);
        }

        StubRule(int number, boolean fails, boolean enabled) {
            this.code = "DCUV_0420415_1_3_%03d".formatted(number);
            this.fails = fails;
            this.enabled = enabled;
        }

        @Override
        public Optional<ValidationErrorDto> validate(DataContext context) {
            calls++;
            return fails ? Optional.of(new ValidationErrorDto(DEFAULT_TITLE, code, "error " + code)) : Optional.empty();
        }

        @Override
        public String getDescription() {
            return "check " + code;
        }

        @Override
        public String getCode() {
            return code;
        }

        @Override
        public boolean isEnabled() {
            return enabled;
        }
    }

    private static List<String> results(List<ProtocolCheckRecordDto> checks) {
        return checks.stream().map(ProtocolCheckRecordDto::getCheckResult).toList();
    }

    @Test
    @DisplayName("Ошибок нет — пустой список, все проверки «Не выявлено»")
    void noErrors() {
        ValidationDataService service = new ValidationDataService(List.of(
                new StubRule(1, false), new StubRule(2, false), new StubRule(5, false), new StubRule(10, false)));

        List<ValidationErrorDto> errors = service.validate(CTX);

        assertThat(errors).isEmpty();
        assertThat(results(service.getChecks(errors))).containsOnly("Не выявлено");
        assertThat(service.countExecutedChecks(errors)).isEqualTo(4);
    }

    @Test
    @DisplayName("Внутри шага выполняются все правила, после шага с ошибками — ни одного (DEF-22)")
    void stopsAfterStageWithErrors() {
        StubRule unit = new StubRule(3, true);
        StubRule value = new StubRule(4, true);
        StubRule orphan = new StubRule(5, true);
        StubRule summary = new StubRule(10, true);
        ValidationDataService service = new ValidationDataService(List.of(
                new StubRule(1, false), new StubRule(2, false), unit, value, orphan, summary));

        List<ValidationErrorDto> errors = service.validate(CTX);

        assertThat(errors).extracting(ValidationErrorDto::errorCode)
                .containsExactly("DCUV_0420415_1_3_003", "DCUV_0420415_1_3_004");
        assertThat(orphan.calls).isZero();
        assertThat(summary.calls).isZero();
        assertThat(results(service.getChecks(errors)))
                .containsExactly("Не выявлено", "Не выявлено", "Выявлено", "Выявлено", "Не проверялось", "Не проверялось");
        assertThat(service.countExecutedChecks(errors)).isEqualTo(4);
    }

    @Test
    @DisplayName("D-52: выключенная проверка не выполняется, в протоколе «Не проверялось», в число проверок не входит")
    void disabledRuleSkipped() {
        StubRule summary = new StubRule(10, true, false);
        ValidationDataService service = new ValidationDataService(List.of(new StubRule(9, false), summary));

        List<ValidationErrorDto> errors = service.validate(CTX);

        assertThat(errors).isEmpty();
        assertThat(summary.calls).isZero();
        assertThat(results(service.getChecks(errors))).containsExactly("Не выявлено", "Не проверялось");
        assertThat(service.countExecutedChecks(errors)).isEqualTo(1);
    }

    @Test
    @DisplayName("Выключенная проверка не мешает прерыванию по шагам")
    void disabledRuleDoesNotBreakStages() {
        StubRule afterError = new StubRule(5, false);
        ValidationDataService service = new ValidationDataService(List.of(
                new StubRule(2, true), new StubRule(3, false, false), afterError));

        List<ValidationErrorDto> errors = service.validate(CTX);

        assertThat(errors).hasSize(1);
        assertThat(afterError.calls).isZero();
    }

    @Test
    @DisplayName("DEF-20: строки CUV-проверок с типом E и числом отклонений")
    void checksHaveErrorRuleType() {
        ValidationDataService service = new ValidationDataService(List.of(new StubRule(5, true), new StubRule(6, false)));

        List<ProtocolCheckRecordDto> checks = service.getChecks(service.validate(CTX));

        assertThat(checks).extracting(ProtocolCheckRecordDto::getRuleType).containsOnly(RuleTypeEnum.E);
        assertThat(checks).extracting(ProtocolCheckRecordDto::getCountingDeviation).containsExactly("1", "0");
    }

    @Test
    @DisplayName("Нет правил — нет ошибок и проверок")
    void noRules() {
        ValidationDataService service = new ValidationDataService(List.of());

        assertThat(service.validate(CTX)).isEmpty();
        assertThat(service.getChecks(List.of())).isEmpty();
    }
}
