package ru.sbrf.gmap.vux.service.validation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.mapper.VuxForm0420415V13ContextMapper;
import ru.sbrf.gmap.vux.mapper.VuxForm0420415V13UnitMapper;
import ru.sbrf.gmap.vux.mapper.VuxForm0420415V13ValueMapper;
import ru.sbrf.gmap.vux.repository.VuxForm0420415V13ContextRepository;
import ru.sbrf.gmap.vux.repository.VuxForm0420415V13DataRepository;
import ru.sbrf.gmap.vux.repository.VuxForm0420415V13UnitRepository;
import ru.sbrf.gmap.vux.repository.VuxForm0420415V13ValueRepository;
import ru.sbrf.gmap.vux.service.checks.DataContext;
import ru.sbrf.gmap.vux.service.checks.Form0420415V13DataContextProvider;
import ru.sbrf.gmap.vux.service.checks.XbrlReferenceDataService;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

/**
 * Провайдер данных формы 0420415.1.3 (аналитика, Q-8 п. 2.1, п. 4.1, п. 4.2; D-17).
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("Form0420415V13DataContextProvider")
class Form0420415V13DataContextProviderTest {

    @Mock
    private VuxForm0420415V13ContextRepository contextRepository;
    @Mock
    private VuxForm0420415V13UnitRepository unitRepository;
    @Mock
    private VuxForm0420415V13ValueRepository valueRepository;
    @Mock
    private VuxForm0420415V13DataRepository dataRepository;
    @Mock
    private XbrlReferenceDataService xbrlReferenceDataService;
    @Mock
    private VuxForm0420415V13ContextMapper contextMapper;
    @Mock
    private VuxForm0420415V13UnitMapper unitMapper;
    @Mock
    private VuxForm0420415V13ValueMapper valueMapper;
    @InjectMocks
    private Form0420415V13DataContextProvider provider;

    private static VuxDocumentScheduleViewEntity record(Long workflowRunId) {
        VuxDocumentScheduleViewEntity record = new VuxDocumentScheduleViewEntity();
        record.setResultDocumentId(100);
        record.setWorkflowRunId(workflowRunId);
        return record;
    }

    @Test
    @DisplayName("Нет workflow_run_id — пустой контекст без запросов к БД (ошибка _001 выдаст правило)")
    void noWorkflowRunId_emptyContext() {
        DataContext context = provider.build(record(null));

        assertThat(context).isNotNull();
        assertThat(context.workflowRunId()).isNull();
        assertThat(context.contextList()).isEmpty();
        verifyNoInteractions(contextRepository, unitRepository, valueRepository, dataRepository);
    }

    @Test
    @DisplayName("Нет context — контекст возвращается (не null), unit и value загружаются (ошибки _002…_004 выдадут правила)")
    void noContext_contextStillBuilt() {
        when(contextRepository.findByWorkflowRunId(5L)).thenReturn(List.of());
        when(unitRepository.findByWorkflowRunId(5L)).thenReturn(List.of());
        when(valueRepository.findByWorkflowRunId(5L)).thenReturn(List.of());
        when(dataRepository.findTaxonomyVersions(5L)).thenReturn(List.of());
        when(xbrlReferenceDataService.loadXbrlLinks()).thenReturn(List.of());
        when(xbrlReferenceDataService.loadEnumValuesMap()).thenReturn(Map.of());

        DataContext context = provider.build(record(5L));

        assertThat(context).isNotNull();
        assertThat(context.workflowRunId()).isEqualTo(5L);
        assertThat(context.contextList()).isEmpty();
        verify(unitRepository).findByWorkflowRunId(5L);
        verify(valueRepository).findByWorkflowRunId(5L);
    }

    @Test
    @DisplayName("Q-8 п. 4.2: версии таксономии data без NULL")
    void dataTaxonomies_withoutNulls() {
        when(contextRepository.findByWorkflowRunId(5L)).thenReturn(List.of());
        when(unitRepository.findByWorkflowRunId(5L)).thenReturn(List.of());
        when(valueRepository.findByWorkflowRunId(5L)).thenReturn(List.of());
        when(dataRepository.findTaxonomyVersions(5L)).thenReturn(Arrays.asList("7.1", null, "7.1"));

        assertThat(provider.build(record(5L)).dataTaxonomies()).containsExactly("7.1");
    }

    @Test
    @DisplayName("Сбой БД пробрасывается — технический сбой, расписание не закрывается (D-14)")
    void dbFailure_propagates() {
        when(contextRepository.findByWorkflowRunId(any())).thenThrow(new IllegalStateException("db"));

        assertThatThrownBy(() -> provider.build(record(5L))).isInstanceOf(IllegalStateException.class);
        verifyNoInteractions(dataRepository);
    }

    @Test
    @DisplayName("Код формы — 0420415.1.3")
    void docTypeCode() {
        assertThat(provider.supportedDocTypeCode()).isEqualTo("0420415.1.3");
    }
}
