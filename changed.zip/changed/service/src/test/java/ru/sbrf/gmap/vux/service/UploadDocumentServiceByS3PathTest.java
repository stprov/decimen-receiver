package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.kafka.core.KafkaTemplate;
import ru.sber.tfs.domain.UploadFileEcmRq;
import ru.sbrf.gmap.vux.IntegrationEcmTfsProps;
import ru.sbrf.gmap.vux.client.EcmClient;
import ru.sbrf.gmap.vux.config.IntegrationEcmProps;
import ru.sbrf.gmap.vux.config.IntegrationSignProps;
import ru.sbrf.gmap.vux.dto.request.ecm.TfsUploadFileRqDto;
import ru.sbrf.gmap.vux.model.DocumentTypeEnum;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;
import tools.jackson.databind.ObjectMapper;

import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("UploadDocumentService.uploadDocumentViaTfsByS3Path")
class UploadDocumentServiceByS3PathTest {

    @Mock
    private EcmClient ecmClient;
    @Mock
    private IntegrationEcmProps integrationEcmProps;
    @Mock
    private IntegrationSignProps integrationSignProps;
    @Mock
    private CryptoHashService cryptoHashService;
    @Mock
    private SignService signService;
    @Mock
    private ObjectProvider<KafkaTemplate<String, String>> kafkaTemplateBean;
    @Mock
    private ObjectProvider<IntegrationEcmTfsProps> integrationEcmTfsPropsBean;
    @Mock
    private ObjectProvider<EcmRqRsSerdesService> ecmRqRsSerdesServiceBean;
    @Mock
    private ObjectProvider<EcmS3Service> ecmS3ServiceBean;
    @Mock
    private ObjectProvider<EcmRqResolverService> ecmRqResolverServiceBean;
    @Mock
    private VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;
    @Mock
    private ObjectMapper objectMapper;

    private UploadDocumentService uploadDocumentService;

    private IntegrationEcmTfsProps integrationEcmTfsProps;
    private EcmS3Service ecmS3Service;
    private EcmRqRsSerdesService ecmRqRsSerdesService;
    private EcmRqResolverService ecmRqResolverService;

    @BeforeEach
    void setUp() {
        integrationEcmTfsProps = new IntegrationEcmTfsProps(
                true,
                new IntegrationEcmTfsProps.Kafka("testClient", "localhost:9092",
                        new IntegrationEcmTfsProps.Consumer("testGroup", "test-in", "latest"),
                        new IntegrationEcmTfsProps.Producer("test-out", "all", "3")),
                new IntegrationEcmTfsProps.EcmS3Properties(false, "http://s3", "key", "secret", "bucket", "folder", 5000, 10),
                new IntegrationEcmTfsProps.TfsParams("fp", "sys", "sp", "scenario", "1.0", "dest")
        );
        ecmS3Service = mock(EcmS3Service.class);
        ecmRqRsSerdesService = mock(EcmRqRsSerdesService.class);
        ecmRqResolverService = mock(EcmRqResolverService.class);

        when(integrationEcmTfsPropsBean.getIfAvailable()).thenReturn(integrationEcmTfsProps);
        when(ecmS3ServiceBean.getIfAvailable()).thenReturn(ecmS3Service);
        when(ecmRqRsSerdesServiceBean.getIfAvailable()).thenReturn(ecmRqRsSerdesService);
        when(ecmRqResolverServiceBean.getIfAvailable()).thenReturn(ecmRqResolverService);
        when(integrationSignProps.enabled()).thenReturn(false);

        uploadDocumentService = new UploadDocumentService(
                ecmClient, integrationEcmProps, integrationSignProps, cryptoHashService, signService,
                kafkaTemplateBean, integrationEcmTfsPropsBean, ecmRqRsSerdesServiceBean,
                ecmS3ServiceBean, ecmRqResolverServiceBean, vuxDocumentValidationResultViewRepository,
                objectMapper
        );
    }

    @Test
    @DisplayName("успешная загрузка: скачивание из S3, без повторной выгрузки в S3, возврат rqUid")
    void uploadByS3Path_success_returnsRqUidAndRegistersInQueue() {
        byte[] file = "content".getBytes();
        when(ecmS3Service.downloadFileFromS3("folder/file.pdf")).thenReturn(file);
        when(ecmRqResolverService.createTfsUploadFileEcmRq(any(), eq(false))).thenReturn(new UploadFileEcmRq());
        when(ecmRqRsSerdesService.writeXml(any())).thenReturn("<xml/>");
        when(kafkaTemplateBean.getObject()).thenReturn(mock(KafkaTemplate.class));

        UUID rqUid = uploadDocumentService.uploadDocumentViaTfsByS3Path(
                "folder/file.pdf", "file.pdf", DocumentTypeEnum.XBRL_DOCUMENT, "slice-1");

        assertThat(rqUid).isNotNull();
        verify(ecmS3Service).downloadFileFromS3("folder/file.pdf");
        ArgumentCaptor<TfsUploadFileRqDto> rqDtoCaptor = ArgumentCaptor.forClass(TfsUploadFileRqDto.class);
        verify(ecmRqResolverService).createTfsUploadFileEcmRq(rqDtoCaptor.capture(), eq(false));
        assertThat(rqDtoCaptor.getValue().getTfsFileName()).isEqualTo("file.pdf");
        assertThat(rqDtoCaptor.getValue().getFileContent()).isEqualTo(file);
        // Файл уже лежит в S3 по присланной ссылке — повторная выгрузка не выполняется
        verify(ecmS3Service, never()).uploadFileToS3(anyString(), any());
        verify(vuxDocumentValidationResultViewRepository).fnEcmRequestCreate(eq(rqUid.toString()), anyString(), eq("slice-1"));
        verify(vuxDocumentValidationResultViewRepository, never()).fnEcmRequestSetError(any(), any());
    }

    @Test
    @DisplayName("ошибка сохранения: вызывается fn_ecm_request_set_error")
    void uploadByS3Path_saveError_registersErrorInQueue() {
        byte[] file = "content".getBytes();
        when(ecmS3Service.downloadFileFromS3("folder/file.pdf")).thenReturn(file);
        when(ecmRqRsSerdesService.writeXml(any())).thenThrow(new IllegalStateException("serialization failed"));

        assertThatThrownBy(() -> uploadDocumentService.uploadDocumentViaTfsByS3Path(
                "folder/file.pdf", "file.pdf", DocumentTypeEnum.XBRL_DOCUMENT, "slice-1"))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("serialization failed");

        // Запрос регистрируется в очереди до сбоя, затем ошибка фиксируется по существующей строке
        verify(vuxDocumentValidationResultViewRepository).fnEcmRequestCreate(any(), anyString(), eq("slice-1"));
        verify(vuxDocumentValidationResultViewRepository).fnEcmRequestSetError(any(), eq("serialization failed"));
    }
}