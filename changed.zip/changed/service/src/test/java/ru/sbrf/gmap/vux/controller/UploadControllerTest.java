package ru.sbrf.gmap.vux.controller;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sbrf.gmap.vux.dto.request.ecm.UploadByS3PathRequestDto;
import ru.sbrf.gmap.vux.model.DocumentTypeEnum;
import ru.sbrf.gmap.vux.service.UploadDocumentService;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("UploadController")
class UploadControllerTest {

    @Mock
    private UploadDocumentService uploadDocumentService;

    @InjectMocks
    private UploadController uploadController;

    @Test
    @DisplayName("успешный вызов возвращает rqUid")
    void uploadByS3Path_success_returnsRqUid() {
        UUID rqUid = UUID.fromString("123e4567-e89b-12d3-a456-426614174000");
        when(uploadDocumentService.uploadDocumentViaTfsByS3Path(
                "folder/file.pdf", "file.pdf", DocumentTypeEnum.XBRL_DOCUMENT, "slice-1"))
                .thenReturn(rqUid);

        UploadByS3PathRequestDto request = UploadByS3PathRequestDto.builder()
                .s3Path("folder/file.pdf")
                .filename("file.pdf")
                .documentType("XBRL_DOCUMENT")
                .sliceId("slice-1")
                .build();

        UUID responseUuid = uploadController.uploadByS3Path(request);

        assertThat(responseUuid).isEqualTo(rqUid);
    }

    @Test
    @DisplayName("некорректный documentType бросает IllegalArgumentException")
    void uploadByS3Path_invalidDocumentType_throws() {
        UploadByS3PathRequestDto request = UploadByS3PathRequestDto.builder()
                .s3Path("folder/file.pdf")
                .filename("file.pdf")
                .documentType("UNKNOWN_TYPE")
                .sliceId("slice-1")
                .build();

        assertThatThrownBy(() -> uploadController.uploadByS3Path(request))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("UNKNOWN_TYPE");
    }
}