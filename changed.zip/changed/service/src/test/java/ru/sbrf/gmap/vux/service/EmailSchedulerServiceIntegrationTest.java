package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import ru.sbrf.gmap.vux.VuxApplicationTests;
import ru.sbrf.gmap.vux.entity.EmailInfoScheduleEntity;
import ru.sbrf.gmap.vux.entity.enums.InfoEmailTypeEnum;
import ru.sbrf.gmap.vux.repository.EmailInfoScheduleRepository;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Интеграционный тест для {@link EmailSchedulerService}.
 * <p>
 * Проверяет:
 * <ul>
 *   <li>Бизнес-логику: чтение записей витрины по типу → шаблон → отправка</li>
 *   <li>Содержимое письма через ArgumentCaptor</li>
 *   <li>Корректность темы, получателей To/Cc</li>
 *   <li>Edge-кейсы: пустая витрина, null-поля в записи</li>
 * </ul>
 */
@DisplayName("Интеграционный тест EmailSchedulerService")
@SpringBootTest
@ActiveProfiles("test")
@Disabled
class EmailSchedulerServiceIntegrationTest extends VuxApplicationTests {

    @Autowired
    private EmailSchedulerService emailSchedulerService;

    @MockitoBean
    private EmailInfoScheduleRepository emailInfoScheduleRepository;

    @MockitoBean
    private MailService mailService;

    @BeforeEach
    void setUp() {
        // Сброс всех моков
        reset(emailInfoScheduleRepository, mailService);
    }

    @Test
    @DisplayName("Успешная отправка письма о подготовке для одной записи витрины")
    void testSendMailForSingleRecord() {
        // given
        EmailInfoScheduleEntity record = createTestRecord(
                1L,
                InfoEmailTypeEnum.PREPARATION,
                LocalDateTime.now(),
                "10-дневной ежемесячной",
                "май 2026 г.",
                "0420416, 0420459",
                LocalDateTime.now().plusDays(1),
                LocalDateTime.now().plusDays(14),
                "7.1",
                "2.3.3",
                "user1@sberbank.ru,user2@sberbank.ru",
                "manager1@sberbank.ru,manager2@sberbank.ru"
        );

        when(emailInfoScheduleRepository.findByInfoEmailTypeAndSendTimeGreaterThanEqualOrderByIdAsc(
                eq(InfoEmailTypeEnum.PREPARATION), any(LocalDateTime.class)))
                .thenReturn(List.of(record));

        // when
        emailSchedulerService.run();

        // then
        ArgumentCaptor<String> subjectCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> bodyCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<List> recipientsCaptor = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<List> ccCaptor = ArgumentCaptor.forClass(List.class);

        verify(mailService, times(1)).sendMail(
                subjectCaptor.capture(),
                bodyCaptor.capture(),
                recipientsCaptor.capture(),
                ccCaptor.capture()
        );

        // Проверка темы
        String subject = subjectCaptor.getValue();
        assertTrue(subject.contains("Напоминание о подготовке отчетных форм ВУИКС"));
        assertTrue(subject.contains("10-дневной ежемесячной"));
        assertTrue(subject.contains("май 2026 г."));

        // Проверка получателей
        List<String> recipients = recipientsCaptor.getValue();
        assertEquals(2, recipients.size());
        assertTrue(recipients.contains("user1@sberbank.ru"));
        assertTrue(recipients.contains("user2@sberbank.ru"));

        // Проверка Cc
        List<String> ccList = ccCaptor.getValue();
        assertEquals(2, ccList.size());
        assertTrue(ccList.contains("manager1@sberbank.ru"));
        assertTrue(ccList.contains("manager2@sberbank.ru"));

        // Проверка тела письма (содержит подставленные параметры)
        String body = bodyCaptor.getValue();
        assertNotNull(body);
        assertTrue(body.contains("7.1"), "Body should contain taxonomy version");
        assertTrue(body.contains("2.3.3"), "Body should contain converter version");
    }

    @Test
    @DisplayName("Пропуск отправки при пустой витрине расписания")
    void testSkipOnEmptySchedule() {
        // given

        // when
        emailSchedulerService.run();

        // then
        verify(mailService, never()).sendMail(anyString(), anyString(), anyList(), anyList());
    }

    @Test
    @DisplayName("Отправка письма с пустым Cc и null copy_list")
    void testSendMailWithEmptyCcList() {
        // given
        EmailInfoScheduleEntity record = createTestRecord(
                2L,
                InfoEmailTypeEnum.PREPARATION,
                LocalDateTime.now(),
                "месячной",
                "июнь 2026 г.",
                "0420415",
                LocalDateTime.now().plusDays(1),
                LocalDateTime.now().plusDays(30),
                "7.1",
                "2.3.3",
                "single@sberbank.ru",
                null // Cc отсутствует
        );

        when(emailInfoScheduleRepository.findByInfoEmailTypeAndSendTimeGreaterThanEqualOrderByIdAsc(
                eq(InfoEmailTypeEnum.PREPARATION), any(LocalDateTime.class)))
                .thenReturn(List.of(record));

        // when
        emailSchedulerService.run();

        // then
        ArgumentCaptor<List> recipientsCaptor = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<List> ccCaptor = ArgumentCaptor.forClass(List.class);

        verify(mailService, times(1)).sendMail(
                anyString(),
                anyString(),
                recipientsCaptor.capture(),
                ccCaptor.capture()
        );

        List<String> recipients = recipientsCaptor.getValue();
        assertEquals(1, recipients.size());
        assertTrue(recipients.contains("single@sberbank.ru"));

        // Cc должен быть пустым при null
        List<String> ccList = ccCaptor.getValue();
        assertTrue(ccList.isEmpty(), "Cc list should be empty when copy_list is null");
    }

    @Test
    @DisplayName("Множественные записи — обрабатываются все")
    void testMultipleRecordsAllProcessed() {
        // given
        EmailInfoScheduleEntity record1 = createTestRecord(
                10L,
                InfoEmailTypeEnum.PREPARATION,
                LocalDateTime.now(), "ежемесячной", "июнь 2026 г.",
                "0420415",
                LocalDateTime.now().plusDays(1),
                LocalDateTime.now().plusDays(30), "7.1", "2.3.3",
                "a@test.ru", null
        );
        EmailInfoScheduleEntity record2 = createTestRecord(
                20L,
                InfoEmailTypeEnum.PREPARATION,
                LocalDateTime.now(), "ежемесячной", "июнь 2026 г.",
                "0420416",
                LocalDateTime.now().plusDays(2),
                LocalDateTime.now().plusDays(60), "7.2", "2.3.4",
                "b@test.ru", null
        );

        when(emailInfoScheduleRepository.findByInfoEmailTypeAndSendTimeGreaterThanEqualOrderByIdAsc(
                eq(InfoEmailTypeEnum.PREPARATION), any(LocalDateTime.class)))
                .thenReturn(List.of(record1, record2));

        // when
        emailSchedulerService.run();

        // then
        verify(mailService, times(2)).sendMail(anyString(), anyString(), anyList(), anyList());
    }

    @Test
    @DisplayName("Проверка парсинга получателей с разделителем ';'")
    void testRecipientsParsing() {
        // given
        EmailInfoScheduleEntity record = createTestRecord(
                1L,
                InfoEmailTypeEnum.PREPARATION,
                LocalDateTime.now(), "ежемесячной", "июнь 2026 г.",
                "0420415",
                LocalDateTime.now().plusDays(1),
                LocalDateTime.now().plusDays(30), "7.1", "2.3.3",
                " a@test.ru , b@test.ru , c@test.ru ", // с пробелами
                null
        );

        when(emailInfoScheduleRepository.findByInfoEmailTypeAndSendTimeGreaterThanEqualOrderByIdAsc(
                eq(InfoEmailTypeEnum.PREPARATION), any(LocalDateTime.class)))
                .thenReturn(List.of(record));

        // when
        emailSchedulerService.run();

        // then
        ArgumentCaptor<List> recipientsCaptor = ArgumentCaptor.forClass(List.class);
        verify(mailService).sendMail(anyString(), anyString(), recipientsCaptor.capture(), anyList());

        List<String> recipients = recipientsCaptor.getValue();
        assertEquals(3, recipients.size());
        assertTrue(recipients.stream().allMatch(r -> !r.isEmpty()), "No empty recipients");
        // Все должны быть без пробелов
        assertTrue(recipients.stream().noneMatch(r -> r.startsWith(" ") || r.endsWith(" ")));
    }

    // --- Вспомогательные методы ---

    private EmailInfoScheduleEntity createTestRecord(
            Long id,
            InfoEmailTypeEnum infoEmailType,
            LocalDateTime sendTime,
            String reportingType,
            String reportDt,
            String forms,
            LocalDateTime startDate,
            LocalDateTime deadlineDate,
            String taxonomy,
            String converterVersion,
            String receiversList,
            String copyList
    ) {
        EmailInfoScheduleEntity entity = new EmailInfoScheduleEntity();
        entity.setId(id);
        entity.setInfoEmailType(infoEmailType);
        entity.setSendTime(sendTime);
        entity.setReportingType(reportingType);
        entity.setReportDt(reportDt);
        entity.setForms(forms);
        entity.setStartDate(startDate);
        entity.setDeadlineDate(deadlineDate);
        entity.setTaxonomy(taxonomy);
        entity.setConverterVersion(converterVersion);
        entity.setReceiversList(receiversList);
        entity.setCopyList(copyList);
        return entity;
    }
}
