package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import ru.sbrf.gmap.vux.config.FeatureToogleConfig;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationResultViewEntity;
import ru.sbrf.gmap.vux.entity.enums.ScheduleStatusEnum;
import ru.sbrf.gmap.vux.mapper.VuxDocumentValidationLogEnityMapper;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;
import ru.sbrf.gmap.vux.service.checks.ContextExistsRule;
import ru.sbrf.gmap.vux.service.checks.DataContext;
import ru.sbrf.gmap.vux.service.checks.DataContextProvider;
import ru.sbrf.gmap.vux.service.checks.UnitExistsRule;
import ru.sbrf.gmap.vux.service.checks.ValueExistsRule;
import ru.sbrf.gmap.vux.service.checks.WorkflowRunIdRule;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Фаза 1 — новый документ (аналитика cuv-csv-ecm-supz-flow, 7.1, 7.2, 7.8; сценарии раздела 11).
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("NewDocumentProcessingService — фаза 1")
class NewDocumentProcessingServiceTest {

    private static final int SCHEDULE_ID = 10;
    private static final int DOC_ID = 100;
    private static final String FORM = "0420415.1.3";

    @Mock
    private ValidationDataService validationDataService;
    @Mock
    private ProtocolBuildingService protocolBuildingService;
    @Mock
    private PostUploadActionsService postUploadActionsService;
    @Mock
    private ValidationDefectsService validationDefectsService;
    @Mock
    private DocumentEcmExportService documentEcmExportService;
    @Mock
    private DataContextProvider provider;
    @Mock
    private VuxDocumentValidationLogEnityMapper logMapper;
    @Mock
    private VuxDocumentValidationResultViewRepository viewRepository;
    @Mock
    private CuvValidationStatusService cuvValidationStatusService;

    private final ProtocolModelDto protocol = ProtocolModelDto.builder().build();
    private final DataContext context = DataContext.empty(DOC_ID, 5L);

    @BeforeEach
    void setUp() {
        when(provider.supportedDocTypeCode()).thenReturn(FORM);
        when(provider.build(any())).thenReturn(context);
        when(validationDefectsService.getResultsForDocWithRnLimit(DOC_ID)).thenReturn(List.of());
        when(validationDefectsService.getErrorsList(anyList())).thenReturn(List.of());
        when(validationDefectsService.getWarningsList(anyList())).thenReturn(List.of());
        when(validationDefectsService.getChecksByDocId(DOC_ID)).thenReturn(List.of());
        when(validationDataService.getChecks(anyList())).thenReturn(List.of());
        when(protocolBuildingService.createCuvSuccessProtocol(any(), anyList(), anyList())).thenReturn(protocol);
        when(protocolBuildingService.createCuvErrorProtocol(any(), anyList(), anyList(), anyList(), anyList())).thenReturn(protocol);
        when(protocolBuildingService.createProtocolModelDto(anyList(), anyList(), anyList(), any())).thenReturn(protocol);
        when(postUploadActionsService.uploadProtocol(any(), any())).thenReturn(Optional.of("protocol-ecm-id"));
        when(postUploadActionsService.sendErrorMail(any(), any())).thenReturn(true);
        when(postUploadActionsService.handlePostUploadActions(any(), any(), anyList())).thenReturn(true);
        when(documentEcmExportService.requestCuvCsvExport(DOC_ID)).thenReturn(true);
    }

    private NewDocumentProcessingService service(boolean cuvEnabled) {
        return service(cuvEnabled, validationDataService);
    }

    private NewDocumentProcessingService service(boolean cuvEnabled, ValidationDataService validation) {
        return new NewDocumentProcessingService(new FeatureToogleConfig(cuvEnabled), validation, protocolBuildingService,
                postUploadActionsService, validationDefectsService, documentEcmExportService, List.of(provider),
                logMapper, viewRepository, cuvValidationStatusService);
    }

    private static VuxDocumentScheduleViewEntity record(String checkMode) {
        VuxDocumentScheduleViewEntity record = new VuxDocumentScheduleViewEntity();
        record.setScheduleId(SCHEDULE_ID);
        record.setResultDocumentId(DOC_ID);
        record.setDocTypeCode(FORM);
        record.setCheckMode(checkMode);
        record.setScheduleStatus(ScheduleStatusEnum.VERIFIED_SUCCESSFULLY);
        record.setWorkflowRunId(5L);
        return record;
    }

    private void cuvErrors(int count) {
        List<ValidationErrorDto> errors = java.util.stream.IntStream.range(0, count)
                .mapToObj(i -> new ValidationErrorDto("t", "DCUV_0420415_1_3_00" + (5 + i), "msg " + i))
                .toList();
        when(validationDataService.validate(context)).thenReturn(errors);
        when(validationDataService.countExecutedChecks(errors)).thenReturn(9);
    }

    private void noCuvErrors() {
        when(validationDataService.validate(context)).thenReturn(List.of());
        when(validationDataService.countExecutedChecks(List.of())).thenReturn(9);
    }

    private void viewErrors() {
        List<VuxDocumentValidationResultViewEntity> errors = List.of(mock(VuxDocumentValidationResultViewEntity.class));
        when(validationDefectsService.getErrorsList(anyList())).thenReturn(errors);
    }

    @Test
    @DisplayName("supports: только записи без ecm_id")
    void supports_onlyWithoutEcmId() {
        VuxDocumentScheduleViewEntity record = record("cuv");
        assertThat(service(true).supports(record)).isTrue();
        record.setEcmId("x");
        assertThat(service(true).supports(record)).isFalse();
    }

    @Test
    @DisplayName("T-1, T-25: CUV и view без ошибок — протокол, статус CUV 1, 3 записи выгрузки, расписание открыто")
    void cuvSuccess_requestsCsvExportAndStaysOpen() {
        noCuvErrors();
        VuxDocumentScheduleViewEntity record = record("cuv");

        ProcessingResult result = service(true).processDocument(record);

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(postUploadActionsService).uploadProtocol(record, protocol);
        verify(cuvValidationStatusService).saveChecked(eq(record), eq(9), eq(0), any(), any());
        verify(documentEcmExportService).requestCuvCsvExport(DOC_ID);
        verify(postUploadActionsService, never()).sendErrorMail(any(), any());
        verify(postUploadActionsService, never()).createSupzTask(any(), anyList(), anyString());
    }

    @Test
    @DisplayName("T-30: флаг U — протокол загружается, записи выгрузки не создаются (D-49)")
    void cuvSuccess_flagU_noCsvExport() {
        noCuvErrors();
        VuxDocumentScheduleViewEntity record = record("cuv");
        record.setFlags("MU");

        ProcessingResult result = service(true).processDocument(record);

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(postUploadActionsService).uploadProtocol(record, protocol);
        verify(cuvValidationStatusService).saveChecked(eq(record), eq(9), eq(0), any(), any());
        verify(documentEcmExportService, never()).requestCuvCsvExport(any());
    }

    @Test
    @DisplayName("T-4: протокол не загрузился — нет выгрузки и статуса CUV, расписание открыто")
    void cuvSuccess_protocolUploadFailed() {
        noCuvErrors();
        when(postUploadActionsService.uploadProtocol(any(), any())).thenReturn(Optional.empty());

        ProcessingResult result = service(true).processDocument(record("cuv"));

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(documentEcmExportService, never()).requestCuvCsvExport(any());
        verify(cuvValidationStatusService, never()).saveChecked(any(), anyInt(), anyInt(), any(), any());
    }

    @Test
    @DisplayName("T-3: CUV без ошибок, есть ошибки view — протокол с ошибками, письмо, закрытие, без выгрузки")
    void cuvSuccess_viewErrors_sendsMail() {
        noCuvErrors();
        viewErrors();
        VuxDocumentScheduleViewEntity record = record("cuv");

        ProcessingResult result = service(true).processDocument(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(postUploadActionsService).sendErrorMail(record, protocol);
        verify(cuvValidationStatusService).saveChecked(eq(record), eq(9), eq(0), any(), any());
        verify(documentEcmExportService, never()).requestCuvCsvExport(any());
    }

    @Test
    @DisplayName("T-2, T-26: ошибки CUV — сохранение, статус расписания 2, протокол, письмо, статус CUV 2")
    void cuvErrors_savedMarkedAndMailed() {
        cuvErrors(2);
        VuxDocumentScheduleViewEntity record = record("cuv");

        ProcessingResult result = service(true).processDocument(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(viewRepository, times(2)).flowCuvSetError(eq((long) DOC_ID), anyString(), anyString());
        verify(viewRepository).flowUpdateSheduleStatus(SCHEDULE_ID, ScheduleStatusEnum.CHECKED_WITH_ERRORS.ordinal());
        verify(postUploadActionsService).uploadProtocol(record, protocol);
        verify(postUploadActionsService).sendErrorMail(record, protocol);
        verify(cuvValidationStatusService).saveChecked(eq(record), eq(9), eq(2), any(), any());
        verify(documentEcmExportService, never()).requestCuvCsvExport(any());
    }

    @Test
    @DisplayName("T-2: ошибки CUV при статусе расписания 2 — fn_flow_update_shedule не вызывается")
    void cuvErrors_statusAlready2_noStatusUpdate() {
        cuvErrors(1);
        VuxDocumentScheduleViewEntity record = record("cuv");
        record.setScheduleStatus(ScheduleStatusEnum.CHECKED_WITH_ERRORS);

        service(true).processDocument(record);

        verify(viewRepository, never()).flowUpdateSheduleStatus(any(), any());
    }

    @Test
    @DisplayName("Ошибки CUV, сбой письма — расписание открыто, статус CUV не пишется")
    void cuvErrors_mailFailed_pending() {
        cuvErrors(1);
        when(postUploadActionsService.sendErrorMail(any(), any())).thenReturn(false);

        ProcessingResult result = service(true).processDocument(record("cuv"));

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(cuvValidationStatusService, never()).saveChecked(any(), anyInt(), anyInt(), any(), any());
    }

    @Test
    @DisplayName("T-21: технический сбой при построении контекста — ничего не делается, расписание открыто")
    void providerFailure_pending() {
        when(provider.build(any())).thenThrow(new IllegalStateException("db down"));

        ProcessingResult result = service(true).processDocument(record("cuv"));

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(postUploadActionsService, never()).uploadProtocol(any(), any());
        verify(cuvValidationStatusService, never()).saveNotChecked(any());
    }

    @Test
    @DisplayName("Провайдер вернул null — дефект провайдера, расписание открыто")
    void providerReturnsNull_pending() {
        when(provider.build(any())).thenReturn(null);

        ProcessingResult result = service(true).processDocument(record("cuv"));

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(postUploadActionsService, never()).uploadProtocol(any(), any());
    }

    @Test
    @DisplayName("T-28: нет workflow_run_id — ошибка _001, статус 2, протокол, письмо, статус CUV 2 (D-17)")
    void noWorkflowRunId_error001AndMail() {
        ValidationDataService realValidation = new ValidationDataService(List.of(
                new WorkflowRunIdRule(), new ContextExistsRule(), new UnitExistsRule(), new ValueExistsRule()));
        DataContext empty = DataContext.empty(DOC_ID, null);
        when(provider.build(any())).thenReturn(empty);
        VuxDocumentScheduleViewEntity record = record("cuv");
        record.setWorkflowRunId(null);

        ProcessingResult result = service(true, realValidation).processDocument(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(viewRepository).flowCuvSetError(eq((long) DOC_ID), anyString(), eq("DCUV_0420415_1_3_001"));
        verify(viewRepository, times(1)).flowCuvSetError(anyLong(), anyString(), anyString());
        verify(viewRepository).flowUpdateSheduleStatus(SCHEDULE_ID, 2);
        verify(postUploadActionsService).sendErrorMail(record, protocol);
        verify(cuvValidationStatusService).saveChecked(eq(record), eq(1), eq(1), any(), any());
    }

    @Test
    @DisplayName("T-29: нет context, unit, value — ошибки _002…_004 с workflow_run_id")
    void noFormData_errors002to004() {
        ValidationDataService realValidation = new ValidationDataService(List.of(
                new WorkflowRunIdRule(), new ContextExistsRule(), new UnitExistsRule(), new ValueExistsRule()));
        when(provider.build(any())).thenReturn(DataContext.empty(DOC_ID, 5L));

        service(true, realValidation).processDocument(record("cuv"));

        ArgumentCaptor<String> codes = ArgumentCaptor.forClass(String.class);
        verify(viewRepository, times(3)).flowCuvSetError(eq((long) DOC_ID), anyString(), codes.capture());
        assertThat(codes.getAllValues())
                .containsExactly("DCUV_0420415_1_3_002", "DCUV_0420415_1_3_003", "DCUV_0420415_1_3_004");
    }

    @Test
    @DisplayName("T-5, T-27: фича-флаг выключен — стандартная проверка, статус CUV 0")
    void toggleOff_standardAndNotChecked() {
        VuxDocumentScheduleViewEntity record = record("cuv");

        ProcessingResult result = service(false).processDocument(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(provider, never()).build(any());
        verify(postUploadActionsService).handlePostUploadActions(record, protocol, List.of("protocol-ecm-id"));
        verify(cuvValidationStatusService).saveNotChecked(record);
    }

    @Test
    @DisplayName("T-27: нет провайдера формы — стандартная проверка, статус CUV 0")
    void noProvider_standardAndNotChecked() {
        VuxDocumentScheduleViewEntity record = record("cuv");
        record.setDocTypeCode("0420415.3");

        ProcessingResult result = service(true).processDocument(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(provider, never()).build(any());
        verify(cuvValidationStatusService).saveNotChecked(record);
    }

    @Test
    @DisplayName("Стандартная проверка не завершена (сбой СУПЗ) — статус CUV не пишется")
    void toggleOff_postUploadFailed_noStatus() {
        when(postUploadActionsService.handlePostUploadActions(any(), any(), anyList())).thenReturn(false);

        ProcessingResult result = service(false).processDocument(record("cuv"));

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(cuvValidationStatusService, never()).saveNotChecked(any());
    }

    @Test
    @DisplayName("T-12: check_mode = null — стандартная проверка без статуса CUV")
    void checkModeNull_standard() {
        VuxDocumentScheduleViewEntity record = record(null);

        ProcessingResult result = service(true).processDocument(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(provider, never()).build(any());
        verify(cuvValidationStatusService, never()).saveNotChecked(any());
    }

    @Test
    @DisplayName("check_mode = xml — стандартная проверка (D-11)")
    void checkModeXml_standard() {
        ProcessingResult result = service(true).processDocument(record("xml"));

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(provider, never()).build(any());
        verify(documentEcmExportService, never()).requestCuvCsvExport(any());
    }

    @Test
    @DisplayName("Стандартная проверка: протокол не загрузился — расписание открыто")
    void standard_protocolUploadFailed_pending() {
        when(postUploadActionsService.uploadProtocol(any(), any())).thenReturn(Optional.empty());

        ProcessingResult result = service(true).processDocument(record(null));

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(postUploadActionsService, never()).handlePostUploadActions(any(), any(), anyList());
    }

    @Test
    @DisplayName("isSupzTaskDisabled: флаг U в любой позиции")
    void flagU() {
        VuxDocumentScheduleViewEntity record = record("cuv");
        assertThat(NewDocumentProcessingService.isSupzTaskDisabled(record)).isFalse();
        record.setFlags("SEU");
        assertThat(NewDocumentProcessingService.isSupzTaskDisabled(record)).isTrue();
        record.setFlags("SEM");
        assertThat(NewDocumentProcessingService.isSupzTaskDisabled(record)).isFalse();
    }
}
