package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.sber.tfs.domain.UploadFileEcmRq;
import ru.sbrf.gmap.vux.IntegrationEcmTfsProps;
import ru.sbrf.gmap.vux.config.IntegrationEcmProps;
import ru.sbrf.gmap.vux.dto.request.ecm.TfsUploadFileRqDto;
import ru.sbrf.gmap.vux.model.DocumentTypeEnum;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Тестовый класс для генерации тестового XML через EcmRqResolverService.
 * Использует JAXB Marshaller для сериализации объектов UploadFileEcmRq в XML.
 */
class EcmRqResolverServiceTest {

    private static final String TARGET_DIR = "target/test-tfs-xml";

    private IntegrationEcmTfsProps integrationEcmTfsProps;
    private IntegrationEcmProps integrationEcmProps;
    private EcmRqResolverService ecmRqResolverService;
    private EcmRqRsSerdesService ecmRqRsSerdesService;
    private Path testOutputDir;

    @BeforeEach
    void setUp() {
        // Мокаем TFS-параметры
        IntegrationEcmTfsProps.TfsParams tfsParams = new IntegrationEcmTfsProps.TfsParams(
                "testFpName",
                "testSystemId",
                "testSpName",
                "testScenarioId",
                "1.0",
                "testDestinationName"
        );
        integrationEcmTfsProps = new IntegrationEcmTfsProps(
                true,
                new IntegrationEcmTfsProps.Kafka("testClient", "localhost:9092",
                        new IntegrationEcmTfsProps.Consumer("testGroup", "test-in", "latest"),
                        new IntegrationEcmTfsProps.Producer("test-out", "all", "3")),
                new IntegrationEcmTfsProps.EcmS3Properties(false, "http://s3", "key", "secret", "bucket", "folder", 5000, 10),
                tfsParams
        );

        integrationEcmProps = new IntegrationEcmProps(
                Map.of("user", "testUser"),
                "true",
                "http://ecm",
                "/test/target/folder"
        );

        // Инициализируем сервис
        ecmRqResolverService = new EcmRqResolverService(integrationEcmTfsProps, integrationEcmProps);

        // Инициализируем сервис сериализации — он запускает JAXB Context в @PostConstruct
        ecmRqRsSerdesService = new EcmRqRsSerdesService();
        ecmRqRsSerdesService.init();

        // Создаём выходную директорию
        testOutputDir = Path.of(TARGET_DIR);
        try {
            Files.createDirectories(testOutputDir);
        } catch (Exception e) {
            // игнорируем, если уже существует
        }
    }

    @Test
    @DisplayName("createTfsUploadFileEcmRq + сериализация в XML — сохраняем в target/test-tfs-xml")
    void shouldGenerateAndSaveXml() throws Exception {
        // 1. Подготавливаем тестовые данные
        UUID rqUid = UUID.fromString("123e4567-e89b-12d3-a456-426614174000");
        String fileName = "test-file-20260813.xml";
        byte[] fileContent = "<root><data>test content</data></root>".getBytes();
        DocumentTypeEnum documentType = DocumentTypeEnum.XBRL_VUX_RFVP_DOCUMENT;

        TfsUploadFileRqDto dto = TfsUploadFileRqDto.builder()
                .rqUid(rqUid)
                .fileName(fileName)
                .tfsFileName("test-file-20260813_tfs.xml")
                .fileContent(fileContent)
                .documentTypeEnum(documentType)
                .resultDocumentId(42)
                .build();

        // 2. Создаём объект UploadFileEcmRq через EcmRqResolverService
        UploadFileEcmRq uploadFileEcmRq = ecmRqResolverService.createTfsUploadFileEcmRq(dto, true);

        // 3. Сериализуем в XML через EcmRqRsSerdesService
        String xmlContent = ecmRqRsSerdesService.writeXml(uploadFileEcmRq);

        // 4. Сохраняем в target/test-tfs-xml
        String outputFileName = "tfs-upload-rq-" + OffsetDateTime.now(ZoneOffset.UTC).toLocalDate().toString().replace("-", "") + ".xml";
        Path outputPath = testOutputDir.resolve(outputFileName);
        Files.writeString(outputPath, xmlContent);

        // 5. Валидируем
        assertThat(outputPath).exists();
        String savedContent = Files.readString(outputPath);
        assertThat(savedContent).isNotEmpty();
        assertThat(savedContent).contains("UploadFileEcmRq");
        assertThat(savedContent).contains(rqUid.toString().replace("-", ""));
        assertThat(savedContent).contains("test-file-20260813.xml");
        assertThat(savedContent).contains("42");
        assertThat(savedContent).contains("/test/target/folder");
        assertThat(savedContent).contains("Signatures");

        System.out.println("XML saved to: " + outputPath.toAbsolutePath());
    }

    @Test
    @DisplayName("createTfsUploadFileEcmRq без подписи — сохраняем в target/test-tfs-xml")
    void shouldGenerateAndSaveXmlWithoutSignature() throws Exception {
        UUID rqUid = UUID.fromString("987fcdeb-51a2-43d7-b661-426614174001");
        String fileName = "document-without-sign.pdf";
        byte[] fileContent = "%PDF-1.4 fake pdf content".getBytes();
        DocumentTypeEnum documentType = DocumentTypeEnum.XBRL_DOCUMENT;

        TfsUploadFileRqDto dto = TfsUploadFileRqDto.builder()
                .rqUid(rqUid)
                .fileName(fileName)
                .tfsFileName("document-without-sign_tfs.pdf")
                .fileContent(fileContent)
                .documentTypeEnum(documentType)
                .resultDocumentId(100)
                .build();

        UploadFileEcmRq uploadFileEcmRq = ecmRqResolverService.createTfsUploadFileEcmRq(dto, false);

        String xmlContent = ecmRqRsSerdesService.writeXml(uploadFileEcmRq);

        String outputFileName = "tfs-upload-rq-no-sign-" + OffsetDateTime.now(ZoneOffset.UTC).toLocalDate().toString().replace("-", "") + ".xml";
        Path outputPath = testOutputDir.resolve(outputFileName);
        Files.writeString(outputPath, xmlContent);

        assertThat(outputPath).exists();
        String savedContent = Files.readString(outputPath);
        assertThat(savedContent).doesNotContain("<Signatures>");
        assertThat(savedContent).contains("987fcdeb51a243d7b661426614174001");
        assertThat(savedContent).contains("document-without-sign.pdf");
        assertThat(savedContent).contains("100");

        System.out.println("XML saved to: " + outputPath.toAbsolutePath());
    }

    @Test
    @DisplayName("createTfsUploadFileEcmRq с XBRL_CSV_RPVP_DOCUMENT — сохраняем в target/test-tfs-xml")
    void shouldGenerateAndSaveXmlWithXbrlCsvRpvp() throws Exception {
        UUID rqUid = UUID.fromString("abcdef01-2345-6789-abcd-ef0123456789");
        String fileName = "xbrl-csv-rpvp-report.csv";
        byte[] fileContent = "id;value\n1;100\n2;200".getBytes();
        DocumentTypeEnum documentType = DocumentTypeEnum.XBRL_CSV_RPVP_DOCUMENT;

        TfsUploadFileRqDto dto = TfsUploadFileRqDto.builder()
                .rqUid(rqUid)
                .fileName(fileName)
                .tfsFileName("xbrl-csv-rpvp-report_tfs.csv")
                .fileContent(fileContent)
                .documentTypeEnum(documentType)
                .resultDocumentId(255)
                .build();

        UploadFileEcmRq uploadFileEcmRq = ecmRqResolverService.createTfsUploadFileEcmRq(dto, true);

        String xmlContent = ecmRqRsSerdesService.writeXml(uploadFileEcmRq);

        String outputFileName = "tfs-upload-rq-xbrl-csv-" + OffsetDateTime.now(ZoneOffset.UTC).toLocalDate().toString().replace("-", "") + ".xml";
        Path outputPath = testOutputDir.resolve(outputFileName);
        Files.writeString(outputPath, xmlContent);

        assertThat(outputPath).exists();
        String savedContent = Files.readString(outputPath);
        assertThat(savedContent).contains("xbrl-csv-rpvp-report.csv");
        assertThat(savedContent).contains("255");
        assertThat(savedContent).contains("Протокол проверки пакета отчетных данных в формате XBRL-CSV");

        System.out.println("XML saved to: " + outputPath.toAbsolutePath());
    }

    @Test
    @DisplayName("generateMultipleXmlFiles — создаём несколько XML с разными типами документов")
    void shouldGenerateMultipleXmlFiles() throws Exception {
        String timestamp = OffsetDateTime.now(ZoneOffset.UTC).toLocalDate().toString().replace("-", "");

        for (int i = 0; i < 3; i++) {
            UUID rqUid = UUID.randomUUID();
            DocumentTypeEnum docType = DocumentTypeEnum.values()[i];
            String fileName = "test-document-" + i + "." + (i == 0 ? "xml" : i == 1 ? "pdf" : "csv");
            byte[] fileContent = ("test content for document " + i).getBytes();

            TfsUploadFileRqDto dto = TfsUploadFileRqDto.builder()
                    .rqUid(rqUid)
                    .fileName(fileName)
                    .tfsFileName("test-document-" + i + "_tfs." + (i == 0 ? "xml" : i == 1 ? "pdf" : "csv"))
                    .fileContent(fileContent)
                    .documentTypeEnum(docType)
                    .resultDocumentId(1000 + i)
                    .build();

            UploadFileEcmRq uploadFileEcmRq = ecmRqResolverService.createTfsUploadFileEcmRq(dto, true);
            String xmlContent = ecmRqRsSerdesService.writeXml(uploadFileEcmRq);

            String outputFileName = "tfs-upload-rq-" + docType.name() + "-" + i + "-" + timestamp + ".xml";
            Path outputPath = testOutputDir.resolve(outputFileName);
            Files.writeString(outputPath, xmlContent);

            assertThat(outputPath).exists();
            assertThat(Files.readString(outputPath)).contains(docType.getNameTemplate());
            System.out.println("XML #" + i + " saved to: " + outputPath.toAbsolutePath());
        }
    }
}
