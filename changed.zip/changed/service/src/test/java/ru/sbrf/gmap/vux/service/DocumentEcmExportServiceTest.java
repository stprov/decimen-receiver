package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import ru.sbrf.gmap.vux.entity.VuxDocumentEcmEntity;
import ru.sbrf.gmap.vux.repository.VuxDocumentEcmRepository;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Выгрузка CSV через {@code t_vux_document_ecm} (аналитика cuv-csv-ecm-supz-flow, 6.1, 7.3, FR-2.2…FR-2.9).
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("DocumentEcmExportService")
class DocumentEcmExportServiceTest {

    private static final int DOC_ID = 100;
    private static final UUID CTX = UUID.randomUUID();
    private static final UUID UNIT = UUID.randomUUID();
    private static final UUID VALUE = UUID.randomUUID();

    @Mock
    private VuxDocumentValidationResultViewRepository viewRepository;
    @Mock
    private VuxDocumentEcmRepository ecmRepository;
    @InjectMocks
    private DocumentEcmExportService service;

    private static VuxDocumentEcmEntity entity(String imageType, UUID ecmId, int disabled, long createdMillis) {
        VuxDocumentEcmEntity e = new VuxDocumentEcmEntity();
        e.setXbrlId(UUID.randomUUID().toString());
        e.setDocId((long) DOC_ID);
        e.setImageType(imageType);
        e.setEcmId(ecmId);
        e.setDisabled((short) disabled);
        e.setCreated(new Timestamp(createdMillis));
        return e;
    }

    private void records(VuxDocumentEcmEntity... entities) {
        when(ecmRepository.findByDocIdAndImageTypeIn(eq((long) DOC_ID), any())).thenReturn(List.of(entities));
    }

    @Test
    @DisplayName("FR-1.2: три записи CONTEXT, UNIT, VALUE с p_archive = 0 и p_s3_del = 1")
    void requestCuvCsvExport_createsThreeRecords() {
        assertThat(service.requestCuvCsvExport(DOC_ID)).isTrue();

        verify(viewRepository).fnXbrlCreateEcm(DOC_ID, "CONTEXT", 0, 1);
        verify(viewRepository).fnXbrlCreateEcm(DOC_ID, "UNIT", 0, 1);
        verify(viewRepository).fnXbrlCreateEcm(DOC_ID, "VALUE", 0, 1);
    }

    @Test
    @DisplayName("E-3: сбой одной записи не прерывает создание остальных")
    void requestCuvCsvExport_partialFailure() {
        when(viewRepository.fnXbrlCreateEcm(DOC_ID, "UNIT", 0, 1)).thenThrow(new IllegalStateException("db"));

        assertThat(service.requestCuvCsvExport(DOC_ID)).isFalse();

        verify(viewRepository).fnXbrlCreateEcm(DOC_ID, "CONTEXT", 0, 1);
        verify(viewRepository).fnXbrlCreateEcm(DOC_ID, "VALUE", 0, 1);
    }

    @Test
    @DisplayName("T-6: все образы с ecm_id — готово, ECM-id в порядке context, unit, value")
    void evaluate_allReady_orderedIds() {
        records(entity("VALUE", VALUE, 0, 1), entity("CONTEXT", CTX, 0, 1), entity("UNIT", UNIT, 0, 1));

        DocumentEcmExportService.ExportState state = service.evaluateCuvCsvExport(DOC_ID);

        assertThat(state.ready()).isTrue();
        assertThat(state.ecmIds()).containsExactly(CTX.toString(), UNIT.toString(), VALUE.toString());
        verify(viewRepository, never()).fnXbrlCreateEcm(any(), anyString(), anyInt(), anyInt());
    }

    @Test
    @DisplayName("D-4: учитывается последняя запись по created")
    void evaluate_usesLatestRecord() {
        records(entity("CONTEXT", CTX, 0, 1), entity("UNIT", UNIT, 0, 1),
                entity("VALUE", VALUE, 0, 1), entity("VALUE", null, 0, 2));

        DocumentEcmExportService.ExportState state = service.evaluateCuvCsvExport(DOC_ID);

        assertThat(state.ready()).isFalse();
        assertThat(state.ecmIds()).isEmpty();
    }

    @Test
    @DisplayName("T-8: ecm_id пуст, disabled = 0 — ожидание, записи не создаются")
    void evaluate_notReady_waits() {
        records(entity("CONTEXT", CTX, 0, 1), entity("UNIT", UNIT, 0, 1), entity("VALUE", null, 0, 1));

        assertThat(service.evaluateCuvCsvExport(DOC_ID).ready()).isFalse();
        verify(viewRepository, never()).fnXbrlCreateEcm(any(), anyString(), anyInt(), anyInt());
    }

    @Test
    @DisplayName("T-7, T-9: disabled = 1 — окончательный отказ, запись не пересоздаётся (D-43)")
    void evaluate_disabled_notRecreated() {
        VuxDocumentEcmEntity failed = entity("UNIT", null, 1, 1);
        failed.setErrorCode("405");
        records(entity("CONTEXT", CTX, 0, 1), failed, entity("VALUE", VALUE, 0, 1));

        assertThat(service.evaluateCuvCsvExport(DOC_ID).ready()).isFalse();
        verify(viewRepository, never()).fnXbrlCreateEcm(any(), anyString(), anyInt(), anyInt());
    }

    @Test
    @DisplayName("FR-2.9: нет записей по типу — восстановление только этого типа")
    void evaluate_missingType_restored() {
        records(entity("CONTEXT", CTX, 0, 1), entity("VALUE", VALUE, 0, 1));

        assertThat(service.evaluateCuvCsvExport(DOC_ID).ready()).isFalse();
        verify(viewRepository).fnXbrlCreateEcm(DOC_ID, "UNIT", 0, 1);
        verify(viewRepository, never()).fnXbrlCreateEcm(DOC_ID, "CONTEXT", 0, 1);
        verify(viewRepository, never()).fnXbrlCreateEcm(DOC_ID, "VALUE", 0, 1);
    }

    @Test
    @DisplayName("image_type сравнивается без учёта регистра и хвостовых пробелов")
    void evaluate_imageTypeNormalized() {
        records(entity("context ", CTX, 0, 1), entity("Unit", UNIT, 0, 1), entity("VALUE", VALUE, 0, 1));

        assertThat(service.evaluateCuvCsvExport(DOC_ID).ready()).isTrue();
    }
}
