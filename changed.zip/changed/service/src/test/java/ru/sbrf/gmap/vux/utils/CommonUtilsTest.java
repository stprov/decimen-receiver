package ru.sbrf.gmap.vux.utils;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.sbrf.gmap.vux.model.DocumentTypeEnum;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

class CommonUtilsTest {

    @Test
    @DisplayName("generateTfsFilename: расширение исходного файла не дублируется в имени TFS-файла")
    void shouldGenerateTfsFileNameWithoutDuplicatedExtension() {
        UUID rqUid = UUID.fromString("1775da15-b8fb-4426-a863-76c57e2d7a2b");

        String tfsFileName = CommonUtils.generateTfsFilename(
                DocumentTypeEnum.XBRL_CSV_RP_DOCUMENT,
                rqUid,
                "1027700132195_00041_00_20260929.zip");

        assertThat(tfsFileName)
                .isEqualTo("XbrlCsvRpDocument_1027700132195_00041_00_20260929_1775da15-b8fb-4426-a863-76c57e2d7a2b.zip");
    }

    @Test
    @DisplayName("getSignFileName: имя подписи строится из TFS_FileName — {TFS_FileName без расширения}.sgn")
    void shouldBuildSignFileNameFromTfsFileName() {
        String tfsFileName = CommonUtils.generateTfsFilename(
                DocumentTypeEnum.XBRL_CSV_RP_DOCUMENT,
                UUID.fromString("1775da15-b8fb-4426-a863-76c57e2d7a2b"),
                "1027700132195_00041_00_20260929.zip");

        assertThat(CommonUtils.getSignFileName(tfsFileName))
                .isEqualTo("XbrlCsvRpDocument_1027700132195_00041_00_20260929_1775da15-b8fb-4426-a863-76c57e2d7a2b.sgn");
    }
}
