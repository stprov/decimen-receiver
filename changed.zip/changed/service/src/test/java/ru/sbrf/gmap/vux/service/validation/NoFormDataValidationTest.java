package ru.sbrf.gmap.vux.service.validation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolCheckRecordDto;
import ru.sbrf.gmap.vux.service.ValidationDataService;
import ru.sbrf.gmap.vux.service.checks.ContextExistsRule;
import ru.sbrf.gmap.vux.service.checks.DataContext;
import ru.sbrf.gmap.vux.service.checks.UnitExistsRule;
import ru.sbrf.gmap.vux.service.checks.ValueExistsRule;
import ru.sbrf.gmap.vux.service.checks.WorkflowRunIdRule;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Нет данных формы — ошибки CUV-проверки по постановке (аналитика, Q-8 п. 2.1, D-17, 7.7 шаги 1–2).
 */
@DisplayName("CUV-проверка: нет данных формы")
class NoFormDataValidationTest {

    private final ValidationDataService service = new ValidationDataService(List.of(
            new WorkflowRunIdRule(), new ContextExistsRule(), new UnitExistsRule(), new ValueExistsRule()));

    @Test
    @DisplayName("workflow_run_id не заполнен → только _001, шаг 2 не выполняется")
    void noWorkflowRunId_onlyError001() {
        List<ValidationErrorDto> errors = service.validate(DataContext.empty(1, null));

        assertThat(errors).extracting(ValidationErrorDto::errorCode)
                .containsExactly("DCUV_0420415_1_3_001");
        assertThat(service.countExecutedChecks(errors)).isEqualTo(1);
        assertThat(service.getChecks(errors)).extracting(ProtocolCheckRecordDto::getCheckResult)
                .containsExactly("Выявлено", "Не проверялось", "Не проверялось", "Не проверялось");
    }

    @Test
    @DisplayName("workflow_run_id есть, данных нет → _002, _003, _004 с workflow_run_id из view")
    void noData_errors002to004() {
        List<ValidationErrorDto> errors = service.validate(DataContext.empty(1, 42L));

        assertThat(errors).extracting(ValidationErrorDto::errorCode)
                .containsExactly("DCUV_0420415_1_3_002", "DCUV_0420415_1_3_003", "DCUV_0420415_1_3_004");
        assertThat(errors).allSatisfy(e -> assertThat(e.errorMessage()).contains("workflow_run_id = 42"));
        assertThat(service.countExecutedChecks(errors)).isEqualTo(4);
    }
}
