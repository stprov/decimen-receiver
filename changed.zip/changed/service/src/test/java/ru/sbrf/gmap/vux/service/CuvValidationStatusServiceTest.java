package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.sql.Timestamp;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Итоговый статус CUV-проверки (аналитика, 7.8, D-47).
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("CuvValidationStatusService")
class CuvValidationStatusServiceTest {

    @Mock
    private VuxDocumentValidationResultViewRepository viewRepository;
    @InjectMocks
    private CuvValidationStatusService service;

    private final Timestamp start = new Timestamp(1_000);
    private final Timestamp end = new Timestamp(2_000);

    private static VuxDocumentScheduleViewEntity record() {
        VuxDocumentScheduleViewEntity record = new VuxDocumentScheduleViewEntity();
        record.setScheduleId(1);
        record.setResultDocumentId(100);
        return record;
    }

    @Test
    @DisplayName("Без ошибок — статус 1")
    void checkedWithoutErrors() {
        service.saveChecked(record(), 10, 0, start, end);

        verify(viewRepository).flowCuvSetStatus(100L, 1, 10, 0L, start, end);
    }

    @Test
    @DisplayName("С ошибками — статус 2 и число ошибок")
    void checkedWithErrors() {
        service.saveChecked(record(), 4, 3, start, end);

        verify(viewRepository).flowCuvSetStatus(100L, 2, 4, 3L, start, end);
    }

    @Test
    @DisplayName("Не проверен — статус 0, без проверок и ошибок")
    void notChecked() {
        service.saveNotChecked(record());

        verify(viewRepository).flowCuvSetStatus(eq(100L), eq(0), eq(0), eq(0L), any(), any());
    }

    @Test
    @DisplayName("«Расписание не найдено» и сбой БД не прерывают обработку")
    void failuresAreSwallowed() {
        when(viewRepository.flowCuvSetStatus(anyLong(), anyInt(), anyInt(), anyLong(), any(), any()))
                .thenReturn(Optional.of("Расписание не найдено"))
                .thenThrow(new IllegalStateException("db"));

        assertThatNoException().isThrownBy(() -> service.saveNotChecked(record()));
        assertThatNoException().isThrownBy(() -> service.saveChecked(record(), 1, 0, start, end));
    }
}
