package ru.sbrf.gmap.vux.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mail.MailSendException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.util.ReflectionTestUtils;
import ru.sbrf.gmap.vux.config.CommonProps;
import ru.sbrf.gmap.vux.config.MailProps;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("MailService")
class MailServiceTest {

    @Mock
    private MailProps mailProps;
    @Mock
    private CommonProps commonProps;
    @Mock
    private JavaMailSender javaMailSender;
    @InjectMocks
    private MailService mailService;

    @Captor
    private ArgumentCaptor<MimeMessage> mimeMessageCaptor;

    @Test
    @DisplayName("sendMail с addPrefix=true добавляет префикс 'Stand:' в тему")
    void sendMail_withPrefix_addsStandPrefix() throws MessagingException {
        when(commonProps.standName()).thenReturn("PROD");
        when(mailProps.from()).thenReturn("test@test.ru");

        MimeMessage message = new MimeMessage((jakarta.mail.Session) null);
        when(javaMailSender.createMimeMessage()).thenReturn(message);

        mailService.sendMail("Test subject", "<html/>", List.of("to@test.ru"), List.of(), true);

        verify(javaMailSender).send(mimeMessageCaptor.capture());
        MimeMessage sent = mimeMessageCaptor.getValue();

        assertThat(sent.getSubject()).isEqualTo("Stand: PROD. null: Test subject");
    }

    @Test
    @DisplayName("sendMail с addPrefix=false НЕ добавляет префикс 'Stand:' в тему")
    void sendMail_withoutPrefix_subjectWithoutPrefix() throws MessagingException {
        when(mailProps.from()).thenReturn("test@test.ru");

        MimeMessage message = new MimeMessage((jakarta.mail.Session) null);
        when(javaMailSender.createMimeMessage()).thenReturn(message);

        mailService.sendMail("Test subject", "<html/>", List.of("to@test.ru"), List.of(), false);

        verify(javaMailSender).send(mimeMessageCaptor.capture());
        MimeMessage sent = mimeMessageCaptor.getValue();

        assertThat(sent.getSubject()).isEqualTo("Test subject");
    }

    @Test
    @DisplayName("sendMail (4 параметра) добавляет префикс 'Stand:' — обратная совместимость")
    void sendMail_legacyMethod_addsStandPrefix() throws MessagingException {
        when(commonProps.standName()).thenReturn("PROD");
        when(mailProps.from()).thenReturn("test@test.ru");

        MimeMessage message = new MimeMessage((jakarta.mail.Session) null);
        when(javaMailSender.createMimeMessage()).thenReturn(message);

        mailService.sendMail("Test subject", "<html/>", List.of("to@test.ru"), List.of());

        verify(javaMailSender).send(mimeMessageCaptor.capture());
        MimeMessage sent = mimeMessageCaptor.getValue();

        assertThat(sent.getSubject()).isEqualTo("Stand: PROD. null: Test subject");
    }

    // ===================== Повторные попытки (DEF-13, аналитика 9.2) =====================

    private void retries(int maxAttempts) {
        ReflectionTestUtils.setField(mailService, "maxAttempts", maxAttempts);
        ReflectionTestUtils.setField(mailService, "retryDelayMs", 0L);
        when(mailProps.from()).thenReturn("test@test.ru");
        when(javaMailSender.createMimeMessage()).thenReturn(new MimeMessage((jakarta.mail.Session) null));
    }

    @Test
    @DisplayName("Сбой на всех попытках — false, число попыток = max-attempts")
    void sendMail_allAttemptsFail_returnsFalse() {
        retries(2);
        doThrow(new MailSendException("smtp down")).when(javaMailSender).send(any(MimeMessage.class));

        boolean sent = mailService.sendMail("s", "<html/>", List.of("to@test.ru"), List.of(), false);

        assertThat(sent).isFalse();
        verify(javaMailSender, times(2)).send(any(MimeMessage.class));
    }

    @Test
    @DisplayName("Сбой, затем успех — true")
    void sendMail_succeedsOnRetry() {
        retries(3);
        doThrow(new MailSendException("smtp down")).doNothing().when(javaMailSender).send(any(MimeMessage.class));

        boolean sent = mailService.sendMail("s", "<html/>", List.of("to@test.ru"), List.of(), false);

        assertThat(sent).isTrue();
        verify(javaMailSender, times(2)).send(any(MimeMessage.class));
    }

    @Test
    @DisplayName("Нет получателей — письмо не отправляется, результат true (как в AS-IS)")
    void sendMail_noRecipients_returnsTrue() {
        boolean sent = mailService.sendMail("s", "<html/>", List.of(), List.of(), false);

        assertThat(sent).isTrue();
        verify(javaMailSender, never()).send(any(MimeMessage.class));
    }
}