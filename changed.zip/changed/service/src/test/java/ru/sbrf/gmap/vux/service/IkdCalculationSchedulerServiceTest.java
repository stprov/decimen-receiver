package ru.sbrf.gmap.vux.service;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.dao.DataAccessResourceFailureException;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты для {@link IkdCalculationSchedulerService}.
 * <p>
 * Проверяют:
 * <ul>
 *   <li>Вызов репозитория ровно один раз за прогон</li>
 *   <li>Логирование INFO при успехе и ERROR при сбое</li>
 *   <li>Перехват исключений без проброса наружу</li>
 *   <li>Условную регистрацию по флагу {@code config.feature-toggles.scheduled-ikd-calculation}</li>
 * </ul>
 * Тайм-аут транзакции задаётся на методе репозитория
 * ({@code @Transactional(timeoutString = "${config.ikd-calculation-scheduler.timeout:3600}")}).
 */
class IkdCalculationSchedulerServiceTest {

    private static final String ENABLED_FLAG = "config.feature-toggles.scheduled-ikd-calculation";

    private final VuxDocumentValidationResultViewRepository repository = mock(VuxDocumentValidationResultViewRepository.class);
    private final ListAppender<ILoggingEvent> appender = new ListAppender<>();
    @SuppressWarnings("LoggerInitializedWithForeignClass")
    private final Logger logbackLogger = (Logger) org.slf4j.LoggerFactory.getLogger(IkdCalculationSchedulerService.class);
    private IkdCalculationSchedulerService service;

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withBean(VuxDocumentValidationResultViewRepository.class, () -> mock(VuxDocumentValidationResultViewRepository.class))
            .withBean(IkdCalculationSchedulerService.class, () -> new IkdCalculationSchedulerService(mock(VuxDocumentValidationResultViewRepository.class)))
            .withPropertyValues(
                    "spring.application.name=gmap2-vux-ecm",
                    "config.ikd-calculation-scheduler.cron=0 0 0 16 * ?",
                    "config.ikd-calculation-scheduler.timezone=Europe/Moscow");

    @BeforeEach
    void setUp() {
        appender.start();
        logbackLogger.addAppender(appender);
        service = new IkdCalculationSchedulerService(repository);
    }

    @AfterEach
    void detachAppender() {
        appender.list.clear();
        logbackLogger.detachAppender(appender);
        appender.stop();
    }

    @Test
    @DisplayName("Успешный прогон вызывает fnLoadRequest один раз")
    void successfulRun_callsRepositoryOnce() {
        when(repository.fnLoadRequest()).thenReturn(Optional.empty());

        service.run();

        verify(repository, times(1)).fnLoadRequest();
    }

    @Test
    @DisplayName("INFO-запись содержит executionId и имя процедуры fn_load_request")
    void successfulRun_logsInfoWithExecutionIdAndProcedureName() {
        when(repository.fnLoadRequest()).thenReturn(Optional.empty());

        service.run();

        var infoEvents = logs(Level.INFO).stream()
                .filter(e -> e.getFormattedMessage().contains("completed successfully"))
                .toList();
        assertThat(infoEvents).hasSize(1);
        var msg = infoEvents.getFirst().getFormattedMessage();
        assertThat(msg).contains("executionId=").contains("procedure=fn_load_request");
    }

    @Test
    @DisplayName("Сбой процедуры логируется ERROR и не пробрасывается наружу")
    void failedProcedure_logsErrorAndIsNotRethrown() {
        when(repository.fnLoadRequest()).thenThrow(new DataAccessResourceFailureException("connection refused"));

        assertThatCode(service::run).doesNotThrowAnyException();

        var errors = logs(Level.ERROR);
        assertThat(errors).hasSize(1);
        var errorEvent = errors.getFirst();
        assertThat(errorEvent.getFormattedMessage())
                .contains("executionId=")
                .contains("procedure=fn_load_request");
        assertThat(errorEvent.getThrowableProxy()).isNotNull();
        assertThat(errorEvent.getThrowableProxy().getMessage()).isEqualTo("connection refused");
    }

    @Test
    @DisplayName("Сетевой сбой логируется ERROR и не пробрасывается наружу")
    void networkFailure_logsErrorAndIsNotRethrown() {
        when(repository.fnLoadRequest()).thenThrow(new org.springframework.dao.TransientDataAccessResourceException("timeout"));

        assertThatCode(service::run).doesNotThrowAnyException();

        var errors = logs(Level.ERROR);
        assertThat(errors).hasSize(1);
        assertThat(errors.getFirst().getThrowableProxy()).isNotNull();
    }

    @Test
    @DisplayName("Произвольное исключение внутри run не приводит к ошибке")
    void arbitraryException_doesNotBreakService() {
        when(repository.fnLoadRequest()).thenThrow(new RuntimeException("unexpected error"));

        assertThatCode(service::run).doesNotThrowAnyException();
    }

    @Test
    @DisplayName("При флаге scheduled-ikd-calculation=false сервис не регистрируется в контексте")
    void serviceAbsentWhenFlagDisabled() {
        contextRunner
                .withPropertyValues(ENABLED_FLAG + "=false")
                .run(context -> assertThat(context).doesNotHaveBean(IkdCalculationSchedulerService.class));
    }

    @Test
    @DisplayName("Сервис зарегистрирован при флаге scheduled-ikd-calculation=true")
    void servicePresentWhenFlagEnabled() {
        contextRunner
                .withPropertyValues(ENABLED_FLAG + "=true")
                .run(context -> assertThat(context).hasSingleBean(IkdCalculationSchedulerService.class));
    }

    @Test
    @DisplayName("Сервис не регистрируется при отсутствии флага scheduled-ikd-calculation")
    void serviceAbsentWhenFlagMissing() {
        contextRunner.run(context -> assertThat(context).doesNotHaveBean(IkdCalculationSchedulerService.class));
    }

    private List<ILoggingEvent> logs(Level level) {
        return appender.list.stream().filter(e -> e.getLevel() == level).toList();
    }
}
