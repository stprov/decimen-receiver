<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            font-size: 14px;
            line-height: 1.5;
            color: #333333;
        }
        .container {
            max-width: 700px;
            margin: 0 auto;
            padding: 20px;
        }
        .greeting {
            margin-bottom: 20px;
        }
        .params {
            margin-bottom: 20px;
            padding-left: 20px;
        }
        .section-title {
            font-weight: bold;
            margin-top: 20px;
            margin-bottom: 10px;
        }
        .numbered-list {
            padding-left: 20px;
        }
        .static-text {
            margin-bottom: 15px;
        }
        .static-path {
            font-family: 'Courier New', monospace;
            font-size: 13px;
            background-color: #f5f5f5;
            padding: 2px 4px;
            border-radius: 3px;
        }
        .contact-info {
            margin-top: 30px;
            padding-top: 15px;
            border-top: 1px solid #dddddd;
            font-size: 13px;
            color: #555555;
        }
        .info-block {
            background-color: #fff8e1;
            border-left: 4px solid #ffc107;
            padding: 10px 15px;
            margin: 15px 0;
            font-size: 13px;
        }
    </style>
</head>
<body>
<div class="container">

    <!-- Раздел 1: Обращение -->
    <div class="greeting">
        Добрый день!
    </div>

    <div class="static-text">
        Напоминаем о необходимости подготовки отчетных форм ниже<br/>
        в рамках <strong>${reportingType}</strong> отчетности за <strong>${reportDt}</strong>:
    </div>

    <div class="params">
        <strong>${forms}</strong>
    </div>

    <!-- Раздел 2: Основная часть -->
    <div class="static-text">
        Просьба размещать на ресурсе с отчетностью файлы:
    </div>

    <div class="numbered-list">
        1. XBRL отчетной формы<br/>
        2. Excel отчетной формы<br/>
        3. Excel «Журнал проверки.xlsx» из ПО «Конвертер»<br/>
        4. Пояснительную записку, содержащую комментарии к каждому предупреждению (при наличии)
    </div>

    <div class="static-text">
        <br/>
        Направьте, пожалуйста, отчетные формы не позднее <strong>${startDate}</strong><br/>
        (в том числе в случае отсутствия данных для подготовки отчетной формы).
    </div>

    <div class="static-text">
        По возможности направляйте формы сразу по готовности.
    </div>

    <div class="static-text">
        Срок представления отчетности в Банк России &mdash; <strong>${deadlineDate}</strong>.
    </div>

    <div class="static-text">
        Актуальный путь к ФИРу для размещения отчетности по формам:<br/>
        <span class="static-path">\\inter232.sigma.sbrf.ru\vol3\Diasoft-Clearing-XBRL\</span>
    </div>

    <div class="static-text">
        Актуальная версия таксономии версия <strong>${taxonomy}</strong><br/>
        для загрузки в ПО «Конвертер» размещена на ресурсе:<br/>
        <span class="static-path">\\inter232.sigma.sbrf.ru\Vol3\Diasoft-Clearing-XBRL\Taxonomies</span>
    </div>

    <div class="static-text">
        Большая просьба при подготовке отчетности в формате XBRL<br/>
        использовать актуальную версию ПО «Конвертер» <strong>${converterVersion}</strong>:<br/>
        <a href="https://sberusersoft.sigma.sbrf.ru/#program/s/14756">https://sberusersoft.sigma.sbrf.ru/#program/s/14756</a>
    </div>

    <div class="info-block">
        <strong>Просьба валидировать отчетность со следующими параметрами ПО Конвертер:</strong><br/>
        1. В закладке «Настройки» → «Параметры» убрать галку с поля<br/>
        &nbsp;&nbsp;&nbsp;«Установить максимальное время валидации формулы»<br/>
        2. Сохранить<br/><br/>
        Наличие галки в данном поле создает риск неполной валидации отчетности.
    </div>

    <!-- Раздел 3: Заключение -->
    <div class="contact-info">
        При наличии вопросов по расписанию сдачи отчетности обращаться<br/>
        к Кожевниковой Екатерине <a href="mailto:EALukicheva@sberbank.ru">EALukicheva@sberbank.ru</a><br/>
        и Ширнину Степану <a href="mailto:SSeShirnin@sberbank.ru">SSeShirnin@sberbank.ru</a>
    </div>

</div>
</body>
</html>