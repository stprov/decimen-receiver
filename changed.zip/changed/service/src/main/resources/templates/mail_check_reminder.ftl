<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            font-size: 14px;
            line-height: 1.5;
            color: #333333;
        }
        .container {
            max-width: 700px;
            margin: 0 auto;
            padding: 20px;
        }
        .greeting {
            margin-bottom: 20px;
        }
        .static-text {
            margin-bottom: 15px;
        }
        .section-title {
            font-weight: bold;
            margin-top: 20px;
            margin-bottom: 10px;
        }
        .numbered-list {
            padding-left: 20px;
        }
        .forms-table {
            border-collapse: collapse;
            margin: 10px 0 15px 0;
        }
        .forms-table td {
            border: 1px solid #dddddd;
            padding: 4px 12px;
            font-weight: bold;
        }
        .static-path {
            font-family: 'Courier New', monospace;
            font-size: 13px;
            background-color: #f5f5f5;
            padding: 2px 4px;
            border-radius: 3px;
        }
        .contact-info {
            margin-top: 30px;
            padding-top: 15px;
            border-top: 1px solid #dddddd;
            font-size: 13px;
            color: #555555;
        }
    </style>
</head>
<body>
<div class="container">

    <!-- Обращение -->
    <div class="greeting">
        Добрый день!
    </div>

    <!-- Напоминание -->
    <div class="static-text">
        Напоминаем о завершении этапа подготовки отчетности со сроком направления<br/>
        в Банк России пакета <strong>${deadlineDate}</strong> и необходимости проверки пакетов<br/>
        с отчетными формами ниже в рамках <strong>${reportingType}</strong> отчетности<br/>
        за <strong>${reportDt}</strong> в соответствии с СОП:
    </div>

    <!-- Таблица форм -->
    <table class="forms-table">
        <#list forms as form>
        <tr><td>${form}</td></tr>
        </#list>
    </table>

    <!-- Чек-лист 1-й руки -->
    <div class="section-title">Чек-лист для подготовки отчетности &mdash; 1-я рука:</div>
    <div class="static-text">
        <span class="static-path">\\Inter232.sigma.sbrf.ru\vol3\Diasoft-Clearing-XBRL\Final\Методология\Материалы для подготовки отчетности\Чек-лист для подготовки отчет</span>
    </div>
    <div class="numbered-list">
        1. Точку входа и отчетную дату<br/>
        2. Наличие файлов в папке final<br/>
        3. Наличие КС в Журнале проверки<br/>
        4. Необходимость формирования ПЗ<br/>
        5. Наличие ПЗ в архиве<br/>
        6. Заполняемость пакета отчетности<br/>
        7. Ручные контроли
    </div>

    <!-- Чек-лист 2-й руки -->
    <div class="section-title">Чек-лист второй руки:</div>
    <div class="static-text">
        <span class="static-path">\\Inter232.sigma.sbrf.ru\vol3\Diasoft-Clearing-XBRL\Final\Методология\Материалы для подготовки отчетности\Чек-лист второй руки</span>
    </div>
    <div class="numbered-list">
        1. Точку входа и отчетную дату<br/>
        2. Файл XML загружен без ошибки<br/>
        3. Наличие КС в Журнале проверки<br/>
        4. Необходимость формирования ПЗ<br/>
        5. Наличие ПЗ в архиве<br/>
        6. Заполняемость пакета отчетности
    </div>

    <!-- Контакты -->
    <div class="contact-info">
        При наличии вопросов обращаться к Кожевниковой Екатерине
        <a href="mailto:EALukicheva@sberbank.ru">EALukicheva@sberbank.ru</a><br/>
        и Ширнину Степану <a href="mailto:SSeShirnin@sberbank.ru">SSeShirnin@sberbank.ru</a>
    </div>

</div>
</body>
</html>
