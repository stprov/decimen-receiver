<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Результат проверки ${documentNumber}</title>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            font-size: 12px;
        }

        h1 {
            color: #333;
            text-align: center;
            font-size: 16px;
            margin-bottom: 10px;
        }

        .container {
            max-width: 700px;
            margin: auto;
            padding: 15px;
            border-radius: 8px;
            background-color: #f9f9f9;
            box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
        }

        .metadata {
            margin-bottom: 15px;
        }

        .metadata-row {
            margin-bottom: 8px;
            line-height: 1.4;
        }

        .metadata-label {
            font-weight: bold;
            display: inline-block;
            width: 180px;
        }

        hr.separator {
            margin: 15px 0;
            border: 0;
            border-top: 1px solid #ddd;
        }

        .section-title {
            font-size: 16px;
            font-weight: bold;
            color: #2c3e50;
            margin: 20px 0 15px 0;
            text-align: left;
            padding: 10px;
            border-radius: 6px;
        }
        
        .section-title-error {
            background-color: rgba(248, 215, 218, 0.5);
            border-left: 16px solid #f5c6cb;
            border-top: 2px solid #f5c6cb;
            border-bottom: 2px solid #f5c6cb;
            border-right: 2px solid #f5c6cb;
            border-radius: 6px;
        }
        
        .section-title-warning {
            background-color: rgba(255, 243, 205, 0.5);
            border-left: 16px solid #ffeaa7;
            border-top: 2px solid #ffeaa7;
            border-bottom: 2px solid #ffeaa7;
            border-right: 2px solid #ffeaa7;
            border-radius: 6px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            margin-bottom: 15px;
            font-size: 11px;
        }

        th, td {
            padding: 6px 8px;
            text-align: left;
        }

        th {
            background-color: #eef2f7;
            font-weight: bold;
            border-bottom: 1px solid #bbb;
        }

        tbody tr:nth-child(even) {
            background-color: #f5f5f5;
        }

        .error-banner {
            background-color: #ffebee;
            padding: 12px;
            border-radius: 4px;
            margin-bottom: 15px;
            font-size: 13px;
            color: #c62828;
        }
        
        .warning-banner {
            background-color: #fff3cd;
            padding: 12px;
            border-radius: 4px;
            margin-bottom: 15px;
            font-size: 13px;
            color: #856404;
        }

        .success-message {
            margin-top: 10px;
            text-align: center;
            padding: 10px;
            background-color: #e8f5e9;
            border-radius: 4px;
            border: 1px solid #c8e6c9;
        }

        .success-label {
            color: #2E8B57;
        }

        .success-text {
            font-weight: bold;
        }

        footer {
            text-align: right;
            margin-top: 30px;
            font-size: 0.8em;
            color: #777;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Протокол проверки № ${documentNumber}</h1>

    <div class="metadata">
        <div class="metadata-row">
            <span class="metadata-label">Дата проверки:</span> ${checkDate}
        </div>
        <div class="metadata-row">
            <span class="metadata-label">Форма отчетности:</span> ${reportType}
        </div>
        <div class="metadata-row">
            <span class="metadata-label">Период отчетности:</span> ${documentDate}
        </div>
        <div class="metadata-row">
            <span class="metadata-label">Проверяющий:</span> ПКАП1055 АС ГР.Отчетность ВУИКС
        </div>
    </div>

    <hr class="separator"/>

    <!--"Результат проверки" -->
    <div class="section-title">Результат проверки</div>

    <!-- Таблица с результатами проверки -->
    <table>
        <thead>
        <tr>
            <th>Вид проверки</th>
            <th>Отклонение</th>
            <th>Количество</th>
        </tr>
        </thead>
        <tbody>
        <#if checksList?has_content>
            <#list checksList as result>
                <tr>
                    <td>${result.checkType!"-"}</td>
                    <td style="color: <#if result.checkResult == 'Выявлено'>red</#if>;">
                        ${result.checkResult!'Не выявлено'}
                    </td>
                    <td>${result.countingDeviation!"0"}</td>
                </tr>
            </#list>
        <#else>
            <tr>
                <td colspan="3" style="text-align: center; color: #999;">Данные отсутствуют</td>
            </tr>
        </#if>
        </tbody>
    </table>

    <#if objects?has_content>
        <div class="error-banner">
            Найдены серьезные ошибки!<br/>
            Показано ${objects?size} из ${totalErrorCount}
        </div>
    </#if>
    
    <#if warnings?has_content>
        <div class="warning-banner">
            Обнаружены предупреждения:<br/>
            Показано ${warnings?size} из ${totalWarningCount}
        </div>
    </#if>
    
    <#if objects?has_content>
        <div class="section-title section-title-error">Список ошибок</div>
        <table>
            <thead>
            <tr>
                <th>№ п/п</th>
                <th>Тип объекта</th>
                <th>Значение объекта</th>
                <th>Номер объекта</th>
                <th>Код ошибки</th>
                <th>Описание ошибки</th>
            </tr>
            </thead>
            <tbody>
            <#list objects as object>
                <tr>
                    <td>${object_index + 1}</td>
                    <td>${object.objectName!""}</td>
                    <td>${object.isinNumber!"-"}</td>
                    <td>${object.objectNumber!"-"}</td>
                    <td>${object.errorCode!"-"}</td>
                    <td>${object.errorMessage!"-"}</td>
                </tr>
            </#list>
            </tbody>
        </table>
    </#if>
    
    <#if warnings?has_content>
        <div class="section-title section-title-warning">Список предупреждений</div>
        <table>
            <thead>
            <tr>
                <th>№ п/п</th>
                <th>Тип объекта</th>
                <th>Значение объекта</th>
                <th>Номер объекта</th>
                <th>Код предупреждения</th>
                <th>Описание предупреждения</th>
            </tr>
            </thead>
            <tbody>
            <#list warnings as warning>
                <tr>
                    <td>${warning_index + 1}</td>
                    <td>${warning.objectName!""}</td>
                    <td>${warning.isinNumber!"-"}</td>
                    <td>${warning.objectNumber!"-"}</td>
                    <td>${warning.errorCode!"-"}</td>
                    <td>${warning.errorMessage!"-"}</td>
                </tr>
            </#list>
            </tbody>
        </table>
    </#if>
    
    <#if !(objects?has_content) && !(warnings?has_content)>
        <div class="success-message">
            <span class="success-text">Результат проверки:</span>
            <strong><span class="success-label">Ошибок и предупреждений не найдено.</span></strong><br/>
        </div>
    </#if>
</div>
</body>
</html>