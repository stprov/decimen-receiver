package ru.sbrf.gmap.vux.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "v_vux_document_validation_log")
public class VuxDocumentValidationLogEntity {
    @Id
    @Column(name = "_id")
    private Integer id;
    @Column(name = "doc_id")
    private Integer docId;
    @Column(name = "rule_id")
    private Integer ruleId;
    @Column(name = "rule_type")
    private String ruleType;
    @Column(name = "error_code")
    private String errorCode;
    @Column(name = "descr")
    private String descr;
    @Column(name = "check_time")
    private Timestamp checkTime;
    @Column(name = "error_count")
    private Integer errorCount;
    @Column(name = "error_message")
    private String errorMessage;
}
