package ru.sbrf.gmap.vux.dto.request.ecm;

import jakarta.validation.constraints.NotBlank;
import lombok.Builder;

@Builder
public record UploadByS3PathRequestDto(
        @NotBlank String s3Path,
        @NotBlank String filename,
        @NotBlank String documentType,
        @NotBlank String sliceId
) {
}