package ru.sbrf.gmap.vux.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationLogEntity;

import java.util.List;

@Repository
public interface VuxDocumentValidationLogRepository extends JpaRepository<VuxDocumentValidationLogEntity, Integer> {
List<VuxDocumentValidationLogEntity> findAllByDocIdOrderByErrorCountDesc(Integer documentId);
}
