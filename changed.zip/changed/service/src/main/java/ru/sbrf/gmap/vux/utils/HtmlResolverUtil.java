package ru.sbrf.gmap.vux.utils;

import com.itextpdf.html2pdf.HtmlConverter;
import lombok.experimental.UtilityClass;

import java.io.ByteArrayOutputStream;

@UtilityClass
public class HtmlResolverUtil {

    public static byte[] resolve(String html) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        HtmlConverter.convertToPdf(html, baos);
        return baos.toByteArray();
    }
}
