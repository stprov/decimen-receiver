package ru.sbrf.gmap.vux.dto.request.okey;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import ru.sbrf.gmap.vux.dto.request.ecm.CreateContentsRequest;

/**
 * DTO для передачи блока подписи (signatures) в запросе create-contents к ECM.
 * Спецификация: ECM.MS-API.V3.15.Create Contents
 *
 * @see CreateContentsRequest
 */
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public record SignatureDto(
        @JsonProperty("signLocation")
        String signLocation,
        @JsonProperty("typeSign")
        String typeSign,
        @JsonProperty("signFileName")
        String signFileName,
        @JsonProperty("businessCode")
        String businessCode,
        @JsonProperty("isClosedForAppend")
        Boolean isClosedForAppend
) {
}