package ru.sbrf.gmap.vux.model.sign;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record SignRequestDto(

        @NotBlank
        @JsonPropertyDescription("Идентификатор хэша")
        String id,

        @NotNull
        @JsonPropertyDescription("Объект с хэшами")
        @Valid
        Hashes hashes,

        @NotNull
        @JsonPropertyDescription("Типы сертификатов, которые включаются в ЭП")
        ProvideCerts provideCerts
) {
    public record Hashes(
            @JsonPropertyDescription("ГОСТ Р 34.11-2012 короткий")
            @JsonProperty("HASH_GOST3411_2012_256")
            @NotBlank
            String hashGost3411_2012_256,
            @JsonPropertyDescription("ГОСТ Р 34.11-2012 длинный")
            @JsonProperty("HASH_GOST3411_2012_512")
            @NotBlank
            String hashGost3411_2012_512
    ) {
    }

    /**
     * FULL_CHAIN - включить все
     * CHAIN_EXCEPT_ROOT - включить все, кроме корневого
     * SIGNER - включить только сертификат подписанта
     */
    public enum ProvideCerts {
        FULL_CHAIN, CHAIN_EXCEPT_ROOT, SIGNER
    }
}
