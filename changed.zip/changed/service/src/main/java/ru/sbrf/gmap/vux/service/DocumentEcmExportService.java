package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.entity.VuxDocumentEcmEntity;
import ru.sbrf.gmap.vux.repository.VuxDocumentEcmRepository;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;
import ru.sbrf.gmap.vux.service.checks.ImageTypeEnum;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Выгрузка образов документа (CSV context/unit/value) в ECM через таблицу-очередь
 * {@code t_vux_document_ecm}.
 * <p>
 * VUX только создаёт записи ({@code fn_xbrl_create_ecm}) и читает их состояние;
 * файлы формирует и загружает в ECM внешний сервис. {@code disabled = 1} — окончательный
 * отказ внешнего сервиса (404/405/406/408, HTTP 4xx от ECM): такая запись не пересоздаётся,
 * расписание остаётся открытым, в лог пишется ERROR для ручного разбора.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DocumentEcmExportService {

    /**
     * {@code p_s3_del = 1}: после успешной загрузки в ECM внешний сервис удаляет файлы из S3.
     */
    private static final int S3_DEL = 1;

    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;
    private final VuxDocumentEcmRepository vuxDocumentEcmRepository;

    /**
     * Значение {@code p_archive} для {@code fn_xbrl_create_ecm}.
     */
    @Value("${config.csv-export.archive:0}")
    private int archive;

    /**
     * Создаёт записи выгрузки для всех CSV-образов CUV (фаза 1).
     * Ошибка по одному образу не прерывает создание остальных: недостающие записи
     * будут созданы в фазе 2.
     *
     * @return {@code true}, если созданы все записи
     */
    public boolean requestCuvCsvExport(Integer docId) {
        boolean allCreated = true;
        for (ImageTypeEnum type : ImageTypeEnum.CUV_CSV_TYPES) {
            allCreated &= createExportRecord(docId, type, "initial");
        }
        return allCreated;
    }

    /**
     * Создаёт одну запись выгрузки образа.
     *
     * @param reason причина для лога: initial / restore
     * @return {@code true} при успехе
     */
    public boolean createExportRecord(Integer docId, ImageTypeEnum type, String reason) {
        try {
            vuxDocumentValidationResultViewRepository.fnXbrlCreateEcm(docId, type.getCode(), archive, S3_DEL);
            log.info("[CSV-EXPORT] Export record created: docId={}, imageType={}, reason={}", docId, type.getCode(), reason);
            return true;
        } catch (Exception e) {
            log.error("[CSV-EXPORT] Failed to create export record: docId={}, imageType={}, reason={}. " +
                    "Will be retried in the next scheduler cycle.", docId, type.getCode(), reason, e);
            return false;
        }
    }

    /**
     * Проверяет состояние выгрузки CSV-образов CUV (фаза 2).
     * <p>
     * Для каждого образа берётся последняя по {@code created} запись:
     * <ul>
     *     <li>{@code ecm_id} заполнен — образ готов;</li>
     *     <li>{@code disabled = 1} — окончательный отказ: запись не пересоздаётся, ERROR в лог,
     *         задача СУПЗ не создаётся до ручного разбора;</li>
     *     <li>{@code ecm_id} пуст, {@code disabled = 0} — внешний сервис ещё обрабатывает, ждём;</li>
     *     <li>записей нет совсем (сбой фазы 1) — создание.</li>
     * </ul>
     *
     * @return состояние; {@link ExportState#ready()} = все образы получили ECM-id
     */
    public ExportState evaluateCuvCsvExport(Integer docId) {
        List<String> codes = ImageTypeEnum.CUV_CSV_TYPES.stream().map(ImageTypeEnum::getCode).toList();
        Map<String, List<VuxDocumentEcmEntity>> byType = vuxDocumentEcmRepository
                .findByDocIdAndImageTypeIn(docId.longValue(), codes).stream()
                .collect(Collectors.groupingBy(e -> normalize(e.getImageType())));

        List<String> ecmIds = new ArrayList<>();
        boolean ready = true;
        for (ImageTypeEnum type : ImageTypeEnum.CUV_CSV_TYPES) {
            List<VuxDocumentEcmEntity> records = byType.getOrDefault(type.getCode(), List.of());
            Optional<VuxDocumentEcmEntity> last = records.stream()
                    .max(Comparator.comparing(VuxDocumentEcmEntity::getCreated,
                            Comparator.nullsFirst(Comparator.<Timestamp>naturalOrder())));

            if (last.isEmpty()) {
                ready = false;
                log.warn("[CSV-EXPORT] No export records found: docId={}, imageType={}. Restoring record.",
                        docId, type.getCode());
                createExportRecord(docId, type, "restore");
                continue;
            }

            VuxDocumentEcmEntity record = last.get();
            if (record.hasEcmId()) {
                ecmIds.add(record.getEcmId().toString());
            } else if (record.isDisabled()) {
                ready = false;
                log.error("[CSV-EXPORT] CSV export failed permanently (disabled=1), manual analysis required: " +
                                "docId={}, imageType={}, xbrlId={}, attempt={}, errorCode={}, errorMessage={}",
                        docId, type.getCode(), record.getXbrlId(), record.getAttempt(),
                        record.getErrorCode(), record.getErrorMessage());
            } else {
                ready = false;
                log.info("[CSV-EXPORT] CSV is not ready yet: docId={}, imageType={}, xbrlId={}, created={}, attempt={}",
                        docId, type.getCode(), record.getXbrlId(), record.getCreated(), record.getAttempt());
            }
        }

        if (ready) {
            log.info("[CSV-EXPORT] All CSV are uploaded to ECM: docId={}, ecmIds={}", docId, ecmIds);
            return new ExportState(true, List.copyOf(ecmIds));
        }
        return new ExportState(false, List.of());
    }

    private static String normalize(String imageType) {
        // image_type передаётся в функцию как bpchar — на случай хвостовых пробелов и другого регистра
        return imageType == null ? "" : imageType.trim().toUpperCase(Locale.ROOT);
    }

    /**
     * Состояние выгрузки CSV.
     *
     * @param ready  все образы загружены в ECM
     * @param ecmIds ECM-идентификаторы CSV в порядке {@link ImageTypeEnum#CUV_CSV_TYPES} (только при ready)
     */
    public record ExportState(boolean ready, List<String> ecmIds) {
    }
}
