package ru.sbrf.gmap.vux.service.checks;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13UnitDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@Order(6)
public class OrphanUnitIdsRule implements ValidationRule {

    private static final String CHECK_DESCRIPTION = "В value отсутствуют лишние значения unit";
    private static final String ERROR_CODE = "DCUV_0420415_1_3_006";

    @Override
    public Optional<ValidationErrorDto> validate(DataContext ctx) {
        if (ctx.unitList().isEmpty() || ctx.valueList().isEmpty()) {
            return Optional.empty();
        }

        Set<String> unitIds = ctx.unitList().stream()
                .map(VuxForm0420415V13UnitDto::unitId)
                .collect(Collectors.toSet());
        Set<String> valueUnitIds = ctx.valueList().stream()
                .map(VuxForm0420415V13ValueDto::unitId)
                .collect(Collectors.toSet());

        Set<String> orphans = new HashSet<>(unitIds);
        orphans.removeAll(valueUnitIds);

        if (!orphans.isEmpty()) {
            return Optional.of(new ValidationErrorDto(
                    DEFAULT_TITLE,
                    ERROR_CODE,
                    "Обнаружены лишние unit: %s.".formatted(orphans)
            ));
        }
        return Optional.empty();
    }

    @Override
    public String getDescription() {
        return CHECK_DESCRIPTION;
    }

    @Override
    public String getCode() {
        return ERROR_CODE;
    }
}