package ru.sbrf.gmap.vux.service;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;
import ru.sber.tfs.domain.AttrIntType;
import ru.sber.tfs.domain.BusinessAttrsType;
import ru.sber.tfs.domain.CheckSumAlgorithmType;
import ru.sber.tfs.domain.ProcessingAttrsUploadType;
import ru.sber.tfs.domain.SignaturesTransportType;
import ru.sber.tfs.domain.SystemInfoUploadType;
import ru.sber.tfs.domain.UploadFileEcmRq;
import ru.sbrf.gmap.vux.IntegrationEcmTfsProps;
import ru.sbrf.gmap.vux.config.IntegrationEcmProps;
import ru.sbrf.gmap.vux.dto.request.ecm.TfsUploadFileRqDto;
import ru.sbrf.gmap.vux.model.DocumentTypeEnum;
import ru.sbrf.gmap.vux.utils.CommonUtils;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
@ConditionalOnProperty(prefix = "integration.ecm.tfs-upload", name = "enabled", havingValue = "true")
@Validated
public class EcmRqResolverService {

    private final IntegrationEcmTfsProps integrationEcmTfsProps;
    private final IntegrationEcmProps integrationEcmProps;
    private static final String PROTOCOL_TFS_ECM_DEFAULT_VERSION = "3.1";
    private static final String IS_PKI_VALUE = "true";

    private static final String RESULT_DOCUMENT_ID_KEY_BA = "resultDocumentId";

    public UploadFileEcmRq createTfsUploadFileEcmRq(@Valid TfsUploadFileRqDto tfsUploadFileRqDto, boolean needSign) {
        IntegrationEcmTfsProps.TfsParams tfsParams = integrationEcmTfsProps.tfsParams();

        UploadFileEcmRq uploadFileEcmRq = new UploadFileEcmRq();
        uploadFileEcmRq.withHeaders(getHeaders());
        uploadFileEcmRq.withRqUID(getUuidWithoutDashes(tfsUploadFileRqDto.getRqUid()));
        uploadFileEcmRq.withRqTm(getXMLGregorianCalendarValue(OffsetDateTime.now()));
        uploadFileEcmRq.withSPName(tfsParams.spName());
        uploadFileEcmRq.withSystemId(tfsParams.systemId());

        uploadFileEcmRq.withDestination(getDestinationValue());

        uploadFileEcmRq.withUser(integrationEcmProps.headers().get("user").toString());
        uploadFileEcmRq.withScenarioId(tfsParams.scenarioId());

        UploadFileEcmRq.File file = new UploadFileEcmRq.File();

        BusinessAttrsType businessAttrsType = getBusinessAttrsWithAttrIntType(List.of(Map.of(RESULT_DOCUMENT_ID_KEY_BA, tfsUploadFileRqDto.getResultDocumentId())));
        file.withBusinessAttrs(businessAttrsType);

        file.withTFSFileName(tfsUploadFileRqDto.getTfsFileName());

        if (needSign) {
            file.withSignatures(getSignature(tfsUploadFileRqDto.getTfsFileName()));
        }

        file.withSystemInfo(getSystemInfo(tfsUploadFileRqDto.getFileName(), tfsUploadFileRqDto.getFileContent(), tfsUploadFileRqDto.getDocumentTypeEnum()));

        UploadFileEcmRq.File.ProcessingAttrs processingAttrs = createNewDocDirective(integrationEcmProps.targetFolder(), null);
        processingAttrs.setClazz(tfsUploadFileRqDto.getDocumentTypeEnum().getDocumentClazz());
        file.withProcessingAttrs(processingAttrs); // формирование директивы ЕСМ на взаимодействие с файлом

        uploadFileEcmRq.withFile(file);

        return uploadFileEcmRq;
    }

    public UploadFileEcmRq.Headers getHeaders() {
        IntegrationEcmTfsProps.TfsParams tfsParams = integrationEcmTfsProps.tfsParams();
        return new UploadFileEcmRq.Headers()
                .withFPName(tfsParams.fpName())
                .withProtoVer(PROTOCOL_TFS_ECM_DEFAULT_VERSION);
    }

    private UploadFileEcmRq.Destination getDestinationValue() {
        IntegrationEcmTfsProps.TfsParams tfsProps = integrationEcmTfsProps.tfsParams();
        return new UploadFileEcmRq.Destination()
                .withName(tfsProps.destinationName())
                .withVersion(tfsProps.version());
    }


    private UploadFileEcmRq.File.ProcessingAttrs createNewDocDirective(String ecmTargetFolder, String guidToUse) {
        ProcessingAttrsUploadType.FileRelation.CreateNewDoc createNewDoc = new ProcessingAttrsUploadType.FileRelation.CreateNewDoc()
                .withECMTargetFolder(ecmTargetFolder)
                .withGuidToUse(guidToUse);
        ProcessingAttrsUploadType.FileRelation fileRelation = new ProcessingAttrsUploadType.FileRelation().withCreateNewDoc(createNewDoc);
        return new UploadFileEcmRq.File.ProcessingAttrs().withFileRelation(fileRelation);
    }

    private UploadFileEcmRq.File.ProcessingAttrs createDocAsChildDirective(String ecmTargetFolder, String parentGuid) {

        ProcessingAttrsUploadType.FileRelation.CreateDocAsChild createDocAsChild = new ProcessingAttrsUploadType.FileRelation.CreateDocAsChild()
                .withECMTargetFolder(ecmTargetFolder)
                .withParentGuid(parentGuid);
        ProcessingAttrsUploadType.FileRelation fileRelation = new ProcessingAttrsUploadType.FileRelation().withCreateDocAsChild(createDocAsChild);
        return new UploadFileEcmRq.File.ProcessingAttrs().withFileRelation(fileRelation);
    }

    private UploadFileEcmRq.File.ProcessingAttrs appendVersionChainDirective(String lastVersionGuid) {
        ProcessingAttrsUploadType.FileRelation.AppendVersionChain appendVersionChain = new ProcessingAttrsUploadType.FileRelation.AppendVersionChain()
                .withLastVersionGUID(lastVersionGuid);
        ProcessingAttrsUploadType.FileRelation fileRelation = new ProcessingAttrsUploadType.FileRelation().withAppendVersionChain(appendVersionChain);
        return new UploadFileEcmRq.File.ProcessingAttrs().withFileRelation(fileRelation);
    }

    private SignaturesTransportType getSignature(String fileName) {
        String signFilename = CommonUtils.getSignFileName(fileName);
        return new SignaturesTransportType()
                .withSignatureAtFileSystem(
                        new SignaturesTransportType.SignatureAtFileSystem()
                                .withFileName(signFilename)
                                .withIsPki(IS_PKI_VALUE)
                );
    }

    private SystemInfoUploadType getSystemInfo(String filename, byte[] fileContent, DocumentTypeEnum documentType) {
        SystemInfoUploadType.CheckSum checkSum = new SystemInfoUploadType.CheckSum()
                .withAlgorithm(CheckSumAlgorithmType.MD_5)
                .withValue(getUuidWithoutDashes(CommonUtils.calculateMD5(fileContent)));

        String fileType = null;
        try {
            fileType = CommonUtils.detectMimeType(filename, fileContent);
        } catch (Exception e) {
            log.error("Error while detecting mime-type for {}", filename, e);
        }

        return new SystemInfoUploadType()
                .withBusinessName(documentType.getNameTemplate())
                .withRetrievalName(filename)
                .withCheckSum(checkSum)
                .withContentType(fileType);
    }

    private BusinessAttrsType getBusinessAttrsWithAttrIntType(List<Map<String, Integer>> intBusinessAttrs) {

        BusinessAttrsType businessAttrsType = new BusinessAttrsType(); // пока добавлены только атрибут/параметр типа int
        intBusinessAttrs.stream()
                .flatMap(map -> map.entrySet().stream())
                .forEach(entry -> {
                    AttrIntType attrIntType = new AttrIntType();
                    attrIntType.withKey(entry.getKey());
                    attrIntType.withValue(entry.getValue());
                    businessAttrsType.withAttrStrOrAttrListOfStrOrAttrInt(attrIntType);
                });
        return businessAttrsType;
    }


    @SneakyThrows
    private XMLGregorianCalendar getXMLGregorianCalendarValue(OffsetDateTime odt) {
        GregorianCalendar gregorianCalendar = GregorianCalendar
                .from(odt.atZoneSameInstant(ZoneId.systemDefault()));
        return DatatypeFactory
                .newInstance()
                .newXMLGregorianCalendar(
                        gregorianCalendar
                );
    }


    /**
     * ТФС проверяет приходящий RqUID регуляркой => '([0-9]|[a-f]|[A-F]){32}'
     * Поэтому в данном методе убираем дефисы из UUID
     *
     * @param uuid - UUID документа
     * @return - UUID документа в формате без дефисов
     */
    private String getUuidWithoutDashes(UUID uuid) {
        return uuid.toString().replace("-", "");
    }

    private String getUuidWithoutDashes(String uuid) {
        return uuid.replace("-", "");
    }
}
