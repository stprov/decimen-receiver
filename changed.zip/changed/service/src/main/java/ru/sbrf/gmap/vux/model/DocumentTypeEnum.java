package ru.sbrf.gmap.vux.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum DocumentTypeEnum {

    XBRL_VUX_RFVP_DOCUMENT("XBRL_VUX_RFVP_Document", "Протокол_проверки_отчетной_формы"),
    XBRL_VUX_RPVP_DOCUMENT("XBRL_VUX_RPVP_Document", "Протокол_проверки_пакета_отчетных_форм"), // контейнер для форм
    XBRL_DOCUMENT("XBRLDocument", "Общий класс документов XBRL"),
    XBRL_CSV_RPVP_DOCUMENT("XbrlCsvRpvpDocument", "Протокол проверки пакета отчетных данных в формате XBRL-CSV"),
    XBRL_CSV_RP_DOCUMENT("XbrlCsvRpDocument", "Пакет отчетных данных в формате XBRL-CSV");
    private final String documentClazz;
    private final String nameTemplate;
}