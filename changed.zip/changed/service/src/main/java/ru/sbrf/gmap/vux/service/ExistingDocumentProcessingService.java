package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.config.FeatureToogleConfig;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationLogEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationResultViewEntity;
import ru.sbrf.gmap.vux.service.checks.DataContextProvider;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Стратегия обработки существующего документа — записи расписания с {@code ecmId}
 * (протокол уже загружен в ECM). Запускается после {@link NewDocumentProcessingService}.
 * <p>
 * Маршрут:
 * <ul>
 *     <li>{@code check_mode = cuv}, фича-флаг включён, для формы есть провайдер и {@code ecm_id != '-1'} — фаза 2 CUV:
 *     документ с ошибками завершается письмом (если оно не отправлено в фазе 1); иначе проверка выгрузки CSV
 *     в {@code t_vux_document_ecm}, пересоздание отклонённых записей, при готовности всех CSV — задача в СУПЗ
 *     (3 CSV + протокол) и закрытие расписания;</li>
 *     <li>иначе, в том числе при {@code ecm_id = '-1'} (D-27), — поведение original: протокол собирается из view
 *     заново, письмо при ошибках либо задача СУПЗ.</li>
 * </ul>
 * См. docs/analytics/cuv-csv-ecm-supz-flow.md, разделы 6.3, 6.5.
 */
@Service
@Order(2)
@RequiredArgsConstructor
@Slf4j
public class ExistingDocumentProcessingService implements DocumentProcessingService {

    /**
     * Значение ecm_id, которое {@code fn_process_shedule} проставляет, когда запись в ECM создавать не нужно.
     */
    private static final String ECM_ID_NOT_REQUIRED = "-1";

    private final FeatureToogleConfig featureToggleConfig;
    private final ProtocolBuildingService protocolBuildingService;
    private final ValidationDefectsService validationDefectsService;
    private final PostUploadActionsService postUploadActionsService;
    private final DocumentEcmExportService documentEcmExportService;
    private final List<DataContextProvider> dataContextProviders;

    @Override
    public boolean supports(VuxDocumentScheduleViewEntity record) {
        return Objects.nonNull(record.getEcmId());
    }

    @Override
    public ProcessingResult processDocument(VuxDocumentScheduleViewEntity record) {
        try {
            if (isCuvPhase2(record)) {
                if (ECM_ID_NOT_REQUIRED.equals(record.getEcmId())) {
                    // D-27: до решения Q-2 запись с ecm_id = '-1' обрабатывается как в original — CUV-проверка
                    // для неё не выполнялась (запись «существующая» с первого цикла), фаза 2 неприменима
                    log.warn("[ORCH] Route: scheduleId={}, docId={}, docTypeCode={}, checkMode={}, phase=legacy, " +
                                    "reason=ecm_id='-1' (ECM record is disabled by schedule flags), CUV is not applied (Q-2)",
                            record.getScheduleId(), record.getResultDocumentId(), record.getDocTypeCode(), record.getCheckMode());
                    return processLegacy(record);
                }
                log.info("[ORCH] Route: scheduleId={}, docId={}, docTypeCode={}, checkMode={}, phase=2, route=cuv",
                        record.getScheduleId(), record.getResultDocumentId(), record.getDocTypeCode(), record.getCheckMode());
                return processCuvPhase2(record);
            }
            log.info("[ORCH] Route: scheduleId={}, docId={}, docTypeCode={}, checkMode={}, phase=legacy",
                    record.getScheduleId(), record.getResultDocumentId(), record.getDocTypeCode(), record.getCheckMode());
            return processLegacy(record);
        } catch (Exception e) {
            log.error("[ORCH] Unexpected error when processing an existing document: scheduleId={}, docId={}. " +
                    "Record is skipped until the next scheduler cycle.", record.getScheduleId(), record.getResultDocumentId(), e);
            return ProcessingResult.PENDING;
        }
    }

    /**
     * Фаза 2 выполняется при тех же условиях, что и CUV-путь фазы 1:
     * {@code check_mode = cuv}, фича-флаг включён и для формы есть {@link DataContextProvider} (D-18).
     */
    private boolean isCuvPhase2(VuxDocumentScheduleViewEntity record) {
        return NewDocumentProcessingService.CHECK_MODE_CUV.equals(record.getCheckMode())
                && featureToggleConfig.isCuvValidationEnabled()
                && hasProvider(record.getDocTypeCode());
    }

    private boolean hasProvider(String docTypeCode) {
        return docTypeCode != null
                && dataContextProviders.stream().anyMatch(p -> docTypeCode.equals(p.supportedDocTypeCode()));
    }

    // ===================== Фаза 2 CUV =====================

    private ProcessingResult processCuvPhase2(VuxDocumentScheduleViewEntity record) {
        Integer docId = record.getResultDocumentId();

        // Документ с ошибками попадает сюда, если в фазе 1 протокол загружен, а письмо не отправлено или не
        // зафиксировано. В выгрузку CSV и СУПЗ он не уходит — завершается письмом об ошибках (D-28)
        List<VuxDocumentValidationResultViewEntity> defects = validationDefectsService.getResultsForDocWithRnLimit(docId);
        List<VuxDocumentValidationResultViewEntity> viewErrors = validationDefectsService.getErrorsList(defects);
        List<ValidationErrorDto> cuvErrors = validationDefectsService.getCuvErrors(docId);
        if (!viewErrors.isEmpty() || !cuvErrors.isEmpty()) {
            return completeDocumentWithErrors(record, viewErrors, validationDefectsService.getWarningsList(defects), cuvErrors);
        }

        // Проверяется после ошибок (R-5): при флаге 'U' документ с ошибками всё равно должен получить письмо.
        // supz_task_id во view = t_vux_document.supz_status: 1 — задача создана или запрещена флагом 'U' (D-22)
        if (record.getSupzTaskId() != null && !record.getSupzTaskId().isEmpty()) {
            log.info("[CUV] Phase 2: SUPZ task is already created or disabled by schedule flag 'U' (supz_status={}): " +
                    "scheduleId={}, docId={}. Schedule is resolved.", record.getSupzTaskId(), record.getScheduleId(), docId);
            return ProcessingResult.COMPLETED;
        }

        DocumentEcmExportService.ExportState state = documentEcmExportService.evaluateCuvCsvExport(docId);
        if (!state.ready()) {
            log.info("[CUV] Phase 2: waiting for CSV upload by the external service: scheduleId={}, docId={}. Schedule stays open.",
                    record.getScheduleId(), docId);
            return ProcessingResult.PENDING;
        }

        // Состав и порядок как в AS-IS: CSV (context, unit, value), затем протокол проверки
        List<String> ecmIds = new ArrayList<>(state.ecmIds());
        ecmIds.add(record.getEcmId());
        long warningsCount = record.getWarningCount() == null ? 0 : record.getWarningCount();

        boolean created = postUploadActionsService.createSupzTask(record, ecmIds, postUploadActionsService.protocolResultText(warningsCount));
        if (created) {
            log.info("[CUV] Phase 2 completed: scheduleId={}, docId={}, ecmIds={}. Schedule is resolved.",
                    record.getScheduleId(), docId, ecmIds);
        }
        return ProcessingResult.of(created);
    }

    /**
     * Завершение документа с ошибками в фазе 2 (D-28). Протокол с ошибками уже в ECM и повторно не загружается.
     * <ul>
     *     <li>письмо по документу уже есть в {@code t_vux_mail} — оно отправлено и зафиксировано в прошлом цикле
     *     (сбой был позже): расписание закрывается (D-34);</li>
     *     <li>иначе письмо собирается заново (ошибки view + CUV-ошибки из таблицы) и отправляется;
     *     при сбое отправки расписание остаётся открытым до следующего цикла (D-14).</li>
     * </ul>
     */
    private ProcessingResult completeDocumentWithErrors(VuxDocumentScheduleViewEntity record,
                                                        List<VuxDocumentValidationResultViewEntity> viewErrors,
                                                        List<VuxDocumentValidationResultViewEntity> viewWarnings,
                                                        List<ValidationErrorDto> cuvErrors) {
        Integer docId = record.getResultDocumentId();
        if (postUploadActionsService.isErrorMailSent(record)) {
            log.info("[CUV] Phase 2: document has validation errors, error mail is already sent (found in t_vux_mail): " +
                            "scheduleId={}, docId={}, viewErrors={}, cuvErrors={}. Schedule is resolved.",
                    record.getScheduleId(), docId, viewErrors.size(), cuvErrors.size());
            return ProcessingResult.COMPLETED;
        }

        log.warn("[CUV] Phase 2: document has validation errors and the error mail was not sent in phase 1: " +
                        "scheduleId={}, docId={}, viewErrors={}, cuvErrors={}. Sending the error mail; CSV export and SUPZ task are skipped.",
                record.getScheduleId(), docId, viewErrors.size(), cuvErrors.size());
        List<VuxDocumentValidationLogEntity> viewChecks = validationDefectsService.getChecksByDocId(docId);
        // Состав протокола — как в фазе 1: CUV-проверки добавляются, только если есть CUV-ошибки
        ProtocolModelDto protocol = cuvErrors.isEmpty()
                ? protocolBuildingService.createProtocolModelDto(viewErrors, viewWarnings, viewChecks, record)
                : protocolBuildingService.createCuvErrorProtocol(record, viewErrors, viewWarnings, viewChecks, cuvErrors);
        return ProcessingResult.of(postUploadActionsService.sendErrorMail(record, protocol));
    }

    // ===================== Legacy (как в original) =====================

    /**
     * Протокол собирается из view заново (в ECM не загружается — используется ранее присвоенный {@code ecmId}),
     * далее письмо при ошибках либо задача в СУПЗ.
     */
    private ProcessingResult processLegacy(VuxDocumentScheduleViewEntity record) {
        Integer docId = record.getResultDocumentId();
        List<VuxDocumentValidationResultViewEntity> defects = validationDefectsService.getResultsForDocWithRnLimit(docId);
        List<VuxDocumentValidationResultViewEntity> errorsList = validationDefectsService.getErrorsList(defects);
        List<VuxDocumentValidationResultViewEntity> warningsList = validationDefectsService.getWarningsList(defects);
        validationDefectsService.logDefects(errorsList, warningsList, docId);
        List<VuxDocumentValidationLogEntity> checkList = validationDefectsService.getChecksByDocId(docId);
        ProtocolModelDto protocolModelDto = protocolBuildingService.createProtocolModelDto(errorsList, warningsList, checkList, record);

        return ProcessingResult.of(
                postUploadActionsService.handlePostUploadActions(record, protocolModelDto, List.of(record.getEcmId())));
    }
}
