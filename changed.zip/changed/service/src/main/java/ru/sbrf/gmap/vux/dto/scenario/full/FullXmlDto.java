package ru.sbrf.gmap.vux.dto.scenario.full;

import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElements;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
@XmlRootElement(name = "root")
@XmlAccessorType(XmlAccessType.FIELD)
public class FullXmlDto {

    @XmlElements({
            @XmlElement(
                    name = "explicitMember",
                    namespace = "https://www.xbrl.org/2006/xbrldi-2006.xsd",
                    type = ExplicitMemberDto.class
            ),
            @XmlElement(
                    name = "typedMember",
                    namespace = "https://www.xbrl.org/2006/xbrldi-2006.xsd",
                    type = TypedMemberDto.class
            )
    })
    private List<Object> members;
}