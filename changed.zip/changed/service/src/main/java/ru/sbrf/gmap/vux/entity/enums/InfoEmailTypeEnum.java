package ru.sbrf.gmap.vux.entity.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Тип информационного email-письма (колонка {@code info_email_type} витрины
 * {@code v_vux_info_email_shedule}). Числовые коды зафиксированы постановкой VUXPCAP-1448.
 */
@RequiredArgsConstructor
@Getter
public enum InfoEmailTypeEnum {

    /**
     * Письмо о проверке готовности отчётных форм перед сдачей отчётности.
     */
    VERIFICATION(0),

    /**
     * Письмо о начале подготовки отчётности.
     */
    PREPARATION(1);

    private final int code;
}
