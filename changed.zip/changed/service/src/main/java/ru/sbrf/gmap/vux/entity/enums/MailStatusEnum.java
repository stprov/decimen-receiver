package ru.sbrf.gmap.vux.entity.enums;

public enum MailStatusEnum {
    DISPATCHED, NOT_SENT
}
