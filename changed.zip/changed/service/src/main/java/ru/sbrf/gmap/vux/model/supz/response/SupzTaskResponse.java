package ru.sbrf.gmap.vux.model.supz.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.ZonedDateTime;

@JsonIgnoreProperties(ignoreUnknown = true)
public record SupzTaskResponse(

        @JsonProperty("response/data")
        SupzTaskResponseData data,

        @JsonProperty("response/time")
        ZonedDateTime responseTime,

        @JsonProperty("request/time")
        ZonedDateTime requestTime,

        @JsonProperty("response/result")
        String result,

        @JsonProperty("request/type")
        String type,

        @JsonProperty("response/srcId")
        String srcId,

        @JsonProperty("response/destId")
        String destId
) {
}