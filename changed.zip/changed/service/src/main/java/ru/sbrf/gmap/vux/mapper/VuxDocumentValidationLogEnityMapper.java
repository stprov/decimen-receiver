package ru.sbrf.gmap.vux.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValueCheckStrategy;
import ru.sbrf.gmap.vux.dto.templates.ProtocolCheckRecordDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationLogEntity;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;

import java.util.List;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
public interface VuxDocumentValidationLogEnityMapper {

    @Mapping(source = "errorMessage", target = "checkType")
    @Mapping(source = "errorCount", target = "countingDeviation")
    @Mapping(target = "checkResult", expression = "java(getCheckResultStatus(entity))")
    @Mapping(target = "ruleType", expression = "java(mapRuleType(entity.getRuleType()))")
    ProtocolCheckRecordDto toProtocolCheckRecordDto(VuxDocumentValidationLogEntity entity);

    List<ProtocolCheckRecordDto> toProtocolCheckRecordDtoList(List<VuxDocumentValidationLogEntity> entities);

    default String getCheckResultStatus(VuxDocumentValidationLogEntity entity) {
        return entity.getErrorCount() == null || entity.getErrorCount() == 0 ? "Не выявлено" : "Выявлено";
    }

    default RuleTypeEnum mapRuleType(String ruleType) {
        if (ruleType == null) return null;
        try {
            return RuleTypeEnum.valueOf(ruleType);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
