package ru.sbrf.gmap.vux.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import ru.sbrf.gmap.vux.entity.base.VuxFormContextBaseEntity;

@Entity
@Table(name = "t_vux_form_0420415_3_context")
public class VuxForm0420415V3ContextEntity extends VuxFormContextBaseEntity {
}
