package ru.sbrf.gmap.vux.model.supz.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Builder;
import ru.sbrf.gmap.vux.dto.request.supz.SupzTaskAttachedUrlDto;
import tools.jackson.databind.JsonNode;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

@Builder
public record SupzTaskDataRequest(

        @JsonProperty("task/srcTypeId")
        List<String> srcTypeId,

        @NotBlank
        @Size(max = 50)
        @JsonProperty("task/srcId")
        UUID taskSrcId,

        @NotBlank
        @Size(max = 50)
        @JsonProperty("task/srcStatus")
        String srcStatus,

        @JsonProperty("task/srcRegisterTime")
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ")
        ZonedDateTime srcRegisterTime,

        @Pattern(regexp = "low|high|minimal|medium|highest|critical")
        @JsonProperty("task/srcPriority")
        String srcPriority,

        @JsonProperty("task/attachUrls")
        @JsonInclude(JsonInclude.Include.NON_EMPTY)
        List<SupzTaskAttachedUrlDto> attachUrls,

        @JsonProperty("task/attributes")
        JsonNode attributes
) {
}