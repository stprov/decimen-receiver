package ru.sbrf.gmap.vux.entity.enums;

public enum MailType {
    SUCCESS, INTERNAL, ERROR
}
