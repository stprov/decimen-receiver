package ru.sbrf.gmap.vux.mapper;

import org.mapstruct.Mapper;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V13ValueEntity;

@Mapper(componentModel = "spring")
public interface VuxForm0420415V13ValueMapper {

    VuxForm0420415V13ValueDto entityToDto(VuxForm0420415V13ValueEntity entity);

    VuxForm0420415V13ValueEntity dtoToEntity(VuxForm0420415V13ValueDto dto);
}
