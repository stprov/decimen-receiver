package ru.sbrf.gmap.vux.mapper;

import org.mapstruct.Mapper;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13UnitDto;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V13UnitEntity;

@Mapper(componentModel = "spring")
public interface VuxForm0420415V13UnitMapper {

    VuxForm0420415V13UnitDto entityToDto(VuxForm0420415V13UnitEntity entity);

    VuxForm0420415V13UnitEntity dtoToEntity(VuxForm0420415V13UnitDto dto);
}
