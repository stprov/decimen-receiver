package ru.sbrf.gmap.vux.dto.request.ecm;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestAttr {

    private AttrStr attrStr;
    private AttrInt attrInt;
    private AttrDateTime attrDateTime;
}
