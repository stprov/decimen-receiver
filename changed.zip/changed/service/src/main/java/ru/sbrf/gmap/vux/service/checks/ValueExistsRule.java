package ru.sbrf.gmap.vux.service.checks;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;

import java.util.Optional;

import static ru.sbrf.gmap.vux.service.utils.ValidateDataCommonUtil.resolveWorkflowRunId;

@Component
@Order(4)
public class ValueExistsRule implements ValidationRule {

    private static final String CHECK_DESCRIPTION = "По workflow_run_id получен набор значений value";
    private static final String ERROR_CODE = "DCUV_0420415_1_3_004";

    @Override
    public Optional<ValidationErrorDto> validate(DataContext ctx) {

        if (ctx.valueList().isEmpty()) {
            Long workflowRunId = resolveWorkflowRunId(ctx);
            return Optional.of(new ValidationErrorDto(
                    DEFAULT_TITLE,
                    ERROR_CODE,
                    "По workflow_run_id = %d НЕ получен набор значений value.".formatted(workflowRunId)
            ));
        }
        return Optional.empty();
    }

    @Override
    public String getDescription() {
        return CHECK_DESCRIPTION;
    }

    @Override
    public String getCode() {
        return ERROR_CODE;
    }
}