package ru.sbrf.gmap.vux.service;

import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.dto.templates.ProtocolCheckRecordDto;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;
import ru.sbrf.gmap.vux.service.checks.DataContext;
import ru.sbrf.gmap.vux.service.checks.ValidationRule;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Сервис бизнес-валидации данных форм XBRL.
 * <p>
 * Координирует применение всех зарегистрированных правил валидации к переданному контексту.
 * Правила выполняются по шагам постановки ({@link ValidationRule#getStage()}, аналитика 7.7):
 * внутри шага выполняются все правила, но если на шаге найдены ошибки, следующие шаги не выполняются.
 */
@Service
public class ValidationDataService {

    private static final String NOT_CHECKED = "Не проверялось";

    private final List<ValidationRule> rules;

    public ValidationDataService(List<ValidationRule> rules) {
        this.rules = rules;
    }

    /**
     * Выполняет последовательную валидацию контекста по всем зарегистрированным правилам.
     *
     * @param context контекст проверки (данные формы)
     * @return список ошибок валидации. Пустой список, если все проверки пройдены.
     * Никогда не возвращает {@code null}.
     */
    public List<ValidationErrorDto> validate(DataContext context) {
        List<ValidationErrorDto> errors = new ArrayList<>();
        Integer currentStage = null;
        boolean stageHasErrors = false;
        // Правила приходят в порядке @Order; шаги идут по возрастанию
        for (ValidationRule rule : rules) {
            if (!rule.isEnabled()) {
                continue;
            }
            int stage = rule.getStage();
            if (currentStage == null || stage != currentStage) {
                if (stageHasErrors) {
                    break;
                }
                currentStage = stage;
            }
            Optional<ValidationErrorDto> error = rule.validate(context);
            if (error.isPresent()) {
                errors.add(error.get());
                stageHasErrors = true;
            }
        }
        return errors;
    }

    /**
     * Количество выполненных проверок: шаги после шага с ошибками не выполняются.
     */
    public int countExecutedChecks(List<ValidationErrorDto> errors) {
        return (int) getChecks(errors).stream()
                .filter(check -> !NOT_CHECKED.equals(check.getCheckResult()))
                .count();
    }

    /**
     * Строки проверок для протокола. Проверки шагов после шага с ошибками не выполнялись —
     * для них результат «Не проверялось».
     */
    public List<ProtocolCheckRecordDto> getChecks(List<ValidationErrorDto> errors) {
        int firstStageWithErrors = rules.stream()
                .filter(rule -> errors.stream().anyMatch(e -> e.errorCode() != null && e.errorCode().equals(rule.getCode())))
                .mapToInt(ValidationRule::getStage)
                .min()
                .orElse(Integer.MAX_VALUE);
        return rules.stream()
                .map(rule -> {
                    long errorCount = errors.stream()
                            .filter(e -> e.errorCode() != null && e.errorCode().equals(rule.getCode()))
                            .count();
                    String result;
                    if (!rule.isEnabled() || rule.getStage() > firstStageWithErrors) {
                        result = NOT_CHECKED;
                    } else {
                        result = errorCount == 0 ? "Не выявлено" : "Выявлено";
                    }
                    return ProtocolCheckRecordDto.builder()
                            .checkType(rule.getDescription())
                            .checkResult(result)
                            .countingDeviation(String.valueOf(errorCount))
                            // CUV-проверки — проверки на ошибки: входят в «Показано N из M» протокола (DEF-20)
                            .ruleType(RuleTypeEnum.E)
                            .build();
                })
                .toList();
    }
}