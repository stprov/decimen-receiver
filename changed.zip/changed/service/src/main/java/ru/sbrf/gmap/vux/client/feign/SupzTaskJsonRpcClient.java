package ru.sbrf.gmap.vux.client.feign;

import feign.FeignException;
import feign.Response;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.resilience.annotation.Retryable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.sbrf.gmap.vux.exception.supz.JsonRpcExceptionDecoder;
import ru.sbrf.gmap.vux.exception.supz.JsonRpcResponseException;
import ru.sbrf.gmap.vux.model.jsonrpc.JsonRpcRequest;
import ru.sbrf.gmap.vux.model.supz.request.SupzRequest;
import ru.sbrf.gmap.vux.model.supz.request.SupzStatusDataRequest;
import ru.sbrf.gmap.vux.model.supz.request.SupzTaskDataRequest;

import java.util.UUID;

@FeignClient(name = "supzJsonRpcFeignClient", url = "${integration.supz.supzClientConfig.url}"
        , configuration = {JsonRpcExceptionDecoder.class}
)
public interface SupzTaskJsonRpcClient {

    @PostMapping(value = "/tfcs-create-task/api/v1/invoke")
    @Retryable(
            value = {FeignException.FeignServerException.class, JsonRpcResponseException.class},
            maxRetriesString = "${integration.supz.supzClientConfig.maxAttempts}",
            delayString = "${integration.supz.supzClientConfig.delay}"
    )
    Response createTask(JsonRpcRequest<SupzRequest<SupzTaskDataRequest>> supzTaskRequest, @RequestHeader("RqUID") UUID requestId);

    @PostMapping(value = "/tfcs-create-task/api/v1/status")
    @Retryable(
            value = {FeignException.FeignServerException.class, JsonRpcResponseException.class},
            maxRetriesString = "${integration.supz.supzClientConfig.maxAttempts}",
            delayString = "${integration.supz.supzClientConfig.delay}"
    )
    Response checkStatus(JsonRpcRequest<SupzRequest<SupzStatusDataRequest>> supzTaskRequest, @RequestHeader("RqUID") UUID requestId);
}