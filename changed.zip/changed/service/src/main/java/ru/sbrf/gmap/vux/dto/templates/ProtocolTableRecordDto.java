package ru.sbrf.gmap.vux.dto.templates;

import lombok.Builder;
import lombok.Getter;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;

@Getter
@Builder
public class ProtocolTableRecordDto {
    String objectName;
    String isinNumber;
    String objectNumber;
    String errorCode;
    String errorMessage;
    RuleTypeEnum ruleType;
}
