package ru.sbrf.gmap.vux.dto.scenario.full;

import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlValue;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
@XmlRootElement(
        name = "explicitMember",
        namespace = "https://www.xbrl.org/2006/xbrldi-2006.xsd"
)
@XmlAccessorType(XmlAccessType.FIELD)
public class ExplicitMemberDto {

    /** Атрибут dimension (например dim-int:Tip_czenBum_naPravSobstvAxis) */
    @XmlAttribute
    private String dimension;

    /** Текстовое содержимое элемента (например mem-int:KolCZenBumagPrinadOrgMember) */
    @XmlValue
    private String value;
}