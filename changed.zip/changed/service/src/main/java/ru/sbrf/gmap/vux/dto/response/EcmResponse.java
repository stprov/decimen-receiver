package ru.sbrf.gmap.vux.dto.response;

public interface EcmResponse {

    ResponseResult getResponseResult();
}
