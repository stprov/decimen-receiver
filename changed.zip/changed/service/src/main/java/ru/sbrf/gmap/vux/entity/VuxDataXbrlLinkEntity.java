package ru.sbrf.gmap.vux.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "t_adm_data_xbrl_link")
public class VuxDataXbrlLinkEntity {

    @EmbeddedId
    private DataXbrlLinkId id;

    @Column(name = "doc_type_id", nullable = false)
    private Integer docTypeId;

    @Column(name = "column_xbrl_type", nullable = false, length = 20)
    private String columnXbrlType;

    @Column(name = "enum_id", length = 500)
    private String enumId;

    @Column(name = "axis_id", length = 500)
    private String axisId;

    @Column(name = "taxis_id", length = 500)
    private String taxisId;

    @Column(name = "parameter_id", length = 500)
    private String parameterId;

    @Column(name = "measure_id", length = 500)
    private String measureId;

    @Column(name = "line_key")
    private Short lineKey;

    @Column(name = "analytical_section", columnDefinition = "text")
    private String analyticalSection;

    @Column(name = "context_code", columnDefinition = "text")
    private String contextCode;

    @Column(name = "unit_code", columnDefinition = "text")
    private String unitCode;

    @Column(name = "decimals", columnDefinition = "text")
    private String decimals;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Embeddable
    public static class DataXbrlLinkId {

        private String taxonomy;

        private String tableName;

        private String columnName;
    }
}