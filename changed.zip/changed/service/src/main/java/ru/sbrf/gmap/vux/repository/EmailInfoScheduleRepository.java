package ru.sbrf.gmap.vux.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.sbrf.gmap.vux.entity.EmailInfoScheduleEntity;
import ru.sbrf.gmap.vux.entity.enums.InfoEmailTypeEnum;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface EmailInfoScheduleRepository extends JpaRepository<EmailInfoScheduleEntity, Long> {

    /**
     * Выбрать неотправленные записи заданного типа из витрины v_vux_info_email_shedule,
     * запланированные к отправке не ранее {@code sendTimeFrom} (защита от обработки
     * зависших записей прошлых периодов).
     * Витрина сама возвращает только необработанные ({@code mail_time IS NULL}) и
     * созревшие ({@code now() >= send_time}) записи — эти условия не дублируются.
     */
    List<EmailInfoScheduleEntity> findByInfoEmailTypeAndSendTimeGreaterThanEqualOrderByIdAsc(
            InfoEmailTypeEnum infoEmailType, LocalDateTime sendTimeFrom);
}
