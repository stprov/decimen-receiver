package ru.sbrf.gmap.vux.client.feign;

import feign.Response;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;
import ru.sbrf.gmap.vux.dto.request.ecm.CreateContentsRequest;

import java.util.Map;

@FeignClient(value = "ecmClient", url = "${integration.ecm.url}", path = "/services")
public interface EcmFeignClient {

    @PostMapping(value = "/create-contents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    Response createContents(
            @RequestHeader Map<String, Object> headers,
            @RequestPart(name = "request") CreateContentsRequest requestBody,
            @RequestPart(name = "files") MultipartFile[] files);
}
