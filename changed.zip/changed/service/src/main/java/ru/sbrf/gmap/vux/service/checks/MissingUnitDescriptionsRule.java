package ru.sbrf.gmap.vux.service.checks;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13UnitDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;

import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

@Component
@Order(8)
public class MissingUnitDescriptionsRule implements ValidationRule {

    private static final String CHECK_DESCRIPTION = "В values не обнаружены unit_id без описания";
    private static final String ERROR_CODE = "DCUV_0420415_1_3_008";

    @Override
    public Optional<ValidationErrorDto> validate(DataContext ctx) {

        if (ctx.unitList().isEmpty() || ctx.valueList().isEmpty()) {
            return Optional.empty();
        }

        // unit_id может быть пустым (у нечисловых значений нет единицы измерения) — такие значения не проверяются
        Set<String> unitIds = ctx.unitList().stream()
                .map(VuxForm0420415V13UnitDto::unitId)
                .filter(v -> v != null && !v.isBlank())
                .collect(Collectors.toSet());

        Set<String> missing = ctx.valueList().stream()
                .map(VuxForm0420415V13ValueDto::unitId)
                .filter(v -> v != null && !v.isBlank())
                .collect(Collectors.toCollection(TreeSet::new));

        missing.removeAll(unitIds);

        if (!missing.isEmpty()) {
            return Optional.of(new ValidationErrorDto(
                    DEFAULT_TITLE,
                    ERROR_CODE,
                    "Обнаружены unit_id без описания: %s.".formatted(missing)
            ));
        }
        return Optional.empty();
    }

    @Override
    public String getDescription() {
        return CHECK_DESCRIPTION;
    }

    @Override
    public String getCode() {
        return ERROR_CODE;
    }
}