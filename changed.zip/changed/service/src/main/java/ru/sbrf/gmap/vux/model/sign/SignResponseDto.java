package ru.sbrf.gmap.vux.model.sign;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;

@JsonIgnoreProperties(ignoreUnknown = true)
public record SignResponseDto(
        @JsonPropertyDescription("Идентификатор хэша")
        String id,
        @JsonPropertyDescription("Хэш, по которому сформирована ЭП для документа (формат HEX)")
        String signedHash,
        @JsonPropertyDescription("Отсоединенная подпись в формате base64")
        String cmsSign,
        @JsonPropertyDescription("Код ошибки (возвращается, если подпись не была сформирована)")
        Integer errorCode,
        @JsonPropertyDescription("Описание результата")
        String errorDescription,
        @JsonPropertyDescription("Код источника ошибки")
        ErrorSource errorSource
) {
    /**
     * OCSP - в случае проверки статуса сертификата через OCSP
     * LOCAL_STORE - в случае проверки статуса сертификата через локальные хранилища сертификатов
     */
    public enum ErrorSource {
        OCSP,
        LOCAL_STORE
    }
}


