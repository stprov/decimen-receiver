package ru.sbrf.gmap.vux.dto;

import lombok.Builder;

/**
 * Рекорд-контейнер результата одной проверки данных.
 *
 * @param errorCode    код ошибки (например, "MANDATORY_FIELD_EMPTY")
 * @param errorMessage человекочитаемое описание ошибки
 */
@Builder
public record ValidationErrorDto(
        String errorTitle,
        String errorCode,
        String errorMessage
) {
}