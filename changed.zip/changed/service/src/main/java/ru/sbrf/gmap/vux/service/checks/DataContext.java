package ru.sbrf.gmap.vux.service.checks;

import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ContextDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13UnitDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;
import ru.sbrf.gmap.vux.entity.AdmXbrlEnumValuesEntity;
import ru.sbrf.gmap.vux.entity.VuxDataXbrlLinkEntity;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V13DataEntity;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Единица входной информации для проверки валидации.
 * <p>
 * Содержит списки контекстных атрибутов, unit-записей, значений элементов,
 * а также данные из БД (data-записи, XBRL-линки, enum-значения) для проверки №10.
 *
 * @param docId         идентификатор проверяемого документа (resultDocumentId)
 * @param contextList   список контекстных атрибутов формы
 * @param unitList      список unit-записей
 * @param valueList     список значений элементов
 * @param dataList      список записей t_vux_form_0420415_1_3_data для docId
 * @param xbrlLinks     список маппингов колонок из t_adm_data_xbrl_link
 * @param enumValuesMap карта enum-текстов (ключ: taxonomy_id|enumId|enumValueCode)
 * @param dataTaxonomies версии таксономии из таблицы data ({@code xbrlvers}) — для проверки 9
 * @param workflowRunId  {@code workflow_run_id} документа из view расписания (Q-8 п. 4.1); {@code null} — не заполнен
 *                       (проверка 1, ошибка {@code _001}). Если не задан, правила берут его из данных формы
 *                       ({@link ru.sbrf.gmap.vux.service.utils.ValidateDataCommonUtil#resolveWorkflowRunId})
 */
public record DataContext(
        long docId,
        List<VuxForm0420415V13ContextDto> contextList,
        List<VuxForm0420415V13UnitDto> unitList,
        List<VuxForm0420415V13ValueDto> valueList,
        List<VuxForm0420415V13DataEntity> dataList,
        List<VuxDataXbrlLinkEntity> xbrlLinks,
        Map<String, AdmXbrlEnumValuesEntity> enumValuesMap,
        Set<String> dataTaxonomies,
        Long workflowRunId
) {
    /**
     * Контекст без явного {@code workflow_run_id} (для тестов): берётся из данных формы.
     */
    public DataContext(long docId,
                       List<VuxForm0420415V13ContextDto> contextList,
                       List<VuxForm0420415V13UnitDto> unitList,
                       List<VuxForm0420415V13ValueDto> valueList,
                       List<VuxForm0420415V13DataEntity> dataList,
                       List<VuxDataXbrlLinkEntity> xbrlLinks,
                       Map<String, AdmXbrlEnumValuesEntity> enumValuesMap,
                       Set<String> dataTaxonomies) {
        this(docId, contextList, unitList, valueList, dataList, xbrlLinks, enumValuesMap, dataTaxonomies, null);
    }

    /**
     * Пустой контекст для документа без данных формы (Q-8 п. 2.1): правила 1–4 выдадут ошибки {@code _001}…{@code _004}.
     *
     * @param workflowRunId {@code workflow_run_id} из view расписания, может быть {@code null}
     */
    public static DataContext empty(long docId, Long workflowRunId) {
        return new DataContext(docId, List.of(), List.of(), List.of(), List.of(), List.of(), Map.of(), Set.of(), workflowRunId);
    }

    /**
     * Контекст без версий таксономии data (для тестов и форм без таблицы data).
     */
    public DataContext(long docId,
                       List<VuxForm0420415V13ContextDto> contextList,
                       List<VuxForm0420415V13UnitDto> unitList,
                       List<VuxForm0420415V13ValueDto> valueList,
                       List<VuxForm0420415V13DataEntity> dataList,
                       List<VuxDataXbrlLinkEntity> xbrlLinks,
                       Map<String, AdmXbrlEnumValuesEntity> enumValuesMap) {
        this(docId, contextList, unitList, valueList, dataList, xbrlLinks, enumValuesMap, Set.of(), null);
    }
}