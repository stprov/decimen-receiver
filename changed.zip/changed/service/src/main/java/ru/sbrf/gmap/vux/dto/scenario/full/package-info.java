@XmlSchema(
        xmlns = {
                @XmlNs(prefix = "xbrldi", namespaceURI = "https://www.xbrl.org/2006/xbrldi-2006.xsd"),
                @XmlNs(prefix = "dim-int", namespaceURI = "https://www.xbrl.org/2006/xbrldi-2006.xsd"),
                @XmlNs(prefix = "mem-int", namespaceURI = "https://www.xbrl.org/2006/xbrldi-2006.xsd")
        },
        elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED
)
package ru.sbrf.gmap.vux.dto.scenario.full;

import jakarta.xml.bind.annotation.XmlNs;
import jakarta.xml.bind.annotation.XmlSchema;