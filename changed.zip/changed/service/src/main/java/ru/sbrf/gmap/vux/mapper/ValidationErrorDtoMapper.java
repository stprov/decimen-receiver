package ru.sbrf.gmap.vux.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.ReportingPolicy;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolTableRecordDto;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;

import java.util.List;

@Mapper(componentModel = "spring",
        imports = RuleTypeEnum.class,
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
public interface ValidationErrorDtoMapper {

    @Mapping(source = "errorTitle", target = "objectName")
    @Mapping(target = "ruleType", expression = "java(RuleTypeEnum.E)")
    ProtocolTableRecordDto toProtocolTableRecordDto(ValidationErrorDto dto);

    List<ProtocolTableRecordDto> toProtocolTableRecordDtoList(List<ValidationErrorDto> dtos);
}
