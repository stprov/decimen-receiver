package ru.sbrf.gmap.vux.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;
import java.sql.Timestamp;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "t_vux_document")
public class VuxDocumentEntity {

    @Id
    @Column(name = "doc_id")
    private Long docId;

    @Column(name = "doc_type_id")
    private Integer docTypeId;

    @Column(name = "doc_number")
    private String docNumber;

    @Column(name = "doc_date")
    private Date docDate;

    @Column(name = "parent_doc_id")
    private Long parentDocId;

    @Column(name = "parent_doc_type_id")
    private Integer parentDocTypeId;

    @Column(name = "doc_create_type")
    private String docCreateType; // todo заменить на enum

    @Column(name = "doc_period")
    private String docPeriod;

    @Column(name = "doc_year")
    private Integer docYear;

    @Column(name = "status")
    private Integer status; // todo replace with Enum

    @Column(name = "ecm_id")
    private String ecmId;

    @Column(name = "ecm_status")
    private String ecmStatus;

    @Column(name = "created", insertable = false, updatable = false)
    private Timestamp created;

    @Column(name = "updated")
    private Timestamp updated;

    @Column(name = "creator", insertable = false, updatable = false)
    private String creator;

    @Column(name = "updater")
    private String updater;

    @Column(name = "workflow_run_id")
    private Long workflowRunId;

    @Column(name = "mail_status")
    private Integer mailStatus; // todo replace by ENUM потом

    @Column(name = "supz_status")
    private Integer supzStatus;

    @Column(name = "mail_type")
    private String mailType;

    @Column(name = "receivers_list")
    private String receiversList;

    @Column(name = "copy_list")
    private String copyList;
}