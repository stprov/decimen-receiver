package ru.sbrf.gmap.vux.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Файл с настройками интеграции с ОKЕй (Омниканальная криптографическая экосистема)
 * Сервис ЭП для УД
 */
@ConditionalOnProperty(prefix = "integration.sign", name = "enabled", havingValue = "true")
@ConfigurationProperties(prefix = "integration.sign")
public record IntegrationSignProps(
        Boolean enabled,
        OkSignatureServiceProps okSignService, // для создания ЭП
        OkSignatureServiceProps okCheckSignService // для проверки ЭП
) {
    public record OkSignatureServiceProps(
            String xSystem,
            String xChannel,
            String url
    ) {
    }
}
