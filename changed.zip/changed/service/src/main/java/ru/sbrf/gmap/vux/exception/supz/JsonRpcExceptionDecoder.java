package ru.sbrf.gmap.vux.exception.supz;

import feign.FeignException;
import feign.Response;
import feign.codec.ErrorDecoder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ru.sbrf.gmap.vux.model.jsonrpc.JsonRpcResponse;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

@Slf4j
@RequiredArgsConstructor
public class JsonRpcExceptionDecoder implements ErrorDecoder {

    private static final String JSON_RPC_FIELD_NAME = "jsonrpc";

    private final Default defaultDecoder = new Default();
    private final ObjectMapper objectMapper;

    @Override
    public Exception decode(String methodKey, Response response) {
        Exception exception = defaultDecoder.decode(methodKey, response);
        if (exception instanceof FeignException feignException) {
            JsonRpcResponse jsonRpcResponse = decodeException(feignException);
            if (jsonRpcResponse != null) {
                return new JsonRpcResponseException(jsonRpcResponse.error());
            }
        }
        return new JsonRpcResponseException(response.status(), response.reason());
    }

    private JsonRpcResponse decodeException(FeignException feignException) {
        if (feignException.responseBody().isPresent() && feignException.responseBody().get().hasRemaining()) {
            try {
                JsonNode body = objectMapper.readValue(feignException.responseBody().get().array(), JsonNode.class);

                if (body.has(JSON_RPC_FIELD_NAME)) {
                    return objectMapper.readValue(feignException.responseBody().get().array(), JsonRpcResponse.class);
                }
            } catch (JacksonException e) {
                log.error(e.getMessage(), e);
            }
        }
        return null;
    }
}