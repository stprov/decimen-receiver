package ru.sbrf.gmap.vux.facade.supz;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SupzTaskAttribute {

    @JsonProperty("class")
    private String className;

    private String name;
    private Integer num;
    private String value;
}