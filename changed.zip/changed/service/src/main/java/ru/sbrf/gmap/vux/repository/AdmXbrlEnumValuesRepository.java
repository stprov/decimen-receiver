package ru.sbrf.gmap.vux.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.sbrf.gmap.vux.entity.AdmXbrlEnumValuesEntity;

public interface AdmXbrlEnumValuesRepository extends JpaRepository<AdmXbrlEnumValuesEntity, AdmXbrlEnumValuesEntity.AdmXbrlEnumValuesEntityId> {
}
