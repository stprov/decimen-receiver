package ru.sbrf.gmap.vux.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V13UnitEntity;

import java.util.List;
import java.util.UUID;

public interface VuxForm0420415V13UnitRepository extends JpaRepository<VuxForm0420415V13UnitEntity, UUID> {

    List<VuxForm0420415V13UnitEntity> findByWorkflowRunId(Long workflowRunId);
}
