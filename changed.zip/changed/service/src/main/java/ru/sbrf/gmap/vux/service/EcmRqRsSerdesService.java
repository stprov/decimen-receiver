package ru.sbrf.gmap.vux.service;

import jakarta.annotation.PostConstruct;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import ru.sber.tfs.domain.UploadFileEcmRq;
import ru.sber.tfs.domain.UploadFileEcmRs;
import ru.sbrf.gmap.vux.exception.ecm.EcmException;
import ru.sbrf.gmap.vux.exception.ecm.ErrorCode;

import java.io.StringReader;
import java.io.StringWriter;

@RequiredArgsConstructor
@Service
@Slf4j
@ConditionalOnProperty(prefix = "integration.ecm.tfs-upload", name = "enabled", havingValue = "true")
public class EcmRqRsSerdesService {

    private ThreadLocal<Unmarshaller> rsUnmarshaller;
    private ThreadLocal<Marshaller> rqMarshaller;

    @PostConstruct
    public void init() {
        try {
            JAXBContext rsContext = JAXBContext.newInstance(UploadFileEcmRs.class);
            rsUnmarshaller = ThreadLocal.withInitial(() -> {
                try {
                    return rsContext.createUnmarshaller();
                } catch (JAXBException je) {
                    log.error("Failed to create Unmarshaller for UploadFileEcmRs", je);
                    throw new EcmException(ErrorCode.GENERAL_ERROR, je.getMessage());
                }
            });
            log.debug("JAXBContext and Unmarshaller initialized successfully for UploadFileEcmRs");
        } catch (JAXBException je) {
            log.error("Failed to initialize JAXBContext or Unmarshaller for UploadFileEcmRs", je);
            throw new EcmException(ErrorCode.GENERAL_ERROR, je.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error during JAXB initialization for UploadFileEcmRs", e);
            throw new EcmException(ErrorCode.GENERAL_ERROR, e.getMessage());
        }

        try {
            JAXBContext rqContext = JAXBContext.newInstance(UploadFileEcmRq.class);
            rqMarshaller = ThreadLocal.withInitial(() -> {
                try {
                    return rqContext.createMarshaller();
                } catch (JAXBException je) {
                    log.error("Failed to create Marshaller for UploadFileEcmRq", je);
                    throw new EcmException(ErrorCode.GENERAL_ERROR, je.getMessage());
                }
            });
            log.debug("JAXBContext and Marshaller initialized successfully for UploadFileEcmRq");
        } catch (JAXBException je) {
            log.error("Failed to initialize JAXBContext or Marshaller for UploadFileEcmRq", je);
            throw new EcmException(ErrorCode.GENERAL_ERROR, je.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error during JAXB initialization for UploadFileEcmRq", e);
            throw new EcmException(ErrorCode.GENERAL_ERROR, e.getMessage());
        }
    }

    private void resolveJaxbContext() {

    }

    public UploadFileEcmRs readEcmResponse(String xmlfile) {
        try (StringReader sr = new StringReader(xmlfile)) {
            Object result = rsUnmarshaller.get().unmarshal(sr);
            if (!(result instanceof UploadFileEcmRs)) {
                log.error("Unmarshalled object is not an instance of UploadFileEcmRs. Got: {}", result != null ? result.getClass() : "null");
                throw new EcmException(ErrorCode.ECM_RESPONSE_ERROR, "Invalid response structure: expected UploadFileEcmRs");
            }
            return (UploadFileEcmRs) result;
        } catch (JAXBException je) {
            log.error("Error occured while unmarshalling xml file", je);
            throw new EcmException(ErrorCode.ECM_RESPONSE_ERROR, je.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error while unmarshalling xml file", e);
            throw new EcmException(ErrorCode.ECM_RESPONSE_GENERAL_ERROR, e.getMessage());
        }
    }

    public String writeXml(UploadFileEcmRq xml) {
        try {
            try (StringWriter sw = new StringWriter()) {
                rqMarshaller.get().marshal(xml, sw);
                return sw.toString();
            }
        } catch (Exception e) {
            throw new EcmException(ErrorCode.ECM_WRITE_XML_ERROR, e.getMessage());
        }
    }
}
