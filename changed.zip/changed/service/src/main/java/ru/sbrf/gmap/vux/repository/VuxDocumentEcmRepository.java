package ru.sbrf.gmap.vux.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.sbrf.gmap.vux.entity.VuxDocumentEcmEntity;

import java.util.Collection;
import java.util.List;

@Repository
public interface VuxDocumentEcmRepository extends JpaRepository<VuxDocumentEcmEntity, String> {

    /**
     * Все записи выгрузки документа по заданным типам образов (включая отклонённые {@code disabled = 1}).
     */
    List<VuxDocumentEcmEntity> findByDocIdAndImageTypeIn(Long docId, Collection<String> imageTypes);
}
