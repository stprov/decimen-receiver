package ru.sbrf.gmap.vux.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import ru.sbrf.gmap.vux.entity.base.VuxFormValueBaseEntity;

@Entity
@Table(name = "t_vux_form_0420415_1_3_value")
public class VuxForm0420415V13ValueEntity extends VuxFormValueBaseEntity {

}
