package ru.sbrf.gmap.vux.model.jsonrpc;


import ru.sbrf.gmap.vux.model.supz.response.SupzTaskResponseError;

public record JsonRpcErrorResponse(

        /* JSON-RPC code of the error */
        String code,

        /* Message of the error */
        String message,

        /* Additional data of the error */
        SupzTaskResponseError data
) {
}
