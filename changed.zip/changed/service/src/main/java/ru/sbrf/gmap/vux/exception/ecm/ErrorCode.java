package ru.sbrf.gmap.vux.exception.ecm;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum ErrorCode {

    GENERAL_ERROR("GENERAL_ERROR", "General service error, id: %s"),
    ECM_EMPTY_RESPONSE_ERROR("ECM_EMPTY_RESPONSE_ERROR", "Invalid response format. At least one item in the list is expected."),
    ECM_S3_UPLOAD_ERROR("ECM_S3_UPLOAD_ERROR", "Error uploading file '%s' to S3 bucket '%s'. Error: '%s'"),
    ECM_S3_GENERAL_ERROR("ECM_S3_COMMON_ERROR", "General error while working with S3 API. File being uploaded: '%s' to bucket '%s'. Error: '%s'"),
    ECM_S3_UNEXPECTED_ERROR("ECM_S3_UNEXPECTED_ERROR", "Unexpected error while working with S3 API. File being uploaded: '%s' to bucket '%s'. Error: '%s'"),
    ECM_S3_DOWNLOAD_ERROR("ECM_S3_DOWNLOAD_ERROR", "Error downloading file '%s' from S3 bucket '%s'. Error: '%s'"),
    ECM_RESPONSE_ERROR("ECM_RESPONSE_ERROR", "Error while parsing response from ECM. Error: '%s'"),
    ECM_RESPONSE_GENERAL_ERROR("ECM_RESPONSE_GENERAL_ERROR", "General error while parsing response from ECM. Error: '%s'"),
    ECM_WRITE_XML_ERROR("ECM_WRITE_XML_ERROR", "Error while writing XML file. Error: '%s'"),
    ECM_READ_XML_ERROR("ECM_READ_XML_ERROR", "Error while reading XML file. Error: '%s'"),
    ECM_RESPONSE_FILE_NOT_FOUND("ECM_RESPONSE_FILE_NOT_FOUND", "Block file not found in UploadFileEcmRs for document with rqUid: '%s'"),
    ECM_RESPONSE_STATUS_IS_NULL("ECM_RESPONSE_STATUS_IS_NULL", "Block status is null in UploadFileEcmRs for document with rqUid: '%s'"),
    ECM_RESPONSE_RESULT_CODE_IS_NOT_SUCCESS("ECM_RESPONSE_RESULT_CODE_IS_NOT_SUCCESS", "Result code is not success in UploadFileEcmRs for document with rqUid: '%s'. Result code: '%s'"),
    ECM_RESPONSE_NEW_ID_IS_BLANK("ECM_RESPONSE_NEW_ID_IS_BLANK", "New id is null or empty in UploadFileEcmRs for document with rqUid: '%s'"),
    ECM_RESPONSE_BA_ATTR_NOT_FOUND("ECM_RESPONSE_BA_ATTR_NOT_FOUND", "Business attribute '%s' not found in UploadFileEcmRs for document with rqUid: '%s'");

    private final String value;
    private final String message;

    public String getMessage(Object... args) {
        return String.format(message, args);
    }
}