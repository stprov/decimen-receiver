package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;
import ru.sber.tfs.domain.AttrIntType;
import ru.sber.tfs.domain.DownloadFileEcmRs;
import ru.sber.tfs.domain.UploadFileEcmRs;
import ru.sbrf.gmap.vux.exception.ecm.EcmException;
import ru.sbrf.gmap.vux.exception.ecm.ErrorCode;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;
import ru.sbrf.gmap.vux.utils.CommonUtils;

import java.util.Optional;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
@ConditionalOnProperty(prefix = "integration.ecm.tfs-upload", value = "enabled", havingValue = "true")
public class TfsResponseListener {

    private final static int GOOD_ECM_RESULT_CODE = 0;
    private final EcmRqRsSerdesService ecmRqRsSerdesService;
    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;
    private static final String RESULT_DOCUMENT_ID_KEY_BA = "resultDocumentId";

    @KafkaListener(
            topics = "${integration.ecm.tfs-upload.kafka.consumer.topicIn}",
            groupId = "${integration.ecm.tfs-upload.kafka.consumer.groupId}",
            containerFactory = "kafkaListenerContainerFactory"
    )
    public void tfsResponseConsumer(ConsumerRecord<String, String> record, Acknowledgment ack) {

        log.debug("Message received from topic: '{}', partition: '{}', offset: '{}', timestamp: '{}', " +
                        "message size: {} bytes, key: {}",
                record.topic(), record.partition(), record.offset(),
                record.timestamp(), record.serializedValueSize(), record.key());
        Optional<UploadFileEcmRs> uploadFileEcmRs = Optional.empty();
        try {
            uploadFileEcmRs = Optional.ofNullable(ecmRqRsSerdesService.readEcmResponse(record.value()));
        } catch (EcmException ee) {
            log.error("Error occured during processing ECM response. EcmException: {}", ee.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error occurred during processing ECM response. Exception: {}", e.getMessage());
        }
        if (uploadFileEcmRs.isPresent()) {
            UUID rqUid = CommonUtils.dashlessUuidToValidUuid(uploadFileEcmRs.get().getRqUID());
            processResponse(uploadFileEcmRs.get(), rqUid);
        }
        ack.acknowledge();
    }

    private void processResponse(UploadFileEcmRs uploadFileEcmRs, UUID rqUid) {
        // Проверяем, зарегистрирован ли rqUid в очереди ECM (SELECT EXISTS по v_vux_ecm_queue)
        boolean inQueue = vuxDocumentValidationResultViewRepository.existsInEcmQueue(rqUid.toString());
        if (!inQueue) {
            // Байтовый (легаси) сценарий — rqUid не регистрировался в очереди ECM, сохраняем текущее поведение
            processByteScenario(uploadFileEcmRs, rqUid);
            return;
        }
        // Сценарий загрузки по S3-path — обрабатываем квитанцию через очередь ECM
        processS3QueueScenario(uploadFileEcmRs, rqUid);
    }

    private void processByteScenario(UploadFileEcmRs uploadFileEcmRs, UUID rqUid) {
        try {
            String newId = getNewId(uploadFileEcmRs, rqUid);
            String resultCode = getResultCode(uploadFileEcmRs);
            log.debug("Document with RqUid '{}' successfully uploaded to ECM with ecmId: '{}' and result code: '{}'", rqUid, newId, resultCode);
            int resultDocumentId = extractAttrIntBusinessAttribute(uploadFileEcmRs, rqUid);
            // Сохраняем присвоенный ECM-ом идентификатор документа через хранимую процедуру (fn_flow_set_ecm_id)
            vuxDocumentValidationResultViewRepository.flowSetEcmId(resultDocumentId, newId, resultCode);
        } catch (EcmException ee) {
            log.error("Error occurred while processing ECM response. Error: '{}'", ee.getMessage());
        }
    }

    private void processS3QueueScenario(UploadFileEcmRs uploadFileEcmRs, UUID rqUid) {
        try {
            String ecmId = getNewId(uploadFileEcmRs, rqUid);
            String resultCode = getResultCode(uploadFileEcmRs);
            log.debug("Document with RqUid '{}' successfully uploaded to ECM with ecmId: '{}' and result code: '{}'", rqUid, ecmId, resultCode);
            // Проставляем присвоенный ECM-ом uuid запросу в очереди (fn_ecm_request_set_ecm_id)
            vuxDocumentValidationResultViewRepository.fnEcmRequestSetEcmId(rqUid.toString(), ecmId);
        } catch (EcmException ee) {
            String errorText = ee.getMessage();
            log.error("ECM receipt returned an error for rqUid '{}'. Error: '{}'", rqUid, errorText);
            // Фиксируем ошибку обработки запроса в очереди ECM (fn_ecm_request_set_error)
            vuxDocumentValidationResultViewRepository.fnEcmRequestSetError(rqUid.toString(), errorText);
        }
    }

    private int extractAttrIntBusinessAttribute(UploadFileEcmRs uploadFileEcmRs, UUID rqUid) {
        return uploadFileEcmRs.getFile().getFirst()
                .getBusinessAttrs().getAttrStrOrAttrListOfStrOrAttrInt().stream()
                .filter(attr -> attr instanceof AttrIntType)
                .map(AttrIntType.class::cast)
                .filter(attr -> TfsResponseListener.RESULT_DOCUMENT_ID_KEY_BA.equals(attr.getKey()))
                .findFirst()
                .map(AttrIntType::getValue)
                .orElseThrow(() -> new EcmException(ErrorCode.ECM_RESPONSE_BA_ATTR_NOT_FOUND, TfsResponseListener.RESULT_DOCUMENT_ID_KEY_BA, rqUid));
    }

    private void validateResponse(UploadFileEcmRs uploadFileEcmRs, UUID rqUid) {

        UploadFileEcmRs.File file = requireNonNull(
                uploadFileEcmRs.getFile().stream().findFirst().orElse(null),
                ErrorCode.ECM_RESPONSE_FILE_NOT_FOUND,
                rqUid
        );

        DownloadFileEcmRs.File.Status status = requireNonNull(
                file.getStatus(),
                ErrorCode.ECM_RESPONSE_STATUS_IS_NULL,
                rqUid
        );

        if (status.getResultCode() != GOOD_ECM_RESULT_CODE) {
            throw new EcmException(ErrorCode.ECM_RESPONSE_RESULT_CODE_IS_NOT_SUCCESS, rqUid, status.getResultCode());
        }
    }

    private String getNewId(UploadFileEcmRs uploadFileEcmRs, UUID rqUid) {
        validateResponse(uploadFileEcmRs, rqUid);
        UploadFileEcmRs.File file =
                uploadFileEcmRs.getFile().getFirst();
        String newId = file.getNewId();

        if (StringUtils.isBlank(newId)) {
            throw new EcmException(ErrorCode.ECM_RESPONSE_NEW_ID_IS_BLANK, rqUid);
        }
        log.debug("New Id for document with RqUid '{}' is '{}'", rqUid, newId);
        return newId;
    }

    private String getResultCode(UploadFileEcmRs uploadFileEcmRs) {
        return String.valueOf(uploadFileEcmRs.getFile().getFirst().getStatus().getResultCode());
    }

    private <T> T requireNonNull(T value, ErrorCode errorCode, UUID rqUid) {

        if (value == null) {
            throw new EcmException(errorCode, rqUid);
        }
        return value;
    }
}