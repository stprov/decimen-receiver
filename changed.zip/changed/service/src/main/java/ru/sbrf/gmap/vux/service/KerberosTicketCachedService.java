package ru.sbrf.gmap.vux.service;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.config.KerberosProps;

import java.io.IOException;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@Slf4j
@RequiredArgsConstructor
@ConditionalOnProperty(value="test-stand", havingValue = "false", matchIfMissing = true)
public class KerberosTicketCachedService {

    private static final Pattern HOST_PATTERN = Pattern.compile("//([^:/]+):?\\d*");

    @Value("${spring.datasource.url}")
    private String jdbcUrl;

    private final KerberosProps kerberosProps;

    /**
     * Проверяет, истёк ли Kerberos-тикет.
     */
    public boolean isKerberosTicketExpired() throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder("klist", "-s");
        Process process = pb.start();

        int exitCode = process.waitFor();

        if (exitCode == 0) {
            log.debug("The Kerberos ticket is valid.");
            return false;
        }
        log.warn("Kerberos ticket not found or outdated (exit code: {}).", exitCode);
        return true;

    }


    @PostConstruct
    public void renewKerberosTickets() throws IOException {

        log.info("Trying to update/release Kerberos ticket...");
        if (!areKerberosPropertiesValid(kerberosProps)) {
            throw new IllegalStateException("Kerberos properties are not fully configured");
        }

        if (renewTgtTicket() == KerberosTicketUpdateStatus.FAILED_UPDATE) {
            throw new IOException("Kerberos TGT update failed!");
        }

        String host = extractHostFromJdbcUrl(jdbcUrl)
                .orElseThrow(() -> new IllegalStateException("Host not found in JDBC URL"));
        log.debug("Host extracted from JDBC URL: {}", host);

        if (renewTgsTicket(host) == KerberosTicketUpdateStatus.FAILED_UPDATE) {
            throw new IOException("Kerberos TGS update failed!");
        }
    }

    private KerberosTicketUpdateStatus renewTgtTicket() {
        ProcessBuilder pb = new ProcessBuilder("kinit");
        pb.command().add("-V");
        pb.command().add("-kt");
        pb.command().add(kerberosProps.keytabPath());
        pb.command().add("-c");
        pb.command().add(kerberosProps.cachePath());
        pb.command().add(kerberosProps.user() + "@" + kerberosProps.realm());
        log.info("KerberosTicketCachedService: Executing command: {}", String.join(" ", pb.command()));
        pb.redirectErrorStream(true);

        try {
            Process process = pb.start();
            int exitCode = process.waitFor();
            if (exitCode == 0) {
                log.info("Kerberos TGT updated or released successfully.");
                return KerberosTicketUpdateStatus.SUCCESSFULLY_UPDATE;
            }
            log.error("Failed to update Kerberos ticket. Exit code: {}", exitCode);
            return KerberosTicketUpdateStatus.FAILED_UPDATE;
        } catch (Exception e) {
            log.error("Exception occurred during update Kerberos TGT", e);
            return KerberosTicketUpdateStatus.FAILED_UPDATE;
        }
    }

    private KerberosTicketUpdateStatus renewTgsTicket(String serviceHost) {

        ProcessBuilder pb = new ProcessBuilder("kvno");
        pb.command().add("postgres/" + serviceHost);
        try {
            Process process = pb.start();
            int exitCode = process.waitFor();
            if (exitCode == 0) {
                log.info("Kerberos TGS updated or released successfully.");
                return KerberosTicketUpdateStatus.SUCCESSFULLY_UPDATE;
            }
            log.error("Error occurred during update Kerberos TGS, exit code: {}", exitCode);
            return KerberosTicketUpdateStatus.FAILED_UPDATE;
        } catch (Exception e) {
            log.error("Exception occurred during update Kerberos TGS", e);
            return KerberosTicketUpdateStatus.FAILED_UPDATE;
        }
    }

    private boolean areKerberosPropertiesValid(KerberosProps kerberosProps) {
        return StringUtils.isNotBlank(kerberosProps.user())
                && StringUtils.isNotBlank(kerberosProps.realm())
                && StringUtils.isNotBlank(kerberosProps.keytabPath())
                && StringUtils.isNotBlank(kerberosProps.cachePath());
    }

    private Optional<String> extractHostFromJdbcUrl(String jdbcUrl) {
        if (StringUtils.isBlank(jdbcUrl)) {
            return Optional.empty();
        }
        Matcher matcher = HOST_PATTERN.matcher(jdbcUrl);
        if (matcher.find()) {
            return Optional.of(matcher.group(1));
        } else {
            log.warn("Failed to extract host from JDBC URL: no match found for pattern in '{}'", jdbcUrl);
            return Optional.empty();
        }
    }

    private enum KerberosTicketUpdateStatus {
        SUCCESSFULLY_UPDATE,
        FAILED_UPDATE
    }
}