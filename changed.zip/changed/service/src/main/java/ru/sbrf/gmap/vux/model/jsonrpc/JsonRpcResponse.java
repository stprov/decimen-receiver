package ru.sbrf.gmap.vux.model.jsonrpc;

import ru.sbrf.gmap.vux.model.supz.response.SupzTaskResponse;


public record JsonRpcResponse(

        /* Version of JSON-RPC protocol */
        String jsonrpc,

        /* Unique response identifier. Should be equals request id */
        String id,

        /* Result of the request */
        SupzTaskResponse result,

        /* Error object if request failed */
        JsonRpcErrorResponse error
) {
}
