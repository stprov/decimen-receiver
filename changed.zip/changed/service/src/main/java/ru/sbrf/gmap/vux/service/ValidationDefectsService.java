package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationLogEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationResultViewEntity;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationLogRepository;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;
import ru.sbrf.gmap.vux.service.checks.ValidationRule;

import java.util.List;

/**
 * Общий компонент для всех стратегий обработки документов: читает нарушения из view
 * {@code v_vux_document_validation_result} и логи проверок, разделяет их
 * на ошибки и предупреждения.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ValidationDefectsService {

    /**
     * Максимальное количество ошибок на документ в выборке.
     */
    @Value("${config.defects-limits.error-set:30}")
    private Integer errorSet;

    /**
     * Максимальное количество нарушений всех типов на документ в выборке.
     */
    @Value("${config.defects-limits.total-set:200}")
    private Integer totalSet;

    private final VuxDocumentValidationLogRepository vuxDocumentValidationLogRepository;
    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;

    /**
     * Нарушения документа из view с ограничением выборки ({@code errorSet}/{@code totalSet}).
     */
    public List<VuxDocumentValidationResultViewEntity> getResultsForDocWithRnLimit(Integer docId) {
        return vuxDocumentValidationResultViewRepository.findByDocIdWithRnLimit(docId, errorSet, totalSet);
    }

    /**
     * Подмножество нарушений с типом правила {@link RuleTypeEnum#E} (ошибки).
     */
    public List<VuxDocumentValidationResultViewEntity> getErrorsList(List<VuxDocumentValidationResultViewEntity> defects) {
        return defects.stream().filter(v -> v.getRuleType() == RuleTypeEnum.E).toList();
    }

    /**
     * Подмножество нарушений с типом правила {@link RuleTypeEnum#W} (предупреждения).
     */
    public List<VuxDocumentValidationResultViewEntity> getWarningsList(List<VuxDocumentValidationResultViewEntity> defects) {
        return defects.stream().filter(v -> v.getRuleType() == RuleTypeEnum.W).toList();
    }

    /**
     * Логи проверок документа (для секции «Проверки» протокола).
     */
    public List<VuxDocumentValidationLogEntity> getChecksByDocId(Integer docId) {
        return vuxDocumentValidationLogRepository.findAllByDocIdOrderByErrorCountDesc(docId);
    }

    /**
     * Ошибки CUV-проверки документа, сохранённые в фазе 1 через {@code fn_flow_cuv_set_error}.
     * Во view {@code v_vux_document_validation_result} их нет — читаются из таблицы напрямую.
     * <p>
     * Заголовок ошибки в таблице не хранится; все CUV-правила используют
     * {@link ValidationRule#DEFAULT_TITLE}, он и подставляется.
     */
    public List<ValidationErrorDto> getCuvErrors(Integer docId) {
        return vuxDocumentValidationResultViewRepository.findCuvValidationErrors(docId.longValue()).stream()
                .map(row -> new ValidationErrorDto(ValidationRule.DEFAULT_TITLE, (String) row[0], (String) row[1]))
                .toList();
    }

    /**
     * Логирует количества ошибок и предупреждений документа.
     */
    public void logDefects(List<VuxDocumentValidationResultViewEntity> errors, List<VuxDocumentValidationResultViewEntity> warnings, Integer docId) {
        long errorCount = errors.stream().filter(v -> v.getRuleType() == RuleTypeEnum.E).count();
        long warningCount = warnings.stream().filter(v -> v.getRuleType() == RuleTypeEnum.W).count();
        log.debug("Found '{}' errors for doc_id='{}'", errorCount, docId);
        log.debug("Found '{}' warnings for doc_id='{}'", warningCount, docId);
    }
}
