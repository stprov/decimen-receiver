package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.config.FeatureToogleConfig;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolCheckRecordDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationLogEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationResultViewEntity;
import ru.sbrf.gmap.vux.entity.enums.ScheduleStatusEnum;
import ru.sbrf.gmap.vux.mapper.VuxDocumentValidationLogEnityMapper;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;
import ru.sbrf.gmap.vux.service.checks.DataContext;
import ru.sbrf.gmap.vux.service.checks.DataContextProvider;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Стратегия обработки нового документа — записи расписания без {@code ecmId}
 * (протокол в ECM ещё не загружен). Фаза 1 процесса, см. docs/analytics/cuv-csv-ecm-supz-flow.md, раздел 6.
 * <p>
 * Маршрут:
 * <ul>
 *     <li>{@code check_mode = cuv}, фича-флаг включён, есть {@link DataContextProvider} формы — CUV-проверка;</li>
 *     <li>{@code check_mode = cuv}, фича-флаг выключен — стандартная проверка (D-2);</li>
 *     <li>{@code check_mode = xml} — стандартная проверка: требований к XML-проверке пока нет, view не возвращает xml (D-11);</li>
 *     <li>иначе — стандартная проверка по результатам из БД.</li>
 * </ul>
 * Итоговый статус CUV-проверки сохраняется через {@code fn_flow_cuv_set_status} (D-47).
 * Успешная CUV-проверка: протокол → ECM, создание записей выгрузки CSV ({@code fn_xbrl_create_ecm} ×3,
 * кроме флага {@code U}, D-49); задача в СУПЗ и закрытие расписания — в фазе 2 ({@link ExistingDocumentProcessingService}).
 * Нет данных формы — ошибки CUV-проверки {@code _001}…{@code _004}, протокол с ошибками и письмо (Q-8 п. 2.1, D-17).
 */
@Service
@Order(1)
@RequiredArgsConstructor
@Slf4j
public class NewDocumentProcessingService implements DocumentProcessingService {

    static final String CHECK_MODE_CUV = "cuv";
    static final String CHECK_MODE_XML = "xml";
    /**
     * Флаг расписания «не создавать задачу в СУПЗ» (t_vux_document_shedule.flags, 6.5).
     */
    static final char FLAG_NO_SUPZ_TASK = 'U';

    private final FeatureToogleConfig featureToggleConfig;
    private final ValidationDataService validationDataService;
    private final ProtocolBuildingService protocolBuildingService;
    private final PostUploadActionsService postUploadActionsService;
    private final ValidationDefectsService validationDefectsService;
    private final DocumentEcmExportService documentEcmExportService;
    private final List<DataContextProvider> dataContextProviders;
    private final VuxDocumentValidationLogEnityMapper vuxDocumentValidationLogEnityMapper;
    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;
    private final CuvValidationStatusService cuvValidationStatusService;

    @Override
    public boolean supports(VuxDocumentScheduleViewEntity record) {
        return Objects.isNull(record.getEcmId());
    }

    @Override
    public ProcessingResult processDocument(VuxDocumentScheduleViewEntity record) {
        try {
            String checkMode = record.getCheckMode();
            Optional<DataContextProvider> cuvProvider = findDataContextProvider(record.getDocTypeCode());

            if (CHECK_MODE_CUV.equals(checkMode)) {
                if (!featureToggleConfig.isCuvValidationEnabled()) {
                    // D-2: при выключенном флаге выполняется стандартная проверка по результатам из БД
                    log.info("[ORCH] Route: scheduleId={}, docId={}, docTypeCode={}, checkMode={}, phase=1, route=standard, " +
                                    "reason=CUV feature toggle is disabled",
                            record.getScheduleId(), record.getResultDocumentId(), record.getDocTypeCode(), checkMode);
                    return processStandardValidationCuvNotChecked(record);
                }
                if (cuvProvider.isEmpty()) {
                    log.warn("[ORCH] Route: scheduleId={}, docId={}, docTypeCode={}, checkMode={}, phase=1, route=standard, " +
                                    "reason=no DataContextProvider registered for the form",
                            record.getScheduleId(), record.getResultDocumentId(), record.getDocTypeCode(), checkMode);
                    return processStandardValidationCuvNotChecked(record);
                }
                log.info("[ORCH] Route: scheduleId={}, docId={}, docTypeCode={}, checkMode={}, phase=1, route=cuv",
                        record.getScheduleId(), record.getResultDocumentId(), record.getDocTypeCode(), checkMode);
                return processCuvFormValidation(record, cuvProvider.get());
            }

            if (CHECK_MODE_XML.equals(checkMode)) {
                // D-11, ревью R-8: требований к XML-проверке нет — до их появления стандартная проверка
                log.warn("[ORCH] Route: scheduleId={}, docId={}, docTypeCode={}, checkMode={}, phase=1, route=standard, " +
                                "reason=XML validation is not implemented yet",
                        record.getScheduleId(), record.getResultDocumentId(), record.getDocTypeCode(), checkMode);
                return processStandardValidation(record);
            }

            log.info("[ORCH] Route: scheduleId={}, docId={}, docTypeCode={}, checkMode={}, phase=1, route=standard",
                    record.getScheduleId(), record.getResultDocumentId(), record.getDocTypeCode(), checkMode);
            return processStandardValidation(record);
        } catch (Exception e) {
            log.error("[ORCH] Unexpected error when processing a new document: scheduleId={}, docId={}. " +
                    "Record is skipped until the next scheduler cycle.", record.getScheduleId(), record.getResultDocumentId(), e);
            return ProcessingResult.PENDING;
        }
    }

    // ===================== CUV =====================

    /**
     * CUV-проверка: провайдер собирает контекст, {@link ValidationDataService} выполняет правила.
     */
    private ProcessingResult processCuvFormValidation(VuxDocumentScheduleViewEntity record, DataContextProvider provider) {
        Integer docId = record.getResultDocumentId();
        Timestamp checkStart = now();
        DataContext context;
        try {
            context = provider.build(record);
        } catch (Exception e) {
            // Технический сбой (БД и т. п.) — запись остаётся открытой до следующего цикла (R-6, D-14)
            log.error("[CUV] Technical error while building DataContext: scheduleId={}, docId={}. " +
                    "Record is skipped until the next scheduler cycle.", record.getScheduleId(), docId, e);
            return ProcessingResult.PENDING;
        }
        if (context == null) {
            // Провайдер обязан вернуть контекст и при отсутствии данных формы — тогда ошибки _001…_004
            // выдают правила (Q-8 п. 2.1, D-17). null — дефект провайдера: технический сбой, запись остаётся открытой
            log.error("[CUV] DataContextProvider returned null: scheduleId={}, docId={}, docTypeCode={}. " +
                    "Record is skipped until the next scheduler cycle.", record.getScheduleId(), docId, record.getDocTypeCode());
            return ProcessingResult.PENDING;
        }
        log.debug("[CUV] DataContext built for docId={}: contextList={}, unitList={}, valueList={}, dataList={}",
                docId, context.contextList().size(), context.unitList().size(),
                context.valueList().size(), context.dataList().size());

        List<ValidationErrorDto> validationErrors = validationDataService.validate(context);
        CuvRun run = new CuvRun(checkStart, now(),
                validationDataService.countExecutedChecks(validationErrors), validationErrors.size());
        log.info("[CUV] Validation completed: scheduleId={}, docId={}, cuvErrors={}, executedChecks={}",
                record.getScheduleId(), docId, validationErrors.size(), run.checkCount());

        return validationErrors.isEmpty()
                ? handleCuvFormSuccess(record, run)
                : handleCuvFormErrors(record, validationErrors, run);
    }

    /**
     * CUV-проверка без ошибок. При ошибках стандартной проверки (view) — протокол с ошибками и письмо.
     * Иначе — успешный протокол в ECM и создание записей выгрузки CSV; задача СУПЗ — в фазе 2,
     * поэтому расписание остаётся открытым.
     */
    private ProcessingResult handleCuvFormSuccess(VuxDocumentScheduleViewEntity record, CuvRun run) {
        Integer docId = record.getResultDocumentId();
        List<VuxDocumentValidationResultViewEntity> defects = validationDefectsService.getResultsForDocWithRnLimit(docId);
        List<VuxDocumentValidationResultViewEntity> viewErrors = validationDefectsService.getErrorsList(defects);
        List<VuxDocumentValidationResultViewEntity> viewWarnings = validationDefectsService.getWarningsList(defects);
        List<VuxDocumentValidationLogEntity> checkList = validationDefectsService.getChecksByDocId(docId);
        log.info("[CUV] View defects: scheduleId={}, docId={}, viewErrors={}, viewWarnings={}",
                record.getScheduleId(), docId, viewErrors.size(), viewWarnings.size());

        if (!viewErrors.isEmpty()) {
            log.warn("[CUV] Standard validation errors found: scheduleId={}, docId={}, count={}. CSV export is not requested.",
                    record.getScheduleId(), docId, viewErrors.size());
            ProtocolModelDto errorProtocol = protocolBuildingService.createProtocolModelDto(viewErrors, viewWarnings, checkList, record);
            return saveCuvStatusIfCompleted(record, run, uploadProtocolAndSendErrorMail(record, errorProtocol));
        }

        List<ProtocolCheckRecordDto> checks = Stream.concat(
                checkList.stream().map(vuxDocumentValidationLogEnityMapper::toProtocolCheckRecordDto),
                validationDataService.getChecks(Collections.emptyList()).stream()
        ).toList();
        ProtocolModelDto successProtocol = protocolBuildingService.createCuvSuccessProtocol(record, viewWarnings, checks);

        if (postUploadActionsService.uploadProtocol(record, successProtocol).isEmpty()) {
            return ProcessingResult.PENDING;
        }
        saveCuvStatus(record, run);

        if (isSupzTaskDisabled(record)) {
            // D-49: при флаге 'U' задача СУПЗ не создаётся, поэтому CSV не выгружаются — записи выгрузки не создаются.
            // Расписание закрывается в следующем цикле: фаза 2 видит supz_task_id = 1 (FR-2.1). Закрытие сразу
            // в фазе 1 — предложение разработки, ждёт ответа (Q-10)
            log.info("[CSV-EXPORT] CSV export is skipped: schedule flag 'U' (SUPZ task is disabled), scheduleId={}, docId={}, " +
                    "flags={}. Schedule will be resolved in phase 2.", record.getScheduleId(), docId, record.getFlags());
            return ProcessingResult.PENDING;
        }

        boolean allRequested = documentEcmExportService.requestCuvCsvExport(docId);
        log.info("[CUV] Phase 1 completed: scheduleId={}, docId={}, csvExportRequested={}. " +
                        "Waiting for CSV upload by the external service, schedule stays open.",
                record.getScheduleId(), docId, allRequested ? "all" : "partially (missing records will be restored in phase 2)");
        return ProcessingResult.PENDING;
    }

    /**
     * Ошибки CUV-проверки: сохранение через {@code fn_flow_cuv_set_error}, протокол (ошибки CUV + view), письмо.
     */
    private ProcessingResult handleCuvFormErrors(VuxDocumentScheduleViewEntity record, List<ValidationErrorDto> validationErrors,
                                                 CuvRun run) {
        Integer docId = record.getResultDocumentId();
        for (ValidationErrorDto error : validationErrors) {
            vuxDocumentValidationResultViewRepository.flowCuvSetError(docId.longValue(), error.errorMessage(), error.errorCode());
            log.debug("Saved error: docId={}, errorCode={}, message={}", docId, error.errorCode(), error.errorMessage());
        }
        // Ошибка CUV равнозначна ошибке проверки БД: расписанию ставится статус 2 «с ошибками» (D-45, Q-7)
        markScheduleCheckedWithErrors(record);

        List<VuxDocumentValidationResultViewEntity> defects = validationDefectsService.getResultsForDocWithRnLimit(docId);
        List<VuxDocumentValidationResultViewEntity> viewErrors = validationDefectsService.getErrorsList(defects);
        List<VuxDocumentValidationResultViewEntity> viewWarnings = validationDefectsService.getWarningsList(defects);
        List<VuxDocumentValidationLogEntity> viewChecks = validationDefectsService.getChecksByDocId(docId);

        // CUV-ошибки явно добавляются к ошибкам view: во view их нет
        ProtocolModelDto protocol = protocolBuildingService.createCuvErrorProtocol(record, viewErrors, viewWarnings, viewChecks, validationErrors);
        log.info("[CUV] Errors saved: scheduleId={}, docId={}, cuvErrors={}, viewErrors={}",
                record.getScheduleId(), docId, validationErrors.size(), viewErrors.size());
        return saveCuvStatusIfCompleted(record, run, uploadProtocolAndSendErrorMail(record, protocol));
    }

    /**
     * Ставит расписанию статус 2 («проверено с ошибками») через {@code fn_flow_update_shedule}.
     * Если статус уже 2 (ошибки нашла и БД) — вызов не нужен.
     */
    private void markScheduleCheckedWithErrors(VuxDocumentScheduleViewEntity record) {
        if (record.getScheduleStatus() == ScheduleStatusEnum.CHECKED_WITH_ERRORS) {
            return;
        }
        vuxDocumentValidationResultViewRepository.flowUpdateSheduleStatus(
                record.getScheduleId(), ScheduleStatusEnum.CHECKED_WITH_ERRORS.ordinal());
        log.info("[CUV] Schedule status set to {} (checked with errors): scheduleId={}, docId={}, previousStatus={}",
                ScheduleStatusEnum.CHECKED_WITH_ERRORS.ordinal(), record.getScheduleId(), record.getResultDocumentId(),
                record.getScheduleStatus());
    }

    /**
     * Итог CUV-проверки ({@code fn_flow_cuv_set_status}, D-47): пишется, когда шаг обработки завершён,
     * чтобы при повторе цикла (технический сбой) не добавлять лишние строки.
     */
    private ProcessingResult saveCuvStatusIfCompleted(VuxDocumentScheduleViewEntity record, CuvRun run, ProcessingResult result) {
        if (result.isCompleted()) {
            saveCuvStatus(record, run);
        }
        return result;
    }

    private void saveCuvStatus(VuxDocumentScheduleViewEntity record, CuvRun run) {
        cuvValidationStatusService.saveChecked(record, run.checkCount(), run.errorCount(), run.checkStart(), run.checkEnd());
    }

    /**
     * Стандартная проверка для формы с {@code check_mode = cuv}, когда CUV-проверка не выполняется
     * (выключен фича-флаг или для формы нет проверки в коде): статус CUV — «не проверен» (D-47).
     */
    private ProcessingResult processStandardValidationCuvNotChecked(VuxDocumentScheduleViewEntity record) {
        ProcessingResult result = processStandardValidation(record);
        if (result.isCompleted()) {
            cuvValidationStatusService.saveNotChecked(record);
        }
        return result;
    }

    /**
     * Флаг расписания {@code U} — «не создавать задачу в СУПЗ» (6.5).
     */
    static boolean isSupzTaskDisabled(VuxDocumentScheduleViewEntity record) {
        return record.getFlags() != null && record.getFlags().indexOf(FLAG_NO_SUPZ_TASK) >= 0;
    }

    private static Timestamp now() {
        return new Timestamp(System.currentTimeMillis());
    }

    /**
     * Данные выполненной CUV-проверки для сохранения статуса.
     */
    private record CuvRun(Timestamp checkStart, Timestamp checkEnd, int checkCount, int errorCount) {
    }

    // ===================== Стандартная проверка =====================

    /**
     * Стандартная проверка по нарушениям из view: протокол → ECM → письмо (ошибки) либо задача СУПЗ.
     */
    private ProcessingResult processStandardValidation(VuxDocumentScheduleViewEntity record) {
        Integer docId = record.getResultDocumentId();
        List<VuxDocumentValidationResultViewEntity> defects = validationDefectsService.getResultsForDocWithRnLimit(docId);
        List<VuxDocumentValidationResultViewEntity> errorsList = validationDefectsService.getErrorsList(defects);
        List<VuxDocumentValidationResultViewEntity> warningsList = validationDefectsService.getWarningsList(defects);
        validationDefectsService.logDefects(errorsList, warningsList, docId);
        List<VuxDocumentValidationLogEntity> checkList = validationDefectsService.getChecksByDocId(docId);
        log.debug("Found records in {} checkList items for result_doc_id: {}", checkList.size(), docId);

        ProtocolModelDto protocolModelDto = protocolBuildingService.createProtocolModelDto(errorsList, warningsList, checkList, record);

        Optional<String> protocolEcmId = postUploadActionsService.uploadProtocol(record, protocolModelDto);
        if (protocolEcmId.isEmpty()) {
            return ProcessingResult.PENDING;
        }
        return ProcessingResult.of(
                postUploadActionsService.handlePostUploadActions(record, protocolModelDto, List.of(protocolEcmId.get())));
    }

    // ===================== Общее =====================

    private ProcessingResult uploadProtocolAndSendErrorMail(VuxDocumentScheduleViewEntity record, ProtocolModelDto protocol) {
        if (postUploadActionsService.uploadProtocol(record, protocol).isEmpty()) {
            return ProcessingResult.PENDING;
        }
        return ProcessingResult.of(postUploadActionsService.sendErrorMail(record, protocol));
    }

    /**
     * Поиск провайдера контекста CUV-проверки по коду формы.
     */
    private Optional<DataContextProvider> findDataContextProvider(String docTypeCode) {
        if (docTypeCode == null) {
            return Optional.empty();
        }
        List<DataContextProvider> matched = dataContextProviders.stream()
                .filter(p -> docTypeCode.equals(p.supportedDocTypeCode()))
                .toList();
        if (matched.size() > 1) {
            log.warn("Duplicate DataContextProvider registered for docTypeCode={}", docTypeCode);
        }
        return matched.stream().findFirst();
    }
}
