package ru.sbrf.gmap.vux.config;

import org.springframework.boot.context.properties.ConfigurationProperties;


@ConfigurationProperties(prefix = "integration.kerberos")
public record KerberosProps(
        String user,
        String realm,
        String keytabPath,
        String cachePath
) {
}