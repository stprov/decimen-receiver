package ru.sbrf.gmap.vux.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource(value = "file:/vault/secrets/env_secret.properties", encoding = "UTF-8")
@ConditionalOnProperty(value="test-stand", havingValue = "false", matchIfMissing = true)
public class SecretConfig {
    // Конфигурация загружает свойства из файла env_secret.properties
    // Доступ к значениям — через @Value или Environment
}