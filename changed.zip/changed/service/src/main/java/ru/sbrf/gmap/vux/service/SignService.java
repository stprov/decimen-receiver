package ru.sbrf.gmap.vux.service;

import feign.Response;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;
import ru.sbrf.gmap.vux.client.feign.SignFeignClient;
import ru.sbrf.gmap.vux.config.IntegrationSignProps;
import ru.sbrf.gmap.vux.dto.request.okey.SignatureBadDto;
import ru.sbrf.gmap.vux.exception.sign.SignIntegrationException;
import ru.sbrf.gmap.vux.model.sign.SignRequestDto;
import ru.sbrf.gmap.vux.model.sign.SignResponseDto;
import tools.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

@Slf4j
@RequiredArgsConstructor
@Service
@ConditionalOnProperty(prefix = "integration.sign", name = "enabled", havingValue = "true")
@Validated
public class SignService {

    private final SignFeignClient signFeignClient;
    private final IntegrationSignProps integrationSignProps;
    private final ObjectMapper objectMapper;

    /**
     * Signs a document by sending a signing request through the SignFeignClient with the provided headers and payload.
     *
     * @param rqUid          The unique request identifier, used for audit trails and idempotency (e.g. UUID)
     * @param xRqTm          The request timestamp in ISO 8601 format (e.g. "2023-01-01T12:00:00Z")
     * @param signRequestDto Data Transfer Object containing the document content and signing metadata
     * @return {@link SignResponseDto} containing the result of the signing operation; includes error details if failed
     * @throws SignIntegrationException if the response contains an error code or error description
     * @see SignFeignClient#signRequest(Map, SignRequestDto)
     * @see SignResponseDto
     */
    public SignResponseDto sign(@NotNull String rqUid, @NotNull String xRqTm, @Valid SignRequestDto signRequestDto) {
        log.debug("Initiating sign request with rqUid: {}, xRqTm: {}, hash id: {}", rqUid, xRqTm, signRequestDto.id());

        Response response = signFeignClient
                .signRequest(getHeaders(rqUid, xRqTm), signRequestDto);

        SignResponseDto responseDto;
        try {
            log.debug("Trying parsing Okay service's response...");
            responseDto = deserializeOkayResponse(response);
        } catch (IOException e) {
            log.error("Failed to parse Okay service's response..", e);
            throw new RuntimeException("Error ocurred during deserialization AC OKAY response: ", e);
        }


        if (hasError(responseDto)) {
            log.error("Sign request failed with: errorCode='{}', errorDescription='{}'",
                    responseDto.errorCode(), responseDto.errorDescription());
            throw new SignIntegrationException(responseDto.errorCode(), responseDto.errorDescription());
        }
        log.info("Sign request successful for rqUid: '{}', hash id: '{}'", rqUid, signRequestDto.id());
        return responseDto;
    }

    private boolean hasError(SignResponseDto response) {
        return ObjectUtils.isNotEmpty(response.errorCode()) &&
                ObjectUtils.isNotEmpty(response.errorDescription());
    }

    private Map<String, Object> getHeaders(String rqUid, String xRqTm) {
        return Map.of(
                "X-RqUid", rqUid,
                "X-RqTm", xRqTm,
                "Content-Type", "application/x-ndjson",
                "X-System", integrationSignProps.okSignService().xSystem(),
                "X-Channel", integrationSignProps.okSignService().xChannel());
    }

    private SignResponseDto deserializeOkayResponse(Response response) throws IOException, SignIntegrationException {
        if (response.status() == HttpStatus.OK.value()) {
            try (InputStream inputStream = response.body().asInputStream()) {
                return objectMapper.readValue(inputStream, SignResponseDto.class);
            }
        }
        SignatureBadDto signatureBadDto = null;
        if (response.body() != null) {
            try (InputStream inputStream = response.body().asInputStream()) {
                signatureBadDto = objectMapper.readValue(inputStream, SignatureBadDto.class);
            }
        }
        log.error("Sign request failed with status: {}", response.status());
        int code = signatureBadDto != null ? Integer.parseInt(signatureBadDto.errorCode()) : -1;
        String description = signatureBadDto != null ? signatureBadDto.errorDescription() : "UNKNOWN REASON";
        throw new SignIntegrationException(code, description);
    }
}
