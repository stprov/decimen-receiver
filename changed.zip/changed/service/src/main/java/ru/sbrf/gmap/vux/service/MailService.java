package ru.sbrf.gmap.vux.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.config.CommonProps;
import ru.sbrf.gmap.vux.config.MailProps;

import java.nio.charset.StandardCharsets;
import java.util.List;

@RequiredArgsConstructor
@Slf4j
@Service
@ConditionalOnProperty(value = "mail.enabled", havingValue = "true")
public class MailService {
    private final MailProps mailProps;
    private final CommonProps commonProps;
    private final JavaMailSender javaMailSender;


    @Value("${spring.application.name}")
    private String appName;

    /**
     * Количество попыток отправки письма (значение меньше 1 трактуется как 1).
     */
    @Value("${mail.retry.max-attempts:3}")
    private int maxAttempts;

    /**
     * Пауза между попытками отправки, мс.
     */
    @Value("${mail.retry.delay-ms:2000}")
    private long retryDelayMs;

    /**
     * @return {@code true}, если письмо отправлено (или отправлять некому), {@code false} — сбой отправки после всех попыток
     */
    public boolean sendMail(String subject, String htmlBody, List<String> recipientsList, List<String> ccList) {
        return this.sendMail(subject, htmlBody, recipientsList, ccList, true);
    }

    /**
     * Отправляет письмо с повторными попытками при ошибке SMTP.
     *
     * @return {@code true}, если письмо отправлено (или отправлять некому), {@code false} — сбой отправки после всех попыток
     * @throws IllegalArgumentException если не удалось сформировать сообщение (некорректные адреса)
     */
    public boolean sendMail(String subject, String htmlBody, List<String> recipientsList, List<String> ccList, boolean addPrefix) {

        if (recipientsList.isEmpty()) {
            log.warn("No recipients for email");
            return true;
        }

        String subjectValue = subject == null ? "No subject" : subject;
        String fullSubject = addPrefix
                ? "Stand: %s. %s: %s".formatted(commonProps.standName(), appName, subjectValue)
                : subjectValue;

        MimeMessage message = javaMailSender.createMimeMessage();
        MimeMessageHelper helper;
        try {
            helper = new MimeMessageHelper(message, true, StandardCharsets.UTF_8.name());
            helper.setFrom(mailProps.from());
            helper.setTo(recipientsList.toArray(String[]::new));

            if (!ccList.isEmpty()) {
                log.debug("CC list: {}", ccList);
                helper.setCc(ccList.toArray(String[]::new));
            }
            helper.setSubject(fullSubject);
            helper.setText(htmlBody, true);
        } catch (MessagingException e) {
            log.error("Error when creating a MIME message", e);
            throw new IllegalArgumentException("Couldn't create email address", e);
        }
        int attempts = Math.max(1, maxAttempts);
        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                log.info("Sending an email to: {} (attempt {}/{})", recipientsList, attempt, attempts);
                javaMailSender.send(message);
                log.info("Email sent successfully.");
                return true;
            } catch (MailException e) {
                log.error("Error when sending email (attempt {}/{})", attempt, attempts, e);
            } catch (Exception e) {
                log.error("Unknown error when sending email (attempt {}/{})", attempt, attempts, e);
            }
            if (attempt < attempts && !pause()) {
                break;
            }
        }
        log.error("[MAIL] Email was NOT sent after {} attempt(s). Subject: '{}', recipients: {}", attempts, fullSubject, recipientsList);
        return false;
    }

    private boolean pause() {
        if (retryDelayMs <= 0) {
            return true;
        }
        try {
            Thread.sleep(retryDelayMs);
            return true;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
    }
}
