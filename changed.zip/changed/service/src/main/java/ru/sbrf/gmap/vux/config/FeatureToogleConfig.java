package ru.sbrf.gmap.vux.config;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "config.feature-toogles", ignoreInvalidFields = true)
@Slf4j
public record FeatureToogleConfig(
        boolean isCuvValidationEnabled
) {

    @PostConstruct
    void init() {
        log.info("Feature toggle config is: '{}'", this);
    }
}
