package ru.sbrf.gmap.vux.service.parser;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.StringReader;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Обобщённый сервис парсинга XML-фрагментов через JAXB.
 *
 * <p>Принимает невалидный/фрагментарный XML (без корневого элемента),
 * оборачивает его в фиктивный корневой элемент {@code <root>} с объявлением
 * namespace-префиксов и выполняет unmarshalling в указанный DTO-класс.
 *
 * <p>Кеширует JAXBContext по классу для производительности.
 *
 * @param <T> тип целевого DTO
 */
@Component
@Slf4j
public class XmlParserService {

    private final Map<Class<?>, JAXBContext> contextCache = new ConcurrentHashMap<>();

    /**
     * Парсит XML-фрагмент в DTO указанного типа.
     *
     * @param xmlFragment  исходный XML-фрагмент (может быть null или пустым)
     * @param dtoClass     класс целевого DTO, аннотированный JAXB
     * @param <T>          тип DTO
     * @return  анмаршалленный DTO, или {@code null} если xmlFragment пустой/нулевой
     * @throws XmlParserException если парсинг не удался
     */
    public <T> T parse(String xmlFragment, Class<T> dtoClass) {
        if (xmlFragment == null || xmlFragment.isBlank()) {
            return null;
        }

        try {
            String wrappedXml = wrapWithRoot(xmlFragment);
            JAXBContext context = getContext(dtoClass);
            Unmarshaller unmarshaller = context.createUnmarshaller();

            @SuppressWarnings("unchecked")
            T result = (T) unmarshaller.unmarshal(new StringReader(wrappedXml));
            return result;
        } catch (Exception e) {
            throw new XmlParserException("Failed to parse XML for " + dtoClass.getSimpleName(), e);
        }
    }

    /**
     * Создаёт контекст для корневого DTO, который содержит ссылки
     * на вложенные DTO через @XmlElements.
     *
     * <p>В случае FullXmlDto контекст создаётся для {@code FullXmlDto.class},
     * JAXB автоматически резолвит {@code ExplicitMemberDto} и {@code TypedMemberDto}
     * через аннотации {@code @XmlElement(type = ...)}.
     */
    private JAXBContext getContext(Class<?> dtoClass) {
        return contextCache.computeIfAbsent(dtoClass, clazz -> {
            try {
                return JAXBContext.newInstance(clazz);
            } catch (JAXBException e) {
                throw new XmlParserException("Failed to create JAXBContext for " + clazz.getSimpleName(), e);
            }
        });
    }

    /**
     * Оборачивает XML-фрагмент в корневой элемент {@code <root>}
     * с объявлением всех namespace-префиксов.
     *
     * <p>Все префиксы (xbrldi, dim-int, mem-int) маппятся на один и тот же
     * namespace URI: {@code https://www.xbrl.org/2006/xbrldi-2006.xsd}.
     *
     * <p>Результирующий XML (пример):
     * <pre>{@code
     * <root xmlns:xbrldi="https://www.xbrl.org/2006/xbrldi-2006.xsd"
     *       xmlns:dim-int="https://www.xbrl.org/2006/xbrldi-2006.xsd"
     *       xmlns:mem-int="https://www.xbrl.org/2006/xbrldi-2006.xsd">
     *     ... исходный фрагмент ...
     * </root>
     * }</pre>
     */
    private String wrapWithRoot(String xmlFragment) {
        return """
                <root xmlns:xbrldi="https://www.xbrl.org/2006/xbrldi-2006.xsd"
                      xmlns:dim-int="https://www.xbrl.org/2006/xbrldi-2006.xsd"
                      xmlns:mem-int="https://www.xbrl.org/2006/xbrldi-2006.xsd">
                    %s
                </root>
                """.formatted(xmlFragment.trim());
    }
}