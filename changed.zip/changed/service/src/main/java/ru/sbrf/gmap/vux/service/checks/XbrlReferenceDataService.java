package ru.sbrf.gmap.vux.service.checks;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.entity.AdmXbrlEnumValuesEntity;
import ru.sbrf.gmap.vux.entity.VuxDataXbrlLinkEntity;
import ru.sbrf.gmap.vux.repository.AdmXbrlEnumValuesRepository;
import ru.sbrf.gmap.vux.repository.VuxDataXbrlLinkRepository;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Общий справочный слой для CUV-проверок (не зависит от конкретной формы):
 * маппинги колонок из {@code t_adm_data_xbrl_link} и enum-значения
 * из {@code t_adm_xbrl_enum_values}.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class XbrlReferenceDataService {

    private final VuxDataXbrlLinkRepository vuxDataXbrlLinkRepository;
    private final AdmXbrlEnumValuesRepository admXbrlEnumValuesRepository;

    /**
     * Загружает XBRL-линки (справочник маппингов колонок).
     */
    public List<VuxDataXbrlLinkEntity> loadXbrlLinks() {
        return vuxDataXbrlLinkRepository.findAll();
    }

    /**
     * Загружает enum-значения и собирает карту по ключу
     * {@code taxonomy_id|enumId|enumValueCode}.
     */
    public Map<String, AdmXbrlEnumValuesEntity> loadEnumValuesMap() {
        return admXbrlEnumValuesRepository.findAll().stream() // todo возможно удалить
                .collect(Collectors.toMap(
                        e -> e.getId().getTaxonomy_id() + "|" + e.getId().getEnumId() + "|" + e.getId().getEnumValueCode(),
                        Function.identity(),
                        (a, b) -> a
                ));
    }
}
