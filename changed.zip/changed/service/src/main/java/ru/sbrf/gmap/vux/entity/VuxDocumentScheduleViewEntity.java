package ru.sbrf.gmap.vux.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import org.hibernate.annotations.Immutable;
import ru.sbrf.gmap.vux.entity.enums.MailStatusEnum;
import ru.sbrf.gmap.vux.entity.enums.MailType;
import ru.sbrf.gmap.vux.entity.enums.ResultCodeEnum;
import ru.sbrf.gmap.vux.entity.enums.ScheduleStatusEnum;
import ru.sbrf.gmap.vux.entity.enums.ValidationStatusEnum;
import ru.sbrf.gmap.vux.model.DocumentTypeEnum;

import java.sql.Date;
import java.sql.Timestamp;

@Immutable
@Entity
@Table(name = "v_vux_document_shedule_int")
@Data
public class VuxDocumentScheduleViewEntity {

    @Id
    @Column(name = "shedule_id")
    private Integer scheduleId;

    @Column(name = "report_dt")
    private Date reportDate;

    @Column(name = "doc_id")
    private Integer documentId;

    @Column(name = "result_doc_id")
    private Integer resultDocumentId;

    @Column(name = "result_code")
    @Enumerated(EnumType.ORDINAL)
    private ResultCodeEnum resultCode;

    @Column(name = "start_date")
    private Date startDate;

    @Column(name = "deadline_date")
    private Date deadlineDate;

    @Column(name = "shedule_status")
    @Enumerated(EnumType.ORDINAL)
    private ScheduleStatusEnum scheduleStatus;

    @Column(name = "ecm_id")
    private String ecmId;

    @Column(name = "ecm_status")
    private String ecmStatus;

    @Column(name = "supz_task_id")
    private String supzTaskId;

    @Column(name = "supz_status")
    private String supzStatus;

    @Column(name = "validation_status")
    @Enumerated(EnumType.ORDINAL)
    private ValidationStatusEnum validationStatus;

    @Column(name = "mail_status")
    @Enumerated(EnumType.ORDINAL)
    private MailStatusEnum mailStatus;

    @Column(name = "doc_number")
    private String docNumber;

    @Column(name = "doc_type_name")
    private String docTypeName;

    @Column(name = "doc_type_code")
    private String docTypeCode;

    @Column(name = "ecm_class_name")
    private DocumentTypeEnum ecmClassName;

    @Column(name = "mail_type")
    @Enumerated(EnumType.STRING)
    private MailType mailType;

    @Column(name = "mail_receivers_list")
    private String mailReceiversList;

    @Column(name = "mail_copy_list")
    private String mailCopyList;

    @Column(name = "doc_created")
    private Timestamp docCreated;

    @Column(name = "doc_type_id")
    private Integer docTypeId;

    @Column(name = "doc_type_short_name")
    private String docTypeShortName;

    @Column(name = "supz_task_type")
    private String supzTaskType;

    @Column(name = "id_label")
    private String idLabel;

    @Column(name = "check_count")
    private Integer checkCount;

    @Column(name = "error_count")
    private Long errorCount;

    @Column(name = "warning_count")
    private Long warningCount;

    @Column(name = "flags")
    private String flags;

    @Column(name = "check_mode")
    private String checkMode;

    @Column(name = "workflow_run_id")
    private Long workflowRunId;

    @Column(name = "table_name")
    private String tableName;

    @Column(name = "table_units_name")
    private String tableUnitsName;

    @Column(name = "table_values_name")
    private String tableValuesName;

    @Column(name = "table_context_name")
    private String tableContextName;

}
