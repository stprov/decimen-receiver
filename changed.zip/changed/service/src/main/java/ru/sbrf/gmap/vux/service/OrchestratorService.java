package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.repository.VuxDocumentScheduleViewRepository;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Оркестратор: расписание через хранимые процедуры, получение задач и диспетчеризация
 * записей по стратегиям {@link DocumentProcessingService} (новый/существующий документ).
 * <p>
 * Расписание закрывается ({@code fn_flow_resolve_shedule}, статус 3 — запись уходит из view)
 * только если стратегия вернула {@link ProcessingResult#COMPLETED}. Иначе запись будет
 * обработана в следующем цикле шедулера.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class OrchestratorService {

    private final VuxDocumentScheduleViewRepository vuxDocumentScheduleViewRepository;
    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;

    /**
     * Стратегии обработки записей, упорядочены {@code @Order}:
     * сначала новые документы (без ECM), затем существующие (с ECM).
     */
    private final List<DocumentProcessingService> documentProcessingServices;

    // TODO: добавить @ShedLock при работе в нескольких экземплярах (Q-3)
    @Scheduled(cron = "${integration.orchestrator.scheduler.cron: 0 */15 * ? * *}")
    public void run() {
        long start = System.currentTimeMillis();
        try {
            initializeSchedule();

            List<VuxDocumentScheduleViewEntity> listOfValidationTasks = getListOfValidationTasks();
            if (listOfValidationTasks.isEmpty()) {
                log.info("[ORCH] No records found for processing. Orchestrator run has been completed.");
                return;
            }

            int completed = 0;
            int pending = 0;
            for (DocumentProcessingService strategy : documentProcessingServices) {
                for (VuxDocumentScheduleViewEntity record : listOfValidationTasks) {
                    if (!strategy.supports(record)) {
                        continue;
                    }
                    ProcessingResult result = strategy.processDocument(record);
                    if (result.isCompleted() && resolveSchedule(record)) {
                        completed++;
                    } else {
                        pending++;
                        log.info("[ORCH] Schedule stays open: scheduleId={}, docId={}", record.getScheduleId(), record.getResultDocumentId());
                    }
                }
            }

            log.info("[ORCH] Orchestrator run completed: total={}, resolved={}, pending={}, durationMs={}",
                    listOfValidationTasks.size(), completed, pending, System.currentTimeMillis() - start);
        } catch (Exception e) {
            log.error("[ORCH] Unexpected error in the orchestrator", e);
        }
    }

    /**
     * Закрывает расписание. Ошибка закрытия не прерывает обработку остальных записей.
     */
    private boolean resolveSchedule(VuxDocumentScheduleViewEntity record) {
        try {
            String result = vuxDocumentValidationResultViewRepository.flowResolveShedule(record.getScheduleId()).orElse(null);
            if (result != null && result.startsWith("расписание")) {
                // Функция сообщает об отказе текстом, без исключения (аналитика 5.4.1)
                log.warn("[ORCH] Schedule was NOT resolved by fn_flow_resolve_shedule: scheduleId={}, docId={}, result='{}'",
                        record.getScheduleId(), record.getResultDocumentId(), result);
                return false;
            }
            log.info("[ORCH] Schedule resolved: scheduleId={}, docId={}, newScheduleId={}",
                    record.getScheduleId(), record.getResultDocumentId(), result);
            return true;
        } catch (Exception e) {
            log.error("[ORCH] Failed to resolve schedule: scheduleId={}, docId={}. It will be processed again in the next cycle.",
                    record.getScheduleId(), record.getResultDocumentId(), e);
            return false;
        }
    }

    /**
     * Получает список задач из представления расписания и логирует статистику по записям.
     */
    private List<VuxDocumentScheduleViewEntity> getListOfValidationTasks() {
        List<VuxDocumentScheduleViewEntity> tasks = vuxDocumentScheduleViewRepository.findAll();
        long newRecords = tasks.stream().filter(it -> it.getEcmId() == null).count();
        var byCheckMode = tasks.stream()
                .collect(Collectors.groupingBy(it -> Objects.toString(it.getCheckMode(), "null"), Collectors.counting()));
        log.info("[ORCH] Found {} records for processing: new={}, existing={}, byCheckMode={}",
                tasks.size(), newRecords, tasks.size() - newRecords, byCheckMode);
        return tasks;
    }

    /**
     * Инициализирует расписание вызовом хранимых процедур.
     */
    private void initializeSchedule() {
        log.info("[ORCH] Starting schedule processing via stored procedures");
        vuxDocumentValidationResultViewRepository.fnLoadShedule();
        vuxDocumentValidationResultViewRepository.processSchedule();
        log.info("[ORCH] Schedule processing via stored procedures completed successfully");
    }
}
