package ru.sbrf.gmap.vux.dto.request.supz;

import com.fasterxml.jackson.annotation.JsonPropertyDescription;

/**
 * Новый формат атрибута task/attachUrls
 */
public record SupzTaskAttachedUrlDto(
        @JsonPropertyDescription("Идентификатор вложения ECM (файла, либо папки)")
        String id,
        @JsonPropertyDescription("Идентификатор конфигурации ECM в РМ ОЦ")
        String ecmSourceSystemId // Идентификатор конфигурации ECM в РМ ОЦ
) {
}
