package ru.sbrf.gmap.vux.client;

import feign.form.spring.converter.SpringManyMultipartFilesReader;
import org.springframework.boot.http.converter.autoconfigure.ClientHttpMessageConvertersCustomizer;
import org.springframework.cloud.openfeign.support.JsonFormWriter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EcmMultipartConfig {

    @Bean
    public ClientHttpMessageConvertersCustomizer multipartConvertersCustomizer() {
        return (clientBuilder) -> clientBuilder.addCustomConverter(new SpringManyMultipartFilesReader(4096));
    }

    @Bean
    JsonFormWriter jsonFormWriter() {
        return new JsonFormWriter();
    }
}
