package ru.sbrf.gmap.vux.exception.ecm;

import lombok.Getter;

@Getter
public class EcmException extends RuntimeException {

    private final ErrorCode errorCode;
    private final Object[] errorMessageArgs;

    public EcmException(ErrorCode errorCode, Object... args) {
        this.errorCode = errorCode;
        this.errorMessageArgs = args;
    }

    @Override
    public String getMessage() {
        return errorCode.getMessage(errorMessageArgs);
    }
}
