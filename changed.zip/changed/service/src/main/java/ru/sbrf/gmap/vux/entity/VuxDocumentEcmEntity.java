package ru.sbrf.gmap.vux.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import org.hibernate.annotations.Immutable;

import java.sql.Timestamp;
import java.util.UUID;

/**
 * Запись выгрузки образа документа (CSV context/unit/value) в ECM — таблица {@code t_vux_document_ecm}.
 * <p>
 * Создаётся функцией {@code fn_xbrl_create_ecm}, обрабатывается внешним сервисом
 * (формирует файл, загружает в ECM, проставляет {@code ecm_id}; при отказе — {@code disabled = 1}).
 * Для VUX — только чтение. Таблица append-only: отклонённые записи остаются,
 * пересоздание — это новая строка.
 */
@Immutable
@Entity
@Data
@Table(name = "t_vux_document_ecm")
public class VuxDocumentEcmEntity {

    public static final short DISABLED = 1;

    @Id
    @Column(name = "xbrl_id")
    private String xbrlId;

    @Column(name = "doc_id")
    private Long docId;

    @Column(name = "ecm_id")
    private UUID ecmId;

    @Column(name = "request_id")
    private String requestId;

    @Column(name = "image_type")
    private String imageType;

    @Column(name = "file_format")
    private String fileFormat;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "archive")
    private Short archive;

    @Column(name = "attempt")
    private Integer attempt;

    @Column(name = "error_code")
    private String errorCode;

    @Column(name = "error_message")
    private String errorMessage;

    @Column(name = "s3_link")
    private String s3Link;

    @Column(name = "s3_del")
    private Short s3Del;

    @Column(name = "created")
    private Timestamp created;

    @Column(name = "updated")
    private Timestamp updated;

    @Column(name = "disabled")
    private Short disabled;

    @Column(name = "sent")
    private Timestamp sent;

    public boolean isDisabled() {
        return disabled != null && disabled == DISABLED;
    }

    public boolean hasEcmId() {
        return ecmId != null;
    }
}
