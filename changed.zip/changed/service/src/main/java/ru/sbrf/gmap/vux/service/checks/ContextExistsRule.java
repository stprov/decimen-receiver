package ru.sbrf.gmap.vux.service.checks;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;

import java.util.Optional;

import static ru.sbrf.gmap.vux.service.utils.ValidateDataCommonUtil.resolveWorkflowRunId;

@Component
@Order(2)
public class ContextExistsRule implements ValidationRule {

    private static final String CHECK_DESCRIPTION = "Проверка что context_id существует в файле value, но отсутствует в context";
    private static final String ERROR_CODE = "DCUV_0420415_1_3_002";

    @Override
    public Optional<ValidationErrorDto> validate(DataContext ctx) {
        if (ctx.contextList().isEmpty()) {
            Long workflowRunId = resolveWorkflowRunId(ctx);
            return Optional.of(new ValidationErrorDto(
                    DEFAULT_TITLE,
                    ERROR_CODE,
                    "По workflow_run_id = %d НЕ получен context.".formatted(workflowRunId)
            ));
        }
        return Optional.empty();
    }

    @Override
    public String getDescription() {
        return CHECK_DESCRIPTION;
    }

    @Override
    public String getCode() {
        return ERROR_CODE;
    }

}