package ru.sbrf.gmap.vux.dto.request.ecm;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AttrStr {

    private String key;
    private String value;
}
