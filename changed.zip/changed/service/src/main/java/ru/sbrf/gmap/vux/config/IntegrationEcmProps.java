package ru.sbrf.gmap.vux.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Map;

@ConfigurationProperties(prefix = "integration.ecm")
public record IntegrationEcmProps(
        Map<String, Object> headers,
        String enabled,
        String url,
        String targetFolder
) {
}
