package ru.sbrf.gmap.vux.entity.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Итоговый статус CUV-проверки документа ({@code t_vux_document_cuv_validation_status.status},
 * функция {@code fn_flow_cuv_set_status}).
 */
@Getter
@RequiredArgsConstructor
public enum CuvValidationStatusEnum {
    /**
     * Не проверен: CUV-проверка выключена, для формы нет проверки в коде или нет данных формы.
     */
    NOT_CHECKED(0),
    /**
     * Проверен без ошибок.
     */
    CHECKED_WITHOUT_ERRORS(1),
    /**
     * Проверен с ошибками.
     */
    CHECKED_WITH_ERRORS(2);

    private final int code;
}
