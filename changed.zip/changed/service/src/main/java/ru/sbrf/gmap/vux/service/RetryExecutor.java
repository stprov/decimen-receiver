package ru.sbrf.gmap.vux.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.function.Supplier;

/**
 * Простые повторные попытки для внешних вызовов, которые сообщают о неуспехе
 * пустым результатом или исключением (ECM-фасад, почта).
 * <p>
 * Используется там, где {@code @Retryable} неприменим, т.к. ошибки перехватываются
 * внутри вызываемого компонента.
 */
@Slf4j
@Component
public class RetryExecutor {

    /**
     * Выполняет действие до первого непустого результата, но не более {@code maxAttempts} раз.
     *
     * @param operation   название операции для логов
     * @param maxAttempts максимальное количество попыток (значение меньше 1 трактуется как 1)
     * @param delayMs     пауза между попытками, мс
     * @param action      действие; пустой результат или исключение считаются неуспехом
     * @return результат первой успешной попытки или {@link Optional#empty()}
     */
    public <T> Optional<T> execute(String operation, int maxAttempts, long delayMs, Supplier<Optional<T>> action) {
        int attempts = Math.max(1, maxAttempts);
        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                Optional<T> result = action.get();
                if (result != null && result.isPresent()) {
                    if (attempt > 1) {
                        log.info("[RETRY] operation='{}' succeeded on attempt {}/{}", operation, attempt, attempts);
                    }
                    return result;
                }
                log.warn("[RETRY] operation='{}' returned empty result, attempt {}/{}", operation, attempt, attempts);
            } catch (Exception e) {
                log.warn("[RETRY] operation='{}' failed on attempt {}/{}: {}", operation, attempt, attempts, e.toString());
            }
            if (attempt < attempts && !sleep(delayMs)) {
                break;
            }
        }
        log.error("[RETRY] operation='{}' failed after {} attempt(s)", operation, attempts);
        return Optional.empty();
    }

    /**
     * Вариант для действий, возвращающих признак успеха.
     */
    public boolean executeBoolean(String operation, int maxAttempts, long delayMs, Supplier<Boolean> action) {
        return execute(operation, maxAttempts, delayMs,
                () -> Boolean.TRUE.equals(action.get()) ? Optional.of(Boolean.TRUE) : Optional.<Boolean>empty())
                .isPresent();
    }

    private boolean sleep(long delayMs) {
        if (delayMs <= 0) {
            return true;
        }
        try {
            Thread.sleep(delayMs);
            return true;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.warn("[RETRY] interrupted while waiting for the next attempt");
            return false;
        }
    }
}
