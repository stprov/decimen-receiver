package ru.sbrf.gmap.vux.entity.base;

import jakarta.persistence.Column;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.UUID;

@NoArgsConstructor
@Data
@MappedSuperclass
public abstract class VuxFormUnitBaseEntity {
    @Id
    @Column(name = "uid")
    private UUID uid;
    @Column(name = "unit_id")
    private String unitId;
    @Column(name = "content")
    private String content;
    @Column(name = "start_date")
    private LocalDate startDate;
    @Column(name = "end_date")
    private LocalDate endDate;
    @Column(name = "taxonomy")
    private String taxonomy;
    @Column(name = "workflow_run_id")
    private Long workflowRunId;

}
