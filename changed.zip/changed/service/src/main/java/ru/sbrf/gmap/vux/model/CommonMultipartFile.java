package ru.sbrf.gmap.vux.model;

import lombok.extern.slf4j.Slf4j;
import org.apache.tika.config.TikaConfig;
import org.apache.tika.exception.TikaException;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.metadata.TikaCoreProperties;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

@Slf4j
public class CommonMultipartFile implements MultipartFile {

    private final String name;
    private final byte[] content;

    public CommonMultipartFile(String name, byte[] content) {
        this.name = name;
        this.content = content;
    }

    //    @NotNull
    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getOriginalFilename() {
        return name;
    }

    @Override
    public String getContentType() {
        try {
            return detectMimeType(name, content);
        } catch (Exception e) {
            log.error("Error while detecting mime-type for " + getName(), e);
            return null;
        }
    }

    @Override
    public long getSize() {
        return content.length;
    }

    @Override
    public boolean isEmpty() {
        return content == null || content.length == 0;
    }

    //    @NotNull
    @Override
    public byte[] getBytes() {
        return content;
    }

    //    @NotNull
    @Override
    public InputStream getInputStream() {
        return new ByteArrayInputStream(content);
    }

    @Override
public void transferTo(File dest) throws IOException {
        try (FileOutputStream f = new FileOutputStream(dest)) {
            f.write(content);
        }
    }

    public String detectMimeType(String filename, byte[] content) throws IOException, TikaException {
        TikaConfig tika = new TikaConfig();
        Metadata metadata = new Metadata();
        metadata.set(TikaCoreProperties.RESOURCE_NAME_KEY, filename);
        return tika.getDetector().detect(TikaInputStream.get(content), metadata).toString();
    }
}