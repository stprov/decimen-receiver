package ru.sbrf.gmap.vux.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

import javax.sql.DataSource;

/**
 * Создаем datasource только после того как поднимется kerberosTicketCachedService и
 * были выпущены TGS и TGT тикеты
 */
@Configuration
@ConditionalOnProperty(value = "test-stand", havingValue = "false", matchIfMissing=true)
public class DataSourceConfig {

    @Value("${spring.datasource.url}")
    private String jdbcUrl;

    @Value("${spring.datasource.username}")
    private String username;

    @Value("${spring.datasource.hikari.connection-test-query}")
    private String connectionTestQuery;

    @Value("${spring.datasource.hikari.maximumPoolSize}")
    private Integer maximumPoolSize;

    @Bean
    @DependsOn("kerberosTicketCachedService")
    public DataSource dataSource() {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(jdbcUrl);
        config.setUsername(username);
        config.setConnectionTestQuery(connectionTestQuery);
        config.setMaximumPoolSize(maximumPoolSize);
        return new HikariDataSource(config);
    }
}
