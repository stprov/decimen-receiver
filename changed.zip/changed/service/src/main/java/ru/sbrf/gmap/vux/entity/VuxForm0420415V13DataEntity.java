package ru.sbrf.gmap.vux.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@Entity
@Table(name = "t_vux_form_0420415_1_3_data")
public class VuxForm0420415V13DataEntity {

    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "kol_pryamoe_repo_peredan")
    private BigDecimal kolPryamoeRepoPeredan;

    @Column(name = "kol_zajm_peredan")
    private BigDecimal kolZajmPeredan;

    @Column(name = "kol_obratnoe_repo_poluchen")
    private BigDecimal kolObratnoeRepoPoluchen;

    @Column(name = "vsego")
    private BigDecimal vsego;

    @Column(name = "itogonp1")
    private BigDecimal itogonp1;

    @Column(name = "kolcprinbuxuch")
    private BigDecimal kolcprinbuxuch;

    @Column(name = "kolpriobrbezpervprizn")
    private BigDecimal kolpriobrbezpervprizn;

    @Column(name = "kolpoluchposdelkamzajma")
    private BigDecimal kolpoluchposdelkamzajma;

    @Column(name = "kol_peredan_zalog_obva_org")
    private BigDecimal kolPeredanZalogObvaOrg;

    @Column(name = "kol_peredan_zalog_obvo_3xlicz")
    private BigDecimal kolPeredanZalogObvo3xlicz;

    @Column(name = "kolobyazpokototsut")
    private BigDecimal kolobyazpokototsut;

    @Column(name = "kolvlozhvkotpriznbeznad")
    private BigDecimal kolvlozhvkotpriznbeznad;

    @Column(name = "kolvlozhvkotoshibzach")
    private BigDecimal kolvlozhvkotoshibzach;

    @Column(name = "kolotsutpobalanschet")
    private BigDecimal kolotsutpobalanschet;

    @Column(name = "naschetdu")
    private BigDecimal naschetdu;

    @Column(name = "nakaznachschet")
    private BigDecimal nakaznachschet;

    @Column(name = "poluchvzaklad")
    private BigDecimal poluchvzaklad;

    @Column(name = "naemissschet")
    private BigDecimal naemissschet;

    @Column(name = "naim_org_uchet")
    private String naimOrgUchet;

    @Column(name = "priznak_org_uchet")
    private String priznakOrgUchet;

    @Column(name = "inn_uchet")
    private String innUchet;

    @Column(name = "ogrn_uchet")
    private String ogrnUchet;

    @Column(name = "oksm_uchet")
    private String oksmUchet;

    @Column(name = "obem_oper_priem")
    private BigDecimal obemOperPriem;

    @Column(name = "obem_oper_snyatie")
    private BigDecimal obemOperSnyatie;

    @Column(name = "obem_oper_perevod")
    private BigDecimal obemOperPerevod;

    @Column(name = "naim__nom_der")
    private String naimNomDer;

    @Column(name = "inn_nom_der")
    private String innNomDer;

    @Column(name = "ogrn_nom_der")
    private String ogrnNomDer;

    @Column(name = "kod_strany_nom_der")
    private String kodStranyNomDer;

    @Column(name = "priznak_nom_der")
    private String priznakNomDer;

    @Column(name = "nom_scheta_nom_der")
    private String nomSchetaNomDer;

    @Column(name = "itogonpmember")
    private BigDecimal itogonpmember;

    @Column(name = "sobremeneniem")
    private BigDecimal sobremeneniem;

    @Column(name = "v_zaloge")
    private BigDecimal vZaloge;

    @Column(name = "uchit_na_torgov_sch")
    private BigDecimal uchitNaTorgovSch;

    @Column(name = "ogran_rasporyazh")
    private BigDecimal ogranRasporyazh;

    @Column(name = "vveden_zapret")
    private BigDecimal vvedenZapret;

    @Column(name = "pod_arestom")
    private BigDecimal podArestom;

    @Column(name = "uchnalicscheskrouagenta")
    private BigDecimal uchnalicscheskrouagenta;

    @Column(name = "uchobnaosnnpaktrf")
    private BigDecimal uchobnaosnnpaktrf;

    @Column(name = "uchobnaosntrebbr")
    private BigDecimal uchobnaosntrebbr;

    @Column(name = "nomerbalansschvtopor")
    private String nomerbalansschvtopor;

    @Column(name = "kolperedanbezprekrpriz")
    private BigDecimal kolperedanbezprekrpriz;

    @Column(name = "kolperedanvdu")
    private BigDecimal kolperedanvdu;

    @Column(name = "kodprinadl_k_sektoru")
    private String kodprinadlKSektoru;

    @Column(name = "kod_str_vl_schet_depo")
    private String kodStrVlSchetDepo;

    @Column(name = "naim_dep")
    private String naimDep;

    @Column(name = "priznak_vysh_dep")
    private String priznakVyshDep;

    @Column(name = "inn_vysh_dep")
    private String innVyshDep;

    @Column(name = "ogrn_dep")
    private String ogrnDep;

    @Column(name = "oksm_vysh_dep")
    private String oksmVyshDep;

    @Column(name = "pervsumosnobpozaklobespipot")
    private BigDecimal pervsumosnobpozaklobespipot;

    @Column(name = "valyuta")
    private String valyuta;

    @Column(name = "nomer_scheta_dep")
    private String nomerSchetaDep;

    @Column(name = "primechanie")
    private String primechanie;

    @Column(name = "vidschetadepo")
    private String vidschetadepo;

    @Column(name = "dealnumber")
    private String dealnumber;

    @Column(name = "instrbrief")
    private String instrbrief;

    @Column(name = "clientbrief")
    private String clientbrief;

    @Column(name = "secbrief")
    private String secbrief;

    @Column(name = "tipczenbum")
    private String tipczenbum;

    @Column(name = "vyshdepbrief")
    private String vyshdepbrief;

    @Column(name = "nomderzbrief")
    private String nomderzbrief;

    @Column(name = "tipoperaczii")
    private String tipoperaczii;

    @Column(name = "id_czennojbumagi")
    private String idCzennojbumagi;

    @Column(name = "grn")
    private String grn;

    @Column(name = "id_stroki")
    private String idStroki;

    @Column(name = "kolnominal")
    private BigDecimal kolnominal;

    @Column(name = "error")
    private String error;

    @Column(name = "warrning")
    private String warrning;

    @Column(name = "ug")
    private BigDecimal ug;

    @Column(name = "row76_woug_increment")
    private BigDecimal row76WougIncrement;

    @Column(name = "pos_vn_increment")
    private BigDecimal posVnIncrement;

    @Column(name = "isin")
    private String isin;

    @Column(name = "kodcfi")
    private String kodcfi;

    @Column(name = "nincrement")
    private BigDecimal nincrement;

    @Column(name = "tradedate")
    private LocalDateTime tradedate;

    @Column(name = "dealid")
    private BigDecimal dealid;

    @Column(name = "xbrlvers")
    private String xbrlvers;

    @Column(name = "kpp_uchet")
    private String kppUchet;

    @Column(name = "kpp_nom_der")
    private String kppNomDer;

    @Column(name = "kpp__dep")
    private String kppDep;

    @Column(name = "naim_emitenta")
    private String naimEmitenta;

    @Column(name = "inn_rekv_em")
    private String innRekvEm;

    @Column(name = "kpp_em")
    private String kppEm;

    @Column(name = "ogrn_em")
    private String ogrnEm;

    @Column(name = "liczen_vysh_dep")
    private String liczenVyshDep;

    @Column(name = "nomer_liczenzii_uchet")
    private String nomerLiczenziiUchet;

    @Column(name = "kod_strany_reg")
    private String kodStranyReg;

    @Column(name = "nominalnaya_stoimost")
    private String nominalnayaStoimost;

    @Column(name = "datestart")
    private LocalDate datestart;

    @Column(name = "dateend")
    private LocalDate dateend;

    @Column(name = "workflow_run_id")
    private Integer workflowRunId;

    @Column(name = "ctl_validfrom")
    private LocalDateTime ctlValidfrom;

    @Column(name = "ctl_loading")
    private Long ctlLoading;

    @Column(name = "xbrlreportdate")
    private LocalDateTime xbrlreportdate;

    @Column(name = "czb_uchtenn_bb")
    private BigDecimal czbUchtennBb;
}