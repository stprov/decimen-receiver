package ru.sbrf.gmap.vux.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.NativeQuery;
import org.springframework.data.repository.query.Param;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V13DataEntity;

import java.util.List;

public interface VuxForm0420415V13DataRepository extends JpaRepository<VuxForm0420415V13DataEntity, Long> {

    /**
     * Не используется в CUV-проверке: сущность {@link VuxForm0420415V13DataEntity} не совпадает с таблицей
     * на тестовом стенде (лишние колонки), запрос падает. Загрузка data — при переписывании проверки 10 (аналитика 7.7).
     */
    List<VuxForm0420415V13DataEntity> findByWorkflowRunId(long workflowRunId);

    /**
     * Версии таксономии ({@code xbrlvers}) строк data по номеру загрузки — для проверки 9.
     */
    @NativeQuery("""
            SELECT DISTINCT xbrlvers
            FROM s_grnplm_as_cib_gm_vux.t_vux_form_0420415_1_3_data
            WHERE workflow_run_id = :workflowRunId""")
    List<String> findTaxonomyVersions(@Param("workflowRunId") long workflowRunId);
}
