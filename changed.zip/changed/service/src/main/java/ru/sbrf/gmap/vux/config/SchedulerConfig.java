package ru.sbrf.gmap.vux.config;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@ConditionalOnProperty(
        value = "config.scheduler.enabled",
        havingValue = "true",
        matchIfMissing = true
)
@Configuration
@Slf4j
//@EnableSchedulerLock(defaultLockAtMostFor = "60m") // TODO добавить потом
public class SchedulerConfig {

    @PostConstruct
    void init() {
        log.info("+=========================+" + "Scheduler is active" + "+=========================+");
    }
}
