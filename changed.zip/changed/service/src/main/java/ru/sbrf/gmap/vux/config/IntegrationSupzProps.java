package ru.sbrf.gmap.vux.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

@ConfigurationProperties(prefix = "integration.supz")
public record IntegrationSupzProps(
        boolean enabled,
        SupzClientConfig supzClientConfig,
        JrpcConfig jrpcConfig,
        SupzConfig supzConfig
) {
    public record JrpcConfig(
            String jsonrpcVersion,
            String method
    ) {
    }

    public record SupzConfig(
            String apiVersion,
            String securityClass,
            String srcId,
            String destId,
            String priority,
            String ecmSourceSystemId,
            List<String> srcTypeIds
    ) {
    }

    public record SupzClientConfig(
            String url,
            String maxAttempts,
            int delay
    ) {
    }
}
