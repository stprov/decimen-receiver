package ru.sbrf.gmap.vux.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V3ValueEntity;

import java.util.UUID;

public interface VuxForm0420415V3ValueRepository extends JpaRepository<VuxForm0420415V3ValueEntity, UUID> {
}
