package ru.sbrf.gmap.vux.service.checks;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.List;

/**
 * Тип образа документа, выгружаемого в ECM через {@code fn_xbrl_create_ecm}
 * ({@code t_vux_document_ecm.image_type}).
 * Значения в верхнем регистре — в таком виде их ожидает внешний сервис формирования CSV.
 */
@Getter
@RequiredArgsConstructor
public enum ImageTypeEnum {
    CONTEXT("CONTEXT"), UNIT("UNIT"), VALUE("VALUE"), XML("XML");

    /**
     * Образы, выгружаемые в CSV после успешной CUV-проверки (порядок = порядок ECM-id в задаче СУПЗ).
     */
    public static final List<ImageTypeEnum> CUV_CSV_TYPES = List.of(CONTEXT, UNIT, VALUE);

    private final String code;
}
