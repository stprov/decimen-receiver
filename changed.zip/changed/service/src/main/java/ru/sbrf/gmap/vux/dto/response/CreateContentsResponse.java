package ru.sbrf.gmap.vux.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import ru.sbrf.gmap.vux.dto.request.ecm.RequestAttr;
import ru.sbrf.gmap.vux.exception.ecm.EcmException;
import ru.sbrf.gmap.vux.exception.ecm.ErrorCode;

import java.util.List;
import java.util.Optional;

@JsonIgnoreProperties(ignoreUnknown = true)
public record CreateContentsResponse(
        List<CreateContentsDocument> documents
) implements EcmResponse {

    @Override
    public ResponseResult getResponseResult() {
        return Optional.ofNullable(documents)
                .map(f -> f.getFirst().result())
                .orElseThrow(() -> new EcmException(ErrorCode.ECM_EMPTY_RESPONSE_ERROR));
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record CreateContentsDocument(
            String id,
            @JsonProperty("class")
            String clazz,
            String target,
            List<RequestAttr> attrs,
            ResponseResult result
    ) {
    }
}