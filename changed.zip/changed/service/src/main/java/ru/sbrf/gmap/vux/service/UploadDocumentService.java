package ru.sbrf.gmap.vux.service;

import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import ru.sber.tfs.domain.UploadFileEcmRq;
import ru.sbrf.gmap.vux.IntegrationEcmTfsProps;
import ru.sbrf.gmap.vux.client.EcmClient;
import ru.sbrf.gmap.vux.config.IntegrationEcmProps;
import ru.sbrf.gmap.vux.config.IntegrationSignProps;
import ru.sbrf.gmap.vux.dto.request.ecm.CreateContentsRequest;
import ru.sbrf.gmap.vux.dto.request.ecm.RequestAttr;
import ru.sbrf.gmap.vux.dto.request.okey.SignatureDto;
import ru.sbrf.gmap.vux.dto.request.ecm.TfsUploadFileRqDto;
import ru.sbrf.gmap.vux.dto.response.CreateContentsResponse;
import ru.sbrf.gmap.vux.model.CommonMultipartFile;
import ru.sbrf.gmap.vux.model.DocumentTypeEnum;
import ru.sbrf.gmap.vux.model.sign.SignRequestDto;
import ru.sbrf.gmap.vux.model.sign.SignResponseDto;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;
import ru.sbrf.gmap.vux.utils.CommonUtils;
import tools.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@Service
@RequiredArgsConstructor
@Slf4j
public class UploadDocumentService {

    private final EcmClient ecmClient;

    private final IntegrationEcmProps integrationEcmProps;


    private final IntegrationSignProps integrationSignProps;
    private final CryptoHashService cryptoHashService;
    private final SignService signService;
    private final ObjectProvider<KafkaTemplate<String, String>> kafkaTemplateBean;

    private final ObjectProvider<IntegrationEcmTfsProps> integrationEcmTfsPropsBean;
    private final ObjectProvider<EcmRqRsSerdesService> ecmRqRsSerdesServiceBean;
    private final ObjectProvider<EcmS3Service> ecmS3ServiceBean;
    private final ObjectProvider<EcmRqResolverService> ecmRqResolverServiceBean;
    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;

    private static final String DATE_TIME_FORMAT_AC_OKEY = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
    private static final String ECM_SUBSYSTEM = "xbrl-csv";
    private final ObjectMapper objectMapper;

    /**
     * Загрузка документа в ECM без подписи.
     */
    public Optional<CreateContentsResponse> uploadDocument(byte[] document, String filename, DocumentTypeEnum documentTypeEnum, List<RequestAttr> attrList) throws IOException {

        MultipartFile multipartFile = new CommonMultipartFile(filename, document);

        Map<String, Object> headers = integrationEcmProps.headers();

        // Генерируем Ecm UUID для запроса
        String rqUid = CommonUtils.UUIDToEcmString(UUID.randomUUID());
        headers.put("id", rqUid);
        var createContentsRequest = CreateContentsRequest.builder()
                .documents(List.of(CreateContentsRequest.CreateContentsDocument.builder()
                        .clazz(documentTypeEnum.getDocumentClazz())
                        .target(integrationEcmProps.targetFolder())
                        .fileName(filename)
                        .name(filename)
                        .attrs(attrList)
                        .signatures(null)
                        .build()))
                .build();

        return Optional.ofNullable(ecmClient.createContents(headers, createContentsRequest, List.of(multipartFile)));
    }

    /**
     * Загрузка документа в ECM с откреплённой электронной подписью.
     * <p>
     * В ECM отправляются два файла в одном multipart-запросе:
     * <ol>
     *     <li>Основной документ (PDF)</li>
     *     <li>Файл с подписью (.sig)</li>
     * </ol>
     * </p>
     *
     * @param document         содержимое PDF-документа
     * @param filename         имя файла документа (без пути)
     * @param signFileBytes    содержимое файла с ЭП (сформированной АС ОКЭЙ)
     * @param signFileName     имя файла подписи
     * @param documentTypeEnum тип документа для определения ECM-класса
     * @param attrList         список атрибутов документа
     * @return ответ ECM {@link CreateContentsResponse}
     * @throws IOException если не удалось сформировать multipart-файл
     */
    public Optional<CreateContentsResponse> uploadDocumentWithSign(
            byte[] document,
            String filename,
            byte[] signFileBytes,
            String signFileName,
            DocumentTypeEnum documentTypeEnum,
            List<RequestAttr> attrList
    ) throws IOException {

        MultipartFile documentFile = new CommonMultipartFile(filename, document);
        MultipartFile signFile = new CommonMultipartFile(signFileName, signFileBytes);

        Map<String, Object> headers = integrationEcmProps.headers();
        String rqUid = CommonUtils.UUIDToEcmString(UUID.randomUUID());
        headers.put("id", rqUid);

        CreateContentsRequest.CreateContentsDocument docRecord = CreateContentsRequest.CreateContentsDocument.builder()
                .clazz(documentTypeEnum.getDocumentClazz())
                .target(integrationEcmProps.targetFolder())
                .fileName(filename)
                .name(filename)
                .attrs(attrList)
                .signatures(List.of(SignatureDto.builder()
                        .signLocation("atFile")
                        .typeSign("PKI")
                        .signFileName(signFileName)
                        .build()))
                .build();

        CreateContentsRequest createContentsRequest = CreateContentsRequest.builder()
                .documents(List.of(docRecord))
                .build();

        log.info("Forming request to upload document with rqUid= '{}', with type='{}', filename='{}' by REST API...", rqUid, documentTypeEnum.getDocumentClazz(), filename);

        CreateContentsResponse response = ecmClient.createContents(headers, createContentsRequest, List.of(documentFile, signFile));

        if (response != null) {
            log.info("Document uploading request was handling successfully: filename='{}', rqUid='{}', status= '{}'", filename, rqUid, response.getResponseResult());
        } else {
            log.warn("Document upload failed: filename='{}', rqUid='{}'", filename, rqUid);
        }

        return Optional.ofNullable(response);
    }

    public void uploadDocumentViaTfs(@NotNull byte[] file, @NotNull String filename, @NotNull DocumentTypeEnum documentType, int resultDocId) {
        UUID rqUid = UUID.randomUUID();
        uploadDocumentViaTfsInternal(UploadDocumentTfsDto.builder()
                .rqUid(rqUid)
                .tfsFileName(CommonUtils.generateTfsFilename(documentType, rqUid, filename))
                .fileContent(file)
                .filename(filename)
                .documentType(documentType)
                .resultDocumentId(resultDocId)
                .saveFileToS3(true)
                .build());
    }

    /**
     * Загрузка документа в ECM по ссылке на объект в S3 (сценарий XBRL-CSV).
     * <p>
     * Файл скачивается из S3 по {@code s3Path} только для расчёта контрольной суммы,
     * определения MIME и подписи. Повторная выгрузка файла в S3 не выполняется:
     * TFS-запрос ссылается на имя объекта из присланного пути, и TFS читает файл
     * напрямую из S3. В случае ошибки сохранения запись фиксируется как ошибочная.
     *
     * @param s3Path       ссылка на объект в S3
     * @param filename     имя файла документа
     * @param documentType тип документа
     * @param sliceId      идентификатор подсистемы (slice_id)
     * @return сформированный {@code rqUid} запроса в ЕСМ
     */
    public UUID uploadDocumentViaTfsByS3Path(@NotNull String s3Path, @NotNull String filename,
                                             @NotNull DocumentTypeEnum documentType,
                                             @NotNull String sliceId) {
        UUID rqUid = UUID.randomUUID();
        // Регистрируем запрос в очереди ECM до отправки в TFS, чтобы строка существовала на любом пути
        // (и для успешной обработки квитанции, и для фиксации ошибки через fn_ecm_request_set_error)
        vuxDocumentValidationResultViewRepository.fnEcmRequestCreate(rqUid.toString(), ECM_SUBSYSTEM, sliceId);
        try {
            TfsBeans beans = resolveTfsBeans();
            byte[] file = beans.ecmS3Service().downloadFileFromS3(s3Path);
            log.info("Trying to upload document with rqUid: '{}', with type:'{}' by S3 path '{}' via TFS...", rqUid, documentType.getDocumentClazz(), s3Path);
            uploadDocumentViaTfsInternal(UploadDocumentTfsDto.builder()
                    .rqUid(rqUid)
                    .tfsFileName(FilenameUtils.getName(s3Path))
                    .fileContent(file)
                    .filename(filename)
                    .documentType(documentType)
                    .saveFileToS3(false)
                    .build());
        } catch (Exception e) {
            String errorText = e.getMessage();
            log.error("Error occurred while uploading document by S3 path '{}' with rqUid: '{}'. Error: '{}'", s3Path, rqUid, errorText, e);
            // Фиксируем ошибку обработки запроса в очереди ECM (fn_ecm_request_set_error)
            vuxDocumentValidationResultViewRepository.fnEcmRequestSetError(rqUid.toString(), errorText);
            throw e;
        }
        return rqUid;
    }

    private void uploadDocumentViaTfsInternal(UploadDocumentTfsDto request) {
        UUID rqUid = request.rqUid();
        String tfsFileName = request.tfsFileName();
        byte[] file = request.fileContent();
        TfsBeans beans = resolveTfsBeans();
        IntegrationEcmTfsProps integrationEcmTfsProps = beans.integrationEcmTfsProps();
        EcmRqRsSerdesService ecmRqRsSerdesService = beans.ecmRqRsSerdesService();
        EcmS3Service ecmS3Service = beans.ecmS3Service();
        EcmRqResolverService ecmRqResolverService = beans.ecmRqResolverService();

        log.info("Trying to upload document with rqUid: '{}', with type:'{}' via TFS...", rqUid, request.documentType().getDocumentClazz());
        String signFileName = CommonUtils.getSignFileName(tfsFileName);
        TfsUploadFileRqDto tfsUploadFileRqDto = TfsUploadFileRqDto.builder()
                .rqUid(rqUid)
                .fileName(request.filename())
                .tfsFileName(tfsFileName)
                .fileContent(file)
                .metaData(Collections.emptyMap())
                .documentTypeEnum(request.documentType())
                .resultDocumentId(request.resultDocumentId())
                .build();

        UploadFileEcmRq uploadFileEcmRq;

        if (integrationSignProps.enabled()) {

            SignRequestDto signRequestDto = cryptoHashService.encrypt(file);
            SignResponseDto signResponseDto = signService.sign(rqUid.toString(), getCurrentIso8601WithOffset(), signRequestDto);
            log.debug("Received a good response from the signature service: '{}'", signResponseDto.cmsSign());

            ecmS3Service.uploadFileToS3(signFileName, signResponseDto.cmsSign().getBytes(StandardCharsets.UTF_8)); // загружаем файл подписи в s3

            uploadFileEcmRq = ecmRqResolverService.createTfsUploadFileEcmRq(tfsUploadFileRqDto, true);
        } else {
            uploadFileEcmRq = ecmRqResolverService.createTfsUploadFileEcmRq(tfsUploadFileRqDto, false);
        }

        if (request.saveFileToS3()) {
            ecmS3Service.uploadFileToS3(tfsFileName, file);
        }
        String xmlUploadFileEcmRq = ecmRqRsSerdesService.writeXml(uploadFileEcmRq);
        kafkaTemplateBean.getObject().send(integrationEcmTfsProps.kafka().producer().topicOut(), xmlUploadFileEcmRq);
        log.info("The upload request was successfully sent to topic: '{}'", integrationEcmTfsProps.kafka().producer().topicOut());

    }

    private TfsBeans resolveTfsBeans() {
        IntegrationEcmTfsProps integrationEcmTfsProps = integrationEcmTfsPropsBean.getIfAvailable();
        if (integrationEcmTfsProps == null || !integrationEcmTfsProps.enabled()) {
            throw new IllegalStateException("Upload file via TFS is not enabled!");
        }
        EcmRqRsSerdesService ecmRqRsSerdesService = ecmRqRsSerdesServiceBean.getIfAvailable();
        EcmS3Service ecmS3Service = ecmS3ServiceBean.getIfAvailable();
        EcmRqResolverService ecmRqResolverService = ecmRqResolverServiceBean.getIfAvailable();
        Stream.of(integrationEcmTfsProps, ecmRqRsSerdesService, ecmS3Service, ecmRqResolverService)
                .filter(Objects::isNull)
                .findFirst()
                .ifPresent(v -> {
                    String message = String.format("Error occurred during TFS upload execution, necessary bean '%s' is not available", v.getClass().getSimpleName());
                    throw new IllegalStateException(message);
                });
        return new TfsBeans(integrationEcmTfsProps, ecmRqRsSerdesService, ecmS3Service, ecmRqResolverService);
    }

    /**
     * Параметры запроса на загрузку документа в ECM через TFS.
     *
     * @param rqUid           уникальный идентификатор запроса
     * @param tfsFileName     имя файла, по которому TFS находит объект в S3
     * @param fileContent     содержимое файла (для MD5, MIME и подписи)
     * @param filename        имя документа в ECM (retrievalName)
     * @param documentType    тип документа
     * @param resultDocumentId идентификатор связанного документа результата (0, если не задан)
     * @param saveFileToS3    true — файл копируется в S3 под tfsFileName; false — объект уже лежит в S3 по присланной ссылке
     */
    @Builder
    private record UploadDocumentTfsDto(
            UUID rqUid,
            String tfsFileName,
            byte[] fileContent,
            String filename,
            DocumentTypeEnum documentType,
            int resultDocumentId,
            boolean saveFileToS3
    ) {
    }

    private record TfsBeans(
            IntegrationEcmTfsProps integrationEcmTfsProps,
            EcmRqRsSerdesService ecmRqRsSerdesService,
            EcmS3Service ecmS3Service,
            EcmRqResolverService ecmRqResolverService
    ) {
    }

    private static String getCurrentIso8601WithOffset() {
        ZonedDateTime now = ZonedDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT_AC_OKEY);
        return now.format(formatter);
    }
}
