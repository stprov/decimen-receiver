package ru.sbrf.gmap.vux.dto.request.ecm;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import ru.sbrf.gmap.vux.dto.request.okey.SignatureDto;

import java.util.List;

@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public record CreateContentsRequest(
        List<CreateContentsDocument> documents
) {
    @Builder
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    public record CreateContentsDocument(
            @JsonProperty("class")
            String clazz,
            String target,
            String fileName,
            String name,
            List<RequestAttr> attrs,
            List<SignatureDto> signatures
    ) {
    }
}