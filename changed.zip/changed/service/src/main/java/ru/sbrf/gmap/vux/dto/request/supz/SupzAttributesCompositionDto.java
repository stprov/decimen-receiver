package ru.sbrf.gmap.vux.dto.request.supz;

import lombok.Builder;
import ru.sbrf.gmap.vux.facade.supz.SupzTaskAttr;

@Builder
public record SupzAttributesCompositionDto(
        @SupzTaskAttr(key = "task/protocolResult", name = "Результат проверки", num = 0)
        String protocolResult,
        @SupzTaskAttr(key = "task/protocolObject", name = "Проверенная форма отчета", num = 1)
        String protocolObject,
        @SupzTaskAttr(key = "task/protocolName", name = "Документ", num = 2)
        String protocolName,
        @SupzTaskAttr(key = "task/protocolNum", name = "Номер документа", num = 3)
        String protocolNum,
        @SupzTaskAttr(key = "task/protocolDate", name = "Дата документа", num = 4)
        String protocolDate
) {
}
