package ru.sbrf.gmap.vux.model.supz.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.ZonedDateTime;

@JsonIgnoreProperties(ignoreUnknown = true)
public record SupzTaskResponseError(

        @JsonProperty("response/data")
        SupzTaskResponseErrorData data,

        @JsonProperty("response/time")
        ZonedDateTime responseTime
) {
}