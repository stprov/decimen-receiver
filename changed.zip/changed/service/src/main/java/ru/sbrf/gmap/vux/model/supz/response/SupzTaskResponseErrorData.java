package ru.sbrf.gmap.vux.model.supz.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public record SupzTaskResponseErrorData(

        @JsonProperty("error/msg")
        String msg,

        @JsonProperty("error/description")
        String description
) {
}