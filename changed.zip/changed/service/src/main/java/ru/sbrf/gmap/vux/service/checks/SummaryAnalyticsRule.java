package ru.sbrf.gmap.vux.service.checks;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ContextDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;
import ru.sbrf.gmap.vux.dto.scenario.full.ExplicitMemberDto;
import ru.sbrf.gmap.vux.dto.scenario.full.FullXmlDto;
import ru.sbrf.gmap.vux.dto.scenario.full.TypedMemberDto;
import ru.sbrf.gmap.vux.entity.VuxDataXbrlLinkEntity;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V13DataEntity;
import ru.sbrf.gmap.vux.service.parser.XmlParserException;
import ru.sbrf.gmap.vux.service.parser.XmlParserService;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/**
 * Правило проверки №10 — сверка данных data ↔ value (DCUV_0420415_1_3_010).
 * <p>
 * Сверяет значения из t_vux_form_0420415_1_3_data (dataList) со значениями
 * из XBRL-файла (valueList) для каждого контекста, используя маппинг из t_adm_data_xbrl_link.
 * <p>
 * Правило остаётся stateless — все данные получает через CheckDataContext.
 */
@Component
@Order(10)
public class SummaryAnalyticsRule implements ValidationRule {

    private static final String CHECK_DESCRIPTION = "Сверка данных data ↔ value";

    private static final String TABLE_NAME = "t_vux_form_0420415_1_3_data";
    private static final String ERROR_CODE = "DCUV_0420415_1_3_010";

    private final XmlParserService xmlParserService;

    public SummaryAnalyticsRule(XmlParserService xmlParserService) {
        this.xmlParserService = xmlParserService;
    }

    /**
     * Проверка выключена до переписывания по постановке (7.7, DEF-21): в протоколе — «Не проверялось» (D-52).
     */
    @Override
    public boolean isEnabled() {
        return false;
    }

    @Override
    public Optional<ValidationErrorDto> validate(DataContext ctx) {
        // todo проверка выключена

//        Long workflowRunId = resolveWorkflowRunId(ctx);
//
//        // Шаг 0. Guard: пустые списки
//        if (ctx.contextList().isEmpty() || ctx.dataList().isEmpty() || ctx.xbrlLinks().isEmpty()) {
//            return Optional.empty();
//        }
//
//        // Шаг 1. Определяем taxonomy из первого контекста
//        String taxonomy = ctx.contextList().getFirst().taxonomy();
//
//        // Шаг 2. Фильтруем xbrlLinks для нашей taxonomy и таблицы
//        List<VuxDataXbrlLinkEntity> links = ctx.xbrlLinks().stream()
//                .filter(l -> taxonomy.equals(l.getId().getTaxonomy()))
//                .filter(l -> TABLE_NAME.equals(l.getId().getTableName()))
//                .toList();
//
//        if (links.isEmpty()) {
//            return Optional.empty();
//        }
//
//        // Шаг 3. Для каждого контекста — поиск записи в data и сверка
//        for (VuxForm0420415V13ContextDto context : ctx.contextList()) {
//            Optional<ValidationErrorDto> error = validateContext(ctx, context, links, taxonomy);
//            if (error.isPresent()) {
//                return error;
//            }
//        }
//
        return Optional.empty();
    }

    @Override
    public String getDescription() {
        return CHECK_DESCRIPTION;
    }

    @Override
    public String getCode() {
        return ERROR_CODE;
    }

    /**
     * Валидация одного контекста: поиск соответствующей data-записи и сверка значений.
     */
    private Optional<ValidationErrorDto> validateContext(
            DataContext ctx,
            VuxForm0420415V13ContextDto context,
            List<VuxDataXbrlLinkEntity> links,
            String taxonomy
    ) {
        // Парсим scenario
        FullXmlDto scenario;
        try {
            scenario = xmlParserService.parse(context.scenario(), FullXmlDto.class);
        } catch (XmlParserException e) {
            return Optional.of(new ValidationErrorDto(
                    DEFAULT_TITLE,
                    ERROR_CODE,
                    "Ошибка парсинга scenario для context_id = %s".formatted(context.contextId())
            ));
        }

        if (scenario == null || scenario.getMembers() == null) {
            return Optional.empty();
        }

        // Извлекаем typedMember: ID_CzennojBumagi и ID_stroki
        String typedIdCzennojBumagi = extractTypedValue(scenario.getMembers(), "dim-int:ID_CzennojBumagiTaxis");
        String typedIdStroki = extractTypedValue(scenario.getMembers(), "dim-int:ID_strokiTaxis");

        // Поиск в dataList по полям idCzennojbumagi и idStroki
        List<VuxForm0420415V13DataEntity> matched = ctx.dataList().stream()
                .filter(d -> typedIdCzennojBumagi == null || typedIdCzennojBumagi.equals(d.getIdCzennojbumagi()))
                .filter(d -> typedIdStroki == null || typedIdStroki.equals(d.getIdStroki()))
                .toList();

        if (matched.isEmpty()) {
            return Optional.of(new ValidationErrorDto(
                    DEFAULT_TITLE,
                    ERROR_CODE,
                    "Не найдена запись в %s по context_id = %s".formatted(TABLE_NAME, context.contextId())
            ));
        }
        if (matched.size() > 1) {
            return Optional.of(new ValidationErrorDto(
                    DEFAULT_TITLE,
                    ERROR_CODE,
                    "Найдено несколько (%d) записей в %s по context_id = %s".formatted(matched.size(), TABLE_NAME, context.contextId())
            ));
        }

        VuxForm0420415V13DataEntity data = matched.getFirst();

        // Шаг 4-6: для каждой link — сверка значений
        return validateLinksForContext(ctx, context, data, links, taxonomy, scenario);
    }

    /**
     * Сверка значений для каждого link маппинга в рамках одного контекста.
     */
    private Optional<ValidationErrorDto> validateLinksForContext(
            DataContext ctx,
            VuxForm0420415V13ContextDto context,
            VuxForm0420415V13DataEntity data,
            List<VuxDataXbrlLinkEntity> links,
            String taxonomy,
            FullXmlDto scenario
    ) {
        for (VuxDataXbrlLinkEntity link : links) {
            // Шаг 4. Проверка analytical_section
            if (link.getAnalyticalSection() != null && !link.getAnalyticalSection().isBlank()) {
                try {
                    FullXmlDto linkXml = xmlParserService.parse(link.getAnalyticalSection(), FullXmlDto.class);
                    if (linkXml == null || linkXml.getMembers() == null) {
                        continue;
                    }
                    String linkValue = findAnalyticalValue(scenario.getMembers(), linkXml.getMembers());
                    // Если analytical_section не совпадает — пропускаем этот link
                    if (!"true".equalsIgnoreCase(linkValue)) {
                        continue;
                    }
                } catch (XmlParserException e) {
                    return Optional.of(new ValidationErrorDto(
                            DEFAULT_TITLE,
                            ERROR_CODE,
                            "Ошибка парсинга analytical_section для link (table=%s, column=%s)"
                                    .formatted(link.getId().getTableName(), link.getId().getColumnName())
                    ));
                }
            }

            // Шаг 5. Определяем XBRL-элемент по column_xbrl_type
            String elementName = switch (link.getColumnXbrlType()) {
                case "measure" -> link.getMeasureId();
                case "enumerator" -> link.getParameterId() != null ? link.getParameterId() : link.getAxisId();
                case "taxis" -> link.getTaxisId();
                default -> null;
            };

            if (elementName == null) {
                continue;
            }

            // Шаг 6. Поиск value
            VuxForm0420415V13ValueDto value = ctx.valueList().stream()
                    .filter(v -> context.contextId().equals(v.contextId())
                            && elementName.equals(v.elementName()))
                    .findFirst()
                    .orElse(null);

            if (value == null) {
                return Optional.of(new ValidationErrorDto(
                        DEFAULT_TITLE,
                        ERROR_CODE,
                        "Не найдено value [element_name=%s] по context_id = %s"
                                .formatted(elementName, context.contextId())
                ));
            }

            // Если nil == "true" — пропускаем
            if ("true".equalsIgnoreCase(value.nil())) {
                continue;
            }

            // Шаг 7. Сверка значений по типу
            String columnName = link.getId().getColumnName();
            String dataValue = extractDataValue(data, columnName);

            if (dataValue == null) {
                continue;
            }

            String xbrlValue = value.value();
            Optional<ValidationErrorDto> valueError = compareValues(
                    link, columnName, dataValue, xbrlValue, context, taxonomy
            );
            if (valueError.isPresent()) {
                return valueError;
            }
        }

        return Optional.empty();
    }

    /**
     * Сравнение значения из БД и XBRL в зависимости от типа колонки.
     */
    private Optional<ValidationErrorDto> compareValues(
            VuxDataXbrlLinkEntity link,
            String columnName,
            String dataValue,
            String xbrlValue,
            VuxForm0420415V13ContextDto context,
            String taxonomy
    ) {
        switch (link.getColumnXbrlType()) {
            case "measure" -> {
                // 7.1 Числовое сравнение
                String formatted = "Выявлены расхождения data ↔ value по context_id = %s: %s (data=%s, value=%s)"
                        .formatted(context.contextId(), columnName, dataValue, xbrlValue);
                try {
                    BigDecimal dataNum = new BigDecimal(dataValue);
                    BigDecimal xbrlNum = new BigDecimal(xbrlValue);
                    if (dataNum.compareTo(xbrlNum) != 0) {
                        return Optional.of(new ValidationErrorDto(
                                DEFAULT_TITLE,
                                ERROR_CODE,
                                formatted
                        ));
                    }
                } catch (NumberFormatException e) {
                    // Если не удалось распарсить как число — сравниваем строки
                    if (!dataValue.equals(xbrlValue)) {
                        return Optional.of(new ValidationErrorDto(
                                DEFAULT_TITLE,
                                ERROR_CODE,
                                formatted
                        ));
                    }
                }
            }
            case "enumerator" -> {
                // 7.2 Enumerator — из value.value() извлекаем код элемента
                String enumCode = extractTypeValue(xbrlValue);
                if (enumCode == null) {
                    return Optional.of(new ValidationErrorDto(
                            DEFAULT_TITLE,
                            ERROR_CODE,
                            "Не удалось извлечь enum-код из value [element_name=%s] по context_id = %s"
                                    .formatted(link.getParameterId(), context.contextId())
                    ));
                }
                if (!enumCode.equals(dataValue)) {
                    return Optional.of(new ValidationErrorDto(
                            DEFAULT_TITLE,
                            ERROR_CODE,
                            "Выявлены расхождения data ↔ value по context_id = %s: %s (data=%s, xbrl=%s)"
                                    .formatted(context.contextId(), columnName, dataValue, enumCode)
                    ));
                }
            }
            case "taxis" -> {
                // 7.3 taxis — значения уже совпали на этапе поиска data
                // Дополнительная сверка не требуется
            }
        }
        return Optional.empty();
    }

    // ======== Вспомогательные методы ========

    /**
     * Извлекает значение typedMember по dimension.
     */
    private String extractTypedValue(List<Object> members, String dimension) {
        return members.stream()
                .filter(TypedMemberDto.class::isInstance)
                .map(TypedMemberDto.class::cast)
                .filter(t -> dimension.equals(t.getDimension()))
                .findFirst()
                .map(TypedMemberDto::getTypedName)
                .orElse(null);
    }

    /**
     * Извлекает значение explicitMember по dimension.
     */
    @SuppressWarnings("unused")
    private String extractExplicitValue(List<Object> members, String dimension) {
        return members.stream()
                .filter(ExplicitMemberDto.class::isInstance)
                .map(ExplicitMemberDto.class::cast)
                .filter(e -> dimension.equals(e.getDimension()))
                .findFirst()
                .map(ExplicitMemberDto::getValue)
                .orElse(null);
    }

    /**
     * Проверяет, совпадает ли analytical_section link-а со scenario контекста.
     * Сравнивает значения explicit-членов из linkXml со значениями соответствующих
     * explicit-членов из scenario. Если все совпали — возвращает "true".
     */
    private String findAnalyticalValue(List<Object> scenarioMembers, List<Object> linkXmlMembers) {
        for (Object linkMember : linkXmlMembers) {
            if (linkMember instanceof ExplicitMemberDto linkExplicit) {
                String dimension = linkExplicit.getDimension();
                String expectedValue = linkExplicit.getValue();

                boolean matched = scenarioMembers.stream()
                        .filter(ExplicitMemberDto.class::isInstance)
                        .map(ExplicitMemberDto.class::cast)
                        .anyMatch(sm -> dimension.equals(sm.getDimension()) && expectedValue.equals(sm.getValue()));

                if (!matched) {
                    return "false";
                }
            }
        }
        return "true";
    }

    /**
     * Извлекает значение из data-entity по имени колонки (snake_case → camelCase → getter).
     */
    private String extractDataValue(VuxForm0420415V13DataEntity data, String columnName) {
        String getterName = "get" + toCamelCase(columnName);
        try {
            Method getter = VuxForm0420415V13DataEntity.class.getMethod(getterName);
            Object value = getter.invoke(data);
            return value == null ? null : value.toString();
        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
            return null;
        }
    }

    /**
     * Конвертирует snake_case в CamelCase (для построения имени getter-метода).
     * Например: "kol_pryamoe_repo_peredan" → "KolPryamoeRepoPeredan"
     */
    private String toCamelCase(String snakeCase) {
        StringBuilder result = new StringBuilder();
        boolean nextUpperCase = true;
        for (int i = 0; i < snakeCase.length(); i++) {
            char c = snakeCase.charAt(i);
            if (c == '_') {
                nextUpperCase = true;
            } else if (nextUpperCase) {
                result.append(Character.toUpperCase(c));
                nextUpperCase = false;
            } else {
                result.append(c);
            }
        }
        return result.toString();
    }

    /**
     * Извлекает код типа из XBRL-значения enumerator.
     * Например: для "Strana_643RusRossiyaMember" → "643"
     */
    private String extractTypeValue(String xbrlValue) {
        if (xbrlValue == null || xbrlValue.isBlank()) {
            return null;
        }
        // Пытаемся найти числовой код между первым подчёркиванием и началом текста
        // Формат: "Strana_643RusRossiyaMember" → "643"
        int firstUnderscore = xbrlValue.indexOf('_');
        if (firstUnderscore < 0) {
            return null;
        }
        StringBuilder digits = new StringBuilder();
        for (int i = firstUnderscore + 1; i < xbrlValue.length(); i++) {
            char c = xbrlValue.charAt(i);
            if (Character.isDigit(c)) {
                digits.append(c);
            } else {
                break;
            }
        }
        return digits.isEmpty() ? null : digits.toString();
    }
}