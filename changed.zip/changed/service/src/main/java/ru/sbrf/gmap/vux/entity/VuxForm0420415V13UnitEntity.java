package ru.sbrf.gmap.vux.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import ru.sbrf.gmap.vux.entity.base.VuxFormUnitBaseEntity;

@Entity
@Table(name = "t_vux_form_0420415_1_3_unit")
public class VuxForm0420415V13UnitEntity extends VuxFormUnitBaseEntity {

}
