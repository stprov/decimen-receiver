package ru.sbrf.gmap.vux.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;
import java.util.Properties;

@ConfigurationProperties(prefix = "mail")
public record MailProps(
        String from,
        String host,
        String protocol,
        int port,
        Properties properties
) {
}
