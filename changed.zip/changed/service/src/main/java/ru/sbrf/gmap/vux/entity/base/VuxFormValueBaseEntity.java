package ru.sbrf.gmap.vux.entity.base;

import jakarta.persistence.Column;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.UUID;

@NoArgsConstructor
@Data
@MappedSuperclass
public abstract class VuxFormValueBaseEntity {
    @Id
    @Column(name = "uid")
    private UUID uid;
    @Column(name = "element_label")
    private String elementLabel;
    @Column(name = "element_url")
    private String elementUrl;
    @Column(name = "element_name")
    private String elementName;
    @Column(name = "value")
    private String value;
    @Column(name = "nil")
    private String nil;
    @Column(name = "context_id")
    private String contextId;
    @Column(name = "unit_id")
    private String unitId;
    @Column(name = "tuple")
    private String tuple;
    @Column(name = "precision")
    private String precision;
    @Column(name = "decimals")
    private String decimals;
    @Column(name = "lang")
    private String lang;
    @Column(name = "start_date")
    private LocalDate startDate;
    @Column(name = "end_date")
    private LocalDate endDate;
    @Column(name = "taxonomy")
    private String taxonomy;
    @Column(name = "workflow_run_id")
    private Long workflowRunId;
}
