package ru.sbrf.gmap.vux.exception.supz;

import feign.FeignException;
import lombok.Getter;
import ru.sbrf.gmap.vux.model.jsonrpc.JsonRpcErrorResponse;
import ru.sbrf.gmap.vux.model.supz.response.SupzTaskResponseError;

/**
 * Декодированное исключение Feign клиента из ответа JSON-RPC.
 */
@Getter
public class JsonRpcResponseException extends FeignException {

    private SupzTaskResponseError data;

    public JsonRpcResponseException(JsonRpcErrorResponse errorResponse) {
        super(Integer.parseInt(errorResponse.code()), errorResponse.message());
        this.data = errorResponse.data();
    }

    public JsonRpcResponseException(int status, String message) {
        super(status, message);
    }
}
