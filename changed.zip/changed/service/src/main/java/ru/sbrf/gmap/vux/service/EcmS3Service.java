package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.IntegrationEcmTfsProps;
import ru.sbrf.gmap.vux.exception.ecm.EcmException;
import ru.sbrf.gmap.vux.exception.ecm.ErrorCode;
import software.amazon.awssdk.core.exception.SdkException;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.core.sync.ResponseTransformer;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.S3Exception;

import java.io.ByteArrayInputStream;

@RequiredArgsConstructor
@Slf4j
@Service
@ConditionalOnProperty(prefix = "integration.ecm.tfs-upload", name = "enabled", havingValue = "true")
public class EcmS3Service {

    private final S3Client ecmS3;
    private final IntegrationEcmTfsProps integrationEcmTfsProps;


    public void uploadFileToS3(String fileName, byte[] fileBodyByteArray) {

        IntegrationEcmTfsProps.EcmS3Properties s3props = integrationEcmTfsProps.s3();
        String fileKey = s3props.folder().isEmpty() ? fileName : s3props.folder() + "/" + fileName;

        PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                .bucket(s3props.bucket())
                .key(fileKey)
                .contentType("application/octet-stream")
                .build();
        try (var inputStream = new ByteArrayInputStream(fileBodyByteArray)) {
            RequestBody body = RequestBody.fromInputStream(inputStream, fileBodyByteArray.length);
            ecmS3.putObject(putObjectRequest, body);

            log.info("File {} successfully uploaded to S3 bucket {}", fileName, s3props.bucket());
        } catch (S3Exception e) {
            log.error("AWS S3 error occurred while uploading file: {}", fileName, e);
            throw new EcmException(ErrorCode.ECM_S3_UPLOAD_ERROR, fileName, s3props.bucket(), e.getMessage());
        } catch (SdkException e) {
            log.error("General SDK error occurred while uploading file: {}", fileName, e);
            throw new EcmException(ErrorCode.ECM_S3_GENERAL_ERROR, fileName, s3props.bucket(), e.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error occurred while uploading file: {}", fileName, e);
            throw new EcmException(ErrorCode.ECM_S3_UNEXPECTED_ERROR, fileName, s3props.bucket(), e.getMessage());
        }
    }

    /**
     * Скачивает файл из S3 по ключу/пути объекта.
     *
     * @param s3Path ключ (путь) объекта в S3
     * @return содержимое файла в виде массива байт
     */
    public byte[] downloadFileFromS3(String s3Path) {
        IntegrationEcmTfsProps.EcmS3Properties s3props = integrationEcmTfsProps.s3();

        GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                .bucket(s3props.bucket())
                .key(s3Path)
                .build();
        try {
            byte[] content = ecmS3.getObject(getObjectRequest, ResponseTransformer.toBytes()).asByteArray();
            log.info("File {} successfully downloaded from S3 bucket {}", s3Path, s3props.bucket());
            return content;
        } catch (S3Exception e) {
            log.error("AWS S3 error occurred while downloading file: {}", s3Path, e);
            throw new EcmException(ErrorCode.ECM_S3_DOWNLOAD_ERROR, s3Path, s3props.bucket(), e.getMessage());
        } catch (SdkException e) {
            log.error("General SDK error occurred while downloading file: {}", s3Path, e);
            throw new EcmException(ErrorCode.ECM_S3_DOWNLOAD_ERROR, s3Path, s3props.bucket(), e.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error occurred while downloading file: {}", s3Path, e);
            throw new EcmException(ErrorCode.ECM_S3_DOWNLOAD_ERROR, s3Path, s3props.bucket(), e.getMessage());
        }
    }
}
