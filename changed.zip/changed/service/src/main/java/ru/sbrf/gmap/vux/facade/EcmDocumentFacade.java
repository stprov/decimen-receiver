package ru.sbrf.gmap.vux.facade;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.dto.request.ecm.RequestAttr;
import ru.sbrf.gmap.vux.dto.response.CreateContentsResponse;
import ru.sbrf.gmap.vux.exception.ecm.EcmAlreadyExistException;
import ru.sbrf.gmap.vux.exception.ecm.EcmUploadException;
import ru.sbrf.gmap.vux.exception.sign.SignIntegrationException;
import ru.sbrf.gmap.vux.model.DocumentTypeEnum;
import ru.sbrf.gmap.vux.service.CryptoHashService;
import ru.sbrf.gmap.vux.service.SignService;
import ru.sbrf.gmap.vux.service.UploadDocumentService;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Сервис для загрузки документа в ECM с предварительным подписанием через АС ОКЭЙ.
 * <p>
 * Последовательность:
 * <ol>
 *     <li>Вычисление ГОСТ-хэша документа (CryptoHashService)</li>
 *     <li>Формирование CMS-подписи через АС ОКЭЙ (SignService)</li>
 *     <li>Загрузка документа + подписи в ECM (UploadDocumentService)</li>
 * </ol>
 * </p>
 * <p>
 * Если сервисы подписи (CryptoHashService, SignService) недоступны (conditional beans),
 * выполняется загрузка документа в ECM без подписи (graceful degradation).
 * </p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class EcmDocumentFacade {

    private static final String SIGNATURE_FILE_SUFFIX = ".sig";
    private static final String DATE_TIME_FORMAT_AC_OKEY = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";

    private final UploadDocumentService uploadDocumentService;
    private final ObjectProvider<CryptoHashService> cryptoHashServiceProvider;
    private final ObjectProvider<SignService> signServiceProvider;

    /**
     * Загружает документ в ECM. Если доступны сервисы подписи (АС ОКЭЙ),
     * то документ предварительно подписывается откреплённой ЭП (CMS).
     * Иначе документ загружается без подписи.
     *
     * @param document         содержимое PDF-документа
     * @param filename         имя файла документа
     * @param documentTypeEnum тип документа (ECM-класс)
     * @param attrList         список ECM-атрибутов
     * @return ответ ECM {@link CreateContentsResponse}
     */
    public Optional<CreateContentsResponse> uploadSignedDocument(
            byte[] document,
            String filename,
            DocumentTypeEnum documentTypeEnum,
            List<RequestAttr> attrList
    ) {
        if (document == null || document.length == 0) {
            log.warn("Cannot upload an empty document. Skipping.");
            return Optional.empty();
        }

        CryptoHashService cryptoHash = cryptoHashServiceProvider.getIfAvailable();
        SignService sign = signServiceProvider.getIfAvailable();

        if (cryptoHash == null || sign == null) {
            log.warn("CryptoHashService or SignService is not available (integration.sign.enabled=false). " +
                    "Uploading document '{}' to ECM without signature.", filename);

            return uploadWithoutSign(document, filename, documentTypeEnum, attrList);
        }

        return uploadWithSign(document, filename, documentTypeEnum, attrList, cryptoHash, sign);
    }

    public Optional<CreateContentsResponse> uploadDocumentByType(DocumentTypeEnum documentTypeEnum, byte[] file, String filename) {
        log.info("Trying to upload document with type:'{}'", documentTypeEnum.getDocumentClazz());
        Optional<CreateContentsResponse> response = Optional.empty();
        try {
            response = uploadDocumentService.uploadDocument(file, filename, documentTypeEnum, Collections.emptyList());
        } catch (EcmAlreadyExistException eaee) {
            log.error("Document with type: '{}' already exists: {}", documentTypeEnum.getDocumentClazz(), eaee.getResponse());
        } catch (EcmUploadException eue) {
            log.error("Upload error: {} - {}", eue.getErrorCode(), eue.getErrorReason());
        } catch (Exception e) {
            log.error("Unknown error: {}", e.getMessage());
        }
        return response;
    }

    public void asyncUploadDocumentByTfs(byte[] file, String filename, DocumentTypeEnum documentType, int resultDocId) {
        log.debug("Trying to upload document by TFS with type:'{}', filename='{}', resultDocID={}", documentType.name(), filename, resultDocId);
        try {
            uploadDocumentService.uploadDocumentViaTfs(file, filename, documentType, resultDocId);
            log.info("Document '{}' was successfully send to upload to ECM via TFS", resultDocId);
        } catch (Exception e) {
            log.error("Failed to send document '{}' to EMC upload. Reason: {}", resultDocId, e.getMessage());
        }
    }

    private Optional<CreateContentsResponse> uploadWithSign(
            byte[] document,
            String filename,
            DocumentTypeEnum documentTypeEnum,
            List<RequestAttr> attrList,
            CryptoHashService cryptoHashService,
            SignService signService
    ) {
        try {
            // Шаг 1: Хэшируем документ
            log.debug("Step 1: Computing hash for document '{}' ({} bytes)", filename, document.length);
            var signRequestDto = cryptoHashService.encrypt(document);

            // Шаг 2: Получаем CMS-подпись от АС ОКЭЙ
            String rqUid = UUID.randomUUID().toString();
            String xRqTm = getCurrentIso8601WithOffset();

            log.debug("Step 2: Sending signing request to SignService, hashId={}", signRequestDto.id());
            var signResponse = signService.sign(rqUid, xRqTm, signRequestDto);

            if (signResponse.cmsSign() == null || signResponse.cmsSign().isBlank()) {
                log.error("SignService returned empty cmsSign. Falling back to upload without signature.");
                return uploadWithoutSign(document, filename, documentTypeEnum, attrList);
            }

            // Декодируем base64 → byte[]
            byte[] signBytes = Base64.getDecoder().decode(signResponse.cmsSign());
            String signFileName = filename + SIGNATURE_FILE_SUFFIX;

            log.debug("Step 3: Uploading document with signature to ECM");
            return uploadDocumentService.uploadDocumentWithSign(
                    document, filename, signBytes, signFileName, documentTypeEnum, attrList);

        } catch (EcmUploadException e) {
            log.error("ECM upload failed for signed document '{}': code={}, reason={}",
                    filename, e.getErrorCode(), e.getErrorReason());
            return Optional.empty();
        } catch (SignIntegrationException sie) {
            log.error("The process of uploading the document to the ECM was unsuccessful due to an error when trying to sign the document: {}", sie.getMessage());
            return Optional.empty();
        } catch (IOException e) {
            log.error("IO error during signed document upload to ECM", e);
            return Optional.empty();
        } catch (Exception e) {
            log.error("Unexpected error during ECM signing and upload for '{}'", filename, e);
            return Optional.empty();
        }
    }

    private Optional<CreateContentsResponse> uploadWithoutSign(
            byte[] document,
            String filename,
            DocumentTypeEnum documentTypeEnum,
            List<RequestAttr> attrList
    ) {
        try {
            return uploadDocumentService.uploadDocument(document, filename, documentTypeEnum, attrList);
        } catch (IOException e) {
            log.error("IO error during document upload to ECM", e);
            return Optional.empty();
        }
    }

    private static String getCurrentIso8601WithOffset() {
        ZonedDateTime now = ZonedDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT_AC_OKEY);
        return now.format(formatter);
    }
}