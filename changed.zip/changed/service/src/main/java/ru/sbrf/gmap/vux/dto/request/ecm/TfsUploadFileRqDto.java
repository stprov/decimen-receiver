package ru.sbrf.gmap.vux.dto.request.ecm;

import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;
import ru.sbrf.gmap.vux.model.DocumentTypeEnum;

import java.util.Map;
import java.util.UUID;

@Data
@Builder
public class TfsUploadFileRqDto {
    @NotNull
    private UUID rqUid;
    @NotNull
    private String fileName;
    @NotNull
    private byte[] fileContent;
    private String tfsFileName;
    private Map<String, String> metaData;
    @NotNull
    private DocumentTypeEnum documentTypeEnum;
    private int resultDocumentId;
}

