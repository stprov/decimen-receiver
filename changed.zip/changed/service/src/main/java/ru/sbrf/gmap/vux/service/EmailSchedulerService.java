package ru.sbrf.gmap.vux.service;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.config.MailSheduledSenderProps;
import ru.sbrf.gmap.vux.entity.EmailInfoScheduleEntity;
import ru.sbrf.gmap.vux.entity.enums.InfoEmailTypeEnum;
import ru.sbrf.gmap.vux.repository.EmailInfoScheduleRepository;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * Сервис рассылки информационных email-писем по расписанию.
 * <p>
 * Запускается по расписанию (cron из конфигурации: {@code config.mail-sheduled-sender.cron}).
 * Выбирает неотправленные записи из витрины v_vux_info_email_shedule (витрина сама возвращает
 * только созревшие и необработанные записи; записи с send_time глубже
 * {@code config.mail-sheduled-sender.max-past-days} дней от текущего момента не обрабатываются),
 * разбивает их по типу письма ({@link InfoEmailTypeEnum}) и для каждой формирует HTML
 * (FreeMarker) → отправляет через MailService:
 * <ul>
 *   <li>{@code PREPARATION} — письмо о начале подготовки отчётности (шаблон mail_reminder.ftl);</li>
 *   <li>{@code VERIFICATION} — письмо о проверке готовности отчётных форм перед сдачей
 *       (шаблон mail_check_reminder.ftl, VUXPCAP-1448).</li>
 * </ul>
 * Управляется feature-toggle {@code config.feature-toggles.scheduled-email}.
 * Рассылка происходит ровно 1 раз: факт отправки фиксируется хранимой процедурой
 * fn_flow_info_email_send, после чего запись исчезает из витрины.
 */
@Slf4j
@Service
@RequiredArgsConstructor
@ConditionalOnProperty(
        value = "config.feature-toggles.scheduled-email",
        havingValue = "true"
)
public class EmailSchedulerService {

    private static final String PREPARATION_TEMPLATE_NAME = "mail_reminder.ftl";
    private static final String VERIFICATION_TEMPLATE_NAME = "mail_check_reminder.ftl";
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    private final Configuration freemarkerConfiguration;
    private final EmailInfoScheduleRepository emailInfoScheduleRepository;
    private final MailService mailService;
    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;
    private final MailSheduledSenderProps mailSheduledSenderProps;

    private Map<InfoEmailTypeEnum, Template> templates;

    @PostConstruct
    public void init() {
        log.info("EmailSchedulerService started");
        Map<InfoEmailTypeEnum, Template> loaded = new EnumMap<>(InfoEmailTypeEnum.class);
        loaded.put(InfoEmailTypeEnum.PREPARATION, loadTemplate(PREPARATION_TEMPLATE_NAME));
        loaded.put(InfoEmailTypeEnum.VERIFICATION, loadTemplate(VERIFICATION_TEMPLATE_NAME));
        this.templates = Collections.unmodifiableMap(loaded);
    }

    /**
     * Основной метод: запуск рассылки по расписанию.
     * Cron берётся из параметра {@code config.mail-sheduled-sender.cron} (по умолчанию каждые 15 минут).
     */
    @Scheduled(cron = "${config.mail-sheduled-sender.cron: 0 */15 * ? * *}")
    public void run() {
        log.info("Starting email schedule sender");

        try {
            LocalDateTime sendTimeFrom = LocalDateTime.now().minusDays(mailSheduledSenderProps.maxPastDays());
            for (InfoEmailTypeEnum type : InfoEmailTypeEnum.values()) {
                List<EmailInfoScheduleEntity> records = emailInfoScheduleRepository
                        .findByInfoEmailTypeAndSendTimeGreaterThanEqualOrderByIdAsc(type, sendTimeFrom);
                if (records.isEmpty()) {
                    log.info("No records of type '{}' found in v_vux_info_email_shedule for processing", type);
                    continue;
                }
                log.info("Found {} record(s) of type '{}' to process", records.size(), type);
                records.forEach(this::processRecord);
            }

            log.info("Email scheduled sender completed successfully");
        } catch (Exception e) {
            log.error("Unexpected error in email schedule sender: '{}'", e.getMessage());
        }
    }

    /**
     * Обработка одной записи витрины: формирование и отправка письма.
     */
    private void processRecord(EmailInfoScheduleEntity record) {
        try {
            InfoEmailTypeEnum type = record.getInfoEmailType();
            if (type == null) {
                log.warn("Skipping schedule record id={} with unknown info email type", record.getId());
                return;
            }

            String subject = buildSubject(record);
            String htmlBody = buildHtmlBody(record);
            List<String> recipients = parseRecipients(record.getReceiversList());
            List<String> ccList = parseRecipients(record.getCopyList());

            if (!mailService.sendMail(subject, htmlBody, recipients, ccList, false)) {
                // DEF-13 / ревью R-7: при сбое отправки факт не фиксируется — запись останется в витрине
                // и будет отправлена в следующем запуске (в пределах mail-sheduled-sender.max-past-days)
                log.error("[MAIL] Info email was NOT sent, record id={} stays for the next run, type='{}'", record.getId(), type);
                return;
            }
            // Фиксируем факт отправки письма через хранимую процедуру (fn_flow_info_email_send)
            vuxDocumentValidationResultViewRepository.fnFlowInfoEmalSend(record.getId());
            log.info("Email sent successfully for record id={}, type='{}'", record.getId(), type);

        } catch (Exception e) {
            log.error("Failed to process email schedule record id='{}', error= '{}'", record.getId(), e.getMessage());
        }
    }

    /**
     * Тема письма по типу.
     * Примеры: "Напоминание о проверке готовности отчетных форм ВУИКС: ..." (VERIFICATION),
     * "Напоминание о подготовке отчетных форм ВУИКС: ..." (PREPARATION).
     */
    private String buildSubject(EmailInfoScheduleEntity record) {
        return switch (record.getInfoEmailType()) {
            case VERIFICATION -> String.format(
                    "Напоминание о проверке готовности отчетных форм ВУИКС: %s за %s",
                    record.getReportingType(), record.getReportDt());
            case PREPARATION -> String.format(
                    "Напоминание о подготовке отчетных форм ВУИКС: %s за %s",
                    record.getReportingType(), record.getReportDt());
        };
    }

    /**
     * Сформировать HTML-тело письма через FreeMarker-шаблон выбранного типа.
     */
    private String buildHtmlBody(EmailInfoScheduleEntity record) {
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("reportingType", record.getReportingType());
            params.put("reportDt", record.getReportDt());
            params.put("deadlineDate", record.getDeadlineDate() != null
                    ? record.getDeadlineDate().format(DATE_FORMATTER) : "");

            switch (record.getInfoEmailType()) {
                case VERIFICATION -> params.put("forms", parseForms(record.getForms()));
                case PREPARATION -> {
                    params.put("forms", record.getForms());
                    params.put("startDate", record.getStartDate() != null
                            ? record.getStartDate().format(DATE_FORMATTER) : "");
                    params.put("taxonomy", record.getTaxonomy());
                    params.put("converterVersion", record.getConverterVersion());
                }
            }

            Writer out = new StringWriter();
            templates.get(record.getInfoEmailType()).process(params, out);
            return out.toString();
        } catch (TemplateException e) {
            log.error("Template processing error for record id={}, error= '{}'", record.getId(), e.getMessage());
            throw new IllegalStateException("Error processing template", e);
        } catch (IOException e) {
            log.error("I/O error processing template for record id={}, error= '{}'", record.getId(), e.getMessage());
            throw new IllegalStateException("I/O error with template", e);
        }
    }

    /**
     * Разбор перечня форм из строки (разделитель: точка с запятой или запятая).
     */
    private List<String> parseForms(String forms) {
        if (forms == null || forms.trim().isEmpty()) {
            return List.of();
        }
        String delimiter = forms.contains(";") ? ";" : ",";
        return Stream.of(forms.split(delimiter))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();
    }

    /**
     * Разбор списка получателей из строки (разделитель: точка с запятой или запятая).
     */
    private List<String> parseRecipients(String recipients) {
        if (recipients == null || recipients.trim().isEmpty()) {
            return List.of();
        }
        String delimiter = recipients.contains(";") ? ";" : ",";
        return Stream.of(recipients.split(delimiter))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();
    }

    private Template loadTemplate(String templateName) {
        try {
            Template template = freemarkerConfiguration.getTemplate(templateName, StandardCharsets.UTF_8.name());
            log.info("Template '{}' loaded and cached successfully", templateName);
            return template;
        } catch (IOException e) {
            log.error("Failed to load template '{}', error= '{}'", templateName, e.getMessage());
            throw new IllegalStateException("Template " + templateName + " not loaded", e);
        }
    }
}
