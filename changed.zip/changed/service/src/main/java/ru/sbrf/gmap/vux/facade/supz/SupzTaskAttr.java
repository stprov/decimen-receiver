package ru.sbrf.gmap.vux.facade.supz;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Описание атрибутов для создания задачи в ППРБ.УПЗ.
 *
 * @see <a href="https://confluence.sberbank.ru/display/UPZ/1.0.0">confluence ППРБ.УПЗ</a>
 * @see <a href="https://confluence.sberbank.ru/pages/viewpage.action?pageId=12863051333#OPNBILLING1520/2303.%D0%91%D0%A2+%D0%A4%D0%A0.[%D0%9F%D0%9F%D0%A0%D0%91.%D0%A3%D0%9F%D0%97]%D0%A3%D0%B2%D0%B5%D0%B4%D0%BE%D0%BC%D0%BB%D0%B5%D0%BD%D0%B8%D0%B5%D0%BF%D0%BE%D0%B4%D0%BE%D0%B3%D0%BE%D0%B2%D0%BE%D1%80%D1%83-3.1.2.1.1%D0%A8%D0%B0%D0%B31%D0%BE%D0%BF%D0%B8%D1%81%D0%B0%D0%BD%D0%B8%D0%B5">confluence</a>
 * Аннотация должна находиться над полями объекта, который передаётся в ППРБ.УПЗ.
 * Описание атрибутов приведены ниже. Также каждый атрибут должен иметь значение ('value'). Значение берётся из значения самого поля объекта.
 * Точнее так:
 * анализируются все поля, помеченные этой аннотацией, а значения этих полей берутся через getter, который обязательно должен быть определён для поля.
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface SupzTaskAttr {

    /**
     * Ключ атрибута.
     * Например: 'task/businessName' - краткое наименование бизнеса
     */
    String key();

    /**
     * Некий "класс" атрибута. У нас не используется и всегда передаётся 'none'
     */
    String clazz() default "none";

    /**
     * Имя (описание) атрибута.
     * Текст для отображения на UI в ППРБ.УПЗ.
     * Например: 'Наименование Бизнеса'
     */
    String name();

    /**
     * Порядковый номер атрибута для отображения на UI
     */
    int num();
}
