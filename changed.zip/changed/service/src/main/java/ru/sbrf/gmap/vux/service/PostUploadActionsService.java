package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.dto.request.supz.SupzAttributesCompositionDto;
import ru.sbrf.gmap.vux.dto.response.CreateContentsResponse;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.entity.enums.MailType;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;
import ru.sbrf.gmap.vux.facade.EcmDocumentFacade;
import ru.sbrf.gmap.vux.facade.supz.SupzTaskFacade;
import ru.sbrf.gmap.vux.model.DocumentTypeEnum;
import ru.sbrf.gmap.vux.model.jsonrpc.SupzTaskResponseWrapper;
import ru.sbrf.gmap.vux.model.supz.request.SupzRequest;
import ru.sbrf.gmap.vux.model.supz.request.SupzTaskDataRequest;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

/**
 * Общие действия стратегий обработки после формирования протокола:
 * загрузка PDF-протокола в ECM, письмо об ошибках, задача в СУПЗ.
 * <p>
 * Каждая операция возвращает признак успеха. При техническом сбое (после ретраев)
 * стратегия прерывает обработку записи и оставляет расписание открытым —
 * следующая попытка будет в следующем цикле шедулера.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class PostUploadActionsService {

    //  TODO: возможно TASK_OBJECT_TEMPLATE нужно будет вынести в Enum
    private static final String TASK_OBJECT_TEMPLATE = "Отчет %d проверочный";
    private static final String TASK_PROTOCOL_SUCCESS_RESULT = "Данные витрины корректны. Можно формировать отчет.";
    private static final String TASK_PROTOCOL_WARNING_RESULT = "Обнаружены предупреждения. Количество: %d. Требуется проверка данных перед формированием отчета.";

    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;
    private final OutputFormingService outputFormingService;
    private final MailService mailService;
    private final SupzTaskFacade supzTaskFacade;
    private final EcmDocumentFacade ecmDocumentFacade;
    private final ProtocolBuildingService protocolBuildingService;
    private final RetryExecutor retryExecutor;

    @Value("${integration.ecm.retry.max-attempts:3}")
    private int ecmMaxAttempts;

    @Value("${integration.ecm.retry.delay-ms:2000}")
    private long ecmRetryDelayMs;

    // ===================== Протокол =====================

    /**
     * Формирует PDF-протокол, загружает его в ECM (с ретраями) и сохраняет присвоенный id
     * через {@code fn_flow_set_ecm_id}.
     *
     * @return ECM-id протокола или {@link Optional#empty()} при сбое
     */
    public Optional<String> uploadProtocol(VuxDocumentScheduleViewEntity record, ProtocolModelDto protocolModelDto) {
        Integer docId = record.getResultDocumentId();
        String pdfName = protocolBuildingService.generateProtocolName(record.getDocTypeCode());
        byte[] pdfContent;
        try {
            pdfContent = outputFormingService.createPdf(protocolModelDto);
        } catch (Exception e) {
            log.error("[ECM] Failed to generate protocol PDF: scheduleId={}, docId={}. Record is skipped until the next scheduler cycle.",
                    record.getScheduleId(), docId, e);
            return Optional.empty();
        }

        final byte[] content = pdfContent;
        final DocumentTypeEnum docType = record.getEcmClassName();
        Optional<CreateContentsResponse> response = retryExecutor.execute(
                "ECM upload protocol docId=" + docId,
                ecmMaxAttempts, ecmRetryDelayMs,
                () -> ecmDocumentFacade.uploadSignedDocument(content, pdfName, docType, List.of()));

        if (response.isEmpty() || response.get().documents() == null || response.get().documents().isEmpty()) {
            log.error("[ECM] Protocol was NOT uploaded to ECM: scheduleId={}, docId={}, fileName='{}'. " +
                    "Record is skipped until the next scheduler cycle.", record.getScheduleId(), docId, pdfName);
            return Optional.empty();
        }

        CreateContentsResponse.CreateContentsDocument doc = response.get().documents().getFirst();
        try {
            // fn_flow_set_ecm_id: id протокола попадает в t_vux_document.ecm_id и далее в ecm_id view расписания
            vuxDocumentValidationResultViewRepository.flowSetEcmId(docId, doc.id(), doc.result().getResultCode());
        } catch (Exception e) {
            log.error("[ECM] Protocol uploaded (ecmId={}) but fn_flow_set_ecm_id failed: scheduleId={}, docId={}. " +
                    "Record is skipped until the next scheduler cycle (protocol will be uploaded again).",
                    doc.id(), record.getScheduleId(), docId, e);
            return Optional.empty();
        }
        log.info("[ECM] Protocol uploaded: scheduleId={}, docId={}, protocolEcmId={}", record.getScheduleId(), docId, doc.id());
        return Optional.of(doc.id());
    }

    // ===================== Пост-обработка (legacy) =====================

    /**
     * Действия после загрузки протокола (стандартный путь и существующие документы):
     * при ошибках — письмо, иначе — задача в СУПЗ с переданными ECM-id.
     *
     * @return {@code true} — обработка завершена, {@code false} — технический сбой
     */
    public boolean handlePostUploadActions(VuxDocumentScheduleViewEntity record, ProtocolModelDto protocolModelDto, List<String> ecmUrls) {
//        if (record.getScheduleStatus() == ScheduleStatusEnum.CHECKED_WITH_ERRORS) { TODO сейчас статус не правильно заполняется на ПРОМ, возможно вернуть
        if (hasErrors(protocolModelDto)) {
            log.info("The document with id={} has errors. Sending a mail.", record.getResultDocumentId());
            return sendErrorMail(record, protocolModelDto);
        }
        // Поведение original: предупреждения считаются по objects (DEF-7 в аналитике — уточняется)
        long warningsCounter = protocolModelDto.getObjects().stream().filter(v -> v.getRuleType() == RuleTypeEnum.W).count();
        log.info("The document with id={} has no errors. Creating a SUPZ task. Warnings: {}", record.getResultDocumentId(), warningsCounter);
        String protocolResult = warningsCounter == 0 ? TASK_PROTOCOL_SUCCESS_RESULT : TASK_PROTOCOL_WARNING_RESULT;
        return createSupzTask(record, ecmUrls, protocolResult);
    }

    /**
     * Есть ли в протоколе записи с ошибками.
     */
    public boolean hasErrors(ProtocolModelDto protocolModelDto) {
        return protocolModelDto.getObjects() != null
                && protocolModelDto.getObjects().stream().anyMatch(v -> v.getRuleType() == RuleTypeEnum.E);
    }

    // ===================== Почта =====================

    /**
     * Письмо об ошибках по документу уже отправлено и зафиксировано ({@code t_vux_mail}, D-34).
     * <p>
     * {@code mail_status} для этого не используется: значение {@code 1} означает и «отправлено»,
     * и «запрещено флагами расписания», а при флаге {@code S} и ошибках только CUV выставлено ещё до обработки.
     */
    public boolean isErrorMailSent(VuxDocumentScheduleViewEntity record) {
        return vuxDocumentValidationResultViewRepository.existsErrorMail(record.getResultDocumentId().longValue());
    }

    /**
     * Формирует и отправляет письмо с ошибками; при успехе фиксирует факт отправки
     * через {@code fn_flow_set_mail_status}.
     *
     * @return {@code true} — письмо отправлено, {@code false} — сбой отправки
     */
    public boolean sendErrorMail(VuxDocumentScheduleViewEntity record, ProtocolModelDto protocolModelDto) {
        Integer documentId = record.getResultDocumentId();
        // XBRL \\\\ 0420415 1.3. Ошибки на отчетную дату 30.11.2025
        String subject = String.format("XBRL \\\\\\\\ %s Ошибки на отчетную дату: %s", record.getDocTypeCode(), protocolModelDto.getDocumentDate());
        String msgBody = outputFormingService.createHtml(protocolModelDto);
        log.debug("Current recievers list is: '{}'", record.getMailReceiversList());
        log.debug("Current cc list is: '{}'", record.getMailCopyList());
        List<String> recipientsList = getMailRecipients(record.getMailReceiversList());
        List<String> ccList = getMailRecipients(record.getMailCopyList());
        String fullRecipientsList = record.getMailReceiversList() + "," + record.getMailCopyList();

        boolean sent = mailService.sendMail(subject, msgBody, recipientsList, ccList);
        if (!sent) {
            log.error("[MAIL] Error mail was NOT sent: scheduleId={}, docId={}, recipients={}. " +
                    "Record is skipped until the next scheduler cycle.", record.getScheduleId(), documentId, recipientsList.size());
            return false;
        }

        // Письмо об ошибках всегда фиксируется с типом «ошибка», независимо от типа письма документа: при ошибках,
        // найденных только CUV-проверкой, тип документа — «успех» (аналитика, D-39)
        String mailCode = MailType.ERROR.toString();
        // Фиксируем факт отправки письма через хранимую процедуру (fn_flow_set_mail_status)
        vuxDocumentValidationResultViewRepository.flowSetMailStatus(documentId, fullRecipientsList, subject, msgBody, mailCode);
        log.info("[MAIL] Error mail sent: scheduleId={}, docId={}, recipients={}, cc={}",
                record.getScheduleId(), documentId, recipientsList.size(), ccList.size());
        return true;
    }

    // ===================== СУПЗ =====================

    /**
     * Текст результата протокола для задачи СУПЗ по количеству предупреждений.
     */
    public String protocolResultText(long warningsCount) {
        return warningsCount == 0
                ? TASK_PROTOCOL_SUCCESS_RESULT
                : String.format(TASK_PROTOCOL_WARNING_RESULT, warningsCount);
    }

    /**
     * Создаёт задачу в СУПЗ (ретраи — в {@code SupzTaskJsonRpcClient}) и сохраняет её через
     * {@code fn_flow_set_supz_id} ({@code t_vux_supz_task} + {@code t_vux_document.supz_status = 1}).
     * <p>
     * Поле view {@code supz_task_id} — это {@code t_vux_document.supz_status}, а не id задачи:
     * {@code 1} = задача уже создана либо её создание запрещено флагом расписания {@code U}.
     * В этом случае задача не создаётся.
     *
     * @param ecmUrls        ECM-идентификаторы документов, прикладываемых к задаче
     * @param protocolResult текст результата протокола
     * @return {@code true} — задача создана (или уже была), {@code false} — технический сбой
     */
    public boolean createSupzTask(VuxDocumentScheduleViewEntity record, List<String> ecmUrls, String protocolResult) {
        Integer docId = record.getResultDocumentId();
        if (record.getSupzTaskId() != null && !record.getSupzTaskId().isEmpty()) {
            log.info("[SUPZ] SUPZ task is already created or disabled by schedule flag 'U' (supz_status={}): " +
                    "scheduleId={}, docId={}. Skipping SUPZ task creation.", record.getSupzTaskId(), record.getScheduleId(), docId);
            return true;
        }

        Optional<SupzTaskResponseWrapper> response = sendSupzCreateTaskRequest(ecmUrls, record, protocolResult);
        if (response.isEmpty()) {
            log.error("[SUPZ] SUPZ task was NOT created: scheduleId={}, docId={}, ecmIds={}. " +
                    "Record is skipped until the next scheduler cycle.", record.getScheduleId(), docId, ecmUrls);
            return false;
        }

        SupzTaskResponseWrapper supzResponse = response.get();
        String taskId = supzResponse.supzTaskResponse().data().taskId().toString();
        try {
            // При успешном создании SUPZ-задачи сохраняем её id и статус через хранимую процедуру (fn_flow_set_supz_id)
            vuxDocumentValidationResultViewRepository.flowSetSupzId(
                    docId, taskId, supzResponse.supzTaskResponse().data().status(), supzResponse.rawResponse());
        } catch (Exception e) {
            log.error("[SUPZ] SUPZ task CREATED (taskId={}) but fn_flow_set_supz_id failed: scheduleId={}, docId={}. " +
                    "Record stays open: the task may be created again in the next cycle — check manually.",
                    taskId, record.getScheduleId(), docId, e);
            return false;
        }
        log.info("[SUPZ] SUPZ task created: scheduleId={}, docId={}, taskId={}, ecmIds={}",
                record.getScheduleId(), docId, taskId, ecmUrls);
        return true;
    }

    /**
     * Отправка запроса в SUPZ на создание задачи
     */
    private Optional<SupzTaskResponseWrapper> sendSupzCreateTaskRequest(List<String> ecmUrls, VuxDocumentScheduleViewEntity record, String taskProtocolResult) {
        try {
            UUID requestId = UUID.randomUUID();
            log.debug("Sending a request to create a SUPZ task with requestId={} for a document with id={}", requestId, record.getResultDocumentId());
            SupzRequest<SupzTaskDataRequest> request = buildSupzCreateTaskRequest(requestId, ecmUrls, record, taskProtocolResult);
            SupzTaskResponseWrapper responseWrapper = supzTaskFacade.createTask(request, requestId);
            return Optional.ofNullable(responseWrapper);
        } catch (Exception e) {
            log.error("Error when creating a SUPZ task for a document with id={}", record.getResultDocumentId(), e);
            return Optional.empty();
        }
    }

    /**
     * Построение запроса на создание задачи в SUPZ
     */
    private SupzRequest<SupzTaskDataRequest> buildSupzCreateTaskRequest(UUID requestId, List<String> ecmUrls, VuxDocumentScheduleViewEntity record, String protocolResult) {
        log.debug("Creating a SUPZ task with requestId={}, for documentId={}", requestId, record.getResultDocumentId());

        String protocolName = protocolBuildingService.generateProtocolName(record.getDocTypeCode());
        String protocolDate = LocalDate.now().toString();
        String protocolObject = String.format(TASK_OBJECT_TEMPLATE, RandomUtils.insecure().randomInt(1, 100000));

        SupzAttributesCompositionDto attributes = SupzAttributesCompositionDto.builder()
                .protocolResult(protocolResult)
                .protocolName(protocolName)
                .protocolDate(protocolDate)
                .protocolNum(record.getDocNumber())
                .protocolObject(protocolObject)
                .build();
        return supzTaskFacade.buildSupzCreateTaskRequest(requestId, ecmUrls, attributes);
    }

    private List<String> getMailRecipients(String recipients) {
        if (recipients == null || recipients.trim().isEmpty()) {
            return List.of();
        }
        return Stream.of(recipients.split(";"))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();
    }
}
