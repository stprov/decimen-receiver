package ru.sbrf.gmap.vux.service.parser;

/**
 * Исключение при парсинге XML через XmlParserService.
 */
public class XmlParserException extends RuntimeException {

    public XmlParserException(String message, Throwable cause) {
        super(message, cause);
    }
}