package ru.sbrf.gmap.vux.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.ZonedDateTime;

public record EcmErrorResponse(
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
        ZonedDateTime timestamp,
        @JsonProperty(value = "status")
        int status,
        @JsonProperty(value = "error")
        String error,
        @JsonProperty(value = "path")
        String path
) {
}
