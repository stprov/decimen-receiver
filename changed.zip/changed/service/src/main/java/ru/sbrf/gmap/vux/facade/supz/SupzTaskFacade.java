package ru.sbrf.gmap.vux.facade.supz;

import feign.Response;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.json.JsonParseException;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.client.feign.SupzTaskJsonRpcClient;
import ru.sbrf.gmap.vux.config.IntegrationSupzProps;
import ru.sbrf.gmap.vux.dto.request.supz.SupzAttributesCompositionDto;
import ru.sbrf.gmap.vux.exception.supz.JsonRpcResponseException;
import ru.sbrf.gmap.vux.exception.supz.SupzErrorResponse;
import ru.sbrf.gmap.vux.model.jsonrpc.JsonRpcRequest;
import ru.sbrf.gmap.vux.model.jsonrpc.JsonRpcResponse;
import ru.sbrf.gmap.vux.model.jsonrpc.SupzTaskResponseWrapper;
import ru.sbrf.gmap.vux.model.supz.request.SupzStatusDataRequest;
import ru.sbrf.gmap.vux.dto.request.supz.SupzTaskAttachedUrlDto;
import ru.sbrf.gmap.vux.model.supz.request.SupzRequest;
import ru.sbrf.gmap.vux.model.supz.request.SupzTaskDataRequest;
import ru.sbrf.gmap.vux.utils.FeignUtils;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.lang.reflect.Field;
import java.time.ZonedDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
@Component
@RequiredArgsConstructor
@ConditionalOnProperty(value = "integration.supz.enabled", havingValue = "true")
public final class SupzTaskFacade {
    private final IntegrationSupzProps integrationSupzProps;
    private final ObjectMapper objectMapper;
    private final SupzTaskJsonRpcClient supzTaskJsonRpcClient;
    private final JsonRpcService jsonRpcService;

    public SupzRequest<SupzTaskDataRequest> buildSupzCreateTaskRequest(UUID srcId, List<String> ecmUrlList, SupzAttributesCompositionDto attributes) {
        ZonedDateTime currentDate = ZonedDateTime.now();
        List<SupzTaskAttachedUrlDto> attachedUrlDtos = mapAttachUrls(ecmUrlList, integrationSupzProps.supzConfig().ecmSourceSystemId());
        JsonNode attributesNode = buildAttributes(attributes);
        SupzTaskDataRequest supzTaskDataRequest = SupzTaskDataRequest.builder()
                .srcTypeId(integrationSupzProps.supzConfig().srcTypeIds())
                .taskSrcId(srcId)
                .srcStatus("new")
                .srcRegisterTime(currentDate)
                .srcPriority(integrationSupzProps.supzConfig().priority())
                .attachUrls(attachedUrlDtos)
                .attributes(attributesNode)
                .build();

        return getBaseRequest(supzTaskDataRequest, UpzRequestTypesEnum.OPERATION_TASK_CREATE);
    }

    public SupzRequest<SupzStatusDataRequest> buildSupzStatusRequest(UUID taskId, List<String> reqAttributes) {
        SupzStatusDataRequest supzStatusDataRequest = new SupzStatusDataRequest(taskId, reqAttributes);
        return getBaseRequest(supzStatusDataRequest, UpzRequestTypesEnum.OPERATION_TASK_STATUS);
    }


    private <T> SupzRequest<T> getBaseRequest(T data, UpzRequestTypesEnum type) {
        return SupzRequest.<T>builder()
                .apiVersion(integrationSupzProps.supzConfig().apiVersion())
                .type(type.getRequestType())
                .time(ZonedDateTime.now())
                .srcId(integrationSupzProps.supzConfig().srcId())
                .destId(integrationSupzProps.supzConfig().destId())
                .securityClass(integrationSupzProps.supzConfig().securityClass())
                .data(data)
                .build();
    }

    public SupzTaskResponseWrapper createTask(SupzRequest<SupzTaskDataRequest> taskRequest, UUID requestId) {
        try {
            log.info("SUPZ request RqUID: '{}' is preparing to send.", requestId);
            log.debug("Send supz task request: {}", taskRequest);
            JsonRpcRequest<SupzRequest<SupzTaskDataRequest>> request = jsonRpcService.buildRequest(taskRequest, integrationSupzProps.jrpcConfig().method());
            Response response = supzTaskJsonRpcClient.createTask(request, requestId);
            String rawResponse = FeignUtils.readRawResponse(response);
            JsonRpcResponse jsonRpcResponse = objectMapper.readValue(rawResponse, JsonRpcResponse.class);
            log.info("SUPZ request RqUID: '{}' is successfully sent.", requestId);
            return jsonRpcService.readResponse(jsonRpcResponse, rawResponse);
        } catch (JsonRpcResponseException e) {
            log.error("Json RPC request with RqUID: '{}' returned error: {}", requestId, e.getMessage());
            throw new SupzErrorResponse(e);
        } catch (JsonParseException e) {
            log.error("Error while parsing RPC response with RqUID: '{}' returned error: {}", requestId, e.getMessage());
            throw new SupzErrorResponse(e);
        } catch (IOException e) {
            log.error("Error while stream manipulation for RPC response with RqUID: '{}' returned error: {}", requestId, e.getMessage());
            throw new SupzErrorResponse(e);
        }
    }


    public SupzTaskResponseWrapper requestStatus(SupzRequest<SupzStatusDataRequest> statusRequest, UUID requestId) {
        try {
            log.info("SUPZ status request RqUID: '{}' is preparing to send.", requestId);
            log.info("Send supz task request: {}", statusRequest);
            JsonRpcRequest<SupzRequest<SupzStatusDataRequest>> request = jsonRpcService.buildRequest(statusRequest, integrationSupzProps.jrpcConfig().method());
            Response response = supzTaskJsonRpcClient.checkStatus(request, requestId);
            String rawResponse = FeignUtils.readRawResponse(response);
            JsonRpcResponse jsonRpcResponse = objectMapper.readValue(rawResponse, JsonRpcResponse.class);
            return jsonRpcService.readResponse(jsonRpcResponse, rawResponse);
        } catch (JsonRpcResponseException e) {
            log.error("Json RPC request with RqUID: '{}' returned error: {}", requestId, e.getMessage());
            throw new SupzErrorResponse(e);
        } catch (JsonParseException e) {
            log.error("Error while parsing RPC response with RqUID: '{}' returned error: {}", requestId, e.getMessage());
            throw new SupzErrorResponse(e);
        } catch (IOException e) {
            log.error("Error while stream manipulation for RPC response with RqUID: '{}' returned error: {}", requestId, e.getMessage());
            throw new SupzErrorResponse(e);
        }
    }

    /**
     * Метод для преобразования списка строковых url в список объектов в новом формате СУПЗ
     *
     * @param attachUrls        - список строковых url, в формате EСМ
     * @param ecmSourceSystemId - id конфигурации ECM для Биллинга на стороне СУПЗ
     */
    private static List<SupzTaskAttachedUrlDto> mapAttachUrls(List<String> attachUrls, String ecmSourceSystemId) {
        return Stream.ofNullable(attachUrls)
                .flatMap(Collection::stream)
                .filter(Objects::nonNull)
                .map(url -> new SupzTaskAttachedUrlDto(url, ecmSourceSystemId))
                .collect(Collectors.toList());
    }

    @SneakyThrows
    private JsonNode buildAttributes(SupzAttributesCompositionDto sourceObject) {
        ObjectNode attributes = objectMapper.createObjectNode();

        for (Field field : sourceObject.getClass().getDeclaredFields()) {

            SupzTaskAttr attributeAnnotation = field.getAnnotation(SupzTaskAttr.class);
            if (Objects.nonNull(attributeAnnotation)) {

                Object fieldValue = sourceObject.getClass().getMethod(field.getName()).invoke(sourceObject);
                if (Objects.nonNull(fieldValue)) {
                    SupzTaskAttribute attribute = SupzTaskAttribute.builder()
                            .className(attributeAnnotation.clazz())
                            .name(attributeAnnotation.name())
                            .num(attributeAnnotation.num())
                            .value(fieldValue.toString())
                            .build();
                    attributes.set(attributeAnnotation.key(), objectMapper.valueToTree(attribute));
                }
            }
        }
        return attributes;
    }
}