package ru.sbrf.gmap.vux.service.checks;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ContextDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Component
@Order(5)
public class OrphanContextIdsRule implements ValidationRule {

    private static final String CHECK_DESCRIPTION = "В value отсутствуют лишние значения context_id";
    private static final String ERROR_CODE = "DCUV_0420415_1_3_005";

    @Override
    public Optional<ValidationErrorDto> validate(DataContext ctx) {
        if (ctx.contextList().isEmpty() || ctx.valueList().isEmpty()) {
            return Optional.empty();
        }

        Set<String> contextIds = ctx.contextList().stream()
                .map(VuxForm0420415V13ContextDto::contextId)
                .collect(Collectors.toSet());
        Set<String> valueContextIds = ctx.valueList().stream()
                .map(VuxForm0420415V13ValueDto::contextId)
                .collect(Collectors.toSet());

        Set<String> orphans = new HashSet<>(contextIds);
        orphans.removeAll(valueContextIds);

        if (!orphans.isEmpty()) {
            return Optional.of(new ValidationErrorDto(
                    DEFAULT_TITLE,
                    ERROR_CODE,
                    "Обнаружены лишние context: %s.".formatted(orphans)
            ));
        }
        return Optional.empty();
    }

    @Override
    public String getDescription() {
        return CHECK_DESCRIPTION;
    }

    @Override
    public String getCode() {
        return ERROR_CODE;
    }
}