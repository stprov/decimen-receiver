package ru.sbrf.gmap.vux.dto.csv;

import lombok.Builder;

import java.time.LocalDate;
import java.util.UUID;

@Builder
public record VuxForm0420415V13ValueDto(
        UUID uid,
        String elementLabel,
        String elementUrl,
        String elementName,
        String value,
        String nil,
        String contextId,
        String unitId,
        String tuple,
        String precision,
        String decimals,
        String lang,
        LocalDate startDate,
        LocalDate endDate,
        String taxonomy,
        Long workflowRunId
) {
}
