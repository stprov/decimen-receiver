package ru.sbrf.gmap.vux.facade.supz;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum UpzRequestTypesEnum {
    OPERATION_TASK_CREATE("operation.task/create"),
    OPERATION_TASK_STATUS("operation.task/status");

    private final String requestType;
}
