package ru.sbrf.gmap.vux.entity.enums;

public enum ValidationStatusEnum {
    ERRORS_HAVE_BEEN_IDENTIFIED, NO_ERRORS_WERE_FOUND
}
