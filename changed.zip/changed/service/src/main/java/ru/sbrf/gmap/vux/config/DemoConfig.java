package ru.sbrf.gmap.vux.config;

import jakarta.annotation.PostConstruct;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;

/**
 * Класс для демо конфигурации
 * С этими параметрами будет вызвана процедура fn_flow_create_shedules_list
 * Что вызовет создание демо расписания
 */
@ConfigurationProperties(prefix = "config.demo-config", ignoreInvalidFields = true)
@ConditionalOnProperty(value = "config.demo-config.enabled", havingValue = "true")
public record DemoConfig(
        Boolean enabled,
        String pSheduleCode,
        Integer pCustomerId,
        String pDocTypeId,
        String pTaxonomy,
        String pReportDtList,
        String pFlags
) { }
