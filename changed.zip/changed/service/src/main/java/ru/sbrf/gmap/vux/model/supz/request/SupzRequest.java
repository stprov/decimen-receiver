package ru.sbrf.gmap.vux.model.supz.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Builder;

import java.time.ZonedDateTime;

@Builder
public record SupzRequest<T>(

        @NotBlank
        @Size(max = 50)
        @JsonProperty("request/apiVersion")
        String apiVersion,

        @NotBlank
        @Size(max = 50)
        @JsonProperty("request/type")
        String type,

        @NotNull
        @JsonProperty("request/time")
        @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ")
        ZonedDateTime time,

        @NotBlank
        @Size(max = 50)
        @JsonProperty("request/srcId")
        String srcId,

        @NotBlank
        @Size(max = 50)
        @JsonProperty("request/destId")
        String destId,

        @Size(max = 50)
        @JsonProperty("request/securityClass")
        String securityClass,

        @Valid
        @NotNull
        @JsonProperty("request/data")
        T data
) {
}