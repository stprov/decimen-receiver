package ru.sbrf.gmap.vux.entity.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum RuleTypeEnum {
    E("Error"), W("Warning");
    private final String ruleName;
}
