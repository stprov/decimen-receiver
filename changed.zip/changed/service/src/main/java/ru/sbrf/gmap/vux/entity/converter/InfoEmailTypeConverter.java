package ru.sbrf.gmap.vux.entity.converter;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.entity.enums.InfoEmailTypeEnum;

/**
 * Преобразование колонки {@code info_email_type} (smallint) витрины
 * {@code v_vux_info_email_shedule} в {@link InfoEmailTypeEnum}.
 * Неизвестное значение трактуется как null — решение о пропуске записи принимает сервис.
 */
@Converter(autoApply = false)
@Component
@Slf4j
public class InfoEmailTypeConverter implements AttributeConverter<InfoEmailTypeEnum, Integer> {

    @Override
    public Integer convertToDatabaseColumn(InfoEmailTypeEnum attribute) {
        if (attribute == null) return null;
        return attribute.getCode();
    }

    @Override
    public InfoEmailTypeEnum convertToEntityAttribute(Integer dbData) {
        if (dbData == null) return null;
        for (InfoEmailTypeEnum type : InfoEmailTypeEnum.values()) {
            if (type.getCode() == dbData) return type;
        }
        log.warn("Unknown info email type code: {}", dbData);
        return null;
    }
}
