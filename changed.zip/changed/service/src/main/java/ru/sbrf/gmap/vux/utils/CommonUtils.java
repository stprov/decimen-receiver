package ru.sbrf.gmap.vux.utils;

import lombok.experimental.UtilityClass;
import org.apache.commons.io.FilenameUtils;
import org.apache.tika.config.TikaConfig;
import org.apache.tika.exception.TikaException;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.metadata.TikaCoreProperties;
import org.springframework.util.DigestUtils;
import ru.sbrf.gmap.vux.model.DocumentTypeEnum;

import java.io.IOException;
import java.util.UUID;

@UtilityClass
public class CommonUtils {

    private static final String SIGN_FILE_EXTENSION = "sgn";
    private static final String REGEX_UUID_DELIMITED = "(\\p{XDigit}{8})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}+)";

    public static String getSignFileName(String filename) {
        return filename.replace(FilenameUtils.getExtension(filename), "") + SIGN_FILE_EXTENSION;
    }

    public static String calculateMD5(byte[] fileContent) {
        return DigestUtils
                .md5DigestAsHex(fileContent)
                .replaceFirst(REGEX_UUID_DELIMITED, "$1-$2-$3-$4-$5");
    }

    public static String detectMimeType(String filename, byte[] content) throws IOException, TikaException {
        TikaConfig tika = new TikaConfig();
        Metadata metadata = new Metadata();
        metadata.set(TikaCoreProperties.RESOURCE_NAME_KEY, filename);
        return tika.getDetector().detect(TikaInputStream.get(content), metadata).toString();
    }

    public static UUID dashlessUuidToValidUuid(String uuid) {
        return UUID.fromString(uuid.replaceFirst(REGEX_UUID_DELIMITED, "$1-$2-$3-$4-$5"));
    }

    public static UUID ecmStringToUUID(String ecmString) {
        return UUID.fromString(ecmString.replace("{", "").replace("}", ""));
    }

    public static String UUIDToEcmString(UUID uuid) {
        return "{" + uuid.toString().toUpperCase() + "}";
    }

    public String generateTfsFilename(DocumentTypeEnum documentType, UUID rqUid, String filename) {
        return documentType.getDocumentClazz() + "_" + FilenameUtils.getBaseName(filename) + "_" + rqUid + "." + FilenameUtils.getExtension(filename);
    }

    public static byte[] readTestPdfFile(String path) {
        try {
            String resourcePath = path;
            if (resourcePath.startsWith("classpath:")) {
                resourcePath = resourcePath.substring("classpath:".length());
            }
            ClassLoader classLoader = CommonUtils.class.getClassLoader();
            var inputStream = classLoader.getResourceAsStream(resourcePath);
            if (inputStream == null) {
                throw new RuntimeException("Resource not found: " + path);
            }
            return inputStream.readAllBytes();
        } catch (IOException e) {
            throw new RuntimeException("Failed to read test.pdf file", e);
        }
    }
}
