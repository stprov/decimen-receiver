package ru.sbrf.gmap.vux.model.jsonrpc;

import ru.sbrf.gmap.vux.model.supz.response.SupzTaskResponse;

/**
 * Класс-обертка для ответа от SupzTask
 * Нужен чтобы сохранить сырой ответ от Supz
 * @param supzTaskResponse - десериализованный ответ
 * @param rawResponse - сырой ответ
 */
public record SupzTaskResponseWrapper(
        SupzTaskResponse supzTaskResponse,
        String rawResponse
) {
}
