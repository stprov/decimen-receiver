package ru.sbrf.gmap.vux.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.sbrf.gmap.vux.entity.VuxDocumentEntity;

import java.util.Optional;

@Repository
public interface VuxDocumentRepository extends JpaRepository<VuxDocumentEntity, Long> {
    Optional<VuxDocumentEntity> findByDocId(long docId);
}