package ru.sbrf.gmap.vux.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import java.util.Properties;

@Configuration
@RequiredArgsConstructor
@Slf4j
@ConditionalOnProperty(value = "mail.enabled", havingValue = "true")
public class MailConfig {

    private final Environment environment;
    private final MailProps mailProperties;

    @Bean
    public JavaMailSender javaMailSender() {
        log.debug("Mail enabled");
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();

        mailSender.setHost(mailProperties.host());
        mailSender.setPort(mailProperties.port());
        mailSender.setProtocol(mailProperties.protocol());

        mailSender.setUsername(environment.getProperty("MAIL_USER"));
        mailSender.setPassword(environment.getProperty("MAIL_PASSWORD"));
        Properties props = mailSender.getJavaMailProperties();
        props.putAll(mailProperties.properties());
        return mailSender;
    }
}

