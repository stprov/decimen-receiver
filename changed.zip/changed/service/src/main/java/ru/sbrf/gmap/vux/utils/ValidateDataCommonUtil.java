package ru.sbrf.gmap.vux.service.utils;

import lombok.experimental.UtilityClass;
import ru.sbrf.gmap.vux.service.checks.DataContext;

@UtilityClass
public class ValidateDataCommonUtil {
    /**
     * {@code workflow_run_id} проверяемого документа: из view расписания (Q-8 п. 4.1), если задан в контексте,
     * иначе — из первой записи данных формы; данных нет — {@code 0}.
     */
    public static Long resolveWorkflowRunId(DataContext ctx) {
        if (ctx.workflowRunId() != null) {
            return ctx.workflowRunId();
        }
        if (!ctx.contextList().isEmpty()) {
            return ctx.contextList().getFirst().workflowRunId();
        }
        if (!ctx.unitList().isEmpty()) {
            return ctx.unitList().getFirst().workflowRunId();
        }
        if (!ctx.valueList().isEmpty()) {
            return ctx.valueList().getFirst().workflowRunId();
        }
        return 0L;
    }
}
