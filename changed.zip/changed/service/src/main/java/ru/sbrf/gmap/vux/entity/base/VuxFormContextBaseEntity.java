package ru.sbrf.gmap.vux.entity.base;

import jakarta.persistence.Column;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.UUID;

@NoArgsConstructor
@Data
@MappedSuperclass
public abstract class VuxFormContextBaseEntity {
    @Id
    @Column(name = "uid")
    private UUID uid;
    @Column(name = "context_id")
    private String contextId;
    @Column(name = "period_type")
    private String periodType;
    @Column(name = "period_value")
    private String periodValue;
    @Column(name = "identifier")
    private String identifier;
    @Column(name = "scheme")
    private String scheme;
    @Column(name = "segment")
    private String segment;
    @Column(name = "scenario")
    private String scenario;
    @Column(name = "start_date")
    private LocalDate startDate;
    @Column(name = "end_date")
    private LocalDate endDate;
    @Column(name = "taxonomy")
    private String taxonomy;
    @Column(name = "workflow_run_id")
    private Long workflowRunId;
}