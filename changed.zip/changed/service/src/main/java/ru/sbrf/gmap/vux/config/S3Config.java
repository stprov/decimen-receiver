package ru.sbrf.gmap.vux.config;


import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ru.sbrf.gmap.vux.IntegrationEcmTfsProps;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.core.internal.http.loader.DefaultSdkHttpClientBuilder;
import software.amazon.awssdk.http.SdkHttpConfigurationOption;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.utils.AttributeMap;

import java.net.URI;

@Configuration
@RequiredArgsConstructor
@ConditionalOnProperty(prefix = "integration.ecm.tfs-upload", value = "enabled", havingValue = "true")
public class S3Config {
    private final IntegrationEcmTfsProps integrationEcmTfsProps;

    @Bean
    public S3Client s3Client() {
        var s3Props = integrationEcmTfsProps.s3();
        // path style access is done by default, if not use
        // .forcePathStyle(true)
        // https://stackoverflow.com/questions/75881298/s3-client-creation-with-aws-sdk-for-java-2-x
        return S3Client.builder()
                .httpClient(
                        new DefaultSdkHttpClientBuilder().buildWithDefaults(
                                AttributeMap.builder()
                                        .put(SdkHttpConfigurationOption.TRUST_ALL_CERTIFICATES, true) // disable ssl for v2
                                        .build()
                        )
                )
                .credentialsProvider(
                        StaticCredentialsProvider.create(
                                AwsBasicCredentials.create(s3Props.accessKeyId(), s3Props.secretAccessKey())
                        )
                )
                .endpointOverride(
                        URI.create(s3Props.url())
                )
                // включение path-Style в отличии от virtual-hosted style который стал по умолчанию
                .forcePathStyle(true)
                .region(Region.US_EAST_1)
                .build();
    }
}
