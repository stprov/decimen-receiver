package ru.sbrf.gmap.vux.service;

import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;

/**
 * Стратегия обработки записи расписания в {@code OrchestratorService}.
 * <p>
 * Реализации регистрируются как бины Spring; оркестратор обходит их в порядке
 * {@code @Order} и передаёт каждой записи, для которых
 * {@link #supports(VuxDocumentScheduleViewEntity)} возвращает {@code true}.
 */
public interface DocumentProcessingService {

    /**
     * Признак того, что данная стратегия обрабатывает переданную запись
     * (например, по наличию/отсутствию {@code ecmId}).
     */
    boolean supports(VuxDocumentScheduleViewEntity record);

    /**
     * Обрабатывает запись расписания (валидация, протокол, пост-обработка).
     * Реализация не должна выбрасывать исключения: при техническом сбое
     * возвращается {@link ProcessingResult#PENDING}.
     *
     * @return {@link ProcessingResult#COMPLETED} — расписание можно закрыть,
     * {@link ProcessingResult#PENDING} — оставить до следующего цикла шедулера
     */
    ProcessingResult processDocument(VuxDocumentScheduleViewEntity record);
}
