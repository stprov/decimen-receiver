package ru.sbrf.gmap.vux.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import org.hibernate.annotations.Immutable;
import ru.sbrf.gmap.vux.entity.converter.InfoEmailTypeConverter;
import ru.sbrf.gmap.vux.entity.enums.InfoEmailTypeEnum;

import java.time.LocalDateTime;

/**
 * Витрина расписания рассылки информационных email-писем
 * о сроках отчётности по формам XBRL (ВУИКС).
 * <p>
 * Витрина возвращает только неотправленные записи, время отправки которых наступило
 * ({@code mail_time IS NULL AND now() >= send_time}), — дополнительная фильтрация в запросах не требуется.
 * Наполняется внешним процессом.
 */
@Immutable
@Entity
@Table(name = "v_vux_info_email_shedule")
@Data
public class EmailInfoScheduleEntity {

    @Id
    @Column(name = "id")
    Long id;

    /**
     * Тип письма: 0 — о проверке готовности, 1 — о начале подготовки (см. {@link InfoEmailTypeEnum})
     */
    @Convert(converter = InfoEmailTypeConverter.class)
    @Column(name = "info_email_type")
    InfoEmailTypeEnum infoEmailType;

    /**
     * Дата и время отправки письма
     */
    @Column(name = "send_time")
    LocalDateTime sendTime;

    /**
     * Вид отчетности (например: "10-дневной ежемесячной")
     */
    @Column(name = "reporting_type")
    String reportingType;

    /**
     * Отчетный период (например: "май 2026 г.")
     */
    @Column(name = "report_dt")
    String reportDt;

    /**
     * Перечень форм, коды через запятую (например: "0420416, 0420459")
     */
    @Column(name = "forms")
    String forms;

    /**
     * Дата, с которой ожидается отчетность
     */
    @Column(name = "start_date")
    LocalDateTime startDate;

    /**
     * Контрольный срок представления отчетности (дедлайн)
     */
    @Column(name = "deadline_date")
    LocalDateTime deadlineDate;

    /**
     * Версия таксономии (например: "7.1")
     */
    @Column(name = "taxonomy")
    String taxonomy;

    /**
     * Версия ПО "Конвертер" (например: "2.3.3")
     */
    @Column(name = "converter_version")
    String converterVersion;

    /**
     * Email-адреса получателей (To)
     */
    @Column(name = "receivers_list")
    String receiversList;

    /**
     * Email-адреса копии (Cc) — необязательно
     */
    @Column(name = "copy_list")
    String copyList;

}
