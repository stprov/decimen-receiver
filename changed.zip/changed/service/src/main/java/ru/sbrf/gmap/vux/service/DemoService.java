package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import ru.sbrf.gmap.vux.config.DemoConfig;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.util.Objects;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class DemoService {
    private final VuxDocumentValidationResultViewRepository documentValidationResultRepository;
    private final Optional<DemoConfig> demoConfig;

    @SuppressWarnings("OptionalGetWithoutIsPresent")
    public void startDemo() {
        if (isDemoConfigCorrect()) {

            DemoConfig demoConfig = this.demoConfig.get();

            log.info("=================================");
            log.info("Demo mode is enabled");
            log.info("Demo config: {}", demoConfig);
            log.info("=================================");

            try {
                documentValidationResultRepository.demoModeInit(
                        demoConfig.pSheduleCode()
                        , demoConfig.pCustomerId()
                        , demoConfig.pDocTypeId()
                        , demoConfig.pTaxonomy()
                        , demoConfig.pReportDtList()
                        , demoConfig.pFlags());
            } catch (Exception e) {
                log.error("An exception occurred during demo mode initialization. Demo mode failed to start.", e);
            }
        }
    }

    private boolean isDemoConfigCorrect() {
        if (this.demoConfig.isEmpty()) {
            log.debug("Demo mode is skipped because demo config is not present.");
            return false;
        }
        if (!isDemoConfigCorrect(this.demoConfig.get())) {
            log.error("Demo configuration is invalid. Demo mode has been skipped.");
            log.error("Demo config {}", this.demoConfig.get());
            return false;
        }
        return true;
    }

    private boolean isDemoConfigCorrect(DemoConfig demoConfig) {
        return StringUtils.hasText(demoConfig.pSheduleCode())
                && StringUtils.hasText(demoConfig.pTaxonomy())
                && StringUtils.hasText(demoConfig.pReportDtList())
                && Objects.nonNull(demoConfig.pCustomerId())
                && Objects.nonNull(demoConfig.pDocTypeId());
    }
}
