package ru.sbrf.gmap.vux.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValueCheckStrategy;
import ru.sbrf.gmap.vux.dto.templates.ProtocolTableRecordDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationResultViewEntity;

import java.util.List;

@Mapper(
        componentModel = "spring",
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS
)
public interface VuxDocumentValidationResultViewEntityMapper {

    int MAX_ERROR_DESCRIPTION_LENGTH = 256;

    @Mapping(source = "idLabel", target = "objectName")
    @Mapping(source = "idText", target = "isinNumber")
    @Mapping(source = "line", target = "objectNumber")
    @Mapping(target = "errorMessage", expression = "java(trimErrorDescription(entity.getErrorMessage()))")
    ProtocolTableRecordDto toProtocolTableRecordDto(VuxDocumentValidationResultViewEntity entity);

    List<ProtocolTableRecordDto> toProtocolTableRecordDtoList(List<VuxDocumentValidationResultViewEntity> entities);

    default String trimErrorDescription(String errorDescription) {
        if (errorDescription == null || errorDescription.isEmpty()) {
            return errorDescription;
        }
        return errorDescription.length() > MAX_ERROR_DESCRIPTION_LENGTH
                ? errorDescription.substring(0, MAX_ERROR_DESCRIPTION_LENGTH) + "..."
                : errorDescription;
    }
}