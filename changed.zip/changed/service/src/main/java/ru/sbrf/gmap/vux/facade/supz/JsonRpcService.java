package ru.sbrf.gmap.vux.facade.supz;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.config.IntegrationSupzProps;
import ru.sbrf.gmap.vux.exception.supz.JsonRpcResponseException;
import ru.sbrf.gmap.vux.model.jsonrpc.JsonRpcRequest;
import ru.sbrf.gmap.vux.model.jsonrpc.JsonRpcResponse;
import ru.sbrf.gmap.vux.model.jsonrpc.SupzTaskResponseWrapper;

import java.util.Objects;
import java.util.Random;

@Service
@RequiredArgsConstructor
public class JsonRpcService {
    private static final Random RANDOM = new Random();

    private final IntegrationSupzProps integrationSupzProps;

    public <T> JsonRpcRequest<T> buildRequest(T object, String methodName) {
        return JsonRpcRequest.<T>builder()
                .id(generateRandomId())
                .method(methodName)
                .jsonrpc(integrationSupzProps.jrpcConfig().jsonrpcVersion())
                .params(object)
                .build();
    }

    public SupzTaskResponseWrapper readResponse(JsonRpcResponse response, String rawResponse) {
        if (Objects.nonNull(response.result())) {
            return new SupzTaskResponseWrapper(response.result(), rawResponse);
        }
        if (Objects.nonNull(response.error())) {
            throw new JsonRpcResponseException(response.error());
        }
        throw new JsonRpcResponseException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Error read response. Invalid format");
    }

    private String generateRandomId() {
        return Integer.toString(RANDOM.nextInt(Integer.MAX_VALUE));
    }
}
