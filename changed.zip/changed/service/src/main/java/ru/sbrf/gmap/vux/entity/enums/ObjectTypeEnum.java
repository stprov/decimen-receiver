package ru.sbrf.gmap.vux.entity.enums;

public enum ObjectTypeEnum {
    DOC_LINE, DOC_FORM, CROSS_DOC
}
