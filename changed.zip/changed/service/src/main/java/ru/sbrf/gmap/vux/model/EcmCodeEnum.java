package ru.sbrf.gmap.vux.model;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum EcmCodeEnum {

    RESULT_CODE_OBJECT_NOT_UNIQUE("ECM:OBJECT_NOT_UNIQUE"),

    ERROR_CODE_E_NOT_UNIQUE("E_NOT_UNIQUE");

    private final String value;
}
