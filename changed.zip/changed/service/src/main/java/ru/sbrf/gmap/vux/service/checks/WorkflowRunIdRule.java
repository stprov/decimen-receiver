package ru.sbrf.gmap.vux.service.checks;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;

import java.util.Optional;

@Component
@Order(1)
public class WorkflowRunIdRule implements ValidationRule {

    private static final String CHECK_DESCRIPTION = "Проверка на заполненность поля workflow_run_id";
    private static final String ERROR_CODE = "DCUV_0420415_1_3_001";
    private static final String ERROR_MESSAGE =
            "Не удалось определить идентификатор процесса создавшего документ workflow_run_id НЕ заполнен.";


    /**
     * Шаг 1 постановки (7.7): {@code workflow_run_id} документа должен быть определён.
     * Источник — view расписания ({@link DataContext#workflowRunId()}, Q-8 п. 4.1); если в контексте он не задан
     * (тесты), — первая запись данных формы. Отсутствие context — это ошибка шага 2 ({@code _002}), а не этого правила.
     */
    @Override
    public Optional<ValidationErrorDto> validate(DataContext ctx) {
        Long workflowRunId = ctx.workflowRunId() != null
                ? ctx.workflowRunId()
                : ctx.contextList().isEmpty() ? null : ctx.contextList().getFirst().workflowRunId();
        if (workflowRunId == null || workflowRunId <= 0) {
            return Optional.of(new ValidationErrorDto(DEFAULT_TITLE, ERROR_CODE, ERROR_MESSAGE));
        }
        return Optional.empty();
    }

    @Override
    public String getDescription() {
        return CHECK_DESCRIPTION;
    }

    @Override
    public String getCode() {
        return ERROR_CODE;
    }
}