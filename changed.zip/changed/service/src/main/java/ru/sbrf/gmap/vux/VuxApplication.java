package ru.sbrf.gmap.vux;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.resilience.annotation.EnableResilientMethods;
import ru.sbrf.gmap.vux.config.CommonProps;
import ru.sbrf.gmap.vux.config.DemoConfig;
import ru.sbrf.gmap.vux.config.FeatureToogleConfig;
import ru.sbrf.gmap.vux.config.IntegrationEcmProps;
import ru.sbrf.gmap.vux.config.IntegrationSignProps;
import ru.sbrf.gmap.vux.config.IntegrationSupzProps;
import ru.sbrf.gmap.vux.config.KerberosProps;
import ru.sbrf.gmap.vux.config.MailProps;
import ru.sbrf.gmap.vux.config.MailSheduledSenderProps;
import ru.sbrf.gmap.vux.facade.EcmDocumentFacade;
import ru.sbrf.gmap.vux.service.DemoService;

@SpringBootApplication(
//        exclude = {
//        DataSourceAutoConfiguration.class, // TODO удалить
//        DataSourceTransactionManagerAutoConfiguration.class,
//        HibernateJpaAutoConfiguration.class}
)
@RequiredArgsConstructor
@EnableConfigurationProperties(value = {IntegrationEcmProps.class, MailProps.class, CommonProps.class, IntegrationSupzProps.class, KerberosProps.class, DemoConfig.class, IntegrationSignProps.class,
        FeatureToogleConfig.class, IntegrationEcmTfsProps.class, MailSheduledSenderProps.class})
@EnableFeignClients
@EnableResilientMethods
@Slf4j
public class VuxApplication implements CommandLineRunner {

    @Value("${test-stand:false}")
    private boolean testStand;

    private final EcmDocumentFacade ecmDocumentFacade;

    private final DemoService demoService;

    public static void main(String[] args) {
        SpringApplication.run(VuxApplication.class, args);
    }

    @Override
    public void run(String... args) throws InterruptedException { // TODO удалить
        log.info("==================================");
        log.info("CommandLineRunner code is running");
        log.info("==================================");

        demoService.startDemo(); // todo вернуть демо режим

    }
}

