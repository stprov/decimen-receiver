package ru.sbrf.gmap.vux.exception.sign;

import ru.sbrf.gmap.vux.exception.ecm.ErrorCode;

public class SignIntegrationException extends RuntimeException {

    private final Integer errorCode;
    private final String errorDescription;
    private final static String errorText = "Error during sing integration process, code: %s, description: %s";


    public SignIntegrationException(Integer errorCode, String errorDescription) {
        this.errorCode = errorCode;
        this.errorDescription = errorDescription;

    }

    @Override
    public String getMessage() {
        return String.format(errorText, errorCode, errorDescription);
    }
}
