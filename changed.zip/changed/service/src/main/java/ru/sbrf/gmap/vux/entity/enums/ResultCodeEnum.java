package ru.sbrf.gmap.vux.entity.enums;

public enum ResultCodeEnum {
    NO_VIOLATIONS, WITH_VIOLATIONS
}
