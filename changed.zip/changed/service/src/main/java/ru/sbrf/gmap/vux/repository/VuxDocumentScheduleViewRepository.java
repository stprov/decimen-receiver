package ru.sbrf.gmap.vux.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;

import java.util.List;

@Repository
public interface VuxDocumentScheduleViewRepository extends JpaRepository<VuxDocumentScheduleViewEntity, Integer> {
}
