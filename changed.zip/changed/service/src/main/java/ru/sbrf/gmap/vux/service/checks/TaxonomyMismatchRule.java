package ru.sbrf.gmap.vux.service.checks;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ContextDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13UnitDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static ru.sbrf.gmap.vux.service.utils.ValidateDataCommonUtil.resolveWorkflowRunId;

@Component
@Order(9)
public class TaxonomyMismatchRule implements ValidationRule {

    private static final String CHECK_DESCRIPTION = "По workflow_run_id отсутствует несовпадение версий таксономий";
    private static final String ERROR_CODE = "DCUV_0420415_1_3_009";

    @Override
    public Optional<ValidationErrorDto> validate(DataContext ctx) {
        Long workflowRunId = resolveWorkflowRunId(ctx);

        Set<String> taxonomies = new HashSet<>();
        ctx.contextList().stream()
                .map(VuxForm0420415V13ContextDto::taxonomy)
                .forEach(taxonomies::add);
        ctx.unitList().stream()
                .map(VuxForm0420415V13UnitDto::taxonomy)
                .forEach(taxonomies::add);
        ctx.valueList().stream()
                .map(VuxForm0420415V13ValueDto::taxonomy)
                .forEach(taxonomies::add);
        // По постановке таксономия сравнивается и с data (колонка xbrlvers, Q-8 п. 2.3 / 4.2)
        if (ctx.dataTaxonomies() != null) {
            taxonomies.addAll(ctx.dataTaxonomies());
        }

        if (taxonomies.size() > 1) {
            return Optional.of(new ValidationErrorDto(
                    DEFAULT_TITLE,
                    ERROR_CODE,
                    "По workflow_run_id = %d выявлено несовпадение версий таксономий.".formatted(workflowRunId)
            ));
        }
        return Optional.empty();
    }

    @Override
    public String getDescription() {
        return CHECK_DESCRIPTION;
    }

    @Override
    public String getCode() {
        return ERROR_CODE;
    }


}