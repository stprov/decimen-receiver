package ru.sbrf.gmap.vux.service;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import ru.infocrypt.icdigest.ICDigest;
import ru.infocrypt.icdigest.enums.DigestParamSet;
import ru.infocrypt.icdigest.exception.BicryptException;
import ru.sbrf.gmap.vux.model.sign.SignRequestDto;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

@Service
@Slf4j
@ConditionalOnProperty(prefix = "integration.sign", name = "enabled", havingValue = "true")
public class CryptoHashService {

    private ICDigest icDigest;
    private Path tempLibDir;

    private static final String TEMP_DIR_PREFIX = "tmp-native-lib";

    public SignRequestDto encrypt(byte[] data) {
        if (ArrayUtils.isEmpty(data)) {
            throw new IllegalArgumentException("Data for hashing cannot be null or empty");
        }

        try {
            String hash256 = Hex.encodeHexString(icDigest.calcDigest(data, DigestParamSet.HASH_GOST3411_2012_256));
            String hash512 = Hex.encodeHexString(icDigest.calcDigest(data, DigestParamSet.HASH_GOST3411_2012_512));

            return new SignRequestDto(
                    UUID.randomUUID().toString(),
                    new SignRequestDto.Hashes(hash256, hash512),
                    SignRequestDto.ProvideCerts.SIGNER
            );
        } catch (BicryptException e) {
            throw new RuntimeException("Error calculating hash using ICDigest", e);
        }
    }

    @PostConstruct
    private void initIcDigest() {
        try {
            tempLibDir = Files.createTempDirectory(TEMP_DIR_PREFIX);
            tempLibDir.toFile().deleteOnExit();
            icDigest = new ICDigest(tempLibDir.toString());
        } catch (IOException e) {
            throw new RuntimeException("Failed to create temporary directory for ICDigest library", e);
        } catch (UnsatisfiedLinkError e) {
            throw new RuntimeException("ICDigest native library not loaded", e);
        } catch (Exception e) {
            throw new RuntimeException("Error initializing ICDigest", e);
        }
    }

    @PreDestroy
    private void cleanup() {
        if (tempLibDir != null && Files.exists(tempLibDir)) {
            try {
                Files.walk(tempLibDir)
                        .sorted(java.util.Comparator.reverseOrder())
                        .forEach(path -> {
                            try {
                                Files.delete(path);
                            } catch (IOException e) {
                                log.error("Failed to delete temporary file: " + path + " — " + e.getMessage());
                            }
                        });
            } catch (IOException e) {
                System.err.println("Error traversing temporary files: " + e.getMessage());
            }
        }
    }
}
