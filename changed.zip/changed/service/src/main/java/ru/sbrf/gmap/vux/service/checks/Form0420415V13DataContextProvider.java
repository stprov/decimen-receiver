package ru.sbrf.gmap.vux.service.checks;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ContextDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13UnitDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V13ContextEntity;
import ru.sbrf.gmap.vux.mapper.VuxForm0420415V13ContextMapper;
import ru.sbrf.gmap.vux.mapper.VuxForm0420415V13UnitMapper;
import ru.sbrf.gmap.vux.mapper.VuxForm0420415V13ValueMapper;
import ru.sbrf.gmap.vux.repository.VuxForm0420415V13ContextRepository;
import ru.sbrf.gmap.vux.repository.VuxForm0420415V13DataRepository;
import ru.sbrf.gmap.vux.repository.VuxForm0420415V13UnitRepository;
import ru.sbrf.gmap.vux.repository.VuxForm0420415V13ValueRepository;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Провайдер контекста проверки для формы 0420415.1.3.
 * <p>
 * Загружает данные из таблиц context/unit/value по workflow_run_id из view расписания,
 * версии таксономии из data и общие справочники через {@link XbrlReferenceDataService}.
 * <p>
 * Отсутствие данных формы — контекст с пустыми списками, ошибки выдают правила 1–4 (Q-8 п. 2.1);
 * технический сбой не перехватывается (ревью R-6).
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class Form0420415V13DataContextProvider implements DataContextProvider {

    public static final String DOC_TYPE_CODE = "0420415.1.3";

    private final VuxForm0420415V13ContextRepository vuxForm0420415V13ContextRepository;
    private final VuxForm0420415V13UnitRepository vuxForm0420415V13UnitRepository;
    private final VuxForm0420415V13ValueRepository vuxForm0420415V13ValueRepository;
    private final VuxForm0420415V13DataRepository vuxForm0420415V13DataRepository;
    private final XbrlReferenceDataService xbrlReferenceDataService;
    private final VuxForm0420415V13ContextMapper vuxForm0420415V13ContextMapper;
    private final VuxForm0420415V13UnitMapper vuxForm0420415V13UnitMapper;
    private final VuxForm0420415V13ValueMapper vuxForm0420415V13ValueMapper;

    @Override
    public String supportedDocTypeCode() {
        return DOC_TYPE_CODE;
    }

    @Override
    public DataContext build(VuxDocumentScheduleViewEntity record) {
        // Исключения БД не перехватываются: это технический сбой, запись остаётся открытой (R-6, D-14)
        long docId = record.getResultDocumentId().longValue();
        // workflow_run_id — из view расписания (= t_vux_document.workflow_run_id); в таблице data нет doc_id (Q-8 п. 4.1).
        // Нет данных формы — не «пропуск», а ошибки CUV-проверки по постановке (Q-8 п. 2.1, D-17):
        // нет workflow_run_id → правило 1 (_001), нет context/unit/value → правила 2–4 (_002…_004).
        if (record.getWorkflowRunId() == null) {
            log.warn("[CUV] No form data: workflow_run_id is empty, docId={}. Check 1 (_001) will report an error.", docId);
            return DataContext.empty(docId, null);
        }
        long workflowRunId = record.getWorkflowRunId();

        List<VuxForm0420415V13ContextEntity> contextEntities =
                vuxForm0420415V13ContextRepository.findByWorkflowRunId(workflowRunId);
        if (contextEntities.isEmpty()) {
            log.warn("[CUV] No context records: docId={}, workflowRunId={}. Check 2 (_002) will report an error.",
                    docId, workflowRunId);
        }

        // Строки data целиком не загружаются: сущность не совпадает с таблицей (см. репозиторий),
        // а проверка 10 выключена до переписывания (7.7). Для проверки 9 нужны только версии таксономии.
        Set<String> dataTaxonomies = vuxForm0420415V13DataRepository.findTaxonomyVersions(workflowRunId).stream()
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());

        // Маппинг context entity → dto (без повторного запроса — используем уже загруженные сущности)
        List<VuxForm0420415V13ContextDto> contextList = contextEntities.stream()
                .map(vuxForm0420415V13ContextMapper::entityToDto)
                .toList();

        // Загрузка и маппинг unit/value (только для данного workflowRunId)
        List<VuxForm0420415V13UnitDto> unitList = DataContextProvider.loadAndMap(
                workflowRunId,
                vuxForm0420415V13UnitRepository::findByWorkflowRunId,
                vuxForm0420415V13UnitMapper::entityToDto);
        List<VuxForm0420415V13ValueDto> valueList = DataContextProvider.loadAndMap(
                workflowRunId,
                vuxForm0420415V13ValueRepository::findByWorkflowRunId,
                vuxForm0420415V13ValueMapper::entityToDto);

        return new DataContext(
                docId,
                contextList,
                unitList,
                valueList,
                List.of(),
                xbrlReferenceDataService.loadXbrlLinks(),
                xbrlReferenceDataService.loadEnumValuesMap(),
                dataTaxonomies,
                workflowRunId
        );
    }
}
