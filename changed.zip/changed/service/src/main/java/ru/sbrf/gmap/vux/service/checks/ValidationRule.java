package ru.sbrf.gmap.vux.service.checks;

import ru.sbrf.gmap.vux.dto.ValidationErrorDto;

import java.util.Optional;

/**
 * Функциональный интерфейс, описывающий единичную проверку данных.
 * <p>
 * Каждая реализация выполняет ровно одну атомарную проверку.
 * Исключения при проверке не выбрасываются — любая ошибка обработки считается
 * ошибкой валидации и возвращается как {@link ValidationErrorDto}.
 */
public interface ValidationRule {
    static final String DEFAULT_TITLE= "Ошибка сверки data с units, values, context по 415 форме";
    /**
     * Выполняет одну проверку данных на основе переданного контекста.
     *
     * @param context контекст проверки, содержащий данные формы
     * @return {@link Optional#empty()} если ошибок нет,
     *         иначе {@link Optional#of(ValidationErrorDto)} с описанием ошибки
     */
    Optional<ValidationErrorDto> validate(DataContext context);

    String getDescription();

    String getCode();

    /**
     * Выключенная проверка не выполняется, в протоколе — «Не проверялось», в число проверок не входит (D-52).
     */
    default boolean isEnabled() {
        return true;
    }

    /**
     * Шаг алгоритма проверки по постановке (аналитика, 7.7): 1 — {@code _001}, 2 — {@code _002}…{@code _004},
     * 3 — {@code _005}…{@code _009}, 4 — {@code _010}. После шага с ошибками следующие шаги не выполняются.
     * Определяется по трём последним цифрам кода ошибки; для кода другого формата — 4 (без прерывания).
     */
    default int getStage() {
        String code = getCode();
        if (code == null || code.length() < 3) {
            return 4;
        }
        int number;
        try {
            number = Integer.parseInt(code.substring(code.length() - 3));
        } catch (NumberFormatException e) {
            return 4;
        }
        if (number == 1) {
            return 1;
        }
        if (number >= 2 && number <= 4) {
            return 2;
        }
        if (number >= 5 && number <= 9) {
            return 3;
        }
        return 4;
    }
}