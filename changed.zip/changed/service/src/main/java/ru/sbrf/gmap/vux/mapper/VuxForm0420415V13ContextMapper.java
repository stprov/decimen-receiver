package ru.sbrf.gmap.vux.mapper;

import org.mapstruct.Mapper;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ContextDto;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V13ContextEntity;

@Mapper(componentModel = "spring")
public interface VuxForm0420415V13ContextMapper {

    VuxForm0420415V13ContextDto entityToDto(VuxForm0420415V13ContextEntity entity);

    VuxForm0420415V13ContextEntity dtoToEntity(VuxForm0420415V13ContextDto dto);
}
