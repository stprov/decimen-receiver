package ru.sbrf.gmap.vux.dto.csv;

import lombok.Builder;

import java.time.LocalDate;
import java.util.UUID;

@Builder
public record VuxForm0420415V13UnitDto(
        UUID uid,
        String unitId,
        String content,
        LocalDate startDate,
        LocalDate endDate,
        String taxonomy,
        Long workflowRunId
) {
}
