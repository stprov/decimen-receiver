package ru.sbrf.gmap.vux.exception.supz;

public class SupzErrorResponse extends RuntimeException {
    public SupzErrorResponse(Throwable cause) {
        super(cause);
    }
}
