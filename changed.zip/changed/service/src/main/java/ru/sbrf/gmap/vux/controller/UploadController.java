package ru.sbrf.gmap.vux.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import ru.sbrf.gmap.vux.dto.request.ecm.UploadByS3PathRequestDto;
import ru.sbrf.gmap.vux.model.DocumentTypeEnum;
import ru.sbrf.gmap.vux.service.UploadDocumentService;

import java.util.UUID;

@Slf4j
@RestController
@RequestMapping("/api/v1/upload")
@RequiredArgsConstructor
public class UploadController {

    private final UploadDocumentService uploadDocumentService;

    /**
     * Эндпоинт загрузки документа в ECM по ссылке на объект в S3.
     *
     * @param request параметры загрузки
     * @return сформированный {@code rqUid} запроса в ЕСМ
     */
    @PostMapping("/by-s3-path")
    @ResponseStatus(HttpStatus.OK)
    public UUID uploadByS3Path(@Valid @RequestBody UploadByS3PathRequestDto request) {
        DocumentTypeEnum documentType = resolveDocumentType(request.documentType());
        UUID rqUid = uploadDocumentService.uploadDocumentViaTfsByS3Path(
                request.s3Path(),
                request.filename(),
                documentType,
                request.sliceId()
        );
        log.info("Document by S3 path '{}' accepted for upload, rqUid: '{}'", request.s3Path(), rqUid);
        return rqUid;
    }

    private DocumentTypeEnum resolveDocumentType(String value) {
        try {
            return DocumentTypeEnum.valueOf(value);
        } catch (IllegalArgumentException | NullPointerException e) {
            throw new IllegalArgumentException("Unknown documentType: '" + value + "'", e);
        }
    }
}