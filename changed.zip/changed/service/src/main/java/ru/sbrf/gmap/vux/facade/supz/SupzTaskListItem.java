package ru.sbrf.gmap.vux.facade.supz;

public interface SupzTaskListItem {

    String getUiText();
}
