package ru.sbrf.gmap.vux.dto;

import lombok.Builder;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationLogEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationResultViewEntity;

import java.sql.Date;
import java.util.List;

@Builder
public record FormingPdfDto(
        String documentName,
        String documentNumber,
        Date documentDate,
        List<String> objectsList,
        List<VuxDocumentValidationResultViewEntity> validationResults,
        List<VuxDocumentValidationLogEntity> validationLogs
) {
}
