package ru.sbrf.gmap.vux.model.supz.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import ru.sbrf.gmap.vux.dto.request.supz.SupzTaskAttachedUrlDto;
import tools.jackson.databind.JsonNode;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

@JsonIgnoreProperties(ignoreUnknown = true)
public record SupzTaskResponseData(

        @JsonProperty("task/id")
        UUID taskId,

        @JsonProperty("task/srcId")
        String srcId,

        @JsonProperty("task/status")
        String status,

        @JsonProperty("task/srcTypeId")
        List<List<String>> srcTypeIds,

        @JsonProperty("task/attachUrls")
        List<SupzTaskAttachedUrlDto> attachUrls,

        @JsonProperty("task/attributes")
        JsonNode attributes,

        @JsonProperty("task/deadlineTime")
        ZonedDateTime deadlineTime,

        @JsonProperty("task/srcAssigneeId")
        String srcAssigneeId,

        @JsonProperty("task/srcInitiatorId")
        String srcInitiatorId,

        @JsonProperty("task/srcParentId")
        String srcParentId,

        @JsonProperty("task/srcParentTime")
        ZonedDateTime srcParentTime,

        @JsonProperty("task/srcPriority")
        String srcPriority,

        @JsonProperty("task/srcRegisterTime")
        ZonedDateTime srcRegisterTime,

        @JsonProperty("task/typeId")
        UUID typeId,

        @JsonProperty("task/assigneeId")
        String assigneeId
) {
}