package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Aspect
@Component
@Slf4j
@RequiredArgsConstructor
@ConditionalOnProperty(value="test-stand", havingValue = "false", matchIfMissing = true)
public class KerberosTicketCheckAspect {

    private final KerberosTicketCachedService kerberosTicketCachedService;

    @Before("execution(* ru.sbrf.gmap.vux.repository.*.*(..))")
    public void checkKerberosTicket() {
        log.debug("Call was intercepted. Checking Kerberos ticket in aspect");
        try {
            if (kerberosTicketCachedService.isKerberosTicketExpired()) {
                log.info("Kerberos ticket is expired. Attempting renewal...");
                kerberosTicketCachedService.renewKerberosTickets();
                log.info("Kerberos tickets successfully renewed.");
            }
        } catch (IOException e) {
            log.error("Kerberos ticket not found or outdated. Error when checking/updating Kerberos ticket in aspect", e);
        } catch (Exception e) {
            log.error("Unexpected error during Kerberos ticket validation", e);
        }
    }
}