package ru.sbrf.gmap.vux.exception.ecm;

import lombok.Getter;

@Getter
public class EcmAlreadyExistException extends RuntimeException {

    private final Object response;

    public EcmAlreadyExistException(Object response) {
        this.response = response;
    }
}
