package ru.sbrf.gmap.vux.service.checks;

import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;

import java.util.List;
import java.util.function.Function;

/**
 * Провайдер контекста проверки {@link DataContext} для конкретной формы.
 * <p>
 * Каждая форма, поддерживающая CUV-проверку, предоставляет свою реализацию
 * (бина Spring) с собственными репозиториями/мапперами entity→dto.
 * Подключение новой формы = добавление нового бина, без изменения
 * {@code OrchestratorService}.
 */
public interface DataContextProvider {

    /**
     * Код формы (doc_type_code), для которой данный провайдер строит контекст,
     * например {@code "0420415.1.3"}.
     */
    String supportedDocTypeCode();

    /**
     * Строит контекст проверки для документа.
     *
     * @param record запись расписания: {@code result_doc_id} и {@code workflow_run_id} берутся из view
     *               {@code v_vux_document_shedule_int} (Q-8 п. 4.1)
     * @return контекст проверки, не {@code null}. Если данных формы нет (нет {@code workflow_run_id}, нет context,
     * unit или value), возвращается контекст с пустыми списками: ошибки {@code _001}…{@code _004} выдают правила
     * CUV-проверки, документ получает протокол с ошибками и письмо (Q-8 п. 2.1, D-17)
     * @throws RuntimeException при техническом сбое (БД и т. п.) — запись остаётся открытой до следующего цикла (D-14)
     */
    DataContext build(VuxDocumentScheduleViewEntity record);

    /**
     * Дженерик-хелпер: загружает entity по workflowRunId и маппит их в DTO.
     * Переиспользуется провайдерами разных форм.
     *
     * @param workflowRunId идентификатор запуска процесса
     * @param finder        ссылка на метод репозитория {@code findByWorkflowRunId(...)}
     * @param mapper        ссылка на метод маппера {@code entityToDto(...)}
     */
    static <E, D> List<D> loadAndMap(long workflowRunId,
                                     Function<Long, List<E>> finder,
                                     Function<E, D> mapper) {
        return finder.apply(workflowRunId).stream()
                .map(mapper)
                .toList();
    }
}
