package ru.sbrf.gmap.vux.model.jsonrpc;

import lombok.Builder;
import lombok.NonNull;

@Builder
public record JsonRpcRequest<T>(

        /* Version of JSON-RPC protocol */
        @NonNull
        String jsonrpc,

        /* Unique request identifier */
        @NonNull
        String id,

        /* JSON-RPC method name */
        @NonNull
        String method,

        /* Additional params. AKA body request */
        T params
) {
}
