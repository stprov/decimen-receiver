package ru.sbrf.gmap.vux.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Параметры шедулера рассылки информационных писем (префикс {@code config.mail-sheduled-sender}).
 *
 * @param maxPastDays глубина окна давности (в днях): записи расписания,
 *                    запланированные к отправке (send_time) более чем N дней назад,
 *                    не обрабатываются. По умолчанию 7.
 */
@ConfigurationProperties(prefix = "config.mail-sheduled-sender")
public record MailSheduledSenderProps(
        @DefaultValue("7") int maxPastDays
) {
}
