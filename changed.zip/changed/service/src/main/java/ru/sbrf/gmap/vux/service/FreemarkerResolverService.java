package ru.sbrf.gmap.vux.service;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class FreemarkerResolverService {

    private final Configuration configurationFreemarker;
    private Template template;
    private final String TEMPLATE_NAME = "xbrl_protocol.ftl";

    @PostConstruct
    public void init() {
        try {
            this.template = configurationFreemarker.getTemplate(TEMPLATE_NAME, StandardCharsets.UTF_8.name());
            log.info("Template '{}'uploaded and cached successfully", TEMPLATE_NAME);
        } catch (IOException e) {
            log.error("Failed to load template '{}' when starting the application", TEMPLATE_NAME, e);
            throw new IllegalStateException("Template " + TEMPLATE_NAME + " not loaded", e);
        }
    }


    public String resolve(ProtocolModelDto protocolModelDto) {
        try {
            Writer out = new StringWriter();
            Map<String, Object> attributes = new HashMap<>();
            attributes.put("documentNumber", protocolModelDto.getDocumentNumber());
            attributes.put("documentDate", protocolModelDto.getDocumentDate());
            attributes.put("checkDate", protocolModelDto.getCheckDate());
            attributes.put("reportType", protocolModelDto.getReportType());
            attributes.put("objects", protocolModelDto.getObjects());
            attributes.put("checksList", protocolModelDto.getChecksList());
            attributes.put("warnings", protocolModelDto.getWarnings());
            attributes.put("totalErrorCount", protocolModelDto.getTotalErrorCount());
            attributes.put("totalWarningCount", protocolModelDto.getTotalWarningCount());
            template.process(attributes, out);
            log.debug("The template '{}' has been successfully processed", TEMPLATE_NAME);
            return out.toString();
        } catch (TemplateException e) {
            log.error("Template processing error '{}': syntax error or invalid data", TEMPLATE_NAME, e);
            throw new IllegalStateException("Error when processing the template " + TEMPLATE_NAME, e);
        } catch (IOException e) {
            log.error("I/O error while processing template '{}'", TEMPLATE_NAME, e);
            throw new IllegalStateException("I/O error when working with a template " + TEMPLATE_NAME, e);
        }
    }

    /**
     * Обрабатывает шаблон и сохраняет HTML в файл для тестов
     */
    public String resolveAndSave(ProtocolModelDto protocolModelDto, String suffix, String outputDir) {
        try {
            Writer out = new StringWriter();
            Map<String, Object> attributes = new HashMap<>();
            attributes.put("documentNumber", protocolModelDto.getDocumentNumber());
            attributes.put("documentDate", protocolModelDto.getDocumentDate());
            attributes.put("checkDate", protocolModelDto.getCheckDate());
            attributes.put("reportType", protocolModelDto.getReportType());
            attributes.put("objects", protocolModelDto.getObjects());
            attributes.put("checksList", protocolModelDto.getChecksList());
            attributes.put("warnings", protocolModelDto.getWarnings());
            template.process(attributes, out);
            log.debug("The template '{}' has been successfully processed", TEMPLATE_NAME);
            
            // Сохраняем HTML в файл для тестов
            saveHtmlToFile(out.toString(), suffix, outputDir);
            
            return out.toString();
        } catch (TemplateException e) {
            log.error("Template processing error '{}': syntax error or invalid data", TEMPLATE_NAME, e);
            throw new IllegalStateException("Error when processing the template " + TEMPLATE_NAME, e);
        } catch (IOException e) {
            log.error("I/O error while processing template '{}'", TEMPLATE_NAME, e);
            throw new IllegalStateException("I/O error when working with a template " + TEMPLATE_NAME, e);
        }
    }

    /**
     * Сохраняет HTML в файл для тестов
     */
    private void saveHtmlToFile(String htmlContent, String suffix, String outputDir) {
        try {
            Path testDir = Paths.get(outputDir);
            if (!Files.exists(testDir)) {
                Files.createDirectories(testDir);
            }
            
            String fileName = "html_" + suffix + ".html";
            Path filePath = testDir.resolve(fileName);
            Files.writeString(filePath, htmlContent);
            log.debug("HTML saved to: {}", filePath.toAbsolutePath());
        } catch (IOException e) {
            log.warn("Failed to save HTML file for testing: {}", e.getMessage());
            // Не прерываем выполнение из-за ошибки сохранения HTML
        }
    }
}
