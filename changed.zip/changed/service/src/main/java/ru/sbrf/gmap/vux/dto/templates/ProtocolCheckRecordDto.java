package ru.sbrf.gmap.vux.dto.templates;

import lombok.Builder;
import lombok.Getter;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;

@Getter
@Builder
public class ProtocolCheckRecordDto {
    String checkType;
    String checkResult;
    String countingDeviation;
    RuleTypeEnum ruleType;
}
