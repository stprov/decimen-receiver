package ru.sbrf.gmap.vux.dto.request.okey;

public record SignatureBadDto(
        String errorCode,
        String errorDescription
) {
}
