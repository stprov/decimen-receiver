package ru.sbrf.gmap.vux.entity.converter;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.model.DocumentTypeEnum;

@Converter(autoApply = true)
@Component
@Slf4j
public class DocumentTypeEnumConverter implements AttributeConverter<DocumentTypeEnum, String> {

    @Override
    public String convertToDatabaseColumn(DocumentTypeEnum attribute) {
        if (attribute == null) return null;
        return attribute.name();
    }

    @Override
    public DocumentTypeEnum convertToEntityAttribute(String ecmClassName) {
        if (ecmClassName == null) return null;
        try {
            return DocumentTypeEnum.valueOf(ecmClassName.toUpperCase());
        } catch (IllegalArgumentException e) {
            log.error("Unknown ECM class name: {}", ecmClassName, e);
            throw new IllegalStateException("ECM class name is not valid!", e);
        }
    }
}