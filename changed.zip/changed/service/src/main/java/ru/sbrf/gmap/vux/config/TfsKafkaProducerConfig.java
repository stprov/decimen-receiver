package ru.sbrf.gmap.vux.config;

import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import ru.sbrf.gmap.vux.IntegrationEcmTfsProps;

import java.util.HashMap;
import java.util.Map;

@Configuration
@RequiredArgsConstructor
@ConditionalOnProperty(prefix = "integration.ecm.tfs-upload", value = "enabled", havingValue = "true")
@EnableKafka
public class TfsKafkaProducerConfig {

    private final IntegrationEcmTfsProps integrationEcmTfsProps;

    @Bean
    public ProducerFactory<String, String> tfsKafkaProducerFactory() {
        IntegrationEcmTfsProps.Kafka kafkaProps = integrationEcmTfsProps.kafka();
        Map<String, Object> configProps = new HashMap<>();
        configProps.put(ProducerConfig.CLIENT_ID_CONFIG, kafkaProps.clientId());
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,
                kafkaProps.bootstrapServers());
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ProducerConfig.ACKS_CONFIG, kafkaProps.producer().ack());
        configProps.put(ProducerConfig.RETRIES_CONFIG, kafkaProps.producer().retries() != null ? kafkaProps.producer().retries() : 0);
        return new DefaultKafkaProducerFactory<>(configProps);
    }

    @Bean
    public KafkaTemplate<String, String> kafkaTemplate() {
        return new KafkaTemplate<>(tfsKafkaProducerFactory());
    }

}
