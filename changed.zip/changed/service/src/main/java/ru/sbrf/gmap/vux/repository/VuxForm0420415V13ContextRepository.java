package ru.sbrf.gmap.vux.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V13ContextEntity;

import java.util.List;
import java.util.UUID;

public interface VuxForm0420415V13ContextRepository extends JpaRepository<VuxForm0420415V13ContextEntity, UUID> {

    List<VuxForm0420415V13ContextEntity> findByWorkflowRunId(Long workflowRunId);
}
