package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.entity.enums.CuvValidationStatusEnum;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.sql.Timestamp;

/**
 * Сохранение итогового статуса CUV-проверки ({@code fn_flow_cuv_set_status}).
 * <p>
 * Функция только добавляет строку, поэтому статус пишется один раз — когда обработка записи
 * на этом шаге завершена. Сбой записи статуса не прерывает обработку документа: статус
 * информационный, в лог пишется ERROR.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CuvValidationStatusService {

    private static final String SCHEDULE_NOT_FOUND = "расписание не найдено";

    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;

    /**
     * Сохраняет результат выполненной CUV-проверки.
     */
    public void saveChecked(VuxDocumentScheduleViewEntity record, int checkCount, int errorCount,
                            Timestamp checkStart, Timestamp checkEnd) {
        CuvValidationStatusEnum status = errorCount == 0
                ? CuvValidationStatusEnum.CHECKED_WITHOUT_ERRORS
                : CuvValidationStatusEnum.CHECKED_WITH_ERRORS;
        save(record, status, checkCount, errorCount, checkStart, checkEnd);
    }

    /**
     * Сохраняет статус «не проверен» (проверка выключена, нет проверки для формы, нет данных формы).
     */
    public void saveNotChecked(VuxDocumentScheduleViewEntity record) {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        save(record, CuvValidationStatusEnum.NOT_CHECKED, 0, 0, now, now);
    }

    private void save(VuxDocumentScheduleViewEntity record, CuvValidationStatusEnum status, int checkCount,
                      int errorCount, Timestamp checkStart, Timestamp checkEnd) {
        Integer docId = record.getResultDocumentId();
        try {
            String result = vuxDocumentValidationResultViewRepository.flowCuvSetStatus(
                    docId.longValue(), status.getCode(), checkCount, (long) errorCount, checkStart, checkEnd).orElse(null);
            if (result != null && result.toLowerCase().contains(SCHEDULE_NOT_FOUND)) {
                log.warn("[CUV] CUV validation status is not saved: scheduleId={}, docId={}, status={}, result={}",
                        record.getScheduleId(), docId, status, result);
                return;
            }
            log.info("[CUV] CUV validation status saved: scheduleId={}, docId={}, status={}({}), checkCount={}, errorCount={}",
                    record.getScheduleId(), docId, status, status.getCode(), checkCount, errorCount);
        } catch (Exception e) {
            log.error("[CUV] Failed to save CUV validation status: scheduleId={}, docId={}, status={}. Processing continues.",
                    record.getScheduleId(), docId, status, e);
        }
    }
}
