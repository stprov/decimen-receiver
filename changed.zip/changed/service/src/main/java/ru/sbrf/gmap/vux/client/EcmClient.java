package ru.sbrf.gmap.vux.client;

import feign.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import ru.sbrf.gmap.vux.client.feign.EcmFeignClient;
import ru.sbrf.gmap.vux.dto.request.ecm.CreateContentsRequest;
import ru.sbrf.gmap.vux.dto.response.CreateContentsResponse;
import ru.sbrf.gmap.vux.dto.response.EcmErrorResponse;
import ru.sbrf.gmap.vux.dto.response.EcmResponse;
import ru.sbrf.gmap.vux.dto.response.ResponseFailure;
import ru.sbrf.gmap.vux.dto.response.ResponseResult;
import ru.sbrf.gmap.vux.exception.ecm.EcmAlreadyExistException;
import ru.sbrf.gmap.vux.exception.ecm.EcmUploadException;
import ru.sbrf.gmap.vux.model.EcmCodeEnum;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.exc.UnrecognizedPropertyException;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
@Slf4j
public class EcmClient {

    private final EcmFeignClient ecmFeignClient;
    private final ObjectMapper objectMapper;


    public CreateContentsResponse createContents(Map<String, Object> headers, CreateContentsRequest createContentsRequest, List<MultipartFile> files) throws IOException {
        return validateEcmResponse(
                ecmFeignClient
                        .createContents(headers, createContentsRequest, files.toArray(MultipartFile[]::new)),
                CreateContentsResponse.class);
    }


    private <T extends EcmResponse> T validateEcmResponse(Response feignResponse, Class<T> responseClazz) throws IOException {
        HttpStatus responseStatus = HttpStatus.valueOf(feignResponse.status());

        // 200
        if (HttpStatus.OK.equals(responseStatus)) {
            return objectMapper.readValue(feignResponse.body().asInputStream(), responseClazz);
        }

        // 206
        if (HttpStatus.PARTIAL_CONTENT.equals(responseStatus)) {
            T response = objectMapper.readValue(feignResponse.body().asInputStream(), responseClazz);
            ResponseResult responseResult = response.getResponseResult();

            if (EcmCodeEnum.RESULT_CODE_OBJECT_NOT_UNIQUE.getValue().equals(responseResult.getResultCode())
                    && EcmCodeEnum.ERROR_CODE_E_NOT_UNIQUE.getValue().equals(responseResult.getFailure().getErrorCode())) {
                throw new EcmAlreadyExistException(response);
            }
            throw new EcmUploadException(feignResponse.status(), responseResult.getFailure().getErrorCode(), responseResult.getFailure().getErrorReason());
//            throw new EcmException(ErrorCode.ECM_ERROR, feignResponse.status(), responseResult.getFailure().getErrorCode(), responseResult.getFailure().getErrorReason());
        }

        // все остальные случаи: 4xx/5xx/...
        String code = "null";
        String message = "null";
        try {
            ResponseFailure responseFailure = objectMapper.readValue(feignResponse.body().asInputStream(), ResponseFailure.class);
            code = responseFailure.getErrorCode();
            message = responseFailure.getErrorReason();
        } catch (UnrecognizedPropertyException upe) {
            try {
                EcmErrorResponse errorResponse = objectMapper.readValue(feignResponse.body().asInputStream(), EcmErrorResponse.class);
                code = String.valueOf(errorResponse.status());
                message = errorResponse.error();
            } catch (Exception e) {
                log.error("Error parsing feignResponse for " + responseClazz, e);
            }
        }
        throw new EcmUploadException(feignResponse.status(), code, message);
    }
}
