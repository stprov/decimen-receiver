package ru.sbrf.gmap.vux.utils;

import feign.Response;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

@Slf4j
@UtilityClass
public class FeignUtils {

    public String readRawResponse(Response response) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(response.body().asInputStream()))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            return sb.toString();
        } catch (Exception e) {
            log.error("Error reading response body stream", e);
            throw new IOException("Error reading response body stream", e);
        }
    }
}
