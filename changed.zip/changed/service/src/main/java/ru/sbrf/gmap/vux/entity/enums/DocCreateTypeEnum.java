package ru.sbrf.gmap.vux.entity.enums;

public enum DocCreateTypeEnum {
    AUTO, MANUAL
}
