package ru.sbrf.gmap.vux.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;


@Data
@NoArgsConstructor
@Entity
@Table(name = "v_vux_document_validation_result")
@AllArgsConstructor
@Builder
public class VuxDocumentValidationResultViewEntity {

    @Id
    @Column(name = "_id")
    private Long id;

    @Column(name = "doc_id")
    private Integer docId;

    @Column(name = "rule_id")
    private Integer ruleId;

    @Column(name = "object_type")
    private String objectType;

    @Column(name = "line")
    private Long line;

    @Column(name = "id_text")
    private String idText;

    @Column(name = "id_label")
    private String idLabel;

    @Column(name = "error_message")
    private String errorMessage;

    @Column(name = "error_code")
    private String errorCode;

    @Column(name = "important_level")
    private Integer importantLevel;

    @Column(name = "rule_type")
    @Enumerated(EnumType.STRING)
    private RuleTypeEnum ruleType;

    @Column(name = "rn")
    private Long rn;
}
