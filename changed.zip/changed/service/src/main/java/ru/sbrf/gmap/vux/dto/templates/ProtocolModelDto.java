package ru.sbrf.gmap.vux.dto.templates;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.util.List;

@Builder
@Getter
@ToString
public class ProtocolModelDto {
    String documentNumber;
    String documentDate;
    String reportType;
    String checkDate;
    List<ProtocolTableRecordDto> objects;
    List<ProtocolTableRecordDto> warnings;
    List<ProtocolCheckRecordDto> checksList;
    long totalErrorCount;
    long totalWarningCount;
}
