package ru.sbrf.gmap.vux.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseResult {
    
    private String resultCode;
    private ResponseFailure failure;
}
