package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.util.UUID;

/**
 * Сервис расчёта метрик ИКД по расписанию.
 * <p>
 * Ежемесячно 16-го числа в 00:00 вызывает хранимую процедуру {@code fn_load_request}
 * для регистрации входящих обращений от ЦБ и записи данных в таблицы
 * {@code t_vux_request_data} и {@code t_vux_request} схемы {@code s_grnplm_as_cib_gm_vux}.
 * Процедура не требует параметров, результат не сохраняется — внутреннее логирование в БД.
 * <p>
 * Управляется флагом {@code config.feature-toggles.scheduled-ikd-calculation}.
 */
@Slf4j
@Service
@RequiredArgsConstructor
@ConditionalOnProperty(
        name = "config.feature-toggles.scheduled-ikd-calculation",
        havingValue = "true",
        matchIfMissing = false
)
public class IkdCalculationSchedulerService {

    private final VuxDocumentValidationResultViewRepository repository;

    /**
     * Основной метод: запуск расчёта метрик ИКД по cron-расписанию.
     * Cron и часовой пояс берутся из параметров {@code config.ikd-calculation-scheduler.cron}
     * и {@code config.ikd-calculation-scheduler.timezone}. Тайм-аут транзакции в секундах берётся из параметра {@code config.ikd-calculation-scheduler.timeout}.
     */
    @Scheduled(cron = "${config.ikd-calculation-scheduler.cron:0 0 0 16 * ?}", zone = "${config.ikd-calculation-scheduler.timezone:Europe/Moscow}")
    public void run() {
        UUID executionId = UUID.randomUUID();
        log.info("Starting IKD metrics calculation, executionId={}", executionId);

        try {
            repository.fnLoadRequest();
            log.info("IKD metrics calculation completed successfully, executionId={}, procedure=fn_load_request", executionId);
        } catch (Exception e) {
            log.error("IKD metrics calculation failed, executionId={}, procedure=fn_load_request, error='{}'", executionId, e.getMessage(), e);
        }
    }
}
