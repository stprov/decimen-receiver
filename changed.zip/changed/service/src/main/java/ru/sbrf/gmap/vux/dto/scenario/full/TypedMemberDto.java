package ru.sbrf.gmap.vux.dto.scenario.full;

import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAnyElement;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.w3c.dom.Element;

@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
@XmlRootElement(
        name = "typedMember",
        namespace = "https://www.xbrl.org/2006/xbrldi-2006.xsd"
)
@XmlAccessorType(XmlAccessType.FIELD)
public class TypedMemberDto {

    /** Атрибут dimension (например dim-int:ID_strokiTaxis) */
    @XmlAttribute
    private String dimension;

    /** Произвольный вложенный элемент (захватывается как DOM Element) */
    @XmlAnyElement(lax = true)
    private Object content;

    /**
     * Извлекает текстовое содержимое дочернего DOM-элемента.
     *
     * @return текст внутри дочернего элемента, или null, если content отсутствует
     *         или не является Element
     */
    public String getTypedName() {
        if (content instanceof Element element) {
            return element.getTextContent();
        }
        return null;
    }
}