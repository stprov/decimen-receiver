package ru.sbrf.gmap.vux.model.supz.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.UUID;

public record SupzStatusDataRequest(
        @JsonProperty("task/id")
        UUID taskId,
        @JsonProperty("task/reqAttributes")
        List<String> reqAtts
) {
}
