package ru.sbrf.gmap.vux;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "integration.ecm.tfs-upload")
@ConditionalOnProperty(prefix = "integration.ecm.tfs-upload", value = "enabled", havingValue = "true")
public record IntegrationEcmTfsProps(
        boolean enabled,
        Kafka kafka,
        EcmS3Properties s3,
        TfsParams tfsParams
) {
    public record Kafka(
            String clientId,
            String bootstrapServers,
            Consumer consumer,
            Producer producer
    ) {
    }

    public record EcmS3Properties(
            boolean enabled,
            String url,
            String accessKeyId,
            String secretAccessKey,
            String bucket,
            String folder,
            Integer timeout,
            Integer maxConnections

    ) {
    }

    public record TfsParams(
            String fpName,
            String systemId,
            String spName,
            String scenarioId,
            String version,
            String destinationName
    ) {
    }

    public record Consumer(
            String groupId,
            String topicIn,
            String resetConfig
    ) {
    }

    public record Producer(
            String topicOut,
            String ack,
            String retries) {
    }
}
