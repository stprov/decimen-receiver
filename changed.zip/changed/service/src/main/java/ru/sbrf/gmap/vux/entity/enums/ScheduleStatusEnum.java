package ru.sbrf.gmap.vux.entity.enums;

public enum ScheduleStatusEnum {
    UPLOADED, VERIFIED_SUCCESSFULLY, CHECKED_WITH_ERRORS, CHECKED_WITH_AN_INTERNAL_ERROR, PROCESSED
}
