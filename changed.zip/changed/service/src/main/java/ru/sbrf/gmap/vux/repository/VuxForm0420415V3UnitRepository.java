package ru.sbrf.gmap.vux.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V3UnitEntity;

import java.util.UUID;

public interface VuxForm0420415V3UnitRepository extends JpaRepository<VuxForm0420415V3UnitEntity, UUID> {
}
