package ru.sbrf.gmap.vux.service;

/**
 * Результат обработки записи расписания стратегией {@link DocumentProcessingService}.
 * <p>
 * Определяет, закрывать ли расписание ({@code fn_flow_resolve_shedule}) после обработки.
 * После закрытия расписание переходит в статус 3 и пропадает из
 * {@code v_vux_document_shedule_int}, поэтому закрывать его можно только тогда,
 * когда обработка записи полностью завершена.
 */
public enum ProcessingResult {

    /**
     * Обработка завершена — расписание закрывается.
     */
    COMPLETED,

    /**
     * Обработка не завершена (ожидание выгрузки CSV внешним сервисом либо технический сбой) —
     * расписание остаётся открытым, запись будет обработана в следующем цикле шедулера.
     */
    PENDING;

    public boolean isCompleted() {
        return this == COMPLETED;
    }

    public static ProcessingResult of(boolean completed) {
        return completed ? COMPLETED : PENDING;
    }
}
