package ru.sbrf.gmap.vux.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "common")
public record CommonProps(
        String standName,
        String host
) {
}
