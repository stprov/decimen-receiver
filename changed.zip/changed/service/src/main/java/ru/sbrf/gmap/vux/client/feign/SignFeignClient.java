package ru.sbrf.gmap.vux.client.feign;

import feign.Response;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.sbrf.gmap.vux.model.sign.SignRequestDto;
import ru.sbrf.gmap.vux.model.sign.SignResponseDto;

import java.util.Map;

@FeignClient(value = "signClient", url = "${integration.sign.okSignService.url}", path = "/v3/cs/cms/sign")
@ConditionalOnProperty(prefix = "integration.sign", name = "enabled", havingValue = "true")
public interface SignFeignClient {


    @PostMapping("/hash")
    Response signRequest(
            @RequestHeader Map<String, Object> headers,
            @RequestBody SignRequestDto signRequest
    );
}
