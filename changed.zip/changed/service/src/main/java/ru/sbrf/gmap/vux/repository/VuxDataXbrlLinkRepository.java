package ru.sbrf.gmap.vux.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.sbrf.gmap.vux.entity.VuxDataXbrlLinkEntity;

@Repository
public interface VuxDataXbrlLinkRepository extends JpaRepository<VuxDataXbrlLinkEntity, VuxDataXbrlLinkEntity.DataXbrlLinkId> {
}