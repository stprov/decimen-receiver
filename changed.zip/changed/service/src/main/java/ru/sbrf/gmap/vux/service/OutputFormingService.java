package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.utils.HtmlResolverUtil;

@Service
@Slf4j
@RequiredArgsConstructor
public class OutputFormingService {

    private final FreemarkerResolverService freemarkerResolverService;

    public byte[] createPdf(ProtocolModelDto formingPdfDto) {
        log.info("Start template-basedpdf generation");
        String html = createHtml(formingPdfDto);
        return HtmlResolverUtil.resolve(html);
    }

    public String createHtml(ProtocolModelDto formingPdfDto) {
        log.info("Start template-base html generation");
        return freemarkerResolverService.resolve(formingPdfDto);
    }
}

