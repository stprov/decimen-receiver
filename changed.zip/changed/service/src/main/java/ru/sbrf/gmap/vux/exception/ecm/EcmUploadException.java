package ru.sbrf.gmap.vux.exception.ecm;

import lombok.Getter;

@Getter
public class EcmUploadException extends RuntimeException {

    private final Integer status;
    private final String errorCode;
    private final String errorReason;

    public EcmUploadException(Integer status, String errorCode, String errorReason) {
        this.status = status;
        this.errorCode = errorCode;
        this.errorReason = errorReason;
    }
}
