package ru.sbrf.gmap.vux.dto.csv;

import lombok.Builder;

import java.time.LocalDate;
import java.util.UUID;

@Builder
public record VuxForm0420415V13ContextDto(
        UUID uid,
        String contextId,
        String periodType,
        String periodValue,
        String identifier,
        String scheme,
        String segment,
        String scenario,
        LocalDate startDate,
        LocalDate endDate,
        String taxonomy,
        Long workflowRunId
) {
}
