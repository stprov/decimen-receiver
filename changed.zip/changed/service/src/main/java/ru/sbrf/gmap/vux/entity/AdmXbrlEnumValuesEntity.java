package ru.sbrf.gmap.vux.entity;

import jakarta.persistence.Embeddable;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "t_adm_xbrl_enum_values")
@NoArgsConstructor
@AllArgsConstructor
@Data
public class AdmXbrlEnumValuesEntity {

    @EmbeddedId
    AdmXbrlEnumValuesEntityId id;
    String enumValueText;

    @Embeddable
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AdmXbrlEnumValuesEntityId {
        String taxonomy_id;
        String enumId;
        String enumValueCode;
    }
}
