package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.util.List;

/**
 * Сохранение ошибок CUV-проверки документа в {@code t_vux_document_cuv_validation_result}.
 * <p>
 * При повторной проверке документа (после технического сбоя) старые ошибки удаляются и записываются новые
 * (аналитика, D-48, Q-9): сначала функция БД очистки ошибок документа, затем {@code fn_flow_cuv_set_error}
 * на каждую ошибку. Всё — в одной транзакции: при сбое посередине таблица возвращается к прежнему состоянию,
 * а не остаётся очищенной или заполненной частично.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CuvErrorStorageService {

    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;

    /**
     * Заменяет ошибки CUV-проверки документа новыми. Исключение БД пробрасывается — вызывающий код
     * оставляет расписание открытым до следующего цикла (D-14).
     *
     * @param record запись расписания ({@code result_doc_id} — документ)
     * @param errors ошибки CUV-проверки
     */
    @Transactional
    public void replaceErrors(VuxDocumentScheduleViewEntity record, List<ValidationErrorDto> errors) {
        long docId = record.getResultDocumentId().longValue();
        vuxDocumentValidationResultViewRepository.flowCuvClearErrors(docId);
        for (ValidationErrorDto error : errors) {
            vuxDocumentValidationResultViewRepository.flowCuvSetError(docId, error.errorMessage(), error.errorCode());
            log.debug("[CUV] Saved error: scheduleId={}, docId={}, errorCode={}, message={}",
                    record.getScheduleId(), docId, error.errorCode(), error.errorMessage());
        }
        log.info("[CUV] CUV errors saved, previous errors of the document removed: scheduleId={}, docId={}, count={}",
                record.getScheduleId(), docId, errors.size());
    }
}
