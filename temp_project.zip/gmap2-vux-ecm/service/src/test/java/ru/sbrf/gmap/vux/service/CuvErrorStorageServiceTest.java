package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("CuvErrorStorageService")
class CuvErrorStorageServiceTest {

    @Mock
    private VuxDocumentValidationResultViewRepository viewRepository;
    @InjectMocks
    private CuvErrorStorageService service;

    private static VuxDocumentScheduleViewEntity record() {
        VuxDocumentScheduleViewEntity record = new VuxDocumentScheduleViewEntity();
        record.setScheduleId(1);
        record.setResultDocumentId(100);
        return record;
    }

    private static ValidationErrorDto error(String code, String message) {
        return new ValidationErrorDto("title", code, message);
    }

    @Test
    @DisplayName("D-48: сначала очистка прежних ошибок документа, затем запись новых")
    void clearsThenSaves() {
        service.replaceErrors(record(), List.of(error("C1", "m1"), error("C2", "m2")));

        InOrder order = inOrder(viewRepository);
        order.verify(viewRepository).flowCuvClearErrors(100L);
        order.verify(viewRepository).flowCuvSetError(100L, "m1", "C1");
        order.verify(viewRepository).flowCuvSetError(100L, "m2", "C2");
    }

    @Test
    @DisplayName("Сбой очистки — ошибки не записываются, исключение пробрасывается (расписание остаётся открытым)")
    void clearFailure_propagates() {
        when(viewRepository.flowCuvClearErrors(100L)).thenThrow(new IllegalStateException("db"));

        assertThatThrownBy(() -> service.replaceErrors(record(), List.of(error("C1", "m1"))))
                .isInstanceOf(IllegalStateException.class);
        verify(viewRepository, never()).flowCuvSetError(anyLong(), anyString(), anyString());
    }
}
