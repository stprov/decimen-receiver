# Коды ошибок конвейера CUV → ЕСМ и правила их обработки перед отправкой задачи в СУПЗ

Документ для доработки `gmap2-vux-ecm`: что именно попадает в `t_vux_document_ecm.error_code` / `error_message`,
почему в этой паре колонок видно не все отказы, и по какому правилу решать «отправлять задачу в СУПЗ или нет».

Составлен 2026-11-13 по коду двух репозиториев и по живой схеме `s_grnplm_as_cib_gm_vux` на ИФТ
(`iftadbpkapgm`). Обозначения: **✅** — проверено по коду или по БД, **⚠️** — вывод из кода, требующий подтверждения.

> **Обновлено 16.11.2026 по доработке `gmap2-vux-ecm`** (аналитика — `docs/analytics/cuv-csv-ecm-supz-flow.md`).
> Разделы про csv-former, очередь ЕСМ и функции БД (3, 4, 6, 7, 11) не менялись. В `gmap2-vux-ecm` изменилось:
> - `OrchestratorService` теперь только раздаёт записи стратегиям `InitialProcessingStrategy` (фаза 1),
>   `EcmDisabledProcessingStrategy` (`ecm_id = '-1'`) и `FollowUpProcessingStrategy` (фаза 2); ссылки на строки
>   `OrchestratorService.java` ниже относятся к версии до доработки.
> - CUV-проверка общая для всех форм с `check_mode = 'cuv'` (D-58); коды — `DCUV_<код формы>_NNN` (раздел 5).
> - Ошибки CUV сохраняет `CuvErrorStorageService`: прежние ошибки документа удаляются перед записью новых (D-48).
> - Перед задачей в СУПЗ сервис читает `t_vux_document_ecm` (`DocumentEcmExportService`, раздел 8).
> - Дефекты D1, D2, D3, D13 исправлены; правило 010 реализовано и включено 17.11.2026 (D-57, D-67, D-68). Статусы — в разделе 9.

Репозитории:

- `C:\Work\java-projects\gmap2-vux-cuv-csv-former` — формирует CSV, выгружает в S3, публикует в ЕСМ, чистит S3;
- `C:\Work\java-projects\gmap2-vux-ecm` — принимает файл по S3-пути, ведёт очередь `t_vux_ecm_queue`,
  проверяет формы с `check_mode = 'cuv'` (правила `DCUV_*`) и создаёт задачу в СУПЗ.

---

## 1. Главное в одном экране

1. `t_vux_document_ecm.error_code` — **только терминальные** отказы. Временные отказы транспорта ЕСМ,
   ожидание ответа TFS и «файл ещё не собран» в этих колонках не видны вообще.
2. `error_code` — не перечисление, а свободный `text` с тремя разными азбуками в одном столбце:
   доменные `404/405/406` (валидатор csv-former), `408` (дедлайн публикации) и HTTP-статусы самого ЕСМ
   (`400/401/403/409/…`). Значение `404` не означает HTTP 404, и наоборот: HTTP 404 от ЕСМ ляжет в ту же колонку.
3. Коды могут быть составными через запятую: `405,406` — один документ, две причины.
   Сравнивать `error_code` на равенство нельзя, разбирать надо как множество.
4. Единственный «живой» признак того, что строка ещё в работе, — `request_id is not null`.
   Обратный переход (`request_id` → `null`) означает отказ транспорта, а не «новая строка».
5. Признак `disabled = 1` ставится **безусловно** функцией `fn_xbrl_set_ecm_error` и **никем не сбрасывается**:
   терминально упавшую строку нельзя «перезапустить» без ручного `update`.
6. Проверка `DCUV_*` (любая форма с `check_mode = 'cuv'`) живёт в отдельной таблице `t_vux_document_cuv_validation_result`
   и в `t_vux_document_ecm` не попадает. Это два независимых потока ошибок.
7. Перед задачей в СУПЗ учитываются оба потока: документ с ошибками (view или CUV) в выгрузку CSV и в СУПЗ
   не уходит, а для документа без ошибок фаза 2 ждёт `ecm_id` по всем трём образам в `t_vux_document_ecm`
   (`DocumentEcmExportService.evaluateCuvCsvExport`, раздел 8). *До доработки состояние публикации не учитывалось.*

---

## 2. Три приёмника ошибок

| Приёмник | Кто пишет | Что попадает | Терминальность |
|---|---|---|---|
| `t_vux_document_ecm.error_code` + `error_message` | csv-former: `CuvTaskHandler.writeError`, `PublicationAttempt.writeError`, `PublicationService.writeTimeout` | доменные `404/405/406`, `408`, HTTP-статусы ЕСМ | ✅ всегда терминально: та же функция ставит `disabled = 1` |
| `t_vux_ecm_queue.error_text` + `response_status` | `gmap2-vux-ecm`: `UploadDocumentService`, `TfsResponseListener` → `fn_ecm_request_set_error` | текст отказа (в т.ч. `Send failed` от Kafka) | ⚠️ не терминально само по себе: подсистема решает, повторять или нет |
| `t_vux_document_cuv_validation_result.error_code` + `error_message` | `gmap2-vux-ecm`: `InitialProcessingStrategy` → `CuvErrorStorageService.replaceErrors` → `fn_flow_cuv_clear_errors` (рабочее имя, Q-9) + `fn_flow_cuv_set_error` × N | `DCUV_<код формы>_001…009` (`010` выключена до этапа 2) | ✅ терминально для отправки в ЕСМ, но `t_vux_document_ecm` не трогает |

Ветки записи (✅):

- `document/CuvTaskHandler.java:137-150` — `fn_xbrl_set_ecm_error(xbrlId, errorCode, errorMessage)` по итогам валидации;
- `ecm/service/PublicationAttempt.java:133-145` — `fn_xbrl_set_ecm_error(xbrlId, String.valueOf(status), body)`;
- `ecm/service/PublicationService.java:198-211` — `fn_xbrl_set_ecm_error(xbrlId, "408", "Истёк срок публикации в ЕСМ")`;
- `service/CuvErrorStorageService.java` — `flowCuvClearErrors(docId)`, затем `flowCuvSetError(docId, error.errorMessage(), error.errorCode())` в одной транзакции.

---

## 3. Состояния строки `t_vux_document_ecm`

Явной колонки статуса у таблицы нет, состояние читается по комбинации полей (✅ по коду и функциям БД):

| Состояние | Признаки | Кто и чем ставит |
|---|---|---|
| Новая строка | `disabled = 0`, `ecm_id is null`, `request_id is null`, `s3_link is null` | создаётся вне этого конвейера (задача CUV) |
| Файл собран | `s3_link` заполнен, `ecm_id is null` | `fn_xbrl_set_ecm_file` из `FileGenerationService` |
| В полёте | `request_id is not null`, `ecm_id is null` | `fn_flow_xbrl_ecm_set_status(..., 'waiting', ...)` — заодно `attempt = coalesce(attempt,0)+1`, `updated = now()` |
| Опубликовано | `ecm_id is not null`, `sent` заполнен | `fn_flow_xbrl_ecm_set_status(..., 'success', ecm_id)` |
| Опубликовано и вычищено | `ecm_id is not null`, `s3_link is null`, `s3_del = 1` | `s3_del` выставляет внешний процесс, `s3_link` обнуляет `fn_xbrl_clear_ecm_file` из `CleanupService` |
| Временный отказ, ждёт повтора | `request_id is null`, `ecm_id is null`, `attempt > 0`, `disabled = 0` | `fn_flow_xbrl_ecm_set_status(..., 'error' / 'timeout', ...)` + `fn_xbrl_set_ecm_file` (сдвиг `updated`) |
| Терминальный отказ | `disabled = 1`, `error_code is not null` | `fn_xbrl_set_ecm_error` |
| Тихий пропуск | `disabled = 0`, `s3_link is null`, `attempt` не менялся, `error_code is null` | нет источника данных / нет `image_type` / справочник не дал класс — только WARN в лог |

Пауза перед повтором (✅ `ecm/service/PublicationDecision.java:46,51,89-90`):
`min(15 мин × 2^(attempt−1), 24 ч)`, отсчёт от `updated`; при `attempt ≤ 0` пауза не применяется.
Дедлайн: 24 часа от `created` → `408`; дедлайн проверяется **раньше** флага `request_id`,
поэтому «зависшая в полёте» строка тоже закроется по `408` (✅ `PublicationDecision.java:71`).

Выборка на публикацию (✅ `PublicationService.java:104-113`): `disabled = 0 and ecm_id is null and s3_link <> ''`,
порядок `updated asc`. Строки в полёте попадают в выборку и отсеиваются решением `NOT_DUE`.

---

## 4. Справочник `t_vux_document_ecm.error_code`

Тип колонки — `text`, длина не ограничена. `error_message` — до 500 символов, переводы строк схлопнуты в пробел
(✅ `PublicationAttempt.java:37,154-163`).

### 4.1 Доменные коды валидатора csv-former

Пишет `CuvTaskHandler.writeError` (✅ `DocumentValidator.java:24-27,52,56-79`).

| `error_code` | `error_message` (дословно) | Когда | Что делать сервису ЕСМ |
|---|---|---|---|
| `404` | `Данные отсутствуют` | нет строки документа, либо `workflow_run_id` / `doc_date` пусты. Проверка прерывает остальные | Пропускать. Строк по этому `xbrl_id` больше не будет, пока данные не появятся и строку не пересоздадут |
| `405` | `НЕ известен класс документа для размещения в ЕСМ` | `doc_type_id` пуст, или типа нет в справочнике, или `ecm_class_name` не разобрался в `DocumentType` (в этом случае код приходит вместе с `406`) | Пропускать: публиковать некуда, нужен справочник |
| `406` | `НЕ известна папка размещения документа размещения в ЕСМ` | в справочнике пуст `ecm_folder_id` | Пропускать: нужен справочник |
| `405,406` | `НЕ известен класс документа для размещения в ЕСМ,НЕ известна папка размещения документа размещения в ЕСМ` | обе причины сразу; порядок кодов фиксирован валидатором, разделитель — запятая **без пробела** | Пропускать; разбирать как множество |

`DocumentOutcome.errorCode()` склеивает коды через `,` (`document/DocumentOutcome.java`), отсюда составное значение.

### 4.2 Дедлайн публикации

| `error_code` | `error_message` | Когда | Что делать |
|---|---|---|---|
| `408` | `Истёк срок публикации в ЕСМ` | 24 часа от `created`, а `ecm_id` так и не появился (в т.ч. если строка всё это время висела в `request_id`) | Пропускать. ⚠️ Строка очереди при этом остаётся `waiting`: `fn_ecm_request_set_timeout` не вызывается, потому что вызовов этой функции в Java нет |

### 4.3 HTTP-отказы транспорта ЕСМ

Пишет `PublicationAttempt.writeError`: `error_code = String.valueOf(status)`, `error_message` = тело ответа
(✅ `PublicationAttempt.java:133-145`). Классификация (✅ `ecm/client/EcmClient.java:93-116`):

| Ответ ЕСМ | Класс | Что пишется в строку |
|---|---|---|
| `200` + UUID в теле | приём | ничего (ждём callback) |
| `429`, `5xx` | временный | ничего в `error_code`; WARN в лог и сдвиг `updated` |
| `200` без UUID, `3xx`, прочие `< 400` | временный | ничего в `error_code` |
| любой `4xx`, кроме `429` | терминальный | `error_code = <статус>`, `error_message` = тело |
| сеть/таймаут (`ResourceAccessException`) | временный | ничего в `error_code` |

Возможные значения: любой `4xx`, кроме `429`, — например `400`, `401`, `403`, `409`, `410`, `413`, `415`, `422`, `423`.
Точный список задаёт сам ЕСМ, поэтому в коде и в проверках нельзя опираться на закрытый перечень.

Особенности текста (✅):

- тело обрезается до 500 символов, переводы строк схлопываются — полное тело только в WARN-логе;
- пустое тело → `Транспорт ЕСМ вернул отказ без текста`;
- тело может содержать внутренние идентификаторы ЕСМ, поэтому `error_message` не годится для показа пользователю.

### 4.4 Коллизия кодов

`404`, `405`, `406`, `408` — доменные коды, но все четыре входят и в пространство HTTP-статусов,
поэтому от ЕСМ может прийти любой из них. Плюс «настоящие» HTTP-коды `400`, `401`, `403` и остальные.
Различить источники по `error_code` нельзя: доменный `404` и HTTP `404` в этой колонке неотличимы.
⚠️ Пока формат не изменён, единственный (и хрупкий) признак — сверка `error_message`
(`Данные отсутствуют` против тела ответа ЕСМ).

---

## 5. Коды CUV-проверки (другой приёмник)

Пишет `InitialProcessingStrategy` (фаза 1) через `CuvErrorStorageService.replaceErrors`: функция очистки прежних
ошибок документа (`fn_flow_cuv_clear_errors`, рабочее имя, Q-9), затем `fn_flow_cuv_set_error(doc_id, error_message,
error_code)` на каждую ошибку, всё в одной транзакции (D-48). Если повторная проверка прошла без ошибок, прежние ошибки
удаляются без записи новых (`CuvErrorStorageService.clearErrorsIfPresent`). У таблицы только три колонки: `doc_id`,
`error_message`, `error_code` (✅ по `information_schema`), времени записи нет.

Проверка общая для всех форм с `check_mode = 'cuv'` (D-58). Код — `DCUV_<код формы>_NNN`, точки в коде формы
заменяются на `_` (`0420415.1.3` → `DCUV_0420415_1_3_005`); строит `CuvErrors.code`. Заголовок ошибки в таблице
не хранится, в протоколе подставляется `Ошибка сверки data с units, values, context по форме <код формы>`.

| Код | Сообщение (шаблон) | Правило |
|---|---|---|
| `DCUV_<форма>_001` | `Не удалось определить идентификатор процесса создавшего документ workflow_run_id НЕ заполнен.` | `WorkflowRunIdRule` |
| `DCUV_<форма>_002` | `По workflow_run_id = %d НЕ получен context.` | `ContextExistsRule` |
| `DCUV_<форма>_003` | `По workflow_run_id = %d НЕ получен набор единиц измерений unit.` | `UnitExistsRule` |
| `DCUV_<форма>_004` | `По workflow_run_id = %d НЕ получен набор значений value.` | `ValueExistsRule` |
| `DCUV_<форма>_005` | `Обнаружены лишние context: [id, …].` | `OrphanContextIdsRule` |
| `DCUV_<форма>_006` | `Обнаружены лишние unit: [id, …].` | `OrphanUnitIdsRule` |
| `DCUV_<форма>_007` | `Обнаружены context_id без описания: [id, …].` | `MissingContextDescriptionsRule` |
| `DCUV_<форма>_008` | `Обнаружены unit_id без описания: [id, …].` | `MissingUnitDescriptionsRule` |
| `DCUV_<форма>_009` | `По workflow_run_id = %d выявлено несовпадение версий таксономий.` или `По workflow_run_id = %d не указана версия таксономии.` (D-64) | `TaxonomyMismatchRule` (context, unit, value и `xbrlvers` из data; пустые значения не учитываются) |
| `DCUV_<форма>_010` | Сводка, одна строка на показатель и вид расхождения: `В отчете id = %d для параметра {показатель} {вид}: N. Примеры контекстов: c1, c2, c3.`; виды — `выявлено несовпадение значений в csv и detail`, `не найдена связь с data в справочнике t_adm_data_xbrl_link`, `найдено несколько связей с data в справочнике t_adm_data_xbrl_link`, `не найдена строка в data`, `найдено несколько строк в data`, `не удалось разобрать описание контекста (scenario)`; обратная сверка — `…отсутствуют значения витрины (колонка {колонка}): N. Примеры строк витрины: {ключ}; …` (аналитика 7.7) | `SummaryAnalyticsRule` (D-57, D-67, D-68). Число N — все расхождения группы; оно же учитывается в «количестве отклонений» протокола и в `error_count` статуса CUV |

Перечни id в ошибках 005–008 отсортированы, чтобы текст не менялся при повторной проверке.

Как это связано с СУПЗ: ошибка CUV равнозначна ошибке проверки БД — расписанию ставится статус 2, загружается
протокол с ошибками, уходит письмо, расписание закрывается; записи выгрузки CSV и задача в СУПЗ не создаются
(D-45, FR-1.5). Если в фазе 1 письмо не ушло, фаза 2 досылает его по ошибкам из этой таблицы (FR-2.12).

Состояние на ИФТ на 13.11.2026 (✅, до доработки): `t_vux_document_cuv_validation_result` — `005` × 15,
`008` × 10, `010` × 8; строк с `error_code = 'ERROR_CODE'` нет. В `t_vux_document_ecm` строк нет вообще.

---

## 6. Очередь `t_vux_ecm_queue`

Колонки: `request_id`, `subsystem`, `subsystem_id`, `request_date`, `ecm_id`, `response_date`, `error_text`,
`response_status` (✅). Связь со строкой документа — `subsystem_id = t_vux_document_ecm.xbrl_id`
(`t_vux_document_ecm.request_id` после отказа обнуляется, поэтому join по `request_id` даёт пусто).

| `response_status` | Кто ставит | `error_text` | Что означает |
|---|---|---|---|
| `waiting` | `fn_ecm_request_create` / `fn_flow_xbrl_ecm_set_status('waiting')` | пусто | запрос принят ЕСМ, ждём TFS |
| `success` | `fn_ecm_request_set_ecm_id` | пусто | `ecm_id` присвоен |
| `error` | `fn_ecm_request_set_error` | текст отказа | отказ обработки (в т.ч. `Send failed` от Kafka) |
| `timeout` | `fn_ecm_request_set_timeout` | **пусто** | ⚠️ вызовов этой функции в Java нет |

Особенности:

- в `error_text` нет машинного кода: причина `429` и `500` выглядит одинаково — человеческой строкой;
  `ErrorCode.value` из `gmap2-vux-ecm` в БД не сохраняется;
- `fn_ecm_request_set_error` обновляет строку только из `waiting` (guard есть), а `fn_ecm_request_set_status`
  — **без guard** и без обнуления `request_id` (✅ по `prosrc`): повторный вызов может переписать `success` на `error`;
- строка в `waiting` без вызывающего `set_timeout` живёт вечно; для CUV-конвейера её закрывает только дедлайн `408`
  на стороне csv-former, и тогда строка очереди остаётся `waiting` навсегда.

---

## 7. `ErrorCode` в `gmap2-vux-ecm`

`exception/ecm/ErrorCode.java` — 15 констант, каждая `(value, messageTemplate)`, `getMessage(...)` через
`String.format`. Значение `value` используется только в текстах исключений и логах: в БД не пишется ни в одну
из трёх таблиц (✅ — прямых вызовов записи `value` нет).

| Константа | `value` | Назначение |
|---|---|---|
| `GENERAL_ERROR` | `GENERAL_ERROR` | общая ошибка сервиса |
| `ECM_S3_UPLOAD_ERROR` | `ECM_S3_UPLOAD_ERROR` | ошибка выгрузки в S3 |
| `ECM_S3_GENERAL_ERROR` | `ECM_S3_COMMON_ERROR` | ⚠️ имя константы и значение расходятся (D16) |
| `ECM_S3_UNEXPECTED_ERROR` | `ECM_S3_UNEXPECTED_ERROR` | непредвиденная ошибка S3 |
| `ECM_S3_DOWNLOAD_ERROR` | `ECM_S3_DOWNLOAD_ERROR` | ошибка скачивания из S3 |
| `ECM_RESPONSE_ERROR` | `ECM_RESPONSE_ERROR` | ошибка ответа ЕСМ |
| `ECM_RESPONSE_GENERAL_ERROR` | `ECM_RESPONSE_GENERAL_ERROR` | общая ошибка разбора ответа |
| `ECM_WRITE_XML_ERROR` | `ECM_WRITE_XML_ERROR` | ошибка записи XML |
| `ECM_READ_XML_ERROR` | `ECM_READ_XML_ERROR` | ⚠️ не выбрасывается ниоткуда (мёртвая константа) |
| `ECM_RESPONSE_FILE_NOT_FOUND` | `ECM_RESPONSE_FILE_NOT_FOUND` | файл не найден в ответе |
| `ECM_RESPONSE_STATUS_IS_NULL` | `ECM_RESPONSE_STATUS_IS_NULL` | пустой статус в ответе |
| `ECM_RESPONSE_RESULT_CODE_IS_NOT_SUCCESS` | `ECM_RESPONSE_RESULT_CODE_IS_NOT_SUCCESS` | `resultCode != success` |
| `ECM_RESPONSE_NEW_ID_IS_BLANK` | `ECM_RESPONSE_NEW_ID_IS_BLANK` | пустой `newId` |
| `ECM_RESPONSE_BA_ATTR_NOT_FOUND` | `ECM_RESPONSE_BA_ATTR_NOT_FOUND` | нет атрибута `ba` |
| `ECM_EMPTY_RESPONSE_ERROR` | `ECM_EMPTY_RESPONSE_ERROR` | пустой ответ |

Ответ на вопрос «что записывается в `error_code`»: эти значения — **ничего**. В `error_code` попадают только
`404/405/406/408` и HTTP-статусы из раздела 4.

---

## 8. Правило проверки перед отправкой задачи в СУПЗ

### 8.1 Точка врезки

**Реализовано (16.11.2026).** Фаза 1 после успешной CUV-проверки и загрузки протокола создаёт три записи выгрузки
(`fn_xbrl_create_ecm`, `image_type` = `CONTEXT` / `UNIT` / `VALUE`) и оставляет расписание открытым. Фаза 2
(`FollowUpProcessingStrategy`) читает `t_vux_document_ecm` по `doc_id` (`VuxDocumentEcmRepository`,
`DocumentEcmExportService.evaluateCuvCsvExport`) и создаёт задачу в СУПЗ, только когда у всех трёх образов есть `ecm_id`.
Разделы 8.2–8.4 — исходный разбор; фактическое правило — в 8.3.

### 8.2 Таблица решений по одной строке

| Условие (по строке `t_vux_document_ecm`) | Состояние | Действие сервиса |
|---|---|---|
| `disabled = 1 and error_code is not null` | терминальный отказ | **блокировать** СУПЗ, зафиксировать код и текст; требуется ручной разбор |
| `ecm_id is not null` | опубликовано | не мешает |
| `request_id is not null` | в полёте | **ждать**, не блокировать навсегда |
| `request_id is null and ecm_id is null and attempt > 0` | был временный отказ | **ждать** повтор; причину брать из `t_vux_ecm_queue` |
| `request_id is null and ecm_id is null and (attempt is null or attempt = 0)` | файл ещё не собран | **ждать** |
| `s3_del = 1` | файл к удалению | не мешает |

### 8.3 Решение по документу

Строк на документ несколько (`image_type` = `CONTEXT` / `UNIT` / `VALUE`, ✅ `ImageTypeEnum.CUV_CSV_TYPES`),
поэтому решение агрегируется по `doc_id`. В коде по каждому типу берётся последняя строка по `created`;
нет строк по типу — запись восстанавливается (`fn_xbrl_create_ecm`), `disabled = 1` — ERROR в лог, запись
не пересоздаётся, расписание остаётся открытым до ручного разбора (D-43). Исходное правило:

1. есть строка с `disabled = 1` → **не отправлять** задачу в СУПЗ, писать WARN с `error_code`/`error_message`;
2. иначе есть строка без `ecm_id` → **отложить** (не отправлять сейчас, повторить на следующем проходе);
3. иначе все строки с `ecm_id` → **отправлять**.

«Отложить» отличается от «не отправлять»: при откладывании `supz_task_id` не заполняется, и следующий проход
планировщика повторит попытку сам; при блокировке нужен ручной разбор, иначе документ будет молча пропускаться
на каждом проходе.

### 8.4 SQL для проверки

Строки документа вместе с их последним запросом (когда `request_id` ещё есть):

```sql
select e.xbrl_id,
       e.image_type,
       e.disabled,
       e.ecm_id,
       e.request_id,
       e.attempt,
       e.error_code,
       e.error_message,
       e.s3_del,
       e.created,
       e.updated,
       q.response_status,
       q.error_text,
       q.response_date
from s_grnplm_as_cib_gm_vux.t_vux_document_ecm e
left join s_grnplm_as_cib_gm_vux.t_vux_ecm_queue q
       on q.request_id = e.request_id
where e.doc_id = :docId
order by e.image_type
```

Причина отказа транспорта, когда `request_id` уже обнулён (join по `subsystem_id`):

```sql
select q.request_id,
       q.response_status,
       q.error_text,
       q.request_date,
       q.response_date
from s_grnplm_as_cib_gm_vux.t_vux_ecm_queue q
where q.subsystem = 'xbrl'
  and q.subsystem_id = :xbrlId
order by q.request_date desc
```

Проверка вхождения кода в составное значение (без равенства):

```sql
select e.xbrl_id, e.error_code
from s_grnplm_as_cib_gm_vux.t_vux_document_ecm e
where e.doc_id = :docId
  and (',' || e.error_code || ',') like '%,406,%'
```

⚠️ В Java: `Arrays.asList(errorCode.split(","))` (с `trim` на всякий случай) — и проверять вхождение,
а не `equals`.

---

## 9. Дефекты, коллизии и пробелы

Приоритет: **P1** — искажает данные или блокирует разбор, **P2** — сбивает сопровождение, **P3** — гигиена.

| № | Приоритет | Что | Где | Последствие |
|---|---|---|---|---|
| D1 | P1 | **Исправлено** (код строит `CuvErrors.code`). В `new ValidationErrorDto(...)` вторым аргументом передана строка `"ERROR_CODE"` вместо константы | `service/checks/MissingUnitDescriptionsRule.java:44` | в `error_code` пишется литерал `ERROR_CODE`; `ValidationDataService.getChecks` (`:46`) сверяет `e.errorCode()` с `getCode()` и показывает по правилу 008 «Не выявлено, 0» |
| D2 | P1 | **Исправлено** (перечень — отсортированный набор). `%s`.formatted(`missing.toArray()`) — массив растекается по varargs, печатается только первый элемент (а при `null`/пустом значении — ничего) | там же, `:45` | сообщение теряет перечень `unit_id`; на ИФТ лежат именно такие строки: `Обнаружены unit_id без описания: .` и `… : [].` |
| D3 | P1 | **Исправлено 17.11.2026:** правило 010 реализовано заново и включено (D-68). Было: правило 010 выключено до этапа 2 (D-57, Q-8). Тело `validate()` закомментировано (`// todo проверка выключена`), метод возвращает `Optional.empty()` | `service/checks/SummaryAnalyticsRule.java:50-90` | правило 010 не срабатывает никогда, а `getCode()` и сообщения остались; при этом на ИФТ есть 8 строк `DCUV_0420415_1_3_010` — значит, писались другой сборкой |
| D4 | P1 | Три азбуки в одном `error_code`: доменные `404/405/406/408` и HTTP-статусы | `DocumentValidator.java:24-27`, `PublicationAttempt.java:133-145` | нельзя отличить доменный `404` от HTTP `404`; фильтры по коду ломаются |
| D5 | P1 | Составной код `405,406` через запятую без пробела | `DocumentOutcome.errorCode()` | сравнение на равенство не работает, нужен разбор множества |
| D6 | P1 | Временные отказы транспорта не попадают ни в `error_code`, ни в `error_message` (только `attempt`, `updated` и лог) | `PublicationAttempt.java:104-118` | по строке нельзя понять, что публикация уже падала; «`request_id` пуст, `attempt = 3`» читается как норма |
| D7 | P2 | `fn_ecm_request_set_timeout` не вызывается из Java; строка очереди в `waiting` не истекает | `t_vux_ecm_queue` | после дедлайна строка документа закрывается `408`, а запись очереди остаётся `waiting` навсегда; `error_text` пуст |
| D8 | P2 | `fn_ecm_request_set_status` обновляет без guard `response_status = 'waiting'` и не обнуляет `request_id` | `prosrc` | повторный/запоздалый вызов может переписать `success` на `error`; при `error` через эту функцию `request_id` останется заполненным и строка «залипнет» в полёте |
| D9 | P2 | `fn_xbrl_set_ecm_error` ставит `disabled = 1` безусловно и не чистит `request_id`; процедуры сброса `disabled` нет | `prosrc` | терминально упавшую строку нельзя перезапустить без ручного `update`; при отказе во время полёта остаются и `request_id`, и `disabled = 1` |
| D10 | P2 | `fn_flow_xbrl_csv_ecm_set_status` не считает `attempt` и не двигает `updated` на `error`/`timeout` | `prosrc` | для подсистемы `xbrl-csv` нет ни счётчика, ни паузы — при подключении будет hot-loop. Сейчас csv-former всегда шлёт `subsystem = 'xbrl'` (`PublicationRequest.java:20`), поэтому дефект спящий |
| D11 | P2 | В `error_text` очереди нет кода ошибки, только текст | `fn_ecm_request_set_error` | нельзя программно отличить `429` от `500`, нельзя строить метрики по причине |
| D12 | P2 | `error_message` обрезается до 500 символов, переводы строк схлопываются | `PublicationAttempt.java:37,154-163` | в БД неполный текст ответа ЕСМ; полный — только в логе |
| D13 | P2 | **Исправлено:** при ошибках view — протокол с ошибками и письмо, без выгрузки (`InitialProcessingStrategy.handleCuvFormSuccess`). `handleCuvFormSuccess` проверяет «стандартные дефекты из view», но блокировка закомментирована (`todo`) | `OrchestratorService.java:213-220` | документ с дефектами из view всё равно публикуется в ЕСМ |
| D14 | P2 | Ошибка записи терминального кода только логируется: строка остаётся активной и будет повторяться без паузы | `CuvTaskHandler.java:147-150` | при недоступности db-facade терминальный отказ не фиксируется, задание крутится каждый цикл |
| D15 | P3 | Тихие пропуски без следа в БД: `image_type is null`, пустой справочник, `DATA_MISSING`/`SOURCE_MISSING` | `PublicationService.java:219-240`, `GenerationOutcome` | строка выглядит как «новая», причину видно только в логе |
| D16 | P3 | Имя константы `ECM_S3_GENERAL_ERROR` не совпадает со значением `ECM_S3_COMMON_ERROR` | `exception/ecm/ErrorCode.java:13` | поиск по имени в логах не находит значение |
| D17 | P3 | `ECM_READ_XML_ERROR` не используется | `exception/ecm/ErrorCode.java` | мёртвая константа |
| D18 | P3 | `CleanupService` ждёт `s3_link <> ''`, а `fn_xbrl_clear_ecm_file` пишет `null` | `EcmColumns.NO_S3_LINK`, `fn_xbrl_clear_ecm_file` | работает только за счёт трёхзначной логики `NULL`; при переходе на `IS DISTINCT FROM` поведение изменится |
| D19 | P3 | Опечатка в тексте: «папка размещения документа размещения в ЕСМ» | `DocumentValidator.java:30` | текст уходит в БД дословно |

Отдельно про D1/D3 и данные ИФТ: `error_code = 'ERROR_CODE'` в таблице нет, а `010` есть, хотя правило выключено.
Значит, текущие строки писались другой сборкой (или до правок), и по ИФТ нельзя судить, что именно запишет
текущая ветка. После первого же прогона валидации с ошибкой 008 в `error_code` появится `ERROR_CODE` —
это и будет проверкой гипотезы.

---

## 10. Что делать по порядку

1. **Сделано.** **P1, минимальная правка:** в `MissingUnitDescriptionsRule` вернуть `ERROR_CODE` и заменить
   `missing.toArray()` на `String.join(", ", missing)` (или `missing`), чтобы в `error_message` был перечень.
   Это единственное место, где код ошибки расходится с `getCode()`, — проверить остальные 9 правил не нужно (✅ проверено).
2. **P1, решение по формату:** либо ввести отдельное пространство доменных кодов (`CUV_404`, `ECM_HTTP_404`),
   либо оставить как есть и в проверке перед СУПЗ опираться на `error_message`, но тогда зафиксировать это
   в коде явным комментарием. Текущее смешение — источник ошибок чтения.
3. **Сделано** (раздел 8.1). **P1, проверка перед СУПЗ:** реализовать чтение `t_vux_document_ecm` по `doc_id` и правило из 8.3.
4. **P2:** вызывать `fn_ecm_request_set_timeout` по расписанию (например, по строкам `waiting` старше N минут либо
   синхронно из csv-former при дедлайне `408`), чтобы очередь не накапливала вечные `waiting`.
5. **P2:** добавить guard `response_status = 'waiting'` в `fn_ecm_request_set_status`; либо перестать её использовать
   и звать `set_error`/`set_timeout`, у которых guard есть.
6. **P2:** решить, нужен ли сброс `disabled`: без него повторная публикация невозможна, а ручной `update`
   в промышленной схеме — плохая практика. Вариант: отдельная процедура `fn_xbrl_reset_ecm_error(xbrl_id, attempt)`.
7. **Сделано 17.11.2026 (D-68).** `SummaryAnalyticsRule` реализовано и включено; проверить на данных стенда (аналитика, Q-8 п. 5).
8. **P3:** поправить текст `406`, выровнять `ECM_S3_GENERAL_ERROR`/`ECM_S3_COMMON_ERROR`, удалить `ECM_READ_XML_ERROR`.

---

## 11. Приложение: как посмотреть состояние самому

ИФТ, схема `s_grnplm_as_cib_gm_vux`. Внутри стенда — через `tools\gp\gp-env.cmd psql`, при необходимости
с `set "GP_ENV=...gp-ift.env"`.

```sql
-- все строки документа и их состояние
select doc_id, xbrl_id, image_type, disabled, ecm_id, request_id, attempt,
       error_code, left(error_message, 80) as msg, s3_del, updated
from s_grnplm_as_cib_gm_vux.t_vux_document_ecm
where doc_id = :docId
order by image_type;

-- терминальные отказы: распределение по кодам
select error_code, count(*)
from s_grnplm_as_cib_gm_vux.t_vux_document_ecm
where disabled = 1 and error_code is not null
group by error_code
order by 2 desc;

-- очередь по документу
select q.request_id, q.subsystem, q.subsystem_id, q.response_status,
       q.request_date, q.response_date, left(q.error_text, 120) as err
from s_grnplm_as_cib_gm_vux.t_vux_ecm_queue q
where q.subsystem = 'xbrl'
  and q.subsystem_id = :xbrlId
order by q.request_date desc;

-- CUV-ошибки формы
select error_code, left(error_message, 120) as msg
from s_grnplm_as_cib_gm_vux.t_vux_document_cuv_validation_result
where doc_id = :docId;
```

Функции, которые меняют состояние (для справки):

| Функция | Что делает |
|---|---|
| `fn_xbrl_set_ecm_file(xbrl_id, file_name, s3_link)` | заполняет `s3_link`, `file_name`, двигает `updated` |
| `fn_flow_xbrl_ecm_set_status(xbrl_id, request_id, status, ecm_id)` | `waiting`: `request_id` + `attempt+1`; `success`: `ecm_id` + `sent`; `error`/`timeout`: `request_id = null` |
| `fn_xbrl_set_ecm_error(xbrl_id, error_code, error_message)` | терминальный отказ: `error_code`, `error_message`, `disabled = 1` |
| `fn_xbrl_clear_ecm_file(xbrl_id)` | `s3_link = null` после удаления объекта из S3 |
| `fn_ecm_request_create(...)` | строка очереди в `waiting` |
| `fn_ecm_request_set_ecm_id(request_id, ecm_id, ecm_date)` | `success` + `ecm_id`, затем callback подсистемы |
| `fn_ecm_request_set_error(request_id, error_text)` | `error` + `error_text`, затем callback подсистемы |
| `fn_ecm_request_set_status(request_id, status)` | статус без guard, без текста |
| `fn_ecm_request_set_timeout(request_id)` | `timeout` (вызовов в Java нет) |
| `fn_flow_cuv_set_error(doc_id, error_message, error_code)` | строка в `t_vux_document_cuv_validation_result` |
| `fn_flow_cuv_clear_errors(doc_id)` — рабочее имя, создаёт команда БД (Q-9) | удаляет прежние ошибки CUV документа |
| `fn_flow_set_supz_id(result_doc_id, supz_id, supz_status, supz_json)` | `supz_task_id` документа и `t_vux_document.supz_status = 1` |
