package ru.sbrf.gmap.vux.service.checks;

import lombok.experimental.UtilityClass;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Коды и заголовки ошибок CUV-проверки. Код ошибки имеет вид {@code DCUV_<код формы>_<номер проверки>},
 * точки в коде формы заменяются на {@code _}: {@code 0420415.1.3} → {@code DCUV_0420415_1_3_005}.
 * Заголовок содержит код формы.
 * <p>
 * Строка сводки проверки 10 описывает несколько расхождений; их число записывается в текст после двоеточия
 * («…: 12. Примеры …») и читается обратно {@link #deviationCount(String)}, потому что в таблице ошибок CUV
 * отдельной колонки для него нет.
 */
@UtilityClass
public class CuvErrors {

    private static final String CODE_PREFIX = "DCUV_";
    private static final String UNKNOWN_FORM = "UNKNOWN";
    private static final String TITLE = "Ошибка сверки data с units, values, context по форме ";
    private static final Pattern DEVIATION_COUNT = Pattern.compile(":\\s(\\d+)\\.(?:\\s|$)");

    /**
     * Формирует код ошибки проверки для формы. Если код формы пуст, используется {@code UNKNOWN}.
     *
     * @param formCode код формы
     * @param number   номер проверки
     * @return код ошибки
     */
    public static String code(String formCode, String number) {
        String form = formCode == null || formCode.isBlank() ? UNKNOWN_FORM : formCode.trim().replace('.', '_');
        return CODE_PREFIX + form + "_" + number;
    }

    /**
     * Формирует заголовок ошибки CUV-проверки для протокола.
     *
     * @param formCode код формы
     * @return заголовок ошибки
     */
    public static String title(String formCode) {
        return TITLE + (formCode == null ? "" : formCode.trim());
    }

    /**
     * Создаёт ошибку проверки для формы документа из контекста.
     *
     * @param context данные формы
     * @param number  номер проверки
     * @param message текст ошибки
     * @return ошибка проверки
     */
    public static ValidationErrorDto error(DataContext context, String number, String message) {
        return new ValidationErrorDto(title(context.formCode()), code(context.formCode(), number), message);
    }

    /**
     * Создаёт строку сводки: одно утверждение о группе расхождений, их число и примеры.
     * Текст имеет вид «{утверждение}: {число}. {подпись примеров}: {примеры}.»; без примеров —
     * «{утверждение}: {число}.».
     *
     * @param context       данные формы
     * @param number        номер проверки
     * @param statement     утверждение без завершающей точки
     * @param count         число расхождений
     * @param examplesLabel подпись примеров, например «Примеры контекстов»
     * @param examples      примеры через разделитель; пустая строка — без примеров
     * @return ошибка проверки с числом расхождений
     */
    public static ValidationErrorDto summaryError(DataContext context, String number, String statement, int count,
                                                  String examplesLabel, String examples) {
        String message = examples == null || examples.isBlank()
                ? "%s: %d.".formatted(statement, count)
                : "%s: %d. %s: %s.".formatted(statement, count, examplesLabel, examples);
        return new ValidationErrorDto(title(context.formCode()), code(context.formCode(), number), message, count);
    }

    /**
     * Читает число расхождений из текста ошибки, сохранённого в БД. Для строки сводки это число после двоеточия,
     * для остальных ошибок — {@code 1}.
     *
     * @param message текст ошибки
     * @return число расхождений, не меньше {@code 1}
     */
    public static int deviationCount(String message) {
        if (message == null) {
            return 1;
        }
        Matcher matcher = DEVIATION_COUNT.matcher(message);
        if (!matcher.find()) {
            return 1;
        }
        try {
            return Math.max(1, Integer.parseInt(matcher.group(1)));
        } catch (NumberFormatException e) {
            return 1;
        }
    }
}
