package ru.sbrf.gmap.vux.service.checks;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.cuv.CuvContextDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvLinkDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvUnitDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvValueDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Загружает данные отчётной формы для CUV-проверки.
 * <p>
 * Имена таблиц формы берутся из записи расписания (view {@code v_vux_document_shedule_int}: {@code table_context_name},
 * {@code table_units_name}, {@code table_values_name}, {@code table_name}; значения — из справочника типов
 * документов), таблицы читаются по {@code workflow_run_id}. Отдельные классы для форм не нужны: таблицы context,
 * unit и value у всех форм устроены одинаково, строки data читаются в виде «колонка → значение».
 * <p>
 * Отсутствие {@code workflow_run_id} или данных не считается сбоем: возвращается контекст с пустыми списками,
 * и правила выдают ошибки {@code _001}–{@code _004}. Ошибки БД и недопустимое имя таблицы передаются вызывающему
 * методу, и запись остаётся открытой до следующего цикла.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CuvFormDataLoader {

    /**
     * Схема таблиц формы.
     */
    static final String SCHEMA = "s_grnplm_as_cib_gm_vux";
    /**
     * Допустимое имя таблицы: строчные латинские буквы, цифры и {@code _}, начинается с буквы (до 63 символов).
     */
    private static final Pattern TABLE_NAME = Pattern.compile("[a-z][a-z0-9_]{0,62}");
    /**
     * Колонка версии таксономии в таблице data (для проверки 9); у формы её может не быть.
     */
    static final String DATA_TAXONOMY_COLUMN = "xbrlvers";
    private static final String WORKFLOW_RUN_ID = "workflowRunId";
    private static final String LINKS_SQL = """
            SELECT table_name, column_name, column_xbrl_type, enum_id, axis_id, taxis_id, parameter_id, measure_id,
                   line_key, analytical_section
            FROM s_grnplm_as_cib_gm_vux.t_adm_data_xbrl_link
            WHERE doc_type_id = :docTypeId
              AND trim(taxonomy) = :taxonomy""";
    private static final String ENUM_VALUES_SQL = """
            SELECT enum_id, enum_value_code, enum_value_text
            FROM s_grnplm_as_cib_gm_vux.t_adm_xbrl_enum_values
            WHERE trim(taxonomy_id) = :taxonomy
              AND enum_id IN (:enumIds)""";

    private final NamedParameterJdbcTemplate jdbcTemplate;

    /**
     * Загружает данные формы документа. Если имя таблицы data не задано, строки data не загружаются.
     * <p>
     * Если данные формы есть, версия таксономии отчёта одна и таблица data задана, дополнительно читаются связи
     * колонок data с показателями XBRL ({@code t_adm_data_xbrl_link}) для формы, таблицы data и таксономии
     * и перекодировка нужных перечислений ({@code t_adm_xbrl_enum_values}) — для проверки 10.
     *
     * @param record запись расписания: документ, код формы, {@code workflow_run_id} и имена таблиц формы
     * @return контекст проверки, не {@code null}
     * @throws IllegalStateException при недопустимом имени таблицы формы в справочнике
     * @throws org.springframework.dao.DataAccessException при ошибке БД
     */
    public DataContext load(VuxDocumentScheduleViewEntity record) {
        long docId = record.getResultDocumentId().longValue();
        String formCode = record.getDocTypeCode();
        Long workflowRunId = record.getWorkflowRunId();
        if (workflowRunId == null) {
            log.warn("[CUV] No form data: workflow_run_id is empty, scheduleId={}, docId={}, form={}. Check 001 will report an error.",
                    record.getScheduleId(), docId, formCode);
            return DataContext.empty(docId, formCode, null);
        }
        Map<String, Object> params = Map.of(WORKFLOW_RUN_ID, workflowRunId);

        List<CuvContextDto> contexts = jdbcTemplate.query(
                "SELECT context_id, scenario, taxonomy, workflow_run_id FROM "
                        + qualifiedTableName(record.getTableContextName(), "context")
                        + " WHERE workflow_run_id = :" + WORKFLOW_RUN_ID,
                params, (rs, rowNum) -> CuvContextDto.builder()
                        .contextId(rs.getString("context_id"))
                        .scenario(rs.getString("scenario"))
                        .taxonomy(rs.getString("taxonomy"))
                        .workflowRunId(getLong(rs, "workflow_run_id"))
                        .build());
        List<CuvUnitDto> units = jdbcTemplate.query(
                "SELECT unit_id, taxonomy, workflow_run_id FROM "
                        + qualifiedTableName(record.getTableUnitsName(), "unit")
                        + " WHERE workflow_run_id = :" + WORKFLOW_RUN_ID,
                params, (rs, rowNum) -> CuvUnitDto.builder()
                        .unitId(rs.getString("unit_id"))
                        .taxonomy(rs.getString("taxonomy"))
                        .workflowRunId(getLong(rs, "workflow_run_id"))
                        .build());
        List<CuvValueDto> values = jdbcTemplate.query(
                "SELECT element_name, value, \"nil\", context_id, unit_id, decimals, taxonomy, workflow_run_id FROM "
                        + qualifiedTableName(record.getTableValuesName(), "value")
                        + " WHERE workflow_run_id = :" + WORKFLOW_RUN_ID,
                params, (rs, rowNum) -> CuvValueDto.builder()
                        .elementName(rs.getString("element_name"))
                        .value(rs.getString("value"))
                        .nil(rs.getString("nil"))
                        .contextId(rs.getString("context_id"))
                        .unitId(rs.getString("unit_id"))
                        .decimals(rs.getString("decimals"))
                        .taxonomy(rs.getString("taxonomy"))
                        .workflowRunId(getLong(rs, "workflow_run_id"))
                        .build());

        List<Map<String, Object>> dataRows = record.getTableName() == null || record.getTableName().isBlank()
                ? List.of()
                : jdbcTemplate.queryForList(
                "SELECT * FROM " + qualifiedTableName(record.getTableName(), "data")
                        + " WHERE workflow_run_id = :" + WORKFLOW_RUN_ID, params);
        Set<String> dataTaxonomies = dataRows.stream()
                .map(row -> row.get(DATA_TAXONOMY_COLUMN))
                .filter(Objects::nonNull)
                .map(Object::toString)
                .collect(Collectors.toCollection(TreeSet::new));

        log.info("[CUV] Form data loaded: scheduleId={}, docId={}, form={}, workflowRunId={}, context={}, unit={}, value={}, data={}",
                record.getScheduleId(), docId, formCode, workflowRunId, contexts.size(), units.size(), values.size(), dataRows.size());
        DataContext context = new DataContext(docId, formCode, workflowRunId, contexts, units, values, dataRows, dataTaxonomies);
        return withReference(record, context);
    }

    /**
     * Дочитывает справочник связей и перекодировку перечислений, если по контексту возможна проверка 10.
     * Связи отбираются по форме ({@code doc_type_id}) и таксономии отчёта, таблица data сравнивается без схемы,
     * кавычек и регистра — формат имени таблицы в справочнике связей может отличаться от справочника типов
     * документов.
     */
    private DataContext withReference(VuxDocumentScheduleViewEntity record, DataContext context) {
        Set<String> taxonomies = context.reportTaxonomies();
        if (!context.hasFormData() || taxonomies.size() != 1 || record.getDocTypeId() == null
                || record.getTableName() == null || record.getTableName().isBlank()) {
            return context;
        }
        String taxonomy = taxonomies.iterator().next();
        String dataTable = shortTableName(record.getTableName());
        List<CuvLinkDto> links = jdbcTemplate.query(LINKS_SQL,
                        Map.of("docTypeId", record.getDocTypeId(), "taxonomy", taxonomy),
                        (rs, rowNum) -> dataTable.equals(shortTableName(rs.getString("table_name"))) ? toLink(rs) : null)
                .stream()
                .filter(Objects::nonNull)
                .toList();
        Map<String, Map<String, String>> enumCodes = loadEnumCodes(taxonomy, links);
        log.info("[CUV] Reference data loaded: scheduleId={}, docId={}, form={}, dataTable={}, taxonomy={}, links={}, enums={}",
                record.getScheduleId(), context.docId(), context.formCode(), dataTable, taxonomy, links.size(), enumCodes.size());
        return context.withReference(links, enumCodes);
    }

    private Map<String, Map<String, String>> loadEnumCodes(String taxonomy, List<CuvLinkDto> links) {
        Set<String> enumIds = links.stream()
                .filter(CuvLinkDto::isEnumerator)
                .map(CuvLinkDto::enumId)
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(id -> !id.isEmpty())
                .collect(Collectors.toCollection(TreeSet::new));
        if (enumIds.isEmpty()) {
            return Map.of();
        }
        Map<String, Map<String, String>> codes = new HashMap<>();
        jdbcTemplate.query(ENUM_VALUES_SQL, Map.of("taxonomy", taxonomy, "enumIds", enumIds), (rs, rowNum) -> {
            String enumId = trimmed(rs.getString("enum_id"));
            String text = trimmed(rs.getString("enum_value_text"));
            String code = trimmed(rs.getString("enum_value_code"));
            if (enumId != null && text != null && code != null) {
                codes.computeIfAbsent(enumId, id -> new HashMap<>()).putIfAbsent(text, code);
            }
            return null;
        });
        return codes;
    }

    private static CuvLinkDto toLink(ResultSet rs) throws SQLException {
        Object lineKey = rs.getObject("line_key");
        return CuvLinkDto.builder()
                .columnName(trimmed(rs.getString("column_name")))
                .columnXbrlType(trimmed(rs.getString("column_xbrl_type")))
                .enumId(trimmed(rs.getString("enum_id")))
                .axisId(trimmed(rs.getString("axis_id")))
                .taxisId(trimmed(rs.getString("taxis_id")))
                .parameterId(trimmed(rs.getString("parameter_id")))
                .measureId(trimmed(rs.getString("measure_id")))
                .lineKey(lineKey == null ? null : ((Number) lineKey).intValue())
                .analyticalSection(rs.getString("analytical_section"))
                .build();
    }

    /**
     * Приводит имя таблицы к виду для сравнения: без кавычек, пробелов по краям, схемы {@value #SCHEMA} и регистра.
     */
    static String shortTableName(String tableName) {
        if (tableName == null) {
            return "";
        }
        String name = tableName.replace("\"", "").replace("`", "").trim().toLowerCase(Locale.ROOT);
        String schemaPrefix = SCHEMA + ".";
        return name.startsWith(schemaPrefix) ? name.substring(schemaPrefix.length()) : name;
    }

    private static String trimmed(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    /**
     * Возвращает имя таблицы формы со схемой. Имя хранится в справочнике в виде
     * {@code s_grnplm_as_cib_gm_vux.<имя>} и подставляется в SQL, поэтому проверяется: кавычки вокруг частей имени
     * снимаются, допускается имя со схемой {@value #SCHEMA} или без схемы. Другая схема или недопустимые символы
     * приводят к исключению.
     *
     * @param tableName имя таблицы из справочника
     * @param role      роль таблицы для текста ошибки: context, unit, value или data
     * @return имя таблицы со схемой
     * @throws IllegalStateException если имя пустое или недопустимое
     */
    static String qualifiedTableName(String tableName, String role) {
        if (tableName == null || tableName.isBlank()) {
            throw new IllegalStateException("Form " + role + " table name is empty in t_adm_document_type_dic");
        }
        String name = tableName.replace("\"", "").replace("`", "").trim().toLowerCase(Locale.ROOT);
        String schemaPrefix = SCHEMA + ".";
        if (name.startsWith(schemaPrefix)) {
            name = name.substring(schemaPrefix.length());
        }
        if (!TABLE_NAME.matcher(name).matches()) {
            throw new IllegalStateException("Invalid form " + role + " table name in t_adm_document_type_dic: '" + tableName + "'");
        }
        return schemaPrefix + name;
    }

    /**
     * Читает числовую колонку как {@link Long}; {@code null} сохраняется.
     */
    private static Long getLong(ResultSet rs, String column) throws SQLException {
        Object value = rs.getObject(column);
        return value == null ? null : ((Number) value).longValue();
    }
}
