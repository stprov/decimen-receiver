package ru.sbrf.gmap.vux.service.checks;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvUnitDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvValueDto;

import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.List;

/**
 * CUV-проверка 006: нет ли в unit лишних {@code unit_id}, на которые не ссылается ни одна строка value.
 * Выполняется, если есть строки unit и value. Идентификаторы в тексте ошибки отсортированы, чтобы текст не менялся при повторной проверке.
 */
@Component
@Order(6)
public class OrphanUnitIdsRule implements ValidationRule {

    private static final String NUMBER = "006";
    private static final String CHECK_DESCRIPTION = "В value отсутствуют лишние значения unit";

    @Override
    public List<ValidationErrorDto> validate(DataContext ctx) {
        if (ctx.unitList().isEmpty() || ctx.valueList().isEmpty()) {
            return List.of();
        }
        Set<String> orphans = ctx.unitList().stream()
                .map(CuvUnitDto::unitId)
                .filter(Objects::nonNull)
                .collect(Collectors.toCollection(TreeSet::new));
        ctx.valueList().stream().map(CuvValueDto::unitId).filter(Objects::nonNull).forEach(orphans::remove);
        if (!orphans.isEmpty()) {
            return List.of(CuvErrors.error(ctx, NUMBER, "Обнаружены лишние unit: %s.".formatted(orphans)));
        }
        return List.of();
    }

    @Override
    public String getDescription() {
        return CHECK_DESCRIPTION;
    }

    @Override
    public String getNumber() {
        return NUMBER;
    }
}
