package ru.sbrf.gmap.vux.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import org.hibernate.annotations.Immutable;
import ru.sbrf.gmap.vux.entity.enums.MailStatusEnum;
import ru.sbrf.gmap.vux.entity.enums.MailType;
import ru.sbrf.gmap.vux.entity.enums.ResultCodeEnum;
import ru.sbrf.gmap.vux.entity.enums.ScheduleStatusEnum;
import ru.sbrf.gmap.vux.entity.enums.ValidationStatusEnum;
import ru.sbrf.gmap.vux.model.DocumentTypeEnum;

import java.sql.Date;
import java.sql.Timestamp;

@Immutable
@Entity
@Table(name = "v_vux_document_shedule_int")
@Data
public class VuxDocumentScheduleViewEntity {

    /**
     * Метка в {@code ecm_id}: загрузка в ECM запрещена флагом расписания {@code M}.
     */
    private static final String ECM_ID_UPLOAD_DISABLED = "-1";

    /**
     * Значение {@code check_mode}: форма проверяется CUV-проверкой.
     */
    private static final String CHECK_MODE_CUV = "cuv";

    @Id
    @Column(name = "shedule_id")
    private Integer scheduleId;

    @Column(name = "report_dt")
    private Date reportDate;

    @Column(name = "doc_id")
    private Integer documentId;

    @Column(name = "result_doc_id")
    private Integer resultDocumentId;

    @Column(name = "result_code")
    @Enumerated(EnumType.ORDINAL)
    private ResultCodeEnum resultCode;

    @Column(name = "start_date")
    private Date startDate;

    @Column(name = "deadline_date")
    private Date deadlineDate;

    @Column(name = "shedule_status")
    @Enumerated(EnumType.ORDINAL)
    private ScheduleStatusEnum scheduleStatus;

    @Column(name = "ecm_id")
    private String ecmId;

    @Column(name = "ecm_status")
    private String ecmStatus;

    @Column(name = "supz_task_id")
    private String supzTaskId;

    @Column(name = "supz_status")
    private String supzStatus;

    @Column(name = "validation_status")
    @Enumerated(EnumType.ORDINAL)
    private ValidationStatusEnum validationStatus;

    @Column(name = "mail_status")
    @Enumerated(EnumType.ORDINAL)
    private MailStatusEnum mailStatus;

    @Column(name = "doc_number")
    private String docNumber;

    @Column(name = "doc_type_name")
    private String docTypeName;

    @Column(name = "doc_type_code")
    private String docTypeCode;

    @Column(name = "ecm_class_name")
    private DocumentTypeEnum ecmClassName;

    @Column(name = "mail_type")
    @Enumerated(EnumType.STRING)
    private MailType mailType;

    @Column(name = "mail_receivers_list")
    private String mailReceiversList;

    @Column(name = "mail_copy_list")
    private String mailCopyList;

    @Column(name = "doc_created")
    private Timestamp docCreated;

    @Column(name = "doc_type_id")
    private Integer docTypeId;

    @Column(name = "doc_type_short_name")
    private String docTypeShortName;

    @Column(name = "supz_task_type")
    private String supzTaskType;

    @Column(name = "id_label")
    private String idLabel;

    @Column(name = "check_count")
    private Integer checkCount;

    @Column(name = "error_count")
    private Long errorCount;

    @Column(name = "warning_count")
    private Long warningCount;

    @Column(name = "flags")
    private String flags;

    @Column(name = "check_mode")
    private String checkMode;

    @Column(name = "workflow_run_id")
    private Long workflowRunId;

    @Column(name = "table_name")
    private String tableName;

    @Column(name = "table_units_name")
    private String tableUnitsName;

    @Column(name = "table_values_name")
    private String tableValuesName;

    @Column(name = "table_context_name")
    private String tableContextName;

    /**
     * Проверяет, проверяется ли форма CUV-проверкой. View возвращает {@code check_mode = 'cuv'}, если у типа документа
     * в справочнике заданы таблицы context, unit и value. Выполняется ли проверка, определяет также фича-флаг
     * ({@link ru.sbrf.gmap.vux.config.FeatureToogleConfig#isCuvApplicable}).
     *
     * @return {@code true}, если {@code check_mode = 'cuv'}
     */
    public boolean isCuvCheckMode() {
        return CHECK_MODE_CUV.equals(checkMode);
    }

    /**
     * Проверяет, запрещена ли загрузка в ECM флагом расписания {@code M}. В этом случае {@code fn_process_shedule}
     * до обработки сервисом ставит {@code ecm_id = '-1'}: поле заполнено, хотя протокола в ECM нет.
     *
     * @return {@code true}, если {@code ecm_id = '-1'}
     */
    public boolean isEcmUploadDisabled() {
        return ECM_ID_UPLOAD_DISABLED.equals(ecmId);
    }

    /**
     * Проверяет, заполнено ли поле {@code supz_task_id}. Во view это {@code t_vux_document.supz_status}, а не id задачи:
     * значение {@code 1} означает, что задача СУПЗ уже создана сервисом ({@code fn_flow_set_supz_id}) или её создание
     * запрещено флагом расписания {@code U} ({@code fn_process_shedule} ставит значение до обработки сервисом).
     * При первичной обработке задача ещё не создавалась, поэтому заполненное поле означает запрет.
     *
     * @return {@code true}, если задача создана или её создание запрещено
     */
    public boolean isSupzTaskCreatedOrDisabled() {
        return supzTaskId != null && !supzTaskId.isBlank();
    }
}
