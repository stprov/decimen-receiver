package ru.sbrf.gmap.vux.service.checks;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvContextDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvLinkDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvValueDto;
import ru.sbrf.gmap.vux.dto.scenario.full.ExplicitMemberDto;
import ru.sbrf.gmap.vux.dto.scenario.full.FullXmlDto;
import ru.sbrf.gmap.vux.dto.scenario.full.TypedMemberDto;
import ru.sbrf.gmap.vux.service.parser.XmlParserException;
import ru.sbrf.gmap.vux.service.parser.XmlParserService;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static ru.sbrf.gmap.vux.dto.cuv.CuvLinkDto.localName;
import static ru.sbrf.gmap.vux.utils.ValidateDataCommonUtil.resolveWorkflowRunId;

/**
 * CUV-проверка 010: сверка значений отчёта (value) с витриной (data) по справочнику {@code t_adm_data_xbrl_link}.
 * <p>
 * <b>Прямая сверка.</b> Для каждого значения отчёта, контекст которого содержит открытые оси, определяется колонка
 * data: строка справочника с типом {@code measure} или {@code enumerator}, показатель которой равен
 * {@code element_name}, а контекст содержит все ключевые оси ({@code line_key}) и все элементы
 * {@code analytical_section} колонки. Строка data находится по значениям ключевых колонок, равным значениям
 * открытых осей контекста. Числа сравниваются точно; значение перечисления из витрины перекодируется
 * в код элемента по {@code t_adm_xbrl_enum_values}; {@code nil} в отчёте совпадает только с пустым значением
 * витрины. Контексты без открытых осей (итоги) не сверяются.
 * <p>
 * <b>Обратная сверка.</b> Для каждой строки data и каждой колонки показателя с непустым значением в отчёте
 * должно быть значение этого показателя в контексте с теми же значениями ключевых осей и с элементами
 * {@code analytical_section} колонки. Значение {@code 0} без значения в отчёте считается расхождением,
 * только если включён параметр {@code config.cuv.check10.zero-missing-is-error}.
 * <p>
 * <b>Результат</b> — сводка: одна ошибка на показатель и вид расхождения с числом расхождений и первыми тремя
 * контекстами (для обратной сверки — ключами строк витрины). Порядок строк и примеров постоянный.
 * <p>
 * Формат {@code analytical_section} в справочнике не зафиксирован. Поддерживаются XML-фрагмент с элементами
 * {@code explicitMember} и текст с именами осей и элементов через разделители ({@code ;}, {@code ,}, {@code =},
 * {@code :}, пробел); префиксы пространств имён ({@code dim-int:}, {@code mem-int:}) не учитываются. Секция
 * подходит контексту, если все её имена есть среди осей и элементов контекста.
 * <p>
 * Проверка выполняется, только если справочник связей прочитан: без него запись ждёт заполнения справочника,
 * и CUV-проверка не запускается.
 */
@Slf4j
@Component
@Order(10)
public class SummaryAnalyticsRule implements ValidationRule {

    private static final String NUMBER = "010";
    private static final String CHECK_DESCRIPTION = "Сверка данных data ↔ value";
    private static final int EXAMPLES_LIMIT = 3;
    private static final String KEY_SEPARATOR = "\u001F";
    private static final String NIL = "true";
    private static final Pattern SECTION_SEPARATORS = Pattern.compile("[\\s;,=|:()\\[\\]{}\"'<>/]+");
    private static final Pattern NAMESPACE_PREFIX = Pattern.compile("[a-z]+(?:-[a-z]+)+");
    private static final Set<String> SECTION_SERVICE_WORDS = Set.of("xbrldi", "explicitMember", "typedMember", "dimension");

    private final XmlParserService xmlParserService;
    private final boolean zeroMissingIsError;

    /**
     * Создаёт проверку.
     *
     * @param xmlParserService   разбор описания контекста ({@code scenario})
     * @param zeroMissingIsError {@code true}, если значение витрины {@code 0} без значения в отчёте — расхождение
     */
    public SummaryAnalyticsRule(XmlParserService xmlParserService,
                                @Value("${config.cuv.check10.zero-missing-is-error:false}") boolean zeroMissingIsError) {
        this.xmlParserService = xmlParserService;
        this.zeroMissingIsError = zeroMissingIsError;
    }

    @Override
    public List<ValidationErrorDto> validate(DataContext ctx) {
        if (ctx.links().isEmpty() || ctx.valueList().isEmpty()) {
            return List.of();
        }
        Reconciliation reconciliation = new Reconciliation(ctx);
        reconciliation.checkReportValues();
        reconciliation.checkDataValues();
        List<ValidationErrorDto> errors = reconciliation.summary.toErrors(ctx);
        log.debug("[CUV] Check 010 completed: docId={}, values={}, dataRows={}, links={}, summaryLines={}",
                ctx.docId(), ctx.valueList().size(), ctx.dataRows().size(), ctx.links().size(), errors.size());
        return errors;
    }

    @Override
    public String getDescription() {
        return CHECK_DESCRIPTION;
    }

    @Override
    public String getNumber() {
        return NUMBER;
    }

    /**
     * Вид расхождения: определяет текст строки сводки и подпись примеров.
     */
    enum Discrepancy {
        MISMATCH("выявлено несовпадение значений в csv и detail"),
        NO_LINK("не найдена связь с data в справочнике t_adm_data_xbrl_link"),
        AMBIGUOUS_LINK("найдено несколько связей с data в справочнике t_adm_data_xbrl_link"),
        NO_ROW("не найдена строка в data"),
        MANY_ROWS("найдено несколько строк в data"),
        INVALID_CONTEXT("не удалось разобрать описание контекста (scenario)"),
        MISSING_IN_REPORT("отсутствуют значения витрины");

        private final String text;

        Discrepancy(String text) {
            this.text = text;
        }

        String statement(long workflowRunId, String indicator, String column) {
            String base = "В отчете id = %d для параметра %s %s".formatted(workflowRunId, indicator, text);
            return this == MISSING_IN_REPORT ? base + " (колонка " + column + ")" : base;
        }

        String examplesLabel() {
            return this == MISSING_IN_REPORT ? "Примеры строк витрины" : "Примеры контекстов";
        }

        String examplesSeparator() {
            return this == MISSING_IN_REPORT ? "; " : ", ";
        }
    }

    /**
     * Разобранное описание контекста.
     *
     * @param typed    открытые оси: имя оси без префикса → значение
     * @param elements имена осей и элементов закрытых осей без префикса
     * @param invalid  описание контекста не удалось разобрать
     */
    record ContextAxes(Map<String, String> typed, Set<String> elements, boolean invalid) {
    }

    /**
     * Сверка одного документа: справочник, разобранные контексты, индексы строк витрины и значений отчёта.
     */
    private final class Reconciliation {

        private final DataContext ctx;
        private final List<CuvLinkDto> keyLinks;
        private final Map<String, List<CuvLinkDto>> valueLinksByIndicator = new HashMap<>();
        private final List<CuvLinkDto> valueLinks;
        private final Map<CuvLinkDto, Set<String>> sections = new IdentityHashMap<>();
        private final Map<String, ContextAxes> contexts = new HashMap<>();
        private final Map<String, List<Map<String, Object>>> rowsByKey = new HashMap<>();
        private final Summary summary = new Summary();

        Reconciliation(DataContext ctx) {
            this.ctx = ctx;
            this.keyLinks = ctx.links().stream()
                    .filter(CuvLinkDto::isKey)
                    .sorted(Comparator.comparing(CuvLinkDto::lineKey).thenComparing(CuvLinkDto::columnName))
                    .toList();
            this.valueLinks = ctx.links().stream().filter(CuvLinkDto::isValueColumn).toList();
            for (CuvLinkDto link : valueLinks) {
                sections.put(link, sectionElements(link.analyticalSection()));
                for (String name : link.indicatorNames()) {
                    valueLinksByIndicator.computeIfAbsent(name, k -> new ArrayList<>()).add(link);
                }
            }
            for (CuvContextDto context : ctx.contextList()) {
                if (context.contextId() != null) {
                    contexts.putIfAbsent(context.contextId(), parseContext(context.scenario()));
                }
            }
            for (Map<String, Object> row : ctx.dataRows()) {
                rowsByKey.computeIfAbsent(rowKey(row), k -> new ArrayList<>()).add(row);
            }
        }

        /**
         * Прямая сверка: каждое значение отчёта с открытыми осями должно совпасть со значением витрины.
         */
        void checkReportValues() {
            for (CuvValueDto value : ctx.valueList()) {
                String element = value.elementName() == null ? "" : value.elementName().trim();
                ContextAxes axes = contexts.get(value.contextId());
                if (axes == null) {
                    continue;
                }
                if (axes.invalid()) {
                    summary.add(element, Discrepancy.INVALID_CONTEXT, null, value.contextId());
                    continue;
                }
                if (axes.typed().isEmpty()) {
                    continue;
                }
                String key = contextKey(axes);
                List<CuvLinkDto> candidates = key == null ? List.of()
                        : valueLinksByIndicator.getOrDefault(localName(element), List.of()).stream()
                        .filter(link -> axes.elements().containsAll(sections.get(link)))
                        .toList();
                if (candidates.isEmpty()) {
                    summary.add(element, Discrepancy.NO_LINK, null, value.contextId());
                    continue;
                }
                if (candidates.size() > 1) {
                    summary.add(element, Discrepancy.AMBIGUOUS_LINK, null, value.contextId());
                    continue;
                }
                List<Map<String, Object>> rows = rowsByKey.getOrDefault(key, List.of());
                if (rows.isEmpty()) {
                    summary.add(element, Discrepancy.NO_ROW, null, value.contextId());
                } else if (rows.size() > 1) {
                    summary.add(element, Discrepancy.MANY_ROWS, null, value.contextId());
                } else {
                    CuvLinkDto link = candidates.getFirst();
                    if (!sameValue(link, value, columnValue(rows.getFirst(), link.columnName()))) {
                        summary.add(element, Discrepancy.MISMATCH, null, value.contextId());
                    }
                }
            }
        }

        /**
         * Обратная сверка: каждое непустое значение витрины должно быть в отчёте.
         */
        void checkDataValues() {
            Map<String, List<Set<String>>> reportFacts = new HashMap<>();
            for (CuvValueDto value : ctx.valueList()) {
                ContextAxes axes = contexts.get(value.contextId());
                if (axes == null || axes.invalid() || axes.typed().isEmpty() || value.elementName() == null) {
                    continue;
                }
                String key = contextKey(axes);
                if (key != null) {
                    reportFacts.computeIfAbsent(localName(value.elementName()) + KEY_SEPARATOR + key, k -> new ArrayList<>())
                            .add(axes.elements());
                }
            }
            for (Map<String, Object> row : ctx.dataRows()) {
                String key = rowKey(row);
                for (CuvLinkDto link : valueLinks) {
                    Object dataValue = columnValue(row, link.columnName());
                    if (isEmpty(dataValue) || (!zeroMissingIsError && isZero(dataValue))) {
                        continue;
                    }
                    Set<String> section = sections.get(link);
                    boolean found = link.indicatorNames().stream()
                            .map(name -> reportFacts.getOrDefault(name + KEY_SEPARATOR + key, List.of()))
                            .flatMap(List::stream)
                            .anyMatch(elements -> elements.containsAll(section));
                    if (!found) {
                        summary.add(link.indicator(), Discrepancy.MISSING_IN_REPORT, link.columnName(), describeRow(row));
                    }
                }
            }
        }

        private String contextKey(ContextAxes axes) {
            List<String> parts = new ArrayList<>(keyLinks.size());
            for (CuvLinkDto keyLink : keyLinks) {
                String value = axes.typed().get(localName(keyLink.taxisId()));
                if (value == null) {
                    return null;
                }
                parts.add(value);
            }
            return String.join(KEY_SEPARATOR, parts);
        }

        private String rowKey(Map<String, Object> row) {
            return keyLinks.stream()
                    .map(keyLink -> normalizeKey(columnValue(row, keyLink.columnName())))
                    .collect(Collectors.joining(KEY_SEPARATOR));
        }

        private String describeRow(Map<String, Object> row) {
            if (keyLinks.isEmpty()) {
                return "без ключевых колонок";
            }
            return keyLinks.stream()
                    .map(keyLink -> keyLink.columnName() + "=" + normalizeKey(columnValue(row, keyLink.columnName())))
                    .collect(Collectors.joining(", "));
        }

        private boolean sameValue(CuvLinkDto link, CuvValueDto value, Object dataValue) {
            boolean reportEmpty = NIL.equalsIgnoreCase(trim(value.nil())) || isEmpty(value.value());
            boolean dataEmpty = isEmpty(dataValue);
            if (reportEmpty || dataEmpty) {
                return reportEmpty && dataEmpty;
            }
            String reportText = value.value().trim();
            String dataText = dataValue.toString().trim();
            if (link.isEnumerator()) {
                String code = ctx.enumCodes().getOrDefault(trim(link.enumId()), Map.of()).get(dataText);
                return Objects.equals(localName(code != null ? code : dataText), localName(reportText));
            }
            BigDecimal reportNumber = decimal(reportText);
            BigDecimal dataNumber = decimal(dataValue);
            if (reportNumber != null && dataNumber != null) {
                return reportNumber.compareTo(dataNumber) == 0;
            }
            return reportText.equals(dataText);
        }
    }

    /**
     * Накапливает расхождения по группам «показатель, вид, колонка» и строит из них строки сводки.
     */
    private static final class Summary {

        private static final Comparator<GroupKey> ORDER = Comparator
                .comparing(GroupKey::indicator)
                .thenComparing(GroupKey::kind)
                .thenComparing(GroupKey::column, Comparator.nullsFirst(Comparator.naturalOrder()));

        private final Map<GroupKey, Group> groups = new TreeMap<>(ORDER);

        void add(String indicator, Discrepancy kind, String column, String example) {
            Group group = groups.computeIfAbsent(new GroupKey(indicator == null ? "" : indicator, kind, column),
                    key -> new Group());
            group.count++;
            if (example != null) {
                group.examples.add(example);
            }
        }

        List<ValidationErrorDto> toErrors(DataContext ctx) {
            long workflowRunId = resolveWorkflowRunId(ctx);
            List<ValidationErrorDto> errors = new ArrayList<>(groups.size());
            groups.forEach((key, group) -> errors.add(CuvErrors.summaryError(ctx, NUMBER,
                    key.kind().statement(workflowRunId, key.indicator(), key.column()), group.count,
                    key.kind().examplesLabel(),
                    group.examples.stream().limit(EXAMPLES_LIMIT).collect(Collectors.joining(key.kind().examplesSeparator())))));
            return errors;
        }

        private record GroupKey(String indicator, Discrepancy kind, String column) {
        }

        private static final class Group {
            private int count;
            private final TreeSet<String> examples = new TreeSet<>();
        }
    }

    /**
     * Разбирает описание контекста: открытые оси со значениями и имена осей и элементов закрытых осей.
     * Пустое описание — контекст без осей (итоги).
     */
    private ContextAxes parseContext(String scenario) {
        if (scenario == null || scenario.isBlank()) {
            return new ContextAxes(Map.of(), Set.of(), false);
        }
        try {
            FullXmlDto dto = xmlParserService.parse(scenario, FullXmlDto.class);
            Map<String, String> typed = new LinkedHashMap<>();
            Set<String> elements = new HashSet<>();
            if (dto != null && dto.getMembers() != null) {
                for (Object member : dto.getMembers()) {
                    if (member instanceof ExplicitMemberDto explicit) {
                        addName(elements, explicit.getDimension());
                        addName(elements, explicit.getValue());
                    } else if (member instanceof TypedMemberDto typedMember) {
                        String axis = localName(typedMember.getDimension());
                        if (axis != null && !axis.isEmpty()) {
                            typed.put(axis, typedMember.getTypedName() == null ? "" : typedMember.getTypedName().trim());
                            elements.add(axis);
                        }
                    }
                }
            }
            return new ContextAxes(typed, elements, false);
        } catch (XmlParserException e) {
            return new ContextAxes(Map.of(), Set.of(), true);
        }
    }

    /**
     * Возвращает имена осей и элементов {@code analytical_section} без префиксов пространств имён.
     */
    Set<String> sectionElements(String section) {
        if (section == null || section.isBlank()) {
            return Set.of();
        }
        if (section.contains("<")) {
            ContextAxes axes = parseContext(section);
            if (!axes.invalid()) {
                return axes.elements();
            }
        }
        return Arrays.stream(SECTION_SEPARATORS.split(section.trim()))
                .filter(token -> !token.isEmpty())
                .filter(token -> !NAMESPACE_PREFIX.matcher(token).matches())
                .filter(token -> !SECTION_SERVICE_WORDS.contains(token))
                .collect(Collectors.toUnmodifiableSet());
    }

    private static void addName(Set<String> names, String name) {
        String local = localName(name);
        if (local != null && !local.isEmpty()) {
            names.add(local);
        }
    }

    private static Object columnValue(Map<String, Object> row, String column) {
        if (column == null) {
            return null;
        }
        String name = column.trim();
        if (row.containsKey(name)) {
            return row.get(name);
        }
        for (Map.Entry<String, Object> entry : row.entrySet()) {
            if (entry.getKey() != null && entry.getKey().equalsIgnoreCase(name)) {
                return entry.getValue();
            }
        }
        return null;
    }

    private static String normalizeKey(Object value) {
        if (value == null) {
            return "";
        }
        BigDecimal number = value instanceof Number ? decimal(value) : null;
        return number != null ? number.stripTrailingZeros().toPlainString() : value.toString().trim();
    }

    private static boolean isEmpty(Object value) {
        return value == null || value.toString().isBlank();
    }

    private static boolean isZero(Object value) {
        BigDecimal number = decimal(value);
        return number != null && number.signum() == 0;
    }

    private static BigDecimal decimal(Object value) {
        if (value == null) {
            return null;
        }
        try {
            return new BigDecimal(value.toString().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static String trim(String value) {
        return value == null ? "" : value.trim();
    }
}
