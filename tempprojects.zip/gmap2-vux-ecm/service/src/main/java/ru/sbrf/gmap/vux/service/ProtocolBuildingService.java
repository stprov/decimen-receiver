package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolCheckRecordDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolTableRecordDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationLogEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationResultViewEntity;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;
import ru.sbrf.gmap.vux.mapper.ValidationErrorDtoMapper;
import ru.sbrf.gmap.vux.mapper.VuxDocumentValidationLogEnityMapper;
import ru.sbrf.gmap.vux.mapper.VuxDocumentValidationResultViewEntityMapper;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Stream;

/**
 * Строит модель PDF-протокола проверки и имя файла протокола. Используется всеми стратегиями обработки.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ProtocolBuildingService {

    private static final String DATETIME_FORMAT_PROTOCOL_NAME = "dd-MM-yyyy";
    private static final String DATETIME_FORMAT_PROTOCOL_FIELD = "dd-MM-yyyy HH:mm:ss";

    private final VuxDocumentValidationResultViewEntityMapper vuxDocumentValidationResultViewEntityMapper;
    private final VuxDocumentValidationLogEnityMapper vuxDocumentValidationLogEnityMapper;
    private final ValidationErrorDtoMapper validationErrorDtoMapper;
    private final ValidationDataService validationDataService;

    /**
     * Формирует имя файла протокола по коду формы и текущей дате.
     *
     * @param docTypeCode код формы документа
     * @return имя файла протокола
     */
    public String generateProtocolName(String docTypeCode) {
        return "Протокол проверки " + docTypeCode + " " + LocalDate.now().format(DateTimeFormatter.ofPattern(DATETIME_FORMAT_PROTOCOL_NAME)) + ".pdf";
    }

    /**
     * Строит модель протокола по нарушениям и журналу проверок документа из БД.
     *
     * @param errors   ошибки
     * @param warnings предупреждения
     * @param checkLis журнал проверок
     * @param record   запись расписания
     * @return модель протокола
     */
    public ProtocolModelDto createProtocolModelDto(List<VuxDocumentValidationResultViewEntity> errors, List<VuxDocumentValidationResultViewEntity> warnings, List<VuxDocumentValidationLogEntity> checkLis, VuxDocumentScheduleViewEntity record) {
        List<ProtocolTableRecordDto> listErrors = vuxDocumentValidationResultViewEntityMapper.toProtocolTableRecordDtoList(errors);
        List<ProtocolTableRecordDto> listWarnings = vuxDocumentValidationResultViewEntityMapper.toProtocolTableRecordDtoList(warnings);
        List<ProtocolCheckRecordDto> listProtocolCheckRecordDto = vuxDocumentValidationLogEnityMapper.toProtocolCheckRecordDtoList(checkLis);
        long totalErrorCount = calculateTotalCount(listProtocolCheckRecordDto, RuleTypeEnum.E);
        long totalWarningCount = calculateTotalCount(listProtocolCheckRecordDto, RuleTypeEnum.W);
        return ProtocolModelDto.builder()
                .documentDate(record.getReportDate().toString())
                .checkDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern(DATETIME_FORMAT_PROTOCOL_FIELD)))
                .reportType(record.getDocTypeName())
                .documentNumber(record.getDocNumber())
                .objects(listErrors)
                .warnings(listWarnings)
                .checksList(listProtocolCheckRecordDto)
                .totalErrorCount(totalErrorCount)
                .totalWarningCount(totalWarningCount)
                .build();
    }

    /**
     * Строит модель протокола по готовым строкам ошибок и проверок; предупреждения берутся из БД.
     *
     * @param errors   строки ошибок
     * @param warnings предупреждения
     * @param checks   строки проверок
     * @param record   запись расписания
     * @return модель протокола
     */
    public ProtocolModelDto createProtocolWithAdditionalErrorsModelDto(List<ProtocolTableRecordDto> errors, List<VuxDocumentValidationResultViewEntity> warnings, List<ProtocolCheckRecordDto> checks, VuxDocumentScheduleViewEntity record) {
        List<ProtocolTableRecordDto> listWarnings = vuxDocumentValidationResultViewEntityMapper.toProtocolTableRecordDtoList(warnings);
        long totalErrorCount = calculateTotalCount(checks, RuleTypeEnum.E);
        long totalWarningCount = calculateTotalCount(checks, RuleTypeEnum.W);
        return ProtocolModelDto.builder()
                .documentDate(record.getReportDate().toString())
                .checkDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern(DATETIME_FORMAT_PROTOCOL_FIELD)))
                .reportType(record.getDocTypeName())
                .documentNumber(record.getDocNumber())
                .objects(errors)
                .warnings(listWarnings)
                .checksList(checks)
                .totalErrorCount(totalErrorCount)
                .totalWarningCount(totalWarningCount)
                .build();
    }

    /**
     * Строит протокол с ошибками CUV-проверки: ошибки и проверки из БД дополняются ошибками и проверками CUV.
     * Ошибки CUV добавляются явно, так как во view {@code v_vux_document_validation_result} их нет.
     * <p>
     * Ошибки CUV передаются сразу после проверки либо читаются из {@code t_vux_document_cuv_validation_result},
     * если письмо об ошибках не было отправлено при первичной обработке.
     *
     * @param record       запись расписания
     * @param viewErrors   ошибки стандартной проверки
     * @param viewWarnings предупреждения стандартной проверки
     * @param viewChecks   журнал проверок из БД
     * @param cuvErrors    ошибки CUV-проверки
     * @return модель протокола
     */
    public ProtocolModelDto createCuvErrorProtocol(VuxDocumentScheduleViewEntity record,
                                                   List<VuxDocumentValidationResultViewEntity> viewErrors,
                                                   List<VuxDocumentValidationResultViewEntity> viewWarnings,
                                                   List<VuxDocumentValidationLogEntity> viewChecks,
                                                   List<ValidationErrorDto> cuvErrors) {
        List<ProtocolTableRecordDto> allErrors = Stream.concat(
                vuxDocumentValidationResultViewEntityMapper.toProtocolTableRecordDtoList(viewErrors).stream(),
                validationErrorDtoMapper.toProtocolTableRecordDtoList(cuvErrors).stream()
        ).toList();
        List<ProtocolCheckRecordDto> checks = Stream.concat(
                vuxDocumentValidationLogEnityMapper.toProtocolCheckRecordDtoList(viewChecks).stream(),
                validationDataService.getChecks(cuvErrors).stream()
        ).toList();
        return createProtocolWithAdditionalErrorsModelDto(allErrors, viewWarnings, checks, record);
    }

    /**
     * Строит протокол успешной CUV-проверки: без ошибок, с предупреждениями стандартной проверки, если они есть.
     * Итоговые количества ошибок и предупреждений рассчитываются по строкам проверок, иначе протокол показывает
     * «Показано N из 0».
     *
     * @param record   запись расписания
     * @param warnings предупреждения стандартной проверки
     * @param checks   строки проверок
     * @return модель протокола
     */
    public ProtocolModelDto createCuvSuccessProtocol(VuxDocumentScheduleViewEntity record,
                                                     List<VuxDocumentValidationResultViewEntity> warnings,
                                                     List<ProtocolCheckRecordDto> checks) {
        return ProtocolModelDto.builder()
                .documentDate(record.getReportDate() != null ? record.getReportDate().toString() : "")
                .checkDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern(DATETIME_FORMAT_PROTOCOL_FIELD)))
                .reportType(record.getDocTypeName())
                .documentNumber(record.getDocNumber())
                .objects(List.of())
                .warnings(warnings.stream()
                        .map(vuxDocumentValidationResultViewEntityMapper::toProtocolTableRecordDto)
                        .toList())
                .checksList(checks)
                .totalErrorCount(calculateTotalCount(checks, RuleTypeEnum.E))
                .totalWarningCount(calculateTotalCount(checks, RuleTypeEnum.W))
                .build();
    }

    /**
     * Суммирует количество нарушений заданного типа по строкам проверок.
     */
    private long calculateTotalCount(List<ProtocolCheckRecordDto> checks, RuleTypeEnum targetType) {
        return checks.stream()
                .filter(c -> c.getRuleType() == targetType)
                .mapToLong(c -> safeParseLong(c.getCountingDeviation()))
                .sum();
    }

    /**
     * Преобразует строку в число; пустое или некорректное значение считается нулём.
     */
    private long safeParseLong(String value) {
        if (value == null || value.isBlank()) return 0;
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            log.warn("Failed to parse countingDeviation value '{}', defaulting to 0", value);
            return 0;
        }
    }
}
