package ru.sbrf.gmap.vux.service.checks;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvUnitDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvValueDto;

import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.List;

/**
 * CUV-проверка 008: у каждого {@code unit_id} из value есть описание в unit. Пустой {@code unit_id}
 * не проверяется: у нечисловых значений нет единицы измерения. Выполняется, если есть строки unit и value.
 * Идентификаторы в тексте ошибки отсортированы, чтобы текст не менялся при повторной проверке.
 */
@Component
@Order(8)
public class MissingUnitDescriptionsRule implements ValidationRule {

    private static final String NUMBER = "008";
    private static final String CHECK_DESCRIPTION = "В values не обнаружены unit_id без описания";

    @Override
    public List<ValidationErrorDto> validate(DataContext ctx) {
        if (ctx.unitList().isEmpty() || ctx.valueList().isEmpty()) {
            return List.of();
        }
        Set<String> unitIds = ctx.unitList().stream()
                .map(CuvUnitDto::unitId)
                .filter(v -> v != null && !v.isBlank())
                .collect(Collectors.toSet());
        Set<String> missing = ctx.valueList().stream()
                .map(CuvValueDto::unitId)
                .filter(v -> v != null && !v.isBlank())
                .collect(Collectors.toCollection(TreeSet::new));
        missing.removeAll(unitIds);
        if (!missing.isEmpty()) {
            return List.of(CuvErrors.error(ctx, NUMBER, "Обнаружены unit_id без описания: %s.".formatted(missing)));
        }
        return List.of();
    }

    @Override
    public String getDescription() {
        return CHECK_DESCRIPTION;
    }

    @Override
    public String getNumber() {
        return NUMBER;
    }
}
