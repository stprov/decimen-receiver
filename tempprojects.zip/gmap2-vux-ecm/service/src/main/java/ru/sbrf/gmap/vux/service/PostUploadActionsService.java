package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.dto.request.supz.SupzAttributesCompositionDto;
import ru.sbrf.gmap.vux.dto.response.CreateContentsResponse;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.entity.enums.MailType;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;
import ru.sbrf.gmap.vux.facade.EcmDocumentFacade;
import ru.sbrf.gmap.vux.facade.supz.SupzTaskFacade;
import ru.sbrf.gmap.vux.model.DocumentTypeEnum;
import ru.sbrf.gmap.vux.model.jsonrpc.SupzTaskResponseWrapper;
import ru.sbrf.gmap.vux.model.supz.request.SupzRequest;
import ru.sbrf.gmap.vux.model.supz.request.SupzTaskDataRequest;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

/**
 * Общие действия стратегий обработки после формирования протокола: загрузка PDF-протокола в ECM,
 * отправка письма об ошибках, создание задачи СУПЗ.
 * <p>
 * Каждая операция возвращает признак успеха. При техническом сбое, в том числе после исчерпания повторных попыток,
 * стратегия прерывает обработку записи и оставляет расписание открытым до следующего цикла планировщика.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class PostUploadActionsService {

    /**
     * Шаблон атрибута задачи СУПЗ «Проверенная форма отчета»; в шаблон подставляется случайное число.
     */
    private static final String TASK_OBJECT_TEMPLATE = "Отчет %d проверочный";
    private static final String TASK_PROTOCOL_SUCCESS_RESULT = "Данные витрины корректны. Можно формировать отчет.";
    private static final String TASK_PROTOCOL_WARNING_RESULT = "Обнаружены предупреждения. Количество: %d. Требуется проверка данных перед формированием отчета.";

    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;
    private final OutputFormingService outputFormingService;
    private final MailService mailService;
    private final SupzTaskFacade supzTaskFacade;
    private final EcmDocumentFacade ecmDocumentFacade;
    private final ProtocolBuildingService protocolBuildingService;
    private final RetryExecutor retryExecutor;

    @Value("${integration.ecm.retry.max-attempts:3}")
    private int ecmMaxAttempts;

    @Value("${integration.ecm.retry.delay-ms:2000}")
    private long ecmRetryDelayMs;

    /**
     * Формирует PDF-протокол, загружает его в ECM с повторными попытками и сохраняет присвоенный id функцией
     * {@code fn_flow_set_ecm_id}. Id попадает в {@code t_vux_document.ecm_id} и в поле {@code ecm_id} view
     * расписания, по которому в следующем цикле выбирается стратегия обработки.
     *
     * @param record           запись расписания
     * @param protocolModelDto модель протокола
     * @return id протокола в ECM или {@link Optional#empty()} при сбое
     */
    public Optional<String> uploadProtocol(VuxDocumentScheduleViewEntity record, ProtocolModelDto protocolModelDto) {
        Integer docId = record.getResultDocumentId();
        String pdfName = protocolBuildingService.generateProtocolName(record.getDocTypeCode());
        byte[] pdfContent;
        try {
            pdfContent = outputFormingService.createPdf(protocolModelDto);
        } catch (Exception e) {
            log.error("[ECM] Failed to generate protocol PDF: scheduleId={}, docId={}. Record is skipped until the next scheduler cycle.",
                    record.getScheduleId(), docId, e);
            return Optional.empty();
        }

        final byte[] content = pdfContent;
        final DocumentTypeEnum docType = record.getEcmClassName();
        Optional<CreateContentsResponse> response = retryExecutor.execute(
                "ECM upload protocol docId=" + docId,
                ecmMaxAttempts, ecmRetryDelayMs,
                () -> ecmDocumentFacade.uploadSignedDocument(content, pdfName, docType, List.of()));

        if (response.isEmpty() || response.get().documents() == null || response.get().documents().isEmpty()) {
            log.error("[ECM] Protocol was NOT uploaded to ECM: scheduleId={}, docId={}, fileName='{}'. " +
                    "Record is skipped until the next scheduler cycle.", record.getScheduleId(), docId, pdfName);
            return Optional.empty();
        }

        CreateContentsResponse.CreateContentsDocument doc = response.get().documents().getFirst();
        try {
            vuxDocumentValidationResultViewRepository.flowSetEcmId(docId, doc.id(), doc.result().getResultCode());
        } catch (Exception e) {
            log.error("[ECM] Protocol uploaded (ecmId={}) but fn_flow_set_ecm_id failed: scheduleId={}, docId={}. " +
                    "Record is skipped until the next scheduler cycle (protocol will be uploaded again).",
                    doc.id(), record.getScheduleId(), docId, e);
            return Optional.empty();
        }
        log.info("[ECM] Protocol uploaded: scheduleId={}, docId={}, protocolEcmId={}", record.getScheduleId(), docId, doc.id());
        return Optional.of(doc.id());
    }

    /**
     * Выполняет действия после загрузки протокола: при ошибках отправляет письмо, иначе создаёт задачу СУПЗ
     * с переданными документами ECM.
     *
     * @param record           запись расписания
     * @param protocolModelDto модель протокола
     * @param ecmUrls          id документов ECM, прикладываемых к задаче СУПЗ
     * @return {@code true}, если обработка завершена; {@code false} при техническом сбое
     */
    public boolean handlePostUploadActions(VuxDocumentScheduleViewEntity record, ProtocolModelDto protocolModelDto, List<String> ecmUrls) {
        if (hasErrors(protocolModelDto)) {
            log.info("[MAIL] Document has errors, sending the error mail: docId={}", record.getResultDocumentId());
            return sendErrorMail(record, protocolModelDto);
        }
        long warningsCounter = protocolModelDto.getObjects().stream().filter(v -> v.getRuleType() == RuleTypeEnum.W).count();
        log.info("[SUPZ] Document has no errors, creating a SUPZ task: docId={}, warnings={}", record.getResultDocumentId(), warningsCounter);
        String protocolResult = warningsCounter == 0 ? TASK_PROTOCOL_SUCCESS_RESULT : TASK_PROTOCOL_WARNING_RESULT;
        return createSupzTask(record, ecmUrls, protocolResult);
    }

    /**
     * Проверяет, есть ли в протоколе записи с ошибками.
     *
     * @param protocolModelDto модель протокола
     * @return {@code true}, если есть хотя бы одна запись с типом правила {@link RuleTypeEnum#E}
     */
    public boolean hasErrors(ProtocolModelDto protocolModelDto) {
        return protocolModelDto.getObjects() != null
                && protocolModelDto.getObjects().stream().anyMatch(v -> v.getRuleType() == RuleTypeEnum.E);
    }

    /**
     * Проверяет, что письмо об ошибках по документу отправлено и зафиксировано в {@code t_vux_mail}.
     * <p>
     * Поле {@code mail_status} для этого не подходит: значение {@code 1} означает и «отправлено», и «запрещено
     * флагами расписания», а при флаге {@code S} и ошибках только CUV-проверки оно выставлено ещё до обработки.
     *
     * @param record запись расписания
     * @return {@code true}, если письмо найдено
     */
    public boolean isErrorMailSent(VuxDocumentScheduleViewEntity record) {
        return vuxDocumentValidationResultViewRepository.existsErrorMail(record.getResultDocumentId().longValue());
    }

    /**
     * Формирует и отправляет письмо об ошибках; при успехе фиксирует отправку функцией
     * {@code fn_flow_set_mail_status}.
     *
     * @param record           запись расписания
     * @param protocolModelDto модель протокола
     * @return {@code true}, если письмо отправлено; {@code false} при сбое отправки
     */
    public boolean sendErrorMail(VuxDocumentScheduleViewEntity record, ProtocolModelDto protocolModelDto) {
        String subject = String.format("XBRL \\\\\\\\ %s Ошибки на отчетную дату: %s", record.getDocTypeCode(), protocolModelDto.getDocumentDate());
        String msgBody = outputFormingService.createHtml(protocolModelDto);
        return sendAndRecordMail(record, subject, msgBody, "Error mail");
    }

    /**
     * Отправляет служебное письмо по документу получателям письма об ошибках и при успехе фиксирует отправку
     * функцией {@code fn_flow_set_mail_status} с типом {@code ERROR}, как письмо об ошибках.
     *
     * @param record   запись расписания
     * @param subject  тема письма
     * @param htmlBody HTML-текст письма
     * @return {@code true}, если письмо отправлено; {@code false} при сбое отправки
     */
    public boolean sendNotificationMail(VuxDocumentScheduleViewEntity record, String subject, String htmlBody) {
        return sendAndRecordMail(record, subject, htmlBody, "Notification mail");
    }

    /**
     * Отправляет письмо получателям из расписания и при успехе фиксирует отправку с типом {@code ERROR}.
     */
    private boolean sendAndRecordMail(VuxDocumentScheduleViewEntity record, String subject, String msgBody, String mailKind) {
        Integer documentId = record.getResultDocumentId();
        log.debug("[MAIL] Recipients: '{}'", record.getMailReceiversList());
        log.debug("[MAIL] Copy recipients: '{}'", record.getMailCopyList());
        List<String> recipientsList = getMailRecipients(record.getMailReceiversList());
        List<String> ccList = getMailRecipients(record.getMailCopyList());
        String fullRecipientsList = record.getMailReceiversList() + "," + record.getMailCopyList();

        boolean sent = mailService.sendMail(subject, msgBody, recipientsList, ccList);
        if (!sent) {
            log.error("[MAIL] {} was NOT sent: scheduleId={}, docId={}, recipients={}. " +
                    "Record is skipped until the next scheduler cycle.", mailKind, record.getScheduleId(), documentId, recipientsList.size());
            return false;
        }

        String mailCode = MailType.ERROR.toString();
        vuxDocumentValidationResultViewRepository.flowSetMailStatus(documentId, fullRecipientsList, subject, msgBody, mailCode);
        log.info("[MAIL] {} sent: scheduleId={}, docId={}, recipients={}, cc={}",
                mailKind, record.getScheduleId(), documentId, recipientsList.size(), ccList.size());
        return true;
    }

    /**
     * Возвращает текст результата протокола для задачи СУПЗ по количеству предупреждений.
     *
     * @param warningsCount количество предупреждений
     * @return текст результата протокола
     */
    public String protocolResultText(long warningsCount) {
        return warningsCount == 0
                ? TASK_PROTOCOL_SUCCESS_RESULT
                : String.format(TASK_PROTOCOL_WARNING_RESULT, warningsCount);
    }

    /**
     * Создаёт задачу СУПЗ и сохраняет её функцией {@code fn_flow_set_supz_id}
     * ({@code t_vux_supz_task} и {@code t_vux_document.supz_status = 1}). Повторные попытки выполняет
     * {@code SupzTaskJsonRpcClient}.
     * <p>
     * Поле view {@code supz_task_id} содержит {@code t_vux_document.supz_status}, а не id задачи: значение {@code 1}
     * означает, что задача уже создана или её создание запрещено флагом расписания {@code U}. В этом случае задача
     * не создаётся.
     *
     * @param record         запись расписания
     * @param ecmUrls        id документов ECM, прикладываемых к задаче
     * @param protocolResult текст результата протокола
     * @return {@code true}, если задача создана или уже была; {@code false} при техническом сбое
     */
    public boolean createSupzTask(VuxDocumentScheduleViewEntity record, List<String> ecmUrls, String protocolResult) {
        Integer docId = record.getResultDocumentId();
        if (record.isSupzTaskCreatedOrDisabled()) {
            log.info("[SUPZ] SUPZ task is already created or disabled by schedule flag 'U' (supz_task_id={}): " +
                    "scheduleId={}, docId={}. Skipping SUPZ task creation.", record.getSupzTaskId(), record.getScheduleId(), docId);
            return true;
        }

        Optional<SupzTaskResponseWrapper> response = sendSupzCreateTaskRequest(ecmUrls, record, protocolResult);
        if (response.isEmpty()) {
            log.error("[SUPZ] SUPZ task was NOT created: scheduleId={}, docId={}, ecmIds={}. " +
                    "Record is skipped until the next scheduler cycle.", record.getScheduleId(), docId, ecmUrls);
            return false;
        }

        SupzTaskResponseWrapper supzResponse = response.get();
        String taskId = supzResponse.supzTaskResponse().data().taskId().toString();
        try {
            vuxDocumentValidationResultViewRepository.flowSetSupzId(
                    docId, taskId, supzResponse.supzTaskResponse().data().status(), supzResponse.rawResponse());
        } catch (Exception e) {
            log.error("[SUPZ] SUPZ task CREATED (taskId={}) but fn_flow_set_supz_id failed: scheduleId={}, docId={}. " +
                    "Record stays open: the task may be created again in the next cycle — check manually.",
                    taskId, record.getScheduleId(), docId, e);
            return false;
        }
        log.info("[SUPZ] SUPZ task created: scheduleId={}, docId={}, taskId={}, ecmIds={}",
                record.getScheduleId(), docId, taskId, ecmUrls);
        return true;
    }

    /**
     * Отправляет в СУПЗ запрос на создание задачи.
     *
     * @return ответ СУПЗ или {@link Optional#empty()} при ошибке
     */
    private Optional<SupzTaskResponseWrapper> sendSupzCreateTaskRequest(List<String> ecmUrls, VuxDocumentScheduleViewEntity record, String taskProtocolResult) {
        try {
            UUID requestId = UUID.randomUUID();
            log.debug("[SUPZ] Sending a create task request: requestId={}, docId={}", requestId, record.getResultDocumentId());
            SupzRequest<SupzTaskDataRequest> request = buildSupzCreateTaskRequest(requestId, ecmUrls, record, taskProtocolResult);
            SupzTaskResponseWrapper responseWrapper = supzTaskFacade.createTask(request, requestId);
            return Optional.ofNullable(responseWrapper);
        } catch (Exception e) {
            log.error("[SUPZ] Create task request failed: docId={}", record.getResultDocumentId(), e);
            return Optional.empty();
        }
    }

    /**
     * Формирует запрос на создание задачи СУПЗ с атрибутами протокола.
     */
    private SupzRequest<SupzTaskDataRequest> buildSupzCreateTaskRequest(UUID requestId, List<String> ecmUrls, VuxDocumentScheduleViewEntity record, String protocolResult) {
        log.debug("[SUPZ] Building a create task request: requestId={}, docId={}", requestId, record.getResultDocumentId());

        String protocolName = protocolBuildingService.generateProtocolName(record.getDocTypeCode());
        String protocolDate = LocalDate.now().toString();
        String protocolObject = String.format(TASK_OBJECT_TEMPLATE, RandomUtils.insecure().randomInt(1, 100000));

        SupzAttributesCompositionDto attributes = SupzAttributesCompositionDto.builder()
                .protocolResult(protocolResult)
                .protocolName(protocolName)
                .protocolDate(protocolDate)
                .protocolNum(record.getDocNumber())
                .protocolObject(protocolObject)
                .build();
        return supzTaskFacade.buildSupzCreateTaskRequest(requestId, ecmUrls, attributes);
    }

    private List<String> getMailRecipients(String recipients) {
        if (recipients == null || recipients.trim().isEmpty()) {
            return List.of();
        }
        return Stream.of(recipients.split(";"))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();
    }
}
