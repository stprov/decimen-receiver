package ru.sbrf.gmap.vux.config;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;

/**
 * Фича-флаги сервиса.
 *
 * @param isCuvValidationEnabled {@code true}, если CUV-проверка включена
 */
@ConfigurationProperties(prefix = "config.feature-toogles", ignoreInvalidFields = true)
@Slf4j
public record FeatureToogleConfig(
        boolean isCuvValidationEnabled
) {

    @PostConstruct
    void init() {
        log.info("Feature toggle config is: '{}'", this);
    }

    /**
     * Проверяет, применяется ли к записи расписания CUV-проверка: режим проверки формы {@code check_mode = 'cuv'}
     * и CUV-проверка включена фича-флагом. Условие одинаково для первичной обработки и для завершения обработки.
     *
     * @param record запись расписания
     * @return {@code true}, если запись обрабатывается по CUV-маршруту
     */
    public boolean isCuvApplicable(VuxDocumentScheduleViewEntity record) {
        return record.isCuvCheckMode() && isCuvValidationEnabled;
    }
}
