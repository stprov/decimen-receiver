package ru.sbrf.gmap.vux.service.checks;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvContextDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvValueDto;

import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.List;

/**
 * CUV-проверка 005: нет ли в context лишних {@code context_id}, на которые не ссылается ни одна строка value.
 * Выполняется, если есть строки context и value. Идентификаторы в тексте ошибки отсортированы, чтобы текст не менялся при повторной проверке.
 */
@Component
@Order(5)
public class OrphanContextIdsRule implements ValidationRule {

    private static final String NUMBER = "005";
    private static final String CHECK_DESCRIPTION = "В value отсутствуют лишние значения context_id";

    @Override
    public List<ValidationErrorDto> validate(DataContext ctx) {
        if (ctx.contextList().isEmpty() || ctx.valueList().isEmpty()) {
            return List.of();
        }
        Set<String> orphans = ctx.contextList().stream()
                .map(CuvContextDto::contextId)
                .filter(Objects::nonNull)
                .collect(Collectors.toCollection(TreeSet::new));
        ctx.valueList().stream().map(CuvValueDto::contextId).filter(Objects::nonNull).forEach(orphans::remove);
        if (!orphans.isEmpty()) {
            return List.of(CuvErrors.error(ctx, NUMBER, "Обнаружены лишние context: %s.".formatted(orphans)));
        }
        return List.of();
    }

    @Override
    public String getDescription() {
        return CHECK_DESCRIPTION;
    }

    @Override
    public String getNumber() {
        return NUMBER;
    }
}
