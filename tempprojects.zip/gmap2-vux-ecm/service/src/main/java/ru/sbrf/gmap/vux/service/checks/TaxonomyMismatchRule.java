package ru.sbrf.gmap.vux.service.checks;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;

import java.util.List;
import java.util.Set;

import static ru.sbrf.gmap.vux.utils.ValidateDataCommonUtil.resolveWorkflowRunId;

/**
 * CUV-проверка 009: совпадают ли версии таксономии в context, unit, value и data (колонка {@code xbrlvers},
 * если она есть в таблице data формы).
 * <p>
 * Сравниваются непустые значения без пробелов по краям ({@link DataContext#reportTaxonomies()}); пустое значение версией не считается, иначе одна строка
 * без таксономии давала бы ложную ошибку. Ошибка «несовпадение», если версий несколько; ошибка «не указана версия
 * таксономии», если данные отчёта есть, а версии нет ни в одной таблице. Если данных отчёта нет, ошибок нет:
 * их выдают проверки 002–004.
 */
@Component
@Order(9)
public class TaxonomyMismatchRule implements ValidationRule {

    private static final String NUMBER = "009";
    private static final String CHECK_DESCRIPTION = "По workflow_run_id отсутствует несовпадение версий таксономий";

    @Override
    public List<ValidationErrorDto> validate(DataContext ctx) {
        Set<String> taxonomies = ctx.reportTaxonomies();
        if (taxonomies.size() > 1) {
            return List.of(CuvErrors.error(ctx, NUMBER,
                    "По workflow_run_id = %d выявлено несовпадение версий таксономий.".formatted(resolveWorkflowRunId(ctx))));
        }
        if (taxonomies.isEmpty() && hasReportData(ctx)) {
            return List.of(CuvErrors.error(ctx, NUMBER,
                    "По workflow_run_id = %d не указана версия таксономии.".formatted(resolveWorkflowRunId(ctx))));
        }
        return List.of();
    }

    /**
     * Проверяет, есть ли строки context, unit или value.
     */
    private static boolean hasReportData(DataContext ctx) {
        return !ctx.contextList().isEmpty() || !ctx.unitList().isEmpty() || !ctx.valueList().isEmpty();
    }

    @Override
    public String getDescription() {
        return CHECK_DESCRIPTION;
    }

    @Override
    public String getNumber() {
        return NUMBER;
    }
}
