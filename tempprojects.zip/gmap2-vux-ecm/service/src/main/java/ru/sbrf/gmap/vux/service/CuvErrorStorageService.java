package ru.sbrf.gmap.vux.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.util.List;

/**
 * Сохраняет ошибки CUV-проверки документа в {@code t_vux_document_cuv_validation_result}.
 * <p>
 * При повторной проверке документа после технического сбоя прежние ошибки удаляются и записываются новые:
 * сначала функция БД удаляет ошибки документа, затем {@code fn_flow_cuv_set_error} записывает каждую ошибку.
 * Операция выполняется в одной транзакции, поэтому при сбое таблица возвращается к прежнему состоянию, а не
 * остаётся очищенной или заполненной частично. Если повторная проверка прошла без ошибок, прежние ошибки
 * удаляются без записи новых ({@link #clearErrors}).
 * <p>
 * Функцию удаления создаёт команда БД. Пока её нет, удаление выключено параметром
 * {@code config.cuv.clear-errors-enabled} (по умолчанию {@code false}) и работает как заглушка: прежние ошибки
 * остаются в таблице. При повторной записи появляются дубли, но при чтении они убираются ({@code DISTINCT}).
 * Если повторная проверка прошла без ошибок, прежние ошибки остаются, и при завершении обработки документ
 * будет считаться документом с ошибками — в журнал пишется WARN.
 */
@Slf4j
@Service
public class CuvErrorStorageService {

    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;
    private final boolean clearErrorsEnabled;

    /**
     * Создаёт сервис.
     *
     * @param vuxDocumentValidationResultViewRepository вызовы функций БД
     * @param clearErrorsEnabled                       {@code true}, если функция удаления ошибок создана в БД
     */
    public CuvErrorStorageService(VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository,
                                  @Value("${config.cuv.clear-errors-enabled:false}") boolean clearErrorsEnabled) {
        this.vuxDocumentValidationResultViewRepository = vuxDocumentValidationResultViewRepository;
        this.clearErrorsEnabled = clearErrorsEnabled;
    }

    /**
     * Заменяет ошибки CUV-проверки документа новыми. Исключение БД передаётся вызывающему методу, и расписание
     * остаётся открытым до следующего цикла.
     *
     * @param record запись расписания; документ определяется по {@code result_doc_id}
     * @param errors ошибки CUV-проверки
     */
    @Transactional
    public void replaceErrors(VuxDocumentScheduleViewEntity record, List<ValidationErrorDto> errors) {
        long docId = record.getResultDocumentId().longValue();
        if (clearErrorsEnabled) {
            vuxDocumentValidationResultViewRepository.flowCuvClearErrors(docId);
        }
        for (ValidationErrorDto error : errors) {
            vuxDocumentValidationResultViewRepository.flowCuvSetError(docId, error.errorMessage(), error.errorCode());
            log.debug("[CUV] Saved error: scheduleId={}, docId={}, errorCode={}, message={}",
                    record.getScheduleId(), docId, error.errorCode(), error.errorMessage());
        }
        log.info("[CUV] CUV errors saved: scheduleId={}, docId={}, count={}, previousErrorsRemoved={}",
                record.getScheduleId(), docId, errors.size(), clearErrorsEnabled);
    }

    /**
     * Проверяет, сохранены ли по документу ошибки предыдущей CUV-проверки.
     *
     * @param record запись расписания; документ определяется по {@code result_doc_id}
     * @return {@code true}, если ошибки есть
     */
    public boolean hasErrors(VuxDocumentScheduleViewEntity record) {
        return !vuxDocumentValidationResultViewRepository.findCuvValidationErrors(record.getResultDocumentId().longValue())
                .isEmpty();
    }

    /**
     * Удаляет ошибки предыдущей CUV-проверки документа без записи новых, если повторная проверка прошла без ошибок.
     * Иначе {@link FollowUpProcessingStrategy} найдёт старые ошибки, отправит письмо об ошибках и закроет расписание,
     * хотя в ECM загружен протокол об успешной проверке.
     * <p>
     * Вызывающий метод заранее проверяет {@link #hasErrors}, чтобы обработка документа без ошибок не зависела
     * от функции удаления. Исключение БД передаётся вызывающему методу, и расписание остаётся открытым.
     *
     * @param record запись расписания; документ определяется по {@code result_doc_id}
     */
    @Transactional
    public void clearErrors(VuxDocumentScheduleViewEntity record) {
        long docId = record.getResultDocumentId().longValue();
        if (!clearErrorsEnabled) {
            log.warn("[CUV] Previous CUV errors are NOT removed: the clear function is disabled " +
                    "(config.cuv.clear-errors-enabled=false). The document may be completed as a document with errors: " +
                    "scheduleId={}, docId={}", record.getScheduleId(), docId);
            return;
        }
        vuxDocumentValidationResultViewRepository.flowCuvClearErrors(docId);
        log.info("[CUV] Previous CUV errors of the document removed, current check has no CUV errors: scheduleId={}, docId={}",
                record.getScheduleId(), docId);
    }
}
