package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.repository.VuxDocumentScheduleViewRepository;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Оркестратор обработки расписания. Запускается по cron и за один цикл:
 * <ol>
 *     <li>загружает и подготавливает расписания функциями БД {@code fn_load_shedule} и {@code fn_process_shedule};</li>
 *     <li>читает записи view {@code v_vux_document_shedule_int} — расписания в статусах 1 и 2;</li>
 *     <li>передаёт каждую запись первой по {@code @Order} стратегии {@link ScheduleRecordStrategy},
 *         которая её поддерживает (выбор по {@code ecm_id}: пусто, {@code '-1'} или id протокола);</li>
 *     <li>закрывает расписание ({@code fn_flow_resolve_shedule}) только если стратегия вернула
 *         {@link ProcessingResult#COMPLETED}.</li>
 * </ol>
 * Закрытое расписание переходит в статус 3 и уходит из view; при исходном статусе 2 и без флага {@code C}
 * функция создаёт повторную проверку. Незакрытое расписание остаётся во view, и запись обрабатывается
 * в следующем цикле — так повторяется обработка после ожидания (выгрузка CSV) и технических сбоев.
 * <p>
 * Сервис рассчитан на работу в одном экземпляре: распределённая блокировка планировщика не используется.
 * Для запуска в нескольких экземплярах нужна блокировка всех методов {@code @Scheduled}.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class OrchestratorService {

    private final VuxDocumentScheduleViewRepository vuxDocumentScheduleViewRepository;
    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;

    private final List<ScheduleRecordStrategy> strategies;

    /**
     * Цикл оркестратора. Исключения наружу не выбрасываются: сбой функций загрузки расписания или чтения view
     * завершает текущий цикл без обработки записей, следующий цикл запускается по cron.
     * Сбой закрытия расписания одной записи на остальные записи не влияет.
     */
    @Scheduled(cron = "${integration.orchestrator.scheduler.cron: 0 */15 * ? * *}")
    public void run() {
        try {
            initializeSchedule();

            List<VuxDocumentScheduleViewEntity> listOfValidationTasks = getListOfValidationTasks();
            if (listOfValidationTasks.isEmpty()) {
                log.debug("[SCHEDULER] No records found for processing. Orchestrator run has been completed.");
                return;
            }

            for (VuxDocumentScheduleViewEntity record : listOfValidationTasks) {
                ScheduleRecordStrategy strategy = findStrategy(record);
                if (strategy == null) {
                    log.warn("[SCHEDULER] No processing strategy for record: scheduleId={}, docId={}, ecmId={}, checkMode={}. " +
                                    "Schedule stays open.",
                            record.getScheduleId(), record.getResultDocumentId(), record.getEcmId(), record.getCheckMode());
                    continue;
                }
                if (strategy.process(record).isCompleted()) {
                    resolveSchedule(record);
                }
            }
        } catch (Exception e) {
            log.error("[SCHEDULER] Unexpected error in the orchestrator", e);
        }
    }

    /**
     * Первая по {@code @Order} стратегия, поддерживающая запись.
     * <p>
     * Если запись поддерживают несколько стратегий, её обрабатывает первая — так запись не обрабатывается
     * дважды за цикл (повторный протокол, письмо, задача СУПЗ). Сейчас условия стратегий взаимоисключающие
     * ({@code ecm_id} пуст / {@code '-1'} / id протокола), приоритет нужен на случай их изменения или новой стратегии.
     *
     * @return стратегия либо {@code null}, если запись не поддерживает ни одна (например, стратегия
     * отключена конфигурацией или условия {@code supports} перестали покрывать все записи)
     */
    private ScheduleRecordStrategy findStrategy(VuxDocumentScheduleViewEntity record) {
        return strategies.stream()
                .filter(strategy -> strategy.supports(record))
                .findFirst()
                .orElse(null);
    }

    /**
     * Закрывает расписание функцией {@code fn_flow_resolve_shedule}.
     * <p>
     * Об отказе функция сообщает текстом, без исключения: «расписание не найдено», «расписание должно быть
     * в статусе 1 или 2»; отказ распознаётся по началу текста. Иначе результат — id созданной
     * повторной проверки либо пусто. Исключение не пробрасывается, чтобы не прервать обработку остальных записей.
     * При отказе или сбое запись остаётся во view и обрабатывается в следующем цикле; результат пишется в лог.
     */
    private void resolveSchedule(VuxDocumentScheduleViewEntity record) {
        try {
            String result = vuxDocumentValidationResultViewRepository.flowResolveShedule(record.getScheduleId()).orElse(null);
            if (result != null && result.startsWith("расписание")) {
                log.warn("[SCHEDULER] Schedule was NOT resolved by fn_flow_resolve_shedule: scheduleId={}, docId={}, result='{}'",
                        record.getScheduleId(), record.getResultDocumentId(), result);
                return;
            }
            log.info("[SCHEDULER] Schedule resolved: scheduleId={}, docId={}, newScheduleId={}",
                    record.getScheduleId(), record.getResultDocumentId(), result);
        } catch (Exception e) {
            log.error("[SCHEDULER] Failed to resolve schedule: scheduleId={}, docId={}. It will be processed again in the next cycle.",
                    record.getScheduleId(), record.getResultDocumentId(), e);
        }
    }

    /**
     * Читает все записи view расписания; если записи есть, логирует статистику: {@code new} — {@code ecm_id} пуст,
     * {@code existing} — заполнен (включая метку {@code '-1'} по флагу {@code M}), {@code byCheckMode} — по {@code check_mode}.
     */
    private List<VuxDocumentScheduleViewEntity> getListOfValidationTasks() {
        List<VuxDocumentScheduleViewEntity> tasks = vuxDocumentScheduleViewRepository.findAll();
        if (tasks.isEmpty()) {
            return tasks;
        }
        long newRecords = tasks.stream().filter(it -> it.getEcmId() == null).count();
        var byCheckMode = tasks.stream()
                .collect(Collectors.groupingBy(it -> Objects.toString(it.getCheckMode(), "null"), Collectors.counting()));
        log.info("[SCHEDULER] Found {} records for processing: new={}, existing={}, byCheckMode={}",
                tasks.size(), newRecords, tasks.size() - newRecords, byCheckMode);
        return tasks;
    }

    /**
     * Загружает расписания из АС ВКД ({@code fn_load_shedule}) и обрабатывает новые ({@code fn_process_shedule}:
     * проверка формы, заполнение выходного документа по флагам расписания). Порядок вызовов обязателен.
     * Каждая функция выполняется в своей транзакции; исключение прерывает текущий цикл.
     */
    private void initializeSchedule() {
        log.debug("[SCHEDULER] Starting schedule processing via stored procedures");
        vuxDocumentValidationResultViewRepository.fnLoadShedule();
        vuxDocumentValidationResultViewRepository.processSchedule();
        log.debug("[SCHEDULER] Schedule processing via stored procedures completed successfully");
    }
}
