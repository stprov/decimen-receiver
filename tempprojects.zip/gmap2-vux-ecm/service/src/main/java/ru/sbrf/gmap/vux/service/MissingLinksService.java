package ru.sbrf.gmap.vux.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;
import ru.sbrf.gmap.vux.service.checks.CuvErrors;
import ru.sbrf.gmap.vux.service.checks.DataContext;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository.MISSING_LINKS_MAIL_SUBJECT_MARKER;

/**
 * Ожидание справочника связей, без которого нельзя выполнить проверку 10.
 * <p>
 * Если данные формы есть и версия таксономии отчёта одна, но у формы не задана таблица витрины data или
 * в {@code t_adm_data_xbrl_link} нет связей для формы, таблицы data и таксономии, CUV-проверка не выполняется:
 * протокол не загружается, статус и ошибки CUV не пишутся, статус расписания не меняется, расписание не
 * закрывается. Ответственным уходит письмо «справочник не заполнен» — не чаще одного раза за интервал
 * {@code config.cuv.missing-links-mail-interval-hours}; время прошлого письма берётся из {@code t_vux_mail}
 * по метке в теме. Как только справочник заполнят, в ближайшем цикле выполнится обычная CUV-проверка.
 * <p>
 * Если версий таксономии несколько или нет ни одной, справочник не проверяется: проверка 9 даст ошибку,
 * и до проверки 10 дело не дойдёт. Если данных формы нет, ошибки дают проверки 1–4.
 */
@Slf4j
@Service
public class MissingLinksService {

    private static final String DAILY = "раз в сутки";

    private final PostUploadActionsService postUploadActionsService;
    private final VuxDocumentValidationResultViewRepository repository;
    private final int mailIntervalHours;

    /**
     * Создаёт сервис.
     *
     * @param postUploadActionsService отправка и фиксация письма
     * @param repository               чтение писем по документу
     * @param mailIntervalHours        минимальный интервал между письмами «справочник не заполнен», часов
     */
    public MissingLinksService(PostUploadActionsService postUploadActionsService,
                               VuxDocumentValidationResultViewRepository repository,
                               @Value("${config.cuv.missing-links-mail-interval-hours:24}") int mailIntervalHours) {
        this.postUploadActionsService = postUploadActionsService;
        this.repository = repository;
        this.mailIntervalHours = Math.max(1, mailIntervalHours);
    }

    /**
     * Причина, по которой проверку 10 выполнить нельзя.
     */
    public enum Reason {
        /**
         * У формы не задана таблица витрины data в {@code t_adm_document_type_dic}.
         */
        DATA_TABLE_NOT_SET("data table is not set in t_adm_document_type_dic"),
        /**
         * В {@code t_adm_data_xbrl_link} нет связей для формы, таблицы data и таксономии отчёта.
         */
        LINKS_NOT_FOUND("no links in t_adm_data_xbrl_link for the form, data table and taxonomy");

        private final String logText;

        Reason(String logText) {
            this.logText = logText;
        }
    }

    /**
     * Определяет, нужно ли ждать справочник связей.
     *
     * @param record  запись расписания
     * @param context данные формы со справочником связей
     * @return причина ожидания; пусто, если CUV-проверку можно выполнять
     */
    public Optional<Reason> detect(VuxDocumentScheduleViewEntity record, DataContext context) {
        if (!context.hasFormData() || context.reportTaxonomies().size() != 1) {
            return Optional.empty();
        }
        if (record.getTableName() == null || record.getTableName().isBlank()) {
            return Optional.of(Reason.DATA_TABLE_NOT_SET);
        }
        return context.links().isEmpty() ? Optional.of(Reason.LINKS_NOT_FOUND) : Optional.empty();
    }

    /**
     * Оставляет запись ждать справочник связей и при необходимости отправляет письмо «справочник не заполнен».
     *
     * @param record  запись расписания
     * @param context данные формы
     * @param reason  причина ожидания
     * @return всегда {@link ProcessingResult#PENDING}: расписание остаётся открытым
     */
    public ProcessingResult waitForReference(VuxDocumentScheduleViewEntity record, DataContext context, Reason reason) {
        long docId = record.getResultDocumentId().longValue();
        String taxonomy = String.join(", ", context.reportTaxonomies());
        String lastMail = repository.findLastMailTime(docId, MISSING_LINKS_MAIL_SUBJECT_MARKER).orElse("none");
        log.warn("[CUV] Check 010 is not possible: {}. CUV check is postponed, schedule stays open: scheduleId={}, docId={}, " +
                        "form={}, dataTable={}, taxonomy={}, lastMissingLinksMail={}",
                reason.logText, record.getScheduleId(), docId, record.getDocTypeCode(), record.getTableName(), taxonomy, lastMail);

        if (repository.existsMailSince(docId, MISSING_LINKS_MAIL_SUBJECT_MARKER, mailIntervalHours)) {
            return ProcessingResult.PENDING;
        }
        postUploadActionsService.sendNotificationMail(record, subject(record), body(record, taxonomy, reason));
        return ProcessingResult.PENDING;
    }

    /**
     * Формирует тему письма; тема обязательно содержит метку {@code MISSING_LINKS_MAIL_SUBJECT_MARKER}.
     */
    String subject(VuxDocumentScheduleViewEntity record) {
        return "XBRL \\ %s Проверка не выполнена: %s. Отчётная дата: %s"
                .formatted(record.getDocTypeCode(), MISSING_LINKS_MAIL_SUBJECT_MARKER, reportDate(record));
    }

    /**
     * Формирует HTML-текст письма по причине ожидания.
     */
    String body(VuxDocumentScheduleViewEntity record, String taxonomy, Reason reason) {
        String form = record.getDocTypeCode();
        String checkCode = CuvErrors.code(form, "010");
        String cause;
        String action;
        if (reason == Reason.DATA_TABLE_NOT_SET) {
            cause = ("Причина: в справочнике типов документов t_adm_document_type_dic для формы %s не задана таблица "
                    + "витрины data (table_name). Без неё нельзя сверить значения отчёта с витриной (проверка %s).")
                    .formatted(form, checkCode);
            action = ("Что сделать: указать таблицу витрины data для формы %s в t_adm_document_type_dic и заполнить "
                    + "для неё связи в t_adm_data_xbrl_link. Запускать проверку повторно не нужно — она выполнится "
                    + "автоматически в течение 15 минут после настройки.").formatted(form);
        } else {
            cause = ("Причина: в справочнике t_adm_data_xbrl_link нет связей показателей отчёта с витриной %s "
                    + "для таксономии %s. Без них нельзя сверить значения отчёта с витриной (проверка %s).")
                    .formatted(record.getTableName(), taxonomy, checkCode);
            action = ("Что сделать: заполнить справочник t_adm_data_xbrl_link для формы %s и таксономии %s. "
                    + "Запускать проверку повторно не нужно — она выполнится автоматически в течение 15 минут "
                    + "после заполнения справочника.").formatted(form, taxonomy);
        }
        String repeat = mailIntervalHours == 24 ? DAILY : "раз в %d ч.".formatted(mailIntervalHours);
        List<String> paragraphs = List.of(
                "Межформенная (CUV) проверка отчёта %s «%s» на отчётную дату %s не выполнена."
                        .formatted(form, nullToEmpty(record.getDocTypeName()), reportDate(record)),
                cause,
                action,
                "Пока справочник не заполнен, это письмо повторяется %s, задача в СУПЗ по отчёту не создаётся."
                        .formatted(repeat),
                "Документ: %d. Расписание: %d.".formatted(record.getResultDocumentId(), record.getScheduleId()),
                "Письмо сформировано автоматически сервисом gmap2-vux-ecm.");
        return paragraphs.stream()
                .map(text -> "<p>" + HtmlUtils.htmlEscape(text, StandardCharsets.UTF_8.name()) + "</p>")
                .collect(Collectors.joining("\n", "<html><body>\n", "\n</body></html>"));
    }

    private static String reportDate(VuxDocumentScheduleViewEntity record) {
        return record.getReportDate() == null ? "" : record.getReportDate().toString();
    }

    private static String nullToEmpty(String value) {
        return value == null ? "" : value;
    }
}
