package ru.sbrf.gmap.vux.service.checks;

import ru.sbrf.gmap.vux.dto.ValidationErrorDto;

import java.util.List;

/**
 * Правило CUV-проверки. Правило общее для всех форм: код ошибки строится по коду формы документа
 * ({@link CuvErrors}), а правило знает только свой номер проверки.
 * <p>
 * Правило не выбрасывает исключения при проверке: найденные нарушения возвращаются списком.
 */
public interface ValidationRule {

    /**
     * Возвращает номер проверки — последнюю часть кода ошибки.
     *
     * @return номер от {@code "001"} до {@code "010"}
     */
    String getNumber();

    /**
     * Возвращает описание проверки для протокола.
     *
     * @return описание проверки
     */
    String getDescription();

    /**
     * Выполняет проверку. Одна проверка может вернуть несколько нарушений.
     *
     * @param context данные формы
     * @return нарушения; пустой список, если нарушений нет
     */
    List<ValidationErrorDto> validate(DataContext context);

    /**
     * Проверяет, включено ли правило. Выключенное правило не выполняется, в протоколе для него указывается
     * «Не проверялось», в число выполненных проверок оно не входит.
     *
     * @return {@code true}, если правило включено
     */
    default boolean isEnabled() {
        return true;
    }

    /**
     * Проверяет, относится ли ошибка к этому правилу, по номеру проверки в конце кода ошибки; код формы не учитывается.
     *
     * @param errorCode код ошибки
     * @return {@code true}, если ошибка относится к правилу
     */
    default boolean matches(String errorCode) {
        return errorCode != null && errorCode.endsWith("_" + getNumber());
    }

    /**
     * Возвращает шаг алгоритма проверки: 1 — проверка {@code 001}; 2 — {@code 002}–{@code 004};
     * 3 — {@code 005}–{@code 009}; 4 — {@code 010} и правила с нечисловым номером. Если на шаге найдены ошибки,
     * следующие шаги не выполняются.
     *
     * @return номер шага
     */
    default int getStage() {
        int number;
        try {
            number = Integer.parseInt(getNumber());
        } catch (NumberFormatException | NullPointerException e) {
            return 4;
        }
        if (number == 1) {
            return 1;
        }
        if (number >= 2 && number <= 4) {
            return 2;
        }
        if (number >= 5 && number <= 9) {
            return 3;
        }
        return 4;
    }
}
