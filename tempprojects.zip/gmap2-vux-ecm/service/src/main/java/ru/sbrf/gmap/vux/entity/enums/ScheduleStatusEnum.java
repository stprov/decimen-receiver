package ru.sbrf.gmap.vux.entity.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Статус расписания ({@code t_vux_document_shedule.shedule_status}).
 * <p>
 * Код статуса в БД задан явно ({@link #getCode()}) и передаётся в {@code fn_flow_update_shedule}. Сущность view
 * расписания читает статус по порядковому номеру ({@code EnumType.ORDINAL}), поэтому код каждого значения
 * совпадает с его позицией: значения нельзя переставлять и добавлять в середину. Совпадение проверяет
 * {@code ScheduleStatusEnumTest}.
 * <p>
 * Названия значений исторические и не везде совпадают со смыслом статуса в БД.
 */
@Getter
@RequiredArgsConstructor
public enum ScheduleStatusEnum {

    /**
     * 0 — назначение статуса в БД не описано.
     */
    UPLOADED(0),

    /**
     * 1 — проверено без ошибок.
     */
    VERIFIED_SUCCESSFULLY(1),

    /**
     * 2 — проверено с ошибками: при закрытии расписания {@code fn_flow_resolve_shedule} создаёт повторную проверку
     * (если нет флага {@code C}).
     */
    CHECKED_WITH_ERRORS(2),

    /**
     * 3 — расписание обработано и закрыто функцией {@code fn_flow_resolve_shedule}; название этому не соответствует.
     */
    CHECKED_WITH_AN_INTERNAL_ERROR(3),

    /**
     * 4 — назначение статуса в БД не описано.
     */
    PROCESSED(4);

    /**
     * Код статуса в БД.
     */
    private final int code;
}
