package ru.sbrf.gmap.vux.dto.cuv;

import lombok.Builder;

import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Строка справочника {@code t_adm_data_xbrl_link}: связь колонки витрины data с показателем или осью XBRL.
 *
 * @param columnName        колонка таблицы data
 * @param columnXbrlType    тип колонки: {@code measure} — показатель, {@code enumerator} — перечисление,
 *                          прочие значения в сверке значений не участвуют
 * @param enumId            перечисление, по которому значение витрины перекодируется в код элемента
 * @param axisId            ось XBRL
 * @param taxisId           открытая ось XBRL, значение которой хранится в ключевой колонке
 * @param parameterId       параметр XBRL (показатель перечисления)
 * @param measureId         показатель XBRL
 * @param lineKey           порядковый номер ключевой колонки строки data; {@code null} — колонка не ключевая
 * @param analyticalSection закрытые оси, при которых показатель лежит именно в этой колонке
 */
@Builder
public record CuvLinkDto(
        String columnName,
        String columnXbrlType,
        String enumId,
        String axisId,
        String taxisId,
        String parameterId,
        String measureId,
        Integer lineKey,
        String analyticalSection
) {

    private static final String TYPE_MEASURE = "measure";
    private static final String TYPE_ENUMERATOR = "enumerator";

    /**
     * Проверяет, задаёт ли строка ключевую колонку строки data.
     *
     * @return {@code true}, если заполнены {@code line_key} и колонка
     */
    public boolean isKey() {
        return lineKey != null && columnName != null && !columnName.isBlank();
    }

    /**
     * Проверяет, хранит ли колонка значение показателя.
     *
     * @return {@code true} для типов {@code measure} и {@code enumerator}
     */
    public boolean isValueColumn() {
        String type = columnXbrlType == null ? "" : columnXbrlType.trim().toLowerCase(Locale.ROOT);
        return (TYPE_MEASURE.equals(type) || TYPE_ENUMERATOR.equals(type)) && columnName != null && !columnName.isBlank();
    }

    /**
     * Проверяет, хранит ли колонка значение перечисления.
     *
     * @return {@code true} для типа {@code enumerator}
     */
    public boolean isEnumerator() {
        return columnXbrlType != null && TYPE_ENUMERATOR.equalsIgnoreCase(columnXbrlType.trim());
    }

    /**
     * Возвращает показатель колонки для текста ошибки: {@code measure_id}, для перечисления — {@code parameter_id},
     * а если он пуст — {@code axis_id}.
     *
     * @return показатель колонки или имя колонки, если показатель не задан
     */
    public String indicator() {
        String indicator = isEnumerator() ? firstNonBlank(parameterId, axisId) : firstNonBlank(measureId, null);
        return indicator == null ? columnName : indicator.trim();
    }

    /**
     * Возвращает имена показателя без префикса пространства имён, по которым колонка сопоставляется
     * со значением отчёта ({@code value.element_name}).
     *
     * @return для показателя — {@code measure_id}; для перечисления — {@code parameter_id} и {@code axis_id}
     */
    public Set<String> indicatorNames() {
        Stream<String> names = isEnumerator() ? Stream.of(parameterId, axisId) : Stream.of(measureId);
        return names.filter(Objects::nonNull)
                .map(String::trim)
                .filter(name -> !name.isEmpty())
                .map(CuvLinkDto::localName)
                .collect(Collectors.toUnmodifiableSet());
    }

    /**
     * Убирает префикс пространства имён: {@code dim-int:ID_strokiTaxis} → {@code ID_strokiTaxis}.
     *
     * @param name имя XBRL
     * @return имя без префикса; {@code null}, если имя не задано
     */
    public static String localName(String name) {
        if (name == null) {
            return null;
        }
        String trimmed = name.trim();
        int colon = trimmed.lastIndexOf(':');
        return colon < 0 ? trimmed : trimmed.substring(colon + 1);
    }

    private static String firstNonBlank(String first, String second) {
        if (first != null && !first.isBlank()) {
            return first;
        }
        return second != null && !second.isBlank() ? second : null;
    }
}
