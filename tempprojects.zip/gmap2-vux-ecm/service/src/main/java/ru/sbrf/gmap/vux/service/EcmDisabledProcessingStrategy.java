package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.config.FeatureToogleConfig;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.service.ValidationDefectsService.ViewDefects;

import java.util.List;

/**
 * Стратегия обработки записи расписания, для которой загрузка протокола в ECM запрещена флагом расписания
 * {@code M} ({@code ecm_id = '-1'}).
 * <p>
 * Метку {@code '-1'} ставит {@code fn_process_shedule} до обработки записи сервисом, поэтому {@code ecm_id} заполнен,
 * хотя протокола в ECM нет.
 * <p>
 * Запись обрабатывается так же, как до внедрения CUV-проверки: CUV-проверка не выполняется, протокол строится
 * по нарушениям, найденным в БД, и в ECM не загружается. При ошибках отправляется письмо, иначе создаётся задача
 * СУПЗ, к которой вместо id протокола прикладывается метка {@code '-1'}. Порядок обработки таких записей
 * с CUV-проверкой ещё не согласован; при его изменении меняется только этот класс.
 */
@Service
@Order(2)
@RequiredArgsConstructor
@Slf4j
public class EcmDisabledProcessingStrategy implements ScheduleRecordStrategy {

    private final FeatureToogleConfig featureToggleConfig;
    private final ProtocolBuildingService protocolBuildingService;
    private final ValidationDefectsService validationDefectsService;
    private final PostUploadActionsService postUploadActionsService;

    @Override
    public boolean supports(VuxDocumentScheduleViewEntity record) {
        return record.isEcmUploadDisabled();
    }

    @Override
    public ProcessingResult process(VuxDocumentScheduleViewEntity record) {
        try {
            if (featureToggleConfig.isCuvApplicable(record)) {
                log.warn("[ROUTE] Route: scheduleId={}, docId={}, docTypeCode={}, checkMode={}, phase=legacy, " +
                                "reason=ecm_id='-1' (ECM upload is disabled by schedule flag M), CUV validation is not applied",
                        record.getScheduleId(), record.getResultDocumentId(), record.getDocTypeCode(), record.getCheckMode());
            } else {
                log.info("[ROUTE] Route: scheduleId={}, docId={}, docTypeCode={}, checkMode={}, phase=legacy, " +
                                "reason=ecm_id='-1' (ECM upload is disabled by schedule flag M)",
                        record.getScheduleId(), record.getResultDocumentId(), record.getDocTypeCode(), record.getCheckMode());
            }

            ViewDefects view = validationDefectsService.loadViewDefects(record.getResultDocumentId());
            ProtocolModelDto protocol = protocolBuildingService.createProtocolModelDto(
                    view.errors(), view.warnings(), view.checks(), record);
            return ProcessingResult.of(
                    postUploadActionsService.handlePostUploadActions(record, protocol, List.of(record.getEcmId())));
        } catch (Exception e) {
            log.error("[ROUTE] Unexpected error when processing a record with ECM upload disabled (ecm_id='-1'): " +
                    "scheduleId={}, docId={}. Record is skipped until the next scheduler cycle.",
                    record.getScheduleId(), record.getResultDocumentId(), e);
            return ProcessingResult.PENDING;
        }
    }
}
