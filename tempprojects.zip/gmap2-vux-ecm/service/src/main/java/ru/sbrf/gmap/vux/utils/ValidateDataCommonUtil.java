package ru.sbrf.gmap.vux.utils;

import lombok.experimental.UtilityClass;
import ru.sbrf.gmap.vux.service.checks.DataContext;

/**
 * Общие методы CUV-проверок.
 */
@UtilityClass
public class ValidateDataCommonUtil {
    /**
     * Возвращает {@code workflow_run_id} проверяемого документа: из view расписания, если он задан, иначе
     * из первой строки context, unit или value.
     *
     * @param ctx данные формы
     * @return номер загрузки; {@code 0}, если данных нет
     */
    public static Long resolveWorkflowRunId(DataContext ctx) {
        if (ctx.workflowRunId() != null) {
            return ctx.workflowRunId();
        }
        if (!ctx.contextList().isEmpty()) {
            return ctx.contextList().getFirst().workflowRunId();
        }
        if (!ctx.unitList().isEmpty()) {
            return ctx.unitList().getFirst().workflowRunId();
        }
        if (!ctx.valueList().isEmpty()) {
            return ctx.valueList().getFirst().workflowRunId();
        }
        return 0L;
    }
}
