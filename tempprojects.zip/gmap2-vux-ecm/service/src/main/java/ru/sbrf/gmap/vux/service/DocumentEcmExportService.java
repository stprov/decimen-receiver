package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.entity.VuxDocumentEcmEntity;
import ru.sbrf.gmap.vux.repository.VuxDocumentEcmRepository;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;
import ru.sbrf.gmap.vux.service.checks.ImageTypeEnum;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Выгрузка образов документа (CSV context/unit/value) в ECM через таблицу-очередь
 * {@code t_vux_document_ecm}.
 * <p>
 * VUX только создаёт записи ({@code fn_xbrl_create_ecm}) и читает их состояние;
 * файлы формирует и загружает в ECM внешний сервис. {@code disabled = 1} — окончательный
 * отказ внешнего сервиса (404/405/406/408, HTTP 4xx от ECM): такая запись не пересоздаётся,
 * расписание остаётся открытым, в лог пишется ERROR для ручного разбора.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DocumentEcmExportService {

    /**
     * {@code p_s3_del = 1}: после успешной загрузки в ECM внешний сервис удаляет файлы из S3.
     */
    private static final int S3_DEL = 1;

    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;
    private final VuxDocumentEcmRepository vuxDocumentEcmRepository;

    /**
     * Значение {@code p_archive} для {@code fn_xbrl_create_ecm}.
     */
    @Value("${config.csv-export.archive:0}")
    private int archive;

    /**
     * Создаёт записи на выгрузку всех CSV-образов CUV-проверки. Ошибка по одному образу не прерывает создание
     * остальных: недостающие записи создаст {@link #evaluateCuvCsvExport} в следующих циклах.
     *
     * @param scheduleId id расписания
     * @param docId      id документа
     * @return {@code true}, если созданы все записи
     */
    public boolean requestCuvCsvExport(Integer scheduleId, Integer docId) {
        boolean allCreated = true;
        for (ImageTypeEnum type : ImageTypeEnum.CUV_CSV_TYPES) {
            allCreated &= createExportRecord(scheduleId, docId, type, "initial");
        }
        return allCreated;
    }

    /**
     * Создаёт запись на выгрузку одного образа функцией {@code fn_xbrl_create_ecm}.
     *
     * @param scheduleId id расписания
     * @param docId      id документа
     * @param type       тип образа
     * @param reason     причина создания для журнала: {@code initial} или {@code restore}
     * @return {@code true}, если запись создана
     */
    public boolean createExportRecord(Integer scheduleId, Integer docId, ImageTypeEnum type, String reason) {
        try {
            vuxDocumentValidationResultViewRepository.fnXbrlCreateEcm(docId, type.getCode(), archive, S3_DEL);
            log.info("[CSV-EXPORT] Export record created: scheduleId={}, docId={}, imageType={}, reason={}", scheduleId, docId, type.getCode(), reason);
            return true;
        } catch (Exception e) {
            log.error("[CSV-EXPORT] Failed to create export record: scheduleId={}, docId={}, imageType={}, reason={}. " +
                    "Will be retried in the next scheduler cycle.", scheduleId, docId, type.getCode(), reason, e);
            return false;
        }
    }

    /**
     * Проверяет состояние выгрузки CSV-образов CUV-проверки.
     * <p>
     * Для каждого образа берётся последняя по {@code created} запись:
     * <ul>
     *     <li>{@code ecm_id} заполнен — образ загружен;</li>
     *     <li>{@code disabled = 1} — окончательный отказ: запись не пересоздаётся, в журнал пишется ERROR,
     *         задача СУПЗ не создаётся до ручного разбора;</li>
     *     <li>{@code ecm_id} пуст, {@code disabled = 0} — внешний сервис ещё обрабатывает запись;</li>
     *     <li>записей нет — запись создаётся заново.</li>
     * </ul>
     *
     * @param scheduleId id расписания
     * @param docId      id документа
     * @return состояние выгрузки; {@link ExportState#ready()} равно {@code true}, если все образы загружены в ECM
     */
    public ExportState evaluateCuvCsvExport(Integer scheduleId, Integer docId) {
        List<String> codes = ImageTypeEnum.CUV_CSV_TYPES.stream().map(ImageTypeEnum::getCode).toList();
        Map<String, List<VuxDocumentEcmEntity>> byType = vuxDocumentEcmRepository
                .findByDocIdAndImageTypeIn(docId.longValue(), codes).stream()
                .collect(Collectors.groupingBy(e -> normalize(e.getImageType())));

        List<String> ecmIds = new ArrayList<>();
        boolean ready = true;
        for (ImageTypeEnum type : ImageTypeEnum.CUV_CSV_TYPES) {
            List<VuxDocumentEcmEntity> records = byType.getOrDefault(type.getCode(), List.of());
            Optional<VuxDocumentEcmEntity> last = records.stream()
                    .max(Comparator.comparing(VuxDocumentEcmEntity::getCreated,
                            Comparator.nullsFirst(Comparator.<Timestamp>naturalOrder())));

            if (last.isEmpty()) {
                ready = false;
                log.warn("[CSV-EXPORT] No export records found: scheduleId={}, docId={}, imageType={}. Restoring record.",
                        scheduleId, docId, type.getCode());
                createExportRecord(scheduleId, docId, type, "restore");
                continue;
            }

            VuxDocumentEcmEntity record = last.get();
            if (record.hasEcmId()) {
                ecmIds.add(record.getEcmId().toString());
            } else if (record.isDisabled()) {
                ready = false;
                log.error("[CSV-EXPORT] CSV export failed permanently (disabled=1), manual analysis required: " +
                                "scheduleId={}, docId={}, imageType={}, xbrlId={}, attempt={}, errorCode={}, errorMessage={}",
                        scheduleId, docId, type.getCode(), record.getXbrlId(), record.getAttempt(),
                        record.getErrorCode(), record.getErrorMessage());
            } else {
                ready = false;
                log.debug("[CSV-EXPORT] CSV is not ready yet: scheduleId={}, docId={}, imageType={}, xbrlId={}, created={}, attempt={}",
                        scheduleId, docId, type.getCode(), record.getXbrlId(), record.getCreated(), record.getAttempt());
            }
        }

        if (ready) {
            log.info("[CSV-EXPORT] All CSV are uploaded to ECM: scheduleId={}, docId={}, ecmIds={}", scheduleId, docId, ecmIds);
            return new ExportState(true, List.copyOf(ecmIds));
        }
        return new ExportState(false, List.of());
    }

    /**
     * Убирает хвостовые пробелы из кода образа: {@code image_type} хранится как {@code bpchar}. Регистр
     * не меняется: коды ищутся точно, а сервис записывает их в верхнем регистре ({@link ImageTypeEnum}).
     */
    private static String normalize(String imageType) {
        return imageType == null ? "" : imageType.trim();
    }

    /**
     * Состояние выгрузки CSV.
     *
     * @param ready  все образы загружены в ECM
     * @param ecmIds ECM-идентификаторы CSV в порядке {@link ImageTypeEnum#CUV_CSV_TYPES} (только при ready)
     */
    public record ExportState(boolean ready, List<String> ecmIds) {
    }
}
