package ru.sbrf.gmap.vux.service.checks;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;

import java.util.List;

/**
 * CUV-проверка 001: заполнен ли {@code workflow_run_id}. Номер загрузки берётся из view расписания, а если
 * он не задан — из первой строки context. Ошибка, если номер не определён или не больше нуля.
 */
@Component
@Order(1)
public class WorkflowRunIdRule implements ValidationRule {

    private static final String NUMBER = "001";
    private static final String CHECK_DESCRIPTION = "Проверка на заполненность поля workflow_run_id";

    @Override
    public List<ValidationErrorDto> validate(DataContext ctx) {
        Long workflowRunId = ctx.workflowRunId() != null
                ? ctx.workflowRunId()
                : ctx.contextList().isEmpty() ? null : ctx.contextList().getFirst().workflowRunId();
        if (workflowRunId == null || workflowRunId <= 0) {
            return List.of(CuvErrors.error(ctx, NUMBER,
                    "Не удалось определить идентификатор процесса создавшего документ workflow_run_id НЕ заполнен."));
        }
        return List.of();
    }

    @Override
    public String getDescription() {
        return CHECK_DESCRIPTION;
    }

    @Override
    public String getNumber() {
        return NUMBER;
    }
}
