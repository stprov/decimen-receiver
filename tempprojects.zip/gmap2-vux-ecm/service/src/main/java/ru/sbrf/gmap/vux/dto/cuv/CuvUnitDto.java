package ru.sbrf.gmap.vux.dto.cuv;

import lombok.Builder;

/**
 * Строка таблицы unit отчётной формы (единица измерения). Общий DTO для всех форм.
 *
 * @param unitId        идентификатор единицы измерения
 * @param taxonomy      версия таксономии
 * @param workflowRunId номер загрузки отчёта
 */
@Builder
public record CuvUnitDto(
        String unitId,
        String taxonomy,
        Long workflowRunId
) {
}
