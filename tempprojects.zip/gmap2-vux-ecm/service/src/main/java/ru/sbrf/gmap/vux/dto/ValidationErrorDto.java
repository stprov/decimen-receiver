package ru.sbrf.gmap.vux.dto;

import lombok.Builder;

/**
 * Ошибка проверки данных.
 *
 * @param errorTitle     заголовок ошибки в протоколе
 * @param errorCode      код ошибки
 * @param errorMessage   текст ошибки
 * @param deviationCount число расхождений, которое описывает ошибка: у строки сводки проверки 10 — число
 *                       расхождений по показателю, у остальных ошибок — {@code 1}; значение меньше 1
 *                       заменяется на {@code 1}
 */
@Builder
public record ValidationErrorDto(
        String errorTitle,
        String errorCode,
        String errorMessage,
        int deviationCount
) {

    /**
     * Заменяет некорректное число расхождений на {@code 1}.
     */
    public ValidationErrorDto {
        deviationCount = Math.max(1, deviationCount);
    }

    /**
     * Создаёт ошибку, которая описывает одно расхождение.
     *
     * @param errorTitle   заголовок ошибки в протоколе
     * @param errorCode    код ошибки
     * @param errorMessage текст ошибки
     */
    public ValidationErrorDto(String errorTitle, String errorCode, String errorMessage) {
        this(errorTitle, errorCode, errorMessage, 1);
    }
}
