package ru.sbrf.gmap.vux.service.checks;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;

import static ru.sbrf.gmap.vux.utils.ValidateDataCommonUtil.resolveWorkflowRunId;

import java.util.List;

/**
 * CUV-проверка 002: получены ли по {@code workflow_run_id} строки context. Ошибка, если строк нет.
 */
@Component
@Order(2)
public class ContextExistsRule implements ValidationRule {

    private static final String NUMBER = "002";
    private static final String CHECK_DESCRIPTION = "По workflow_run_id получен context";

    @Override
    public List<ValidationErrorDto> validate(DataContext ctx) {
        if (ctx.contextList().isEmpty()) {
            return List.of(CuvErrors.error(ctx, NUMBER,
                    "По workflow_run_id = %d НЕ получен context.".formatted(resolveWorkflowRunId(ctx))));
        }
        return List.of();
    }

    @Override
    public String getDescription() {
        return CHECK_DESCRIPTION;
    }

    @Override
    public String getNumber() {
        return NUMBER;
    }
}
