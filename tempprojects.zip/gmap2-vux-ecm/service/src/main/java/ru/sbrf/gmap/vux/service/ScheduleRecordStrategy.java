package ru.sbrf.gmap.vux.service;

import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;

/**
 * Стратегия обработки записи расписания в {@link OrchestratorService}.
 * <p>
 * Реализации регистрируются как бины Spring. Каждую запись оркестратор передаёт первой
 * по {@code @Order} стратегии, для которой {@link #supports(VuxDocumentScheduleViewEntity)}
 * возвращает {@code true}: {@code @Order} — приоритет, если запись поддерживают несколько стратегий.
 * Запись, которую не поддерживает ни одна стратегия, не обрабатывается и остаётся открытой (WARN в логе).
 * <p>
 * Стратегию определяет поле {@code ecm_id} записи:
 * <ul>
 *     <li>пусто — {@link InitialProcessingStrategy}: первый проход, сервис ещё не загружал протокол в ECM;</li>
 *     <li>{@code '-1'} — {@link EcmDisabledProcessingStrategy}: загрузка в ECM запрещена флагом расписания {@code M};</li>
 *     <li>id протокола — {@link FollowUpProcessingStrategy}: протокол загружен, обработка доводится до конца.</li>
 * </ul>
 */
public interface ScheduleRecordStrategy {

    /**
     * Проверяет, обрабатывает ли стратегия переданную запись.
     *
     * @param record запись расписания
     * @return {@code true}, если стратегия обрабатывает запись
     */
    boolean supports(VuxDocumentScheduleViewEntity record);

    /**
     * Обрабатывает запись расписания: проверка, протокол, письмо, задача СУПЗ — в зависимости от стратегии.
     * Реализация не выбрасывает исключения: при техническом сбое возвращается {@link ProcessingResult#PENDING}.
     *
     * @param record запись расписания
     * @return {@link ProcessingResult#COMPLETED}, если расписание можно закрыть;
     *         {@link ProcessingResult#PENDING}, если запись нужно обработать в следующем цикле планировщика
     */
    ProcessingResult process(VuxDocumentScheduleViewEntity record);
}
