package ru.sbrf.gmap.vux.entity.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Итоговый статус CUV-проверки документа ({@code t_vux_document_cuv_validation_status.status},
 * функция {@code fn_flow_cuv_set_status}).
 */
@Getter
@RequiredArgsConstructor
public enum CuvValidationStatusEnum {
    /**
     * Не проверено: CUV-проверка выключена фича-флагом. Отсутствие данных формы — это ошибки
     * {@code _001}–{@code _004} и статус {@link #CHECKED_WITH_ERRORS}.
     */
    NOT_CHECKED(0),
    /**
     * Проверен без ошибок.
     */
    CHECKED_WITHOUT_ERRORS(1),
    /**
     * Проверен с ошибками.
     */
    CHECKED_WITH_ERRORS(2);

    /**
     * Код статуса в БД.
     */
    private final int code;
}
