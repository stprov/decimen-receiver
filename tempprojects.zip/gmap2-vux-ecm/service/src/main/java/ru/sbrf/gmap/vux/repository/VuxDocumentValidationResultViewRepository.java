package ru.sbrf.gmap.vux.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.NativeQuery;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationResultViewEntity;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public interface VuxDocumentValidationResultViewRepository extends JpaRepository<VuxDocumentValidationResultViewEntity, Long> {
    /**
     * Нарушения документа из view с ограничением выборки: не больше {@code error_set} на правило ({@code rn})
     * и не больше {@code total_set} всего.
     * <p>
     * Ошибки ({@code rule_type = 'E'}) идут раньше предупреждений, чтобы {@code LIMIT} не отрезал их при большом числе
     * предупреждений: по выборке решается, есть ли у документа ошибки (письмо вместо выгрузки CSV и задачи СУПЗ).
     * Первая строка каждого правила проходит фильтр {@code rn}, поэтому при наличии ошибок хотя бы одна попадает
     * в выборку. Внутри ошибок и внутри предупреждений порядок прежний — по {@code line}, {@code error_code}.
     */
    @Transactional
    @NativeQuery("""
            SELECT * FROM s_grnplm_as_cib_gm_vux.v_vux_document_validation_result
            WHERE doc_id = :doc_id
              AND rn <= :error_set
            ORDER BY CASE WHEN rule_type = 'E' THEN 0 ELSE 1 END, line, error_code
            LIMIT :total_set
            """)
    List<VuxDocumentValidationResultViewEntity> findByDocIdWithRnLimit(@Param("doc_id") Integer docId, @Param("error_set") Integer errorSet, @Param("total_set") Integer totalSet);

    @Transactional
    @NativeQuery("""
            SELECT FROM s_grnplm_as_cib_gm_vux.fn_process_shedule();""")
    Optional<Void> processSchedule();

    @Transactional
    @NativeQuery("""
            SELECT
            FROM s_grnplm_as_cib_gm_vux.fn_flow_set_ecm_id(:resultDocId, :ecmId, :ecmStatus);""")
    Optional<Void> flowSetEcmId(@Param("resultDocId") Integer resultDocId, @Param("ecmId") String ecmId, @Param("ecmStatus") String ecmStatus);

    @Transactional
    @NativeQuery("""
            SELECT
            FROM s_grnplm_as_cib_gm_vux.fn_flow_set_mail_status(:resultDocId, :recipients, :theme, :body, :mailType);""")
    Optional<Void> flowSetMailStatus(@Param("resultDocId") Integer resultDocId, @Param("recipients") String recipients, @Param("theme") String theme, @Param("body") String body, @Param("mailType") String mailType);

    @Transactional
    @NativeQuery("""
            SELECT
            FROM s_grnplm_as_cib_gm_vux.fn_flow_set_supz_id(:resultDocId, :supzId, :supzStatus, :supzJson);""")
    Optional<Void> flowSetSupzId(@Param("resultDocId") Integer resultDocId, @Param("supzId") String supzId, @Param("supzStatus") String supzStatus, @Param("supzJson") String supzJson);

    @Transactional
    @NativeQuery("""
            select FROM s_grnplm_as_cib_gm_vux.fn_flow_create_shedules_list(:pSheduleCode, :pCustomerId, :pDocTypeId, :pTaxonomy, :pReportDtList, :pFlags);
            """)
    Optional<Void> demoModeInit(@Param("pSheduleCode") String pSheduleCode, @Param("pCustomerId") Integer pCustomerId
            , @Param("pDocTypeId") String pDocTypeId, @Param("pTaxonomy") String pTaxonomy
            , @Param("pReportDtList") String pReportDtList, @Param("pFlags") String pFlags);

    /**
     * Закрывает расписание ({@code fn_flow_resolve_shedule}).
     *
     * @return результат функции: id нового расписания (повторная проверка), пусто,
     * либо текст отказа ('расписание не найдено', 'расписание должно быть в статусе 1 или 2') — без исключения
     */
    @Transactional
    @NativeQuery("SELECT s_grnplm_as_cib_gm_vux.fn_flow_resolve_shedule(:scheduleId)")
    Optional<String> flowResolveShedule(@Param("scheduleId") Integer scheduleId);

    /**
     * Меняет статус расписания ({@code fn_flow_update_shedule(int8, int4)}): обновляется только
     * {@code shedule_status}, остальные поля не меняются.
     * <p>
     * Используется при ошибках CUV-проверки: статус 2 («проверено с ошибками») нужен, чтобы
     * {@code fn_flow_resolve_shedule} при закрытии создал повторную проверку, как при ошибках БД.
     *
     * @return результат функции (служебный текст журнала БД)
     */
    @Transactional
    @NativeQuery("SELECT s_grnplm_as_cib_gm_vux.fn_flow_update_shedule(CAST(:scheduleId AS int8), CAST(:status AS int4))")
    Optional<String> flowUpdateSheduleStatus(@Param("scheduleId") Integer scheduleId, @Param("status") Integer status);

    /**
     * Фиксирует ошибку обработки документа в витрине данных.
     * <p>
     * Вызов хранимой процедуры {@code s_grnplm_as_cib_gm_vux.fn_flow_cuv_set_error}.
     *
     * @param pDocId        идентификатор документа (doc_id из витрины)
     * @param pErrorMessage  текст ошибки
     * @param pErrorCode    код ошибки
     * @return пустой Optional после успешного выполнения процедуры
     */
    @Transactional
    @NativeQuery("""
            SELECT
            FROM s_grnplm_as_cib_gm_vux.fn_flow_cuv_set_error(:pDocId, :pErrorMessage, :pErrorCode);""")
    Optional<Void> flowCuvSetError(@Param("pDocId") Long pDocId, @Param("pErrorMessage") String pErrorMessage, @Param("pErrorCode") String pErrorCode);

    /**
     * Удаляет прежние ошибки CUV-проверки документа из {@code t_vux_document_cuv_validation_result} перед записью
     * новых. Функцию создаёт команда БД; {@code fn_flow_cuv_clear_errors(pDocId int8)} — рабочее имя, имя и параметры
     * функции могут измениться.
     *
     * @param pDocId id документа ({@code result_doc_id})
     * @return пустой {@link Optional} после успешного выполнения функции
     */
    @Transactional
    @NativeQuery("""
            SELECT
            FROM s_grnplm_as_cib_gm_vux.fn_flow_cuv_clear_errors(CAST(:pDocId AS int8));""")
    Optional<Void> flowCuvClearErrors(@Param("pDocId") Long pDocId);

    /**
     * Сохраняет итоговый статус CUV-проверки ({@code fn_flow_cuv_set_status}): функция находит активное
     * расписание по {@code result_doc_id} и добавляет строку в {@code t_vux_document_cuv_validation_status}
     * (только INSERT).
     *
     * @param pDocId      {@code result_doc_id}
     * @param pStatus     0 — не проверен, 1 — проверен без ошибок, 2 — проверен с ошибками
     * @param pCheckCount количество выполненных проверок
     * @param pErrorCount количество найденных ошибок
     * @param pCheckStart начало проверки
     * @param pCheckEnd   окончание проверки
     * @return результат функции: служебный текст журнала БД либо «расписание не найдено» (без исключения)
     */
    @Transactional
    @NativeQuery("""
            SELECT s_grnplm_as_cib_gm_vux.fn_flow_cuv_set_status(
                CAST(:pDocId AS int8), CAST(:pStatus AS int2), CAST(:pCheckCount AS int4),
                CAST(:pErrorCount AS int8), CAST(:pCheckStart AS timestamp), CAST(:pCheckEnd AS timestamp))""")
    Optional<String> flowCuvSetStatus(@Param("pDocId") Long pDocId, @Param("pStatus") Integer pStatus,
                                      @Param("pCheckCount") Integer pCheckCount, @Param("pErrorCount") Long pErrorCount,
                                      @Param("pCheckStart") Timestamp pCheckStart, @Param("pCheckEnd") Timestamp pCheckEnd);

    /**
     * Метод для инициации загрузки расписаний через ВКД.
     * Вызывать строго до fn_process_shedule.
     *
     * @return void
     */
    @Transactional
    @NativeQuery("SELECT FROM s_grnplm_as_cib_gm_vux.fn_load_shedule()")
    Optional<Void> fnLoadShedule();

    @Transactional
    @NativeQuery("SELECT FROM s_grnplm_as_cib_gm_vux.fn_flow_info_email_send(:id)")
    Optional<Void> fnFlowInfoEmalSend(@Param("id") Long id);

    /**
     * Регистрирует запрос в очереди ECM.
     * <p>
     * Вызов хранимой процедуры {@code s_grnplm_as_cib_gm_vux.fn_ecm_request_create}.
     *
     * @param pRequestId   сформированный uuid запроса в ЕСМ
     * @param pSubsystem   подсистема (всегда {@code xbrl-csv})
     * @param pSubsystemId идентификатор подсистемы (slice_id)
     * @return пустой Optional после успешного выполнения процедуры
     */
    @Transactional
    @NativeQuery("""
            SELECT
            FROM s_grnplm_as_cib_gm_vux.fn_ecm_request_create(:pRequestId, :pSubsystem, :pSubsystemId);""")
    Optional<Void> fnEcmRequestCreate(@Param("pRequestId") String pRequestId, @Param("pSubsystem") String pSubsystem, @Param("pSubsystemId") String pSubsystemId);

    /**
     * Проставляет присвоенный ЕСМ-ом uuid после успешной загрузки документа.
     * <p>
     * Вызов хранимой процедуры {@code s_grnplm_as_cib_gm_vux.fn_ecm_request_set_ecm_id}.
     *
     * @param pRequestId сформированный uuid запроса в ЕСМ
     * @param pEcmId     присвоенный ЕСМ-ом uuid
     * @return пустой Optional после успешного выполнения процедуры
     */
    @Transactional
    @NativeQuery("""
            SELECT
            FROM s_grnplm_as_cib_gm_vux.fn_ecm_request_set_ecm_id(:pRequestId, :pEcmId);""")
    Optional<Void> fnEcmRequestSetEcmId(@Param("pRequestId") String pRequestId, @Param("pEcmId") String pEcmId);

    /**
     * Фиксирует ошибку обработки запроса в очереди ECM.
     * <p>
     * Вызов хранимой процедуры {@code s_grnplm_as_cib_gm_vux.fn_ecm_request_set_error}.
     *
     * @param pRequestId  сформированный uuid запроса в ЕСМ
     * @param pErrorText  текст ошибки
     * @return пустой Optional после успешного выполнения процедуры
     */
    @Transactional
    @NativeQuery("""
            SELECT
            FROM s_grnplm_as_cib_gm_vux.fn_ecm_request_set_error(:pRequestId, :pErrorText);""")
    Optional<Void> fnEcmRequestSetError(@Param("pRequestId") String pRequestId, @Param("pErrorText") String pErrorText);

    /**
     * Проверяет наличие записи с заданным {@code rqUid} в очереди ECM.
     *
     * @param requestId сформированный uuid запроса в ЕСМ
     * @return {@code true}, если запись с указанным {@code requestId} присутствует в {@code v_vux_ecm_queue}
     */
    @Transactional
    @NativeQuery("""
            SELECT EXISTS(
                SELECT 1
                FROM s_grnplm_as_cib_gm_vux.v_vux_ecm_queue
                WHERE request_id = :requestId
            );""")
    boolean existsInEcmQueue(@Param("requestId") String requestId);

    /**
     * Вызывает хранимую процедуру для расчёта метрик ИКД и регистрации обращений от ЦБ.
     * Процедура записывает данные в {@code t_vux_request_data} и {@code t_vux_request},
     * параметры не требуются, результат не сохраняется.
     *
     * @return пустой Optional после успешного выполнения процедуры
     */
    @Transactional(timeoutString = "${config.ikd-calculation-scheduler.timeout:3600}")
    @NativeQuery("""
            SELECT FROM s_grnplm_as_cib_gm_vux.fn_load_request()""")
    Optional<Void> fnLoadRequest();

    /**
     * Метка в теме письма о незаполненном справочнике связей. Это письмо и письмо об ошибках фиксируются
     * в {@code t_vux_mail} функцией {@code fn_flow_set_mail_status} с одинаковым типом {@code ERROR}, другого признака
     * в таблице нет, поэтому письма различаются по теме. Тема письма о незаполненном справочнике должна содержать
     * эту метку.
     */
    String MISSING_LINKS_MAIL_SUBJECT_MARKER = "не заполнен справочник связей";

    /**
     * Проверяет, есть ли по документу зафиксированное письмо об ошибках.
     * <p>
     * В {@code t_vux_mail} пишет только {@code fn_flow_set_mail_status}, которую сервис вызывает после успешной отправки
     * письма. Письма-напоминания пишутся в {@code t_vux_info_email_sent}, запрет писем флагами расписания в таблицу
     * не попадает. Письмо о незаполненном справочнике связей пишется в ту же таблицу, но письмом об ошибках
     * не считается.
     *
     * @param docId id документа ({@code result_doc_id})
     * @return {@code true}, если письмо об ошибках найдено
     */
    default boolean existsErrorMail(Long docId) {
        return existsMailExcludingSubject(docId, MISSING_LINKS_MAIL_SUBJECT_MARKER);
    }

    /**
     * Проверяет, есть ли по документу письмо в {@code t_vux_mail}, тема которого не содержит {@code subjectMarker}.
     * Используется {@code strpos}, а не {@code LIKE}, чтобы метку не нужно было экранировать.
     *
     * @param docId         id документа ({@code result_doc_id})
     * @param subjectMarker метка темы, письма с которой не учитываются
     * @return {@code true}, если такое письмо найдено
     */
    @Transactional
    @NativeQuery("""
            SELECT EXISTS(
                SELECT 1
                FROM s_grnplm_as_cib_gm_vux.t_vux_mail
                WHERE doc_id = :docId
                  AND strpos(coalesce(mail_header, ''), :subjectMarker) = 0
            )""")
    boolean existsMailExcludingSubject(@Param("docId") Long docId, @Param("subjectMarker") String subjectMarker);

    /**
     * Возвращает время последнего письма по документу в {@code t_vux_mail}, тема которого содержит
     * {@code subjectMarker}. Используется для журнала при ожидании справочника связей.
     *
     * @param docId         id документа ({@code result_doc_id})
     * @param subjectMarker метка темы письма
     * @return время в формате {@code YYYY-MM-DD HH24:MI:SS}; пусто, если писем нет
     */
    @Transactional
    @NativeQuery("""
            SELECT to_char(max(created), 'YYYY-MM-DD HH24:MI:SS')
            FROM s_grnplm_as_cib_gm_vux.t_vux_mail
            WHERE doc_id = :docId
              AND strpos(coalesce(mail_header, ''), :subjectMarker) > 0""")
    Optional<String> findLastMailTime(@Param("docId") Long docId, @Param("subjectMarker") String subjectMarker);

    /**
     * Проверяет, было ли по документу письмо в {@code t_vux_mail} с меткой {@code subjectMarker} в теме
     * за последние {@code hours} часов. Время сравнивается на стороне БД, чтобы не зависеть от часов сервиса.
     *
     * @param docId         id документа ({@code result_doc_id})
     * @param subjectMarker метка темы письма
     * @param hours         интервал, часов
     * @return {@code true}, если такое письмо было
     */
    @Transactional
    @NativeQuery("""
            SELECT EXISTS(
                SELECT 1
                FROM s_grnplm_as_cib_gm_vux.t_vux_mail
                WHERE doc_id = :docId
                  AND strpos(coalesce(mail_header, ''), :subjectMarker) > 0
                  AND created > now() - CAST(:hours AS int4) * interval '1 hour'
            )""")
    boolean existsMailSince(@Param("docId") Long docId, @Param("subjectMarker") String subjectMarker,
                            @Param("hours") Integer hours);

    /**
     * Проверяет, сохранён ли статус CUV-проверки документа в {@code t_vux_document_cuv_validation_status}.
     * Функция {@code fn_flow_cuv_set_status} только добавляет строку, поэтому перед сохранением статуса сервис
     * проверяет, не сохранён ли он при прошлой обработке документа.
     *
     * @param docId id документа ({@code result_doc_id})
     * @return {@code true}, если статус уже сохранён
     */
    @Transactional
    @NativeQuery("""
            SELECT EXISTS(
                SELECT 1
                FROM s_grnplm_as_cib_gm_vux.t_vux_document_cuv_validation_status
                WHERE doc_id = :docId
            )""")
    boolean existsCuvValidationStatus(@Param("docId") Long docId);

    /**
     * Загружает ошибки CUV-проверки документа, сохранённые функцией {@code fn_flow_cuv_set_error}.
     * <p>
     * В {@code t_vux_document_cuv_validation_result} три колонки: {@code doc_id}, {@code error_message},
     * {@code error_code}. Даты и id расписания нет, поэтому повторно сохранённые ошибки неотличимы от исходных;
     * дубли убираются через {@code DISTINCT}.
     *
     * @param docId id документа ({@code result_doc_id})
     * @return строки {@code [error_code, error_message]}; пустой список, если ошибок нет
     */
    @Transactional
    @NativeQuery("""
            SELECT DISTINCT error_code, error_message
            FROM s_grnplm_as_cib_gm_vux.t_vux_document_cuv_validation_result
            WHERE doc_id = :docId
            ORDER BY error_code, error_message""")
    List<Object[]> findCuvValidationErrors(@Param("docId") Long docId);

    /**
     * Создаёт запись выгрузки образа документа в ECM в таблице {@code t_vux_document_ecm}.
     * <p>
     * Вызов хранимой процедуры {@code s_grnplm_as_cib_gm_vux.fn_xbrl_create_ecm}
     * (перегрузка {@code (int8, bpchar, text, int4, text, int4)}; {@code xbrl_id} генерируется в БД).
     * Запись затем обрабатывает внешний сервис: формирует CSV, загружает в ECM и проставляет {@code ecm_id}.
     * <p>
     * Все 6 параметров передаются позиционно с явным приведением типов — так однозначно выбирается
     * нужная перегрузка, а {@code p_archive}/{@code p_s3_del} не смещаются на места
     * {@code p_file_name}/{@code p_archive}.
     *
     * @param pDocId     идентификатор документа (result_doc_id записи расписания)
     * @param pImageType тип образа: {@code CONTEXT}, {@code UNIT}, {@code VALUE}
     * @param pArchive   признак архива (0/1)
     * @param pS3Del     признак удаления файла из S3 после загрузки (0/1)
     * @return пустой Optional после успешного выполнения процедуры
     */
    @Transactional
    @NativeQuery("""
            SELECT
            FROM s_grnplm_as_cib_gm_vux.fn_xbrl_create_ecm(
                CAST(:pDocId AS int8),
                CAST(:pImageType AS bpchar),
                CAST(NULL AS text),
                CAST(:pArchive AS int4),
                CAST(NULL AS text),
                CAST(:pS3Del AS int4));""")
    Optional<Void> fnXbrlCreateEcm(@Param("pDocId") Integer pDocId,
                                   @Param("pImageType") String pImageType,
                                   @Param("pArchive") Integer pArchive,
                                   @Param("pS3Del") Integer pS3Del);
}
