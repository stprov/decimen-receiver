package ru.sbrf.gmap.vux.service.checks;

import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvContextDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvValueDto;

import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.List;

/**
 * CUV-проверка 007: у каждого {@code context_id} из value есть описание в context.
 * Выполняется, если есть строки context и value. Идентификаторы в тексте ошибки отсортированы, чтобы текст не менялся при повторной проверке.
 */
@Component
@Order(7)
public class MissingContextDescriptionsRule implements ValidationRule {

    private static final String NUMBER = "007";
    private static final String CHECK_DESCRIPTION = "В values не обнаружены context_id без описания";

    @Override
    public List<ValidationErrorDto> validate(DataContext ctx) {
        if (ctx.contextList().isEmpty() || ctx.valueList().isEmpty()) {
            return List.of();
        }
        Set<String> contextIds = ctx.contextList().stream()
                .map(CuvContextDto::contextId)
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());
        Set<String> missing = ctx.valueList().stream()
                .map(CuvValueDto::contextId)
                .filter(Objects::nonNull)
                .collect(Collectors.toCollection(TreeSet::new));
        missing.removeAll(contextIds);
        if (!missing.isEmpty()) {
            return List.of(CuvErrors.error(ctx, NUMBER, "Обнаружены context_id без описания: %s.".formatted(missing)));
        }
        return List.of();
    }

    @Override
    public String getDescription() {
        return CHECK_DESCRIPTION;
    }

    @Override
    public String getNumber() {
        return NUMBER;
    }
}
