package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.config.FeatureToogleConfig;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolCheckRecordDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.entity.enums.ScheduleStatusEnum;
import ru.sbrf.gmap.vux.mapper.VuxDocumentValidationLogEnityMapper;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;
import ru.sbrf.gmap.vux.service.ValidationDefectsService.ViewDefects;
import ru.sbrf.gmap.vux.service.checks.DataContext;
import ru.sbrf.gmap.vux.service.checks.CuvFormDataLoader;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Стратегия первичной обработки записи расписания, по которой протокол ещё не загружался в ECM
 * ({@code ecm_id} пуст).
 * <p>
 * Маршрут выбирается по режиму проверки {@code check_mode}:
 * <ul>
 *     <li>{@code cuv} при включённом фича-флаге — CUV-проверка данных формы, загруженных
 *     {@link CuvFormDataLoader};</li>
 *     <li>{@code cuv} при выключенном фича-флаге — стандартная проверка; статус CUV-проверки «не проверен»
 *     сохраняется до загрузки протокола и при повторной обработке не дублируется;</li>
 *     <li>{@code xml} — стандартная проверка, так как XML-проверка не реализована;</li>
 *     <li>прочие значения — стандартная проверка по нарушениям, найденным в БД.</li>
 * </ul>
 * После успешной CUV-проверки протокол загружается в ECM и создаются записи на выгрузку CSV-файлов
 * ({@code fn_xbrl_create_ecm}). Задачу СУПЗ создаёт и расписание закрывает {@link FollowUpProcessingStrategy}.
 * Если у расписания уже заполнен {@code supz_task_id} (например, задача СУПЗ отключена флагом {@code U}),
 * выгрузка CSV не запрашивается и расписание закрывается сразу.
 * <p>
 * Если для проверки 10 у формы не задана таблица витрины data или нет связей в справочнике
 * {@code t_adm_data_xbrl_link}, CUV-проверка откладывается до заполнения справочника ({@link MissingLinksService}):
 * расписание остаётся открытым, письмо «справочник не заполнен» уходит не чаще раза в интервал.
 * <p>
 * Отсутствие данных формы считается ошибкой CUV-проверки (проверки {@code _001}–{@code _004}): в ECM загружается
 * протокол с ошибками и отправляется письмо.
 * <p>
 * При технической ошибке возвращается {@link ProcessingResult#PENDING}, и запись обрабатывается повторно
 * в следующем цикле планировщика.
 */
@Service
@Order(1)
@RequiredArgsConstructor
@Slf4j
public class InitialProcessingStrategy implements ScheduleRecordStrategy {

    private static final String CHECK_MODE_XML = "xml";
    /**
     * Фрагмент текста отказа «расписание не найдено». Сейчас {@code fn_flow_update_shedule} отказ не возвращает,
     * проверка оставлена на случай изменения функции.
     */
    private static final String SCHEDULE_NOT_FOUND = "не найден";

    private final FeatureToogleConfig featureToggleConfig;
    private final ValidationDataService validationDataService;
    private final ProtocolBuildingService protocolBuildingService;
    private final PostUploadActionsService postUploadActionsService;
    private final ValidationDefectsService validationDefectsService;
    private final DocumentEcmExportService documentEcmExportService;
    private final CuvFormDataLoader cuvFormDataLoader;
    private final VuxDocumentValidationLogEnityMapper vuxDocumentValidationLogEnityMapper;
    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;
    private final CuvValidationStatusService cuvValidationStatusService;
    private final CuvErrorStorageService cuvErrorStorageService;
    private final MissingLinksService missingLinksService;

    @Override
    public boolean supports(VuxDocumentScheduleViewEntity record) {
        return Objects.isNull(record.getEcmId());
    }

    @Override
    public ProcessingResult process(VuxDocumentScheduleViewEntity record) {
        try {
            String checkMode = record.getCheckMode();

            if (record.isCuvCheckMode()) {
                if (!featureToggleConfig.isCuvValidationEnabled()) {
                    log.info("[ROUTE] Route: scheduleId={}, docId={}, docTypeCode={}, checkMode={}, phase=1, route=standard, " +
                                    "reason=CUV feature toggle is disabled",
                            record.getScheduleId(), record.getResultDocumentId(), record.getDocTypeCode(), checkMode);
                    cuvValidationStatusService.saveNotChecked(record);
                    return processStandardRoute(record);
                }
                log.info("[ROUTE] Route: scheduleId={}, docId={}, docTypeCode={}, checkMode={}, phase=1, route=cuv",
                        record.getScheduleId(), record.getResultDocumentId(), record.getDocTypeCode(), checkMode);
                return processCuvRoute(record);
            }

            if (CHECK_MODE_XML.equals(checkMode)) {
                log.warn("[ROUTE] Route: scheduleId={}, docId={}, docTypeCode={}, checkMode={}, phase=1, route=standard, " +
                                "reason=XML validation is not implemented yet",
                        record.getScheduleId(), record.getResultDocumentId(), record.getDocTypeCode(), checkMode);
                return processStandardRoute(record);
            }

            log.info("[ROUTE] Route: scheduleId={}, docId={}, docTypeCode={}, checkMode={}, phase=1, route=standard",
                    record.getScheduleId(), record.getResultDocumentId(), record.getDocTypeCode(), checkMode);
            return processStandardRoute(record);
        } catch (Exception e) {
            log.error("[ROUTE] Unexpected error in initial processing: scheduleId={}, docId={}. " +
                    "Record is skipped until the next scheduler cycle.", record.getScheduleId(), record.getResultDocumentId(), e);
            return ProcessingResult.PENDING;
        }
    }

    /**
     * Выполняет CUV-проверку: загружает данные формы, применяет правила проверки и сохраняет статус
     * CUV-проверки. Если для проверки 10 не заполнен справочник связей, проверка не выполняется и запись ждёт
     * справочник ({@link MissingLinksService}).
     *
     * @param record запись расписания
     * @return {@link ProcessingResult#PENDING}, если данные формы не загружены; иначе результат обработки
     *         проверки без ошибок или с ошибками
     */
    private ProcessingResult processCuvRoute(VuxDocumentScheduleViewEntity record) {
        Integer docId = record.getResultDocumentId();
        Timestamp checkStart = now();
        DataContext context;
        try {
            context = cuvFormDataLoader.load(record);
        } catch (Exception e) {
            log.error("[CUV] Technical error while loading form data: scheduleId={}, docId={}. " +
                    "Record is skipped until the next scheduler cycle.", record.getScheduleId(), docId, e);
            return ProcessingResult.PENDING;
        }
        if (context == null) {
            log.error("[CUV] Form data loader returned null: scheduleId={}, docId={}, docTypeCode={}. " +
                    "Record is skipped until the next scheduler cycle.", record.getScheduleId(), docId, record.getDocTypeCode());
            return ProcessingResult.PENDING;
        }

        Optional<MissingLinksService.Reason> missingReference = missingLinksService.detect(record, context);
        if (missingReference.isPresent()) {
            return missingLinksService.waitForReference(record, context, missingReference.get());
        }

        List<ValidationErrorDto> validationErrors = validationDataService.validate(context);
        CuvRunResult cuvRunResult = new CuvRunResult(checkStart, now(),
                validationDataService.countExecutedChecks(validationErrors), ValidationDataService.countDeviations(validationErrors));
        log.info("[CUV] Validation completed: scheduleId={}, docId={}, cuvErrors={}, deviations={}, executedChecks={}",
                record.getScheduleId(), docId, validationErrors.size(), cuvRunResult.errorCount(), cuvRunResult.checkCount());

        saveCuvStatus(record, cuvRunResult);

        return validationErrors.isEmpty()
                ? handleCuvFormSuccess(record)
                : handleCuvFormErrors(record, validationErrors);
    }

    /**
     * Обрабатывает CUV-проверку без ошибок.
     * <p>
     * Сначала удаляются результаты предыдущей CUV-проверки с ошибками, если они сохранены. Если стандартная
     * проверка в БД нашла ошибки, в ECM загружается протокол с ошибками и отправляется письмо. Иначе в ECM
     * загружается протокол об успешной проверке и создаются записи на выгрузку CSV-файлов; расписание остаётся
     * открытым до создания задачи СУПЗ.
     *
     * @param record запись расписания
     * @return результат обработки записи
     */
    private ProcessingResult handleCuvFormSuccess(VuxDocumentScheduleViewEntity record) {
        Integer docId = record.getResultDocumentId();
        ViewDefects view = validationDefectsService.loadViewDefects(docId);
        log.info("[CUV] View defects: scheduleId={}, docId={}, viewErrors={}, viewWarnings={}",
                record.getScheduleId(), docId, view.errors().size(), view.warnings().size());

        try {
            if (!resetPreviousCuvErrors(record, !view.hasErrors())) {
                return ProcessingResult.PENDING;
            }
        } catch (Exception e) {
            log.error("[CUV] Failed to reset results of the previous CUV check: scheduleId={}, docId={}. " +
                    "Record is skipped until the next scheduler cycle.", record.getScheduleId(), docId, e);
            return ProcessingResult.PENDING;
        }

        if (view.hasErrors()) {
            log.warn("[CUV] Standard validation errors found: scheduleId={}, docId={}, count={}. CSV export is not requested.",
                    record.getScheduleId(), docId, view.errors().size());
            ProtocolModelDto errorProtocol = protocolBuildingService.createProtocolModelDto(
                    view.errors(), view.warnings(), view.checks(), record);
            return uploadProtocolAndSendErrorMail(record, errorProtocol);
        }

        List<ProtocolCheckRecordDto> checks = Stream.concat(
                view.checks().stream().map(vuxDocumentValidationLogEnityMapper::toProtocolCheckRecordDto),
                validationDataService.getChecks(Collections.emptyList()).stream()
        ).toList();
        ProtocolModelDto successProtocol = protocolBuildingService.createCuvSuccessProtocol(record, view.warnings(), checks);

        if (postUploadActionsService.uploadProtocol(record, successProtocol).isEmpty()) {
            return ProcessingResult.PENDING;
        }

        if (record.isSupzTaskCreatedOrDisabled()) {
            log.info("[CSV-EXPORT] CSV export and SUPZ task are skipped: supz_task_id is already set ({}), " +
                    "scheduleId={}, docId={}. Processing is completed in phase 1, schedule will be resolved.",
                    record.getSupzTaskId(), record.getScheduleId(), docId);
            return ProcessingResult.COMPLETED;
        }

        boolean allRequested = documentEcmExportService.requestCuvCsvExport(record.getScheduleId(), docId);
        log.info("[CUV] Phase 1 completed: scheduleId={}, docId={}, csvExportRequested={}. " +
                        "Waiting for CSV upload by the external service, schedule stays open.",
                record.getScheduleId(), docId, allRequested ? "all" : "partially (missing records will be restored in phase 2)");
        return ProcessingResult.PENDING;
    }

    /**
     * Удаляет результаты предыдущей CUV-проверки с ошибками, если текущая CUV-проверка ошибок не нашла.
     * <p>
     * Такие результаты остаются, если предыдущая обработка прервалась после сохранения ошибок CUV, например при сбое
     * загрузки протокола или отправки письма. Если стандартная проверка ошибок не нашла, а расписание в статусе
     * {@link ScheduleStatusEnum#CHECKED_WITH_ERRORS}, этот статус был поставлен из-за ошибок CUV, и расписанию
     * возвращается статус {@link ScheduleStatusEnum#VERIFIED_SUCCESSFULLY}; иначе при закрытии расписания будет
     * создана лишняя повторная проверка. Затем сохранённые ошибки CUV удаляются, чтобы
     * {@link FollowUpProcessingStrategy} не приняла их за ошибки текущей проверки. Статус CUV-проверки не меняется.
     * <p>
     * Статус расписания исправляется до удаления ошибок: если удаление не выполнится, в следующем цикле ошибки
     * будут найдены снова, а статус уже будет верным. Функция удаления вызывается, только если ошибки сохранены.
     *
     * @param record       запись расписания
     * @param noViewErrors {@code true}, если стандартная проверка в БД ошибок не нашла
     * @return {@code false}, если {@code fn_flow_update_shedule} отказала в смене статуса; запись остаётся открытой
     */
    private boolean resetPreviousCuvErrors(VuxDocumentScheduleViewEntity record, boolean noViewErrors) {
        if (!cuvErrorStorageService.hasErrors(record)) {
            return true;
        }
        if (noViewErrors && record.getScheduleStatus() == ScheduleStatusEnum.CHECKED_WITH_ERRORS
                && !updateScheduleStatus(record, ScheduleStatusEnum.VERIFIED_SUCCESSFULLY,
                "previous CUV errors are not confirmed by the current check")) {
            return false;
        }
        cuvErrorStorageService.clearErrors(record);
        return true;
    }

    /**
     * Обрабатывает CUV-проверку с ошибками: сохраняет ошибки вместо прежних ошибок документа, ставит расписанию
     * статус {@link ScheduleStatusEnum#CHECKED_WITH_ERRORS}, загружает в ECM протокол с ошибками CUV-проверки
     * и стандартной проверки и отправляет письмо.
     *
     * @param record           запись расписания
     * @param validationErrors ошибки CUV-проверки
     * @return результат обработки записи
     */
    private ProcessingResult handleCuvFormErrors(VuxDocumentScheduleViewEntity record, List<ValidationErrorDto> validationErrors) {
        Integer docId = record.getResultDocumentId();
        cuvErrorStorageService.replaceErrors(record, validationErrors);

        if (!markScheduleCheckedWithErrors(record)) {
            return ProcessingResult.PENDING;
        }

        ViewDefects view = validationDefectsService.loadViewDefects(docId);

        ProtocolModelDto protocol = protocolBuildingService.createCuvErrorProtocol(
                record, view.errors(), view.warnings(), view.checks(), validationErrors);
        log.info("[CUV] Error protocol created: scheduleId={}, docId={}, cuvErrors={}, viewErrors={}",
                record.getScheduleId(), docId, validationErrors.size(), view.errors().size());
        return uploadProtocolAndSendErrorMail(record, protocol);
    }

    /**
     * Ставит расписанию статус {@link ScheduleStatusEnum#CHECKED_WITH_ERRORS}, если стандартная проверка в БД
     * не поставила его раньше.
     *
     * @param record запись расписания
     * @return {@code false}, если {@code fn_flow_update_shedule} отказала в смене статуса; запись остаётся открытой
     */
    private boolean markScheduleCheckedWithErrors(VuxDocumentScheduleViewEntity record) {
        if (record.getScheduleStatus() == ScheduleStatusEnum.CHECKED_WITH_ERRORS) {
            return true;
        }
        return updateScheduleStatus(record, ScheduleStatusEnum.CHECKED_WITH_ERRORS, "CUV errors found");
    }

    /**
     * Меняет статус расписания функцией {@code fn_flow_update_shedule}.
     * <p>
     * Функция обновляет {@code shedule_status} по {@code shedule_id} без проверок и возвращает служебный текст
     * журнала БД ({@code fn_log_end}); отказа она не возвращает. Если текст всё же содержит «не найден»
     * (на случай изменения функции), запись остаётся открытой и обрабатывается повторно в следующем цикле:
     * без нужного статуса {@code fn_flow_resolve_shedule} при закрытии расписания неверно определит, нужна ли
     * повторная проверка. Исключения БД передаются вызывающему методу.
     *
     * @param record запись расписания
     * @param target устанавливаемый статус
     * @param reason причина смены статуса для журнала
     * @return {@code true}, если статус установлен
     */
    private boolean updateScheduleStatus(VuxDocumentScheduleViewEntity record, ScheduleStatusEnum target, String reason) {
        int status = target.getCode();
        String result = vuxDocumentValidationResultViewRepository.flowUpdateSheduleStatus(record.getScheduleId(), status)
                .orElse(null);
        if (result != null && result.toLowerCase(Locale.ROOT).contains(SCHEDULE_NOT_FOUND)) {
            log.error("[CUV] Schedule status is NOT set to {}: scheduleId={}, docId={}, previousStatus={}, reason={}, " +
                            "result={}. Record is skipped until the next scheduler cycle.",
                    status, record.getScheduleId(), record.getResultDocumentId(), record.getScheduleStatus(), reason, result);
            return false;
        }
        log.info("[CUV] Schedule status set to {}: scheduleId={}, docId={}, previousStatus={}, reason={}, result={}",
                status, record.getScheduleId(), record.getResultDocumentId(), record.getScheduleStatus(), reason, result);
        return true;
    }

    /**
     * Сохраняет итог CUV-проверки функцией {@code fn_flow_cuv_set_status}. При повторной обработке документа
     * после технического сбоя статус не дублируется (см. {@link CuvValidationStatusService}).
     *
     * @param record       запись расписания
     * @param cuvRunResult итог выполненной проверки
     */
    private void saveCuvStatus(VuxDocumentScheduleViewEntity record, CuvRunResult cuvRunResult) {
        cuvValidationStatusService.saveChecked(record, cuvRunResult.checkCount(), cuvRunResult.errorCount(),
                cuvRunResult.checkStart(), cuvRunResult.checkEnd());
    }

    private static Timestamp now() {
        return new Timestamp(System.currentTimeMillis());
    }

    /**
     * Итог выполненной CUV-проверки: время начала и окончания, число выполненных проверок и число расхождений
     * (строка сводки проверки 10 даёт число расхождений по показателю).
     */
    private record CuvRunResult(Timestamp checkStart, Timestamp checkEnd, int checkCount, int errorCount) {
    }

    /**
     * Выполняет стандартную проверку по нарушениям, найденным в БД: загружает протокол в ECM, затем отправляет
     * письмо об ошибках или создаёт задачу СУПЗ.
     *
     * @param record запись расписания
     * @return {@link ProcessingResult#PENDING}, если протокол не загружен; иначе результат действий после загрузки
     */
    private ProcessingResult processStandardRoute(VuxDocumentScheduleViewEntity record) {
        ViewDefects view = validationDefectsService.loadViewDefects(record.getResultDocumentId());
        ProtocolModelDto protocolModelDto = protocolBuildingService.createProtocolModelDto(
                view.errors(), view.warnings(), view.checks(), record);

        Optional<String> protocolEcmId = postUploadActionsService.uploadProtocol(record, protocolModelDto);
        if (protocolEcmId.isEmpty()) {
            return ProcessingResult.PENDING;
        }
        return ProcessingResult.of(
                postUploadActionsService.handlePostUploadActions(record, protocolModelDto, List.of(protocolEcmId.get())));
    }

    /**
     * Загружает протокол с ошибками в ECM и отправляет письмо об ошибках.
     *
     * @param record   запись расписания
     * @param protocol протокол с ошибками
     * @return {@link ProcessingResult#PENDING}, если протокол не загружен или письмо не отправлено
     */
    private ProcessingResult uploadProtocolAndSendErrorMail(VuxDocumentScheduleViewEntity record, ProtocolModelDto protocol) {
        if (postUploadActionsService.uploadProtocol(record, protocol).isEmpty()) {
            return ProcessingResult.PENDING;
        }
        return ProcessingResult.of(postUploadActionsService.sendErrorMail(record, protocol));
    }

}
