package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.config.FeatureToogleConfig;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.service.ValidationDefectsService.ViewDefects;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Стратегия завершения обработки записи расписания, по которой протокол уже загружен в ECM
 * ({@code ecm_id} содержит id протокола).
 * <p>
 * Запись обрабатывается здесь в следующих циклах после {@link InitialProcessingStrategy}, если первичная
 * обработка не завершилась: ожидается выгрузка CSV-файлов или после загрузки протокола произошёл сбой.
 * Записи с меткой {@code ecm_id = '-1'} обрабатывает {@link EcmDisabledProcessingStrategy}.
 * <p>
 * Маршрут:
 * <ul>
 *     <li>{@code check_mode = cuv} при включённом фича-флаге — завершение CUV-маршрута: документ с ошибками
 *     завершается письмом об ошибках; иначе проверяется выгрузка CSV-файлов в {@code t_vux_document_ecm},
 *     отсутствующие записи на выгрузку создаются заново (отклонённые записи с {@code disabled = 1} не пересоздаются),
 *     после загрузки всех CSV-файлов создаётся задача СУПЗ с CSV-файлами и протоколом и расписание закрывается;</li>
 *     <li>иначе — стандартная обработка: протокол строится заново по нарушениям из БД, затем отправляется письмо
 *     об ошибках или создаётся задача СУПЗ.</li>
 * </ul>
 */
@Service
@Order(3)
@RequiredArgsConstructor
@Slf4j
public class FollowUpProcessingStrategy implements ScheduleRecordStrategy {

    private final FeatureToogleConfig featureToggleConfig;
    private final ProtocolBuildingService protocolBuildingService;
    private final ValidationDefectsService validationDefectsService;
    private final PostUploadActionsService postUploadActionsService;
    private final DocumentEcmExportService documentEcmExportService;

    @Override
    public boolean supports(VuxDocumentScheduleViewEntity record) {
        return Objects.nonNull(record.getEcmId()) && !record.isEcmUploadDisabled();
    }

    @Override
    public ProcessingResult process(VuxDocumentScheduleViewEntity record) {
        try {
            if (featureToggleConfig.isCuvApplicable(record)) {
                log.info("[ROUTE] Route: scheduleId={}, docId={}, docTypeCode={}, checkMode={}, phase=2, route=cuv",
                        record.getScheduleId(), record.getResultDocumentId(), record.getDocTypeCode(), record.getCheckMode());
                return processCuvPhase2(record);
            }
            log.info("[ROUTE] Route: scheduleId={}, docId={}, docTypeCode={}, checkMode={}, phase=legacy",
                    record.getScheduleId(), record.getResultDocumentId(), record.getDocTypeCode(), record.getCheckMode());
            return processLegacy(record);
        } catch (Exception e) {
            log.error("[ROUTE] Unexpected error in follow-up processing: scheduleId={}, docId={}. " +
                    "Record is skipped until the next scheduler cycle.", record.getScheduleId(), record.getResultDocumentId(), e);
            return ProcessingResult.PENDING;
        }
    }

    /**
     * Завершает CUV-маршрут. Шаги выполняются по порядку:
     * <ol>
     *     <li>если стандартная или CUV-проверка нашла ошибки, документ завершается письмом об ошибках без выгрузки CSV
     *     и задачи СУПЗ ({@link #completeDocumentWithErrors}). Такой документ попадает сюда, если протокол загружен,
     *     а письмо не отправлено или его отправка не зафиксирована;</li>
     *     <li>если задача СУПЗ уже создана или отключена флагом {@code U}, обработка завершена. Условие проверяется
     *     после ошибок, чтобы документ с ошибками получил письмо и при флаге {@code U};</li>
     *     <li>если не все CSV-файлы загружены в ECM, расписание остаётся открытым
     *     ({@link DocumentEcmExportService#evaluateCuvCsvExport});</li>
     *     <li>если все CSV-файлы загружены, создаётся задача СУПЗ; к ней прикладываются CSV-файлы (context, unit, value),
     *     затем протокол.</li>
     * </ol>
     *
     * @param record запись расписания
     * @return {@link ProcessingResult#COMPLETED}, если обработка завершена и расписание можно закрыть
     */
    private ProcessingResult processCuvPhase2(VuxDocumentScheduleViewEntity record) {
        Integer docId = record.getResultDocumentId();

        ViewDefects view = validationDefectsService.loadViewDefects(docId);
        List<ValidationErrorDto> cuvErrors = validationDefectsService.getCuvErrors(docId, record.getDocTypeCode());
        if (view.hasErrors() || !cuvErrors.isEmpty()) {
            return completeDocumentWithErrors(record, view, cuvErrors);
        }

        if (record.isSupzTaskCreatedOrDisabled()) {
            log.info("[CUV] Phase 2: SUPZ task is already created or disabled by schedule flag 'U' (supz_task_id={}): " +
                    "scheduleId={}, docId={}. Processing is completed, schedule will be resolved.", record.getSupzTaskId(), record.getScheduleId(), docId);
            return ProcessingResult.COMPLETED;
        }

        DocumentEcmExportService.ExportState state = documentEcmExportService.evaluateCuvCsvExport(record.getScheduleId(), docId);
        if (!state.ready()) {
            log.info("[CUV] Phase 2: waiting for CSV upload by the external service: scheduleId={}, docId={}. Schedule stays open.",
                    record.getScheduleId(), docId);
            return ProcessingResult.PENDING;
        }

        List<String> ecmIds = new ArrayList<>(state.ecmIds());
        ecmIds.add(record.getEcmId());
        long warningsCount = record.getWarningCount() == null ? 0 : record.getWarningCount();

        boolean created = postUploadActionsService.createSupzTask(record, ecmIds, postUploadActionsService.protocolResultText(warningsCount));
        if (created) {
            log.info("[CUV] Phase 2 completed: scheduleId={}, docId={}, ecmIds={}. Schedule will be resolved.",
                    record.getScheduleId(), docId, ecmIds);
        }
        return ProcessingResult.of(created);
    }

    /**
     * Завершает обработку документа с ошибками. Протокол с ошибками уже загружен в ECM и повторно не загружается.
     * <ul>
     *     <li>если письмо по документу уже есть в {@code t_vux_mail}, оно отправлено в прошлом цикле, а сбой произошёл
     *     позже, — расписание закрывается;</li>
     *     <li>иначе письмо формируется заново по ошибкам стандартной проверки и сохранённым ошибкам CUV и отправляется;
     *     при сбое отправки расписание остаётся открытым до следующего цикла.</li>
     * </ul>
     * Состав протокола совпадает с протоколом первичной обработки: результаты CUV-проверок включаются в него,
     * только если есть ошибки CUV.
     *
     * @param record    запись расписания
     * @param view      нарушения стандартной проверки
     * @param cuvErrors сохранённые ошибки CUV-проверки
     * @return {@link ProcessingResult#COMPLETED}, если письмо отправлено ранее или в текущем цикле
     */
    private ProcessingResult completeDocumentWithErrors(VuxDocumentScheduleViewEntity record, ViewDefects view,
                                                        List<ValidationErrorDto> cuvErrors) {
        Integer docId = record.getResultDocumentId();
        if (postUploadActionsService.isErrorMailSent(record)) {
            log.info("[CUV] Phase 2: document has validation errors, error mail is already sent (found in t_vux_mail): " +
                            "scheduleId={}, docId={}, viewErrors={}, cuvErrors={}. Processing is completed, schedule will be resolved.",
                    record.getScheduleId(), docId, view.errors().size(), cuvErrors.size());
            return ProcessingResult.COMPLETED;
        }

        log.warn("[CUV] Phase 2: document has validation errors and the error mail has not been sent yet: " +
                        "scheduleId={}, docId={}, viewErrors={}, cuvErrors={}. Sending the error mail; CSV export and SUPZ task are skipped.",
                record.getScheduleId(), docId, view.errors().size(), cuvErrors.size());
        ProtocolModelDto protocol = cuvErrors.isEmpty()
                ? protocolBuildingService.createProtocolModelDto(view.errors(), view.warnings(), view.checks(), record)
                : protocolBuildingService.createCuvErrorProtocol(record, view.errors(), view.warnings(), view.checks(), cuvErrors);
        return ProcessingResult.of(postUploadActionsService.sendErrorMail(record, protocol));
    }

    /**
     * Выполняет стандартную обработку: строит протокол заново по нарушениям из БД, затем отправляет письмо
     * об ошибках или создаёт задачу СУПЗ. Протокол в ECM повторно не загружается, используется уже присвоенный
     * {@code ecm_id}.
     *
     * @param record запись расписания
     * @return {@link ProcessingResult#COMPLETED}, если письмо отправлено или задача СУПЗ создана
     */
    private ProcessingResult processLegacy(VuxDocumentScheduleViewEntity record) {
        ViewDefects view = validationDefectsService.loadViewDefects(record.getResultDocumentId());
        ProtocolModelDto protocolModelDto = protocolBuildingService.createProtocolModelDto(
                view.errors(), view.warnings(), view.checks(), record);

        return ProcessingResult.of(
                postUploadActionsService.handlePostUploadActions(record, protocolModelDto, List.of(record.getEcmId())));
    }
}
