package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.entity.enums.CuvValidationStatusEnum;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.sql.Timestamp;

/**
 * Сохраняет итоговый статус CUV-проверки функцией {@code fn_flow_cuv_set_status}.
 * <p>
 * Статус сохраняется сразу после проверки или при выборе стандартного маршрута, до загрузки протокола и отправки
 * письма. Функция только добавляет строку, поэтому статус сохраняется по документу один раз: при повторной
 * обработке после технического сбоя он уже есть и не дублируется. Сбой сохранения статуса не прерывает
 * обработку документа: статус носит информационный характер, в журнал пишется ERROR.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CuvValidationStatusService {

    /**
     * Текст, которым {@code fn_flow_cuv_set_status} сообщает об отказе.
     */
    private static final String SCHEDULE_NOT_FOUND = "расписание не найдено";

    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;

    /**
     * Сохраняет статус выполненной CUV-проверки: «проверено без ошибок» или «проверено с ошибками».
     *
     * @param record     запись расписания
     * @param checkCount количество выполненных проверок
     * @param errorCount количество ошибок
     * @param checkStart время начала проверки
     * @param checkEnd   время окончания проверки
     */
    public void saveChecked(VuxDocumentScheduleViewEntity record, int checkCount, int errorCount,
                            Timestamp checkStart, Timestamp checkEnd) {
        CuvValidationStatusEnum status = errorCount == 0
                ? CuvValidationStatusEnum.CHECKED_WITHOUT_ERRORS
                : CuvValidationStatusEnum.CHECKED_WITH_ERRORS;
        save(record, status, checkCount, errorCount, checkStart, checkEnd);
    }

    /**
     * Сохраняет статус «не проверено», когда CUV-проверка выключена фича-флагом.
     *
     * @param record запись расписания
     */
    public void saveNotChecked(VuxDocumentScheduleViewEntity record) {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        save(record, CuvValidationStatusEnum.NOT_CHECKED, 0, 0, now, now);
    }

    /**
     * Сохраняет статус, если по документу он ещё не сохранён. Исключения не передаются вызывающему методу.
     */
    private void save(VuxDocumentScheduleViewEntity record, CuvValidationStatusEnum status, int checkCount,
                      int errorCount, Timestamp checkStart, Timestamp checkEnd) {
        Integer docId = record.getResultDocumentId();
        try {
            if (vuxDocumentValidationResultViewRepository.existsCuvValidationStatus(docId.longValue())) {
                log.info("[CUV] CUV validation status is already saved for the document, skipped: scheduleId={}, docId={}, status={}",
                        record.getScheduleId(), docId, status);
                return;
            }
            String result = vuxDocumentValidationResultViewRepository.flowCuvSetStatus(
                    docId.longValue(), status.getCode(), checkCount, (long) errorCount, checkStart, checkEnd).orElse(null);
            if (result != null && result.toLowerCase().contains(SCHEDULE_NOT_FOUND)) {
                log.warn("[CUV] CUV validation status is not saved: scheduleId={}, docId={}, status={}, result={}",
                        record.getScheduleId(), docId, status, result);
                return;
            }
            log.info("[CUV] CUV validation status saved: scheduleId={}, docId={}, status={}({}), checkCount={}, errorCount={}",
                    record.getScheduleId(), docId, status, status.getCode(), checkCount, errorCount);
        } catch (Exception e) {
            log.error("[CUV] Failed to save CUV validation status: scheduleId={}, docId={}, status={}. Processing continues.",
                    record.getScheduleId(), docId, status, e);
        }
    }
}
