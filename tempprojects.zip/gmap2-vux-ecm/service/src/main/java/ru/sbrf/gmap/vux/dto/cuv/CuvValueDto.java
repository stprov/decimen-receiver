package ru.sbrf.gmap.vux.dto.cuv;

import lombok.Builder;

/**
 * Строка таблицы value отчётной формы (значение показателя). Общий DTO для всех форм.
 *
 * @param elementName   имя показателя XBRL
 * @param value         значение
 * @param nil           признак пустого значения ({@code "true"})
 * @param contextId     контекст значения
 * @param unitId        единица измерения (у нечисловых значений может быть пустой)
 * @param decimals      точность
 * @param taxonomy      версия таксономии
 * @param workflowRunId номер загрузки отчёта
 */
@Builder
public record CuvValueDto(
        String elementName,
        String value,
        String nil,
        String contextId,
        String unitId,
        String decimals,
        String taxonomy,
        Long workflowRunId
) {
}
