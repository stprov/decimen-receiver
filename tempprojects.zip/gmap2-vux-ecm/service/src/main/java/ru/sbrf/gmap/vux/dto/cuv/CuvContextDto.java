package ru.sbrf.gmap.vux.dto.cuv;

import lombok.Builder;

/**
 * Строка таблицы context отчётной формы (XBRL-контекст). Структура таблицы context у всех форм одинаковая,
 * поэтому DTO общий.
 *
 * @param contextId     идентификатор контекста
 * @param scenario      XML с осями контекста ({@code typedMember}, {@code explicitMember}) — для проверки 10
 * @param taxonomy      версия таксономии
 * @param workflowRunId номер загрузки отчёта
 */
@Builder
public record CuvContextDto(
        String contextId,
        String scenario,
        String taxonomy,
        Long workflowRunId
) {
}
