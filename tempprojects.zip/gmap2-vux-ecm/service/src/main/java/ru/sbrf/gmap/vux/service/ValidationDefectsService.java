package ru.sbrf.gmap.vux.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationLogEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationResultViewEntity;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationLogRepository;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;
import ru.sbrf.gmap.vux.service.checks.CuvErrors;

import java.util.List;

/**
 * Читает нарушения документа из view {@code v_vux_document_validation_result} и журнал проверок документа
 * и разделяет нарушения на ошибки и предупреждения. Используется всеми стратегиями обработки.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ValidationDefectsService {

    /**
     * Максимальное количество ошибок на документ в выборке.
     */
    @Value("${config.defects-limits.error-set:30}")
    private Integer errorSet;

    /**
     * Максимальное количество нарушений всех типов на документ в выборке.
     */
    @Value("${config.defects-limits.total-set:200}")
    private Integer totalSet;

    private final VuxDocumentValidationLogRepository vuxDocumentValidationLogRepository;
    private final VuxDocumentValidationResultViewRepository vuxDocumentValidationResultViewRepository;

    /**
     * Загружает нарушения и проверки документа, по которым строится протокол.
     * <p>
     * Нарушения читаются из view с ограничением выборки ({@code errorSet} на правило, {@code totalSet} всего)
     * и делятся на ошибки ({@link RuleTypeEnum#E}) и предупреждения ({@link RuleTypeEnum#W}). Проверки берутся
     * из журнала проверок документа и выводятся в разделе протокола «Проверки».
     *
     * @param docId id документа ({@code result_doc_id})
     * @return нарушения и проверки документа
     */
    public ViewDefects loadViewDefects(Integer docId) {
        List<VuxDocumentValidationResultViewEntity> defects =
                vuxDocumentValidationResultViewRepository.findByDocIdWithRnLimit(docId, errorSet, totalSet);
        ViewDefects viewDefects = new ViewDefects(
                filterByRuleType(defects, RuleTypeEnum.E),
                filterByRuleType(defects, RuleTypeEnum.W),
                vuxDocumentValidationLogRepository.findAllByDocIdOrderByErrorCountDesc(docId));
        log.debug("View defects loaded: docId={}, errors={}, warnings={}, checks={}",
                docId, viewDefects.errors().size(), viewDefects.warnings().size(), viewDefects.checks().size());
        return viewDefects;
    }

    /**
     * Загружает ошибки CUV-проверки документа, сохранённые функцией {@code fn_flow_cuv_set_error}.
     * Во view {@code v_vux_document_validation_result} этих ошибок нет, поэтому они читаются из таблицы напрямую.
     * <p>
     * Заголовок ошибки в таблице не хранится и подставляется по коду формы ({@link CuvErrors#title}); число расхождений
     * строки сводки проверки 10 читается из текста ({@link CuvErrors#deviationCount}).
     *
     * @param docId    id документа
     * @param formCode код формы документа ({@code doc_type_code})
     * @return ошибки CUV-проверки
     */
    public List<ValidationErrorDto> getCuvErrors(Integer docId, String formCode) {
        return vuxDocumentValidationResultViewRepository.findCuvValidationErrors(docId.longValue()).stream()
                .map(row -> new ValidationErrorDto(CuvErrors.title(formCode), (String) row[0], (String) row[1],
                        CuvErrors.deviationCount((String) row[1])))
                .toList();
    }

    private static List<VuxDocumentValidationResultViewEntity> filterByRuleType(
            List<VuxDocumentValidationResultViewEntity> defects, RuleTypeEnum ruleType) {
        return defects.stream().filter(v -> v.getRuleType() == ruleType).toList();
    }

    /**
     * Нарушения и проверки документа из БД.
     *
     * @param errors   ошибки из view ({@code rule_type = 'E'})
     * @param warnings предупреждения из view ({@code rule_type = 'W'})
     * @param checks   логи проверок документа
     */
    public record ViewDefects(List<VuxDocumentValidationResultViewEntity> errors,
                              List<VuxDocumentValidationResultViewEntity> warnings,
                              List<VuxDocumentValidationLogEntity> checks) {

        /**
         * Проверяет, есть ли ошибки стандартной проверки.
         *
         * @return {@code true}, если список ошибок не пуст
         */
        public boolean hasErrors() {
            return !errors.isEmpty();
        }
    }
}
