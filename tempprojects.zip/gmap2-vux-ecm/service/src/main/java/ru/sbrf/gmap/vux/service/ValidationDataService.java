package ru.sbrf.gmap.vux.service;

import org.springframework.stereotype.Service;
import ru.sbrf.gmap.vux.dto.templates.ProtocolCheckRecordDto;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;
import ru.sbrf.gmap.vux.service.checks.DataContext;
import ru.sbrf.gmap.vux.service.checks.ValidationRule;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;

import java.util.ArrayList;
import java.util.List;

/**
 * Выполняет CUV-проверку данных формы XBRL по зарегистрированным правилам {@link ValidationRule}.
 * <p>
 * Правила общие для всех форм: ошибка относится к правилу по номеру проверки в конце кода
 * ({@link ValidationRule#matches}). Правила выполняются по шагам ({@link ValidationRule#getStage()}): внутри шага
 * выполняются все правила, но если на шаге найдены ошибки, следующие шаги не выполняются.
 */
@Service
public class ValidationDataService {

    private static final String NOT_CHECKED = "Не проверялось";

    private final List<ValidationRule> rules;

    public ValidationDataService(List<ValidationRule> rules) {
        this.rules = rules;
    }

    /**
     * Проверяет контекст по всем включённым правилам. Правила перебираются в порядке {@code @Order},
     * номера шагов идут по возрастанию.
     *
     * @param context контекст проверки с данными формы
     * @return ошибки проверки; пустой список, если ошибок нет; никогда не {@code null}
     */
    public List<ValidationErrorDto> validate(DataContext context) {
        List<ValidationErrorDto> errors = new ArrayList<>();
        Integer currentStage = null;
        boolean stageHasErrors = false;
        for (ValidationRule rule : rules) {
            if (!rule.isEnabled()) {
                continue;
            }
            int stage = rule.getStage();
            if (currentStage == null || stage != currentStage) {
                if (stageHasErrors) {
                    break;
                }
                currentStage = stage;
            }
            List<ValidationErrorDto> ruleErrors = rule.validate(context);
            if (ruleErrors != null && !ruleErrors.isEmpty()) {
                errors.addAll(ruleErrors);
                stageHasErrors = true;
            }
        }
        return errors;
    }

    /**
     * Подсчитывает выполненные проверки: проверки шагов после шага с ошибками и выключенные правила не учитываются.
     *
     * @param errors ошибки проверки
     * @return количество выполненных проверок
     */
    public int countExecutedChecks(List<ValidationErrorDto> errors) {
        return (int) getChecks(errors).stream()
                .filter(check -> !NOT_CHECKED.equals(check.getCheckResult()))
                .count();
    }

    /**
     * Формирует строки проверок для протокола. Для выключенных правил и правил шагов после шага с ошибками
     * результат — «Не проверялось». Число отклонений — сумма расхождений по ошибкам правила: строка сводки
     * проверки 10 даёт число расхождений по показателю, остальные ошибки — по одному. Все CUV-проверки имеют тип
     * {@link RuleTypeEnum#E} и учитываются в итоге «Показано N из M» протокола.
     *
     * @param errors ошибки проверки
     * @return строки проверок в порядке правил
     */
    public List<ProtocolCheckRecordDto> getChecks(List<ValidationErrorDto> errors) {
        int firstStageWithErrors = rules.stream()
                .filter(rule -> errors.stream().anyMatch(e -> rule.matches(e.errorCode())))
                .mapToInt(ValidationRule::getStage)
                .min()
                .orElse(Integer.MAX_VALUE);
        return rules.stream()
                .map(rule -> {
                    long errorCount = errors.stream()
                            .filter(e -> rule.matches(e.errorCode()))
                            .mapToLong(ValidationErrorDto::deviationCount)
                            .sum();
                    String result;
                    if (!rule.isEnabled() || rule.getStage() > firstStageWithErrors) {
                        result = NOT_CHECKED;
                    } else {
                        result = errorCount == 0 ? "Не выявлено" : "Выявлено";
                    }
                    return ProtocolCheckRecordDto.builder()
                            .checkType(rule.getDescription())
                            .checkResult(result)
                            .countingDeviation(String.valueOf(errorCount))
                            .ruleType(RuleTypeEnum.E)
                            .build();
                })
                .toList();
    }

    /**
     * Подсчитывает расхождения: строка сводки проверки 10 даёт число расхождений по показателю,
     * остальные ошибки — по одному.
     *
     * @param errors ошибки проверки
     * @return общее число расхождений
     */
    public static int countDeviations(List<ValidationErrorDto> errors) {
        return errors.stream().mapToInt(ValidationErrorDto::deviationCount).sum();
    }
}
