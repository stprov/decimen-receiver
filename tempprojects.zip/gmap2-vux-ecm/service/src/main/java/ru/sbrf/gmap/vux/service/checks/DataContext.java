package ru.sbrf.gmap.vux.service.checks;

import ru.sbrf.gmap.vux.dto.cuv.CuvContextDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvLinkDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvUnitDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvValueDto;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Данные отчётной формы для CUV-проверки. Структура общая для всех форм; контекст строит
 * {@link CuvFormDataLoader} по именам таблиц формы из view расписания.
 *
 * @param docId          id проверяемого документа ({@code result_doc_id})
 * @param formCode       код формы ({@code doc_type_code}, например {@code 0420415.1.3}) для кодов и заголовков ошибок
 * @param workflowRunId  номер загрузки отчёта из view расписания; {@code null}, если не заполнен (ошибка {@code _001})
 * @param contextList    строки context
 * @param unitList       строки unit
 * @param valueList      строки value
 * @param dataRows       строки витрины data в виде «колонка → значение» для проверки 10
 * @param dataTaxonomies версии таксономии из колонки {@code xbrlvers} витрины data, если она есть, для проверки 9
 * @param links          связи колонок витрины data с показателями XBRL ({@code t_adm_data_xbrl_link}) для формы,
 *                       таблицы data и таксономии отчёта; пусто, если справочник не заполнен или не читался
 * @param enumCodes      перекодировка перечислений: {@code enum_id} → (текст значения витрины → код элемента)
 */
public record DataContext(
        long docId,
        String formCode,
        Long workflowRunId,
        List<CuvContextDto> contextList,
        List<CuvUnitDto> unitList,
        List<CuvValueDto> valueList,
        List<Map<String, Object>> dataRows,
        Set<String> dataTaxonomies,
        List<CuvLinkDto> links,
        Map<String, Map<String, String>> enumCodes
) {

    /**
     * Заменяет отсутствующие списки пустыми.
     */
    public DataContext {
        contextList = contextList == null ? List.of() : contextList;
        unitList = unitList == null ? List.of() : unitList;
        valueList = valueList == null ? List.of() : valueList;
        dataRows = dataRows == null ? List.of() : dataRows;
        dataTaxonomies = dataTaxonomies == null ? Set.of() : dataTaxonomies;
        links = links == null ? List.of() : links;
        enumCodes = enumCodes == null ? Map.of() : enumCodes;
    }

    /**
     * Создаёт контекст без справочника связей.
     *
     * @param docId          id документа
     * @param formCode       код формы
     * @param workflowRunId  номер загрузки отчёта
     * @param contextList    строки context
     * @param unitList       строки unit
     * @param valueList      строки value
     * @param dataRows       строки витрины data
     * @param dataTaxonomies версии таксономии из витрины data
     */
    public DataContext(long docId, String formCode, Long workflowRunId, List<CuvContextDto> contextList,
                       List<CuvUnitDto> unitList, List<CuvValueDto> valueList, List<Map<String, Object>> dataRows,
                       Set<String> dataTaxonomies) {
        this(docId, formCode, workflowRunId, contextList, unitList, valueList, dataRows, dataTaxonomies, List.of(), Map.of());
    }

    /**
     * Создаёт контекст документа без данных формы; правила 1–4 выдадут по нему ошибки {@code _001}–{@code _004}.
     *
     * @param docId         id документа
     * @param formCode      код формы
     * @param workflowRunId номер загрузки из view расписания, может быть {@code null}
     * @return контекст с пустыми списками
     */
    public static DataContext empty(long docId, String formCode, Long workflowRunId) {
        return new DataContext(docId, formCode, workflowRunId, List.of(), List.of(), List.of(), List.of(), Set.of());
    }

    /**
     * Возвращает копию контекста со справочником связей и перекодировкой перечислений.
     *
     * @param newLinks     связи колонок витрины data с показателями XBRL
     * @param newEnumCodes перекодировка перечислений
     * @return новый контекст
     */
    public DataContext withReference(List<CuvLinkDto> newLinks, Map<String, Map<String, String>> newEnumCodes) {
        return new DataContext(docId, formCode, workflowRunId, contextList, unitList, valueList, dataRows, dataTaxonomies,
                newLinks, newEnumCodes);
    }

    /**
     * Проверяет, есть ли данные формы: заполнены {@code workflow_run_id} и строки context, unit и value.
     * Без них проверки 1–4 дают ошибки, и до сверки значений дело не доходит.
     *
     * @return {@code true}, если данные формы есть
     */
    public boolean hasFormData() {
        return workflowRunId != null && !contextList.isEmpty() && !unitList.isEmpty() && !valueList.isEmpty();
    }

    /**
     * Возвращает версии таксономии отчёта: непустые значения из context, unit, value и {@code xbrlvers} витрины
     * data без пробелов по краям.
     *
     * @return версии таксономии в порядке сортировки
     */
    public Set<String> reportTaxonomies() {
        Set<String> taxonomies = Stream.of(
                        contextList.stream().map(CuvContextDto::taxonomy),
                        unitList.stream().map(CuvUnitDto::taxonomy),
                        valueList.stream().map(CuvValueDto::taxonomy),
                        dataTaxonomies.stream())
                .flatMap(stream -> stream)
                .filter(Objects::nonNull)
                .map(String::strip)
                .filter(taxonomy -> !taxonomy.isEmpty())
                .collect(Collectors.toCollection(TreeSet::new));
        return Collections.unmodifiableSet(taxonomies);
    }
}
