package ru.sbrf.gmap.vux.repository;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.CALLS_REAL_METHODS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository.MISSING_LINKS_MAIL_SUBJECT_MARKER;

@DisplayName("VuxDocumentValidationResultViewRepository — письмо об ошибках")
class VuxDocumentValidationResultViewRepositoryTest {

    @Test
    @DisplayName("Письмо «справочник не заполнен» не считается письмом об ошибках")
    void existsErrorMail_excludesMissingLinksMail() {
        VuxDocumentValidationResultViewRepository repository =
                mock(VuxDocumentValidationResultViewRepository.class, CALLS_REAL_METHODS);
        when(repository.existsMailExcludingSubject(100L, MISSING_LINKS_MAIL_SUBJECT_MARKER)).thenReturn(true);

        assertThat(repository.existsErrorMail(100L)).isTrue();

        verify(repository).existsMailExcludingSubject(100L, MISSING_LINKS_MAIL_SUBJECT_MARKER);
    }
}
