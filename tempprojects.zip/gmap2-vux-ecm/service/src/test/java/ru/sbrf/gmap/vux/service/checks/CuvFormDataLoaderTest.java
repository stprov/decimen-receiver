package ru.sbrf.gmap.vux.service.checks;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import ru.sbrf.gmap.vux.dto.cuv.CuvContextDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvLinkDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvUnitDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvValueDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

/**
 * Общий загрузчик данных формы.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("CuvFormDataLoader")
class CuvFormDataLoaderTest {

    @Mock
    private NamedParameterJdbcTemplate jdbcTemplate;
    @InjectMocks
    private CuvFormDataLoader loader;

    private static VuxDocumentScheduleViewEntity record(Long workflowRunId) {
        VuxDocumentScheduleViewEntity record = new VuxDocumentScheduleViewEntity();
        record.setScheduleId(1);
        record.setResultDocumentId(100);
        record.setDocTypeCode("0420415.3");
        record.setWorkflowRunId(workflowRunId);
        record.setTableContextName("t_vux_form_0420415_3_context");
        record.setTableUnitsName("t_vux_form_0420415_3_unit");
        record.setTableValuesName("s_grnplm_as_cib_gm_vux.t_vux_form_0420415_3_value");
        record.setTableName("T_VUX_FORM_0420415_3_DATA");
        return record;
    }

    @Test
    @DisplayName("Нет workflow_run_id — пустой контекст без обращения к БД")
    void noWorkflowRunId_emptyContext() {
        DataContext ctx = loader.load(record(null));

        assertThat(ctx.workflowRunId()).isNull();
        assertThat(ctx.formCode()).isEqualTo("0420415.3");
        assertThat(ctx.contextList()).isEmpty();
        verifyNoInteractions(jdbcTemplate);
    }

    @Test
    @DisplayName("Таблицы формы — по именам из view, со схемой; версии таксономии — из колонки xbrlvers data")
    @SuppressWarnings("unchecked")
    void loadsFormTablesByName() {
        CuvContextDto context = CuvContextDto.builder().contextId("c1").taxonomy("7.1").workflowRunId(5L).build();
        when(jdbcTemplate.query(contains("t_vux_form_0420415_3_context"), anyMap(), any(RowMapper.class)))
                .thenReturn(List.of(context));
        when(jdbcTemplate.query(contains("t_vux_form_0420415_3_unit"), anyMap(), any(RowMapper.class))).thenReturn(List.of());
        when(jdbcTemplate.query(contains("t_vux_form_0420415_3_value"), anyMap(), any(RowMapper.class))).thenReturn(List.of());
        when(jdbcTemplate.queryForList(anyString(), anyMap()))
                .thenReturn(List.of(Map.of("xbrlvers", "7.1", "id", 1), Map.of("id", 2)));

        DataContext ctx = loader.load(record(5L));

        assertThat(ctx.contextList()).containsExactly(context);
        assertThat(ctx.dataRows()).hasSize(2);
        assertThat(ctx.dataTaxonomies()).containsExactly("7.1");
        assertThat(ctx.workflowRunId()).isEqualTo(5L);
        ArgumentCaptor<String> sql = ArgumentCaptor.forClass(String.class);
        verify(jdbcTemplate).queryForList(sql.capture(), anyMap());
        assertThat(sql.getValue()).contains("FROM s_grnplm_as_cib_gm_vux.t_vux_form_0420415_3_data WHERE workflow_run_id");
    }

    @Test
    @DisplayName("Таблица data не задана — строк data нет, остальное читается")
    @SuppressWarnings("unchecked")
    void noDataTable() {
        when(jdbcTemplate.query(anyString(), anyMap(), any(RowMapper.class))).thenReturn(List.of());
        VuxDocumentScheduleViewEntity record = record(5L);
        record.setTableName(null);

        DataContext ctx = loader.load(record);

        assertThat(ctx.dataRows()).isEmpty();
        verify(jdbcTemplate, never()).queryForList(anyString(), anyMap());
    }

    @Test
    @DisplayName("Имя таблицы проверяется перед подстановкой в SQL")
    void tableNameValidation() {
        assertThat(CuvFormDataLoader.qualifiedTableName("t_vux_form_1_context", "context"))
                .isEqualTo("s_grnplm_as_cib_gm_vux.t_vux_form_1_context");
        assertThat(CuvFormDataLoader.qualifiedTableName(" S_GRNPLM_AS_CIB_GM_VUX.T_X ", "data"))
                .isEqualTo("s_grnplm_as_cib_gm_vux.t_x");
        assertThat(CuvFormDataLoader.qualifiedTableName("s_grnplm_as_cib_gm_vux.t_vux_form_0420415_1_3_data", "data"))
                .isEqualTo("s_grnplm_as_cib_gm_vux.t_vux_form_0420415_1_3_data");
        assertThat(CuvFormDataLoader.qualifiedTableName("\"s_grnplm_as_cib_gm_vux\".\"t_vux_form_0420415_1_3_data\"", "data"))
                .isEqualTo("s_grnplm_as_cib_gm_vux.t_vux_form_0420415_1_3_data");
        assertThat(CuvFormDataLoader.qualifiedTableName("`s_grnplm_as_cib_gm_vux`.t_vux_form_0420415_1_3_data", "data"))
                .isEqualTo("s_grnplm_as_cib_gm_vux.t_vux_form_0420415_1_3_data");
        assertThatThrownBy(() -> CuvFormDataLoader.qualifiedTableName("t_x; drop table y", "data"))
                .isInstanceOf(IllegalStateException.class);
        assertThatThrownBy(() -> CuvFormDataLoader.qualifiedTableName("other_schema.t_x", "data"))
                .isInstanceOf(IllegalStateException.class);
        assertThatThrownBy(() -> CuvFormDataLoader.qualifiedTableName(null, "context"))
                .isInstanceOf(IllegalStateException.class);
    }

    @Test
    @DisplayName("Недопустимое имя таблицы в справочнике — исключение (запись остаётся открытой)")
    void invalidTableName_throws() {
        VuxDocumentScheduleViewEntity record = record(5L);
        record.setTableContextName("bad name");

        assertThatThrownBy(() -> loader.load(record)).isInstanceOf(IllegalStateException.class);
    }

    private static ResultSet linkRow(String table, String column, String type, String enumId) throws SQLException {
        ResultSet rs = mock(ResultSet.class);
        when(rs.getString("table_name")).thenReturn(table);
        when(rs.getString("column_name")).thenReturn(column);
        when(rs.getString("column_xbrl_type")).thenReturn(type);
        when(rs.getString("enum_id")).thenReturn(enumId);
        when(rs.getString("parameter_id")).thenReturn("purcb-dic:" + column);
        when(rs.getString("measure_id")).thenReturn("purcb-dic:" + column);
        return rs;
    }

    @Test
    @DisplayName("Данные есть, таксономия одна — читаются связи формы для таблицы data и перекодировка перечислений")
    @SuppressWarnings("unchecked")
    void loadsReferenceData() throws SQLException {
        VuxDocumentScheduleViewEntity record = record(5L);
        record.setDocTypeId(7);
        when(jdbcTemplate.query(contains("t_vux_form_0420415_3_context"), anyMap(), any(RowMapper.class)))
                .thenReturn(List.of(CuvContextDto.builder().contextId("c1").taxonomy("7.1").build()));
        when(jdbcTemplate.query(contains("t_vux_form_0420415_3_unit"), anyMap(), any(RowMapper.class)))
                .thenReturn(List.of(CuvUnitDto.builder().unitId("u1").taxonomy("7.1").build()));
        when(jdbcTemplate.query(contains("t_vux_form_0420415_3_value"), anyMap(), any(RowMapper.class)))
                .thenReturn(List.of(CuvValueDto.builder().elementName("e").contextId("c1").taxonomy("7.1").build()));
        when(jdbcTemplate.queryForList(anyString(), anyMap())).thenReturn(List.of());
        ResultSet sameTable = linkRow("S_GRNPLM_AS_CIB_GM_VUX.\"t_vux_form_0420415_3_data\"", "strana", "enumerator", "E1");
        ResultSet otherTable = linkRow("t_other_data", "kol", "measure", null);
        when(jdbcTemplate.query(contains("t_adm_data_xbrl_link"), anyMap(), any(RowMapper.class))).thenAnswer(invocation -> {
            RowMapper<Object> mapper = invocation.getArgument(2);
            return Arrays.asList(mapper.mapRow(sameTable, 0), mapper.mapRow(otherTable, 1));
        });
        ResultSet enumRow = mock(ResultSet.class);
        when(enumRow.getString("enum_id")).thenReturn("E1");
        when(enumRow.getString("enum_value_text")).thenReturn(" 643 ");
        when(enumRow.getString("enum_value_code")).thenReturn("Strana_643RusRossiyaMember");
        when(jdbcTemplate.query(contains("t_adm_xbrl_enum_values"), anyMap(), any(RowMapper.class))).thenAnswer(invocation -> {
            RowMapper<Object> mapper = invocation.getArgument(2);
            mapper.mapRow(enumRow, 0);
            return List.of();
        });

        DataContext ctx = loader.load(record);

        assertThat(ctx.links()).extracting(CuvLinkDto::columnName).containsExactly("strana");
        assertThat(ctx.enumCodes()).containsEntry("E1", Map.of("643", "Strana_643RusRossiyaMember"));
    }

    @Test
    @DisplayName("Версий таксономии несколько — справочник связей не читается")
    @SuppressWarnings("unchecked")
    void severalTaxonomies_noReference() {
        VuxDocumentScheduleViewEntity record = record(5L);
        record.setDocTypeId(7);
        when(jdbcTemplate.query(contains("t_vux_form_0420415_3_context"), anyMap(), any(RowMapper.class)))
                .thenReturn(List.of(CuvContextDto.builder().contextId("c1").taxonomy("7.1").build()));
        when(jdbcTemplate.query(contains("t_vux_form_0420415_3_unit"), anyMap(), any(RowMapper.class)))
                .thenReturn(List.of(CuvUnitDto.builder().unitId("u1").taxonomy("7.2").build()));
        when(jdbcTemplate.query(contains("t_vux_form_0420415_3_value"), anyMap(), any(RowMapper.class)))
                .thenReturn(List.of(CuvValueDto.builder().elementName("e").contextId("c1").taxonomy("7.1").build()));
        when(jdbcTemplate.queryForList(anyString(), anyMap())).thenReturn(List.of());

        DataContext ctx = loader.load(record);

        assertThat(ctx.links()).isEmpty();
        verify(jdbcTemplate, never()).query(contains("t_adm_data_xbrl_link"), anyMap(), any(RowMapper.class));
    }
}
