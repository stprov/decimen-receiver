package ru.sbrf.gmap.vux.entity.enums;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

@DisplayName("ScheduleStatusEnum")
class ScheduleStatusEnumTest {

    @Test
    @DisplayName("Код статуса совпадает с порядковым номером: сущность view читает статус по ORDINAL")
    void codeMatchesOrdinal() {
        for (ScheduleStatusEnum status : ScheduleStatusEnum.values()) {
            assertThat(status.getCode()).as(status.name()).isEqualTo(status.ordinal());
        }
    }

    @Test
    @DisplayName("Коды, которые сервис записывает в БД: 1 — проверено без ошибок, 2 — проверено с ошибками")
    void writtenCodes() {
        assertThat(ScheduleStatusEnum.VERIFIED_SUCCESSFULLY.getCode()).isEqualTo(1);
        assertThat(ScheduleStatusEnum.CHECKED_WITH_ERRORS.getCode()).isEqualTo(2);
    }
}
