package ru.sbrf.gmap.vux.service.checks;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvContextDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvLinkDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvUnitDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvValueDto;
import ru.sbrf.gmap.vux.service.parser.XmlParserService;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Проверка 10: прямая и обратная сверка значений отчёта с витриной, сводка расхождений.
 */
@DisplayName("SummaryAnalyticsRule — проверка 10")
class SummaryAnalyticsRuleTest {

    private static final String FORM = "0420415.1.3";
    private static final long WR = 42L;
    private static final String KOL = "purcb-dic:Kolichestvo";
    private static final String STRANA = "purcb-dic:Strana";
    private static final String SECTION = "dim-int:Tip_czenBum_naPravSobstvAxis=mem-int:KolCZenBumagPrinadOrgMember";

    private static final CuvLinkDto KEY = CuvLinkDto.builder()
            .columnName("id_stroki").columnXbrlType("typed").taxisId("dim-int:ID_strokiTaxis").lineKey(1).build();
    private static final CuvLinkDto KOL_LINK = CuvLinkDto.builder()
            .columnName("kol").columnXbrlType("measure").measureId(KOL).analyticalSection(SECTION).build();
    private static final CuvLinkDto STRANA_LINK = CuvLinkDto.builder()
            .columnName("strana").columnXbrlType("enumerator").parameterId(STRANA).enumId("E1").build();

    private final SummaryAnalyticsRule rule = new SummaryAnalyticsRule(new XmlParserService(), false);

    private static String scenario(String rowId) {
        return "<xbrldi:explicitMember dimension=\"dim-int:Tip_czenBum_naPravSobstvAxis\">mem-int:KolCZenBumagPrinadOrgMember</xbrldi:explicitMember>"
                + "<xbrldi:typedMember dimension=\"dim-int:ID_strokiTaxis\"><dim-int:ID_strokiTypedname>" + rowId
                + "</dim-int:ID_strokiTypedname></xbrldi:typedMember>";
    }

    private static CuvContextDto context(String id, String rowId) {
        return CuvContextDto.builder().contextId(id).scenario(rowId == null ? null : scenario(rowId))
                .taxonomy("7.1").workflowRunId(WR).build();
    }

    private static CuvValueDto value(String element, String contextId, String value) {
        return CuvValueDto.builder().elementName(element).contextId(contextId).value(value).unitId("u1")
                .taxonomy("7.1").workflowRunId(WR).build();
    }

    private static Map<String, Object> row(String id, Object kol, Object strana) {
        Map<String, Object> row = new HashMap<>();
        row.put("id_stroki", id);
        row.put("kol", kol);
        row.put("strana", strana);
        return row;
    }

    private static DataContext ctx(List<CuvContextDto> contexts, List<CuvValueDto> values, List<Map<String, Object>> rows,
                                   List<CuvLinkDto> links) {
        return new DataContext(1, FORM, WR, contexts,
                List.of(CuvUnitDto.builder().unitId("u1").taxonomy("7.1").workflowRunId(WR).build()),
                values, rows, Set.of(), links, Map.of("E1", Map.of("643", "Strana_643RusRossiyaMember")));
    }

    private static DataContext standard(List<CuvValueDto> values, List<Map<String, Object>> rows) {
        return ctx(List.of(context("c1", "R1"), context("c2", "R2"), context("total", null)), values, rows,
                List.of(KEY, KOL_LINK, STRANA_LINK));
    }

    @Test
    @DisplayName("Значения совпадают в обе стороны, итоги без открытых осей не сверяются — расхождений нет")
    void allMatch() {
        DataContext data = standard(
                List.of(value(KOL, "c1", "10"), value(KOL, "c2", "5"),
                        value(STRANA, "c1", "mem-int:Strana_643RusRossiyaMember"), value(KOL, "total", "15")),
                List.of(row("R1", new BigDecimal("10.00"), "643"), row("R2", 5.0, null)));

        assertThat(rule.validate(data)).isEmpty();
    }

    @Test
    @DisplayName("Расхождение значения — строка сводки с числом расхождений и контекстом")
    void mismatch() {
        DataContext data = standard(List.of(value(KOL, "c1", "10"), value(KOL, "c2", "6")),
                List.of(row("R1", 10, null), row("R2", 5, null)));

        List<ValidationErrorDto> errors = rule.validate(data);

        assertThat(errors).singleElement().satisfies(error -> {
            assertThat(error.errorCode()).isEqualTo("DCUV_0420415_1_3_010");
            assertThat(error.errorMessage()).isEqualTo("В отчете id = 42 для параметра " + KOL
                    + " выявлено несовпадение значений в csv и detail: 1. Примеры контекстов: c2.");
            assertThat(error.deviationCount()).isEqualTo(1);
        });
    }

    @Test
    @DisplayName("Перечисление: значение витрины перекодируется в код элемента, префикс отчёта не учитывается")
    void enumeratorRecoded() {
        DataContext ok = standard(List.of(value(KOL, "c1", "10"), value(STRANA, "c1", "mem-int:Strana_643RusRossiyaMember")),
                List.of(row("R1", 10, "643")));
        DataContext wrong = standard(List.of(value(KOL, "c1", "10"), value(STRANA, "c1", "mem-int:Strana_398Member")),
                List.of(row("R1", 10, "643")));

        assertThat(rule.validate(ok)).isEmpty();
        assertThat(rule.validate(wrong)).extracting(ValidationErrorDto::errorMessage)
                .containsExactly("В отчете id = 42 для параметра " + STRANA
                        + " выявлено несовпадение значений в csv и detail: 1. Примеры контекстов: c1.");
    }

    @Test
    @DisplayName("Сводка: одна строка на показатель и вид, число — все расхождения, примеры — первые три контекста")
    void summaryGroupsByIndicatorAndKind() {
        List<CuvContextDto> contexts = new ArrayList<>();
        List<CuvValueDto> values = new ArrayList<>();
        List<Map<String, Object>> rows = new ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            contexts.add(context("c" + i, "R" + i));
            values.add(value(KOL, "c" + i, "100"));
            rows.add(row("R" + i, i, null));
        }
        contexts.add(context("c9", "R9"));
        values.add(value(KOL, "c9", "1"));

        List<ValidationErrorDto> errors = rule.validate(ctx(contexts, values, rows, List.of(KEY, KOL_LINK)));

        assertThat(errors).extracting(ValidationErrorDto::errorMessage).containsExactly(
                "В отчете id = 42 для параметра " + KOL
                        + " выявлено несовпадение значений в csv и detail: 5. Примеры контекстов: c1, c2, c3.",
                "В отчете id = 42 для параметра " + KOL + " не найдена строка в data: 1. Примеры контекстов: c9.");
        assertThat(errors).extracting(ValidationErrorDto::deviationCount).containsExactly(5, 1);
        assertThat(CuvErrors.deviationCount(errors.getFirst().errorMessage())).isEqualTo(5);
    }

    @Test
    @DisplayName("Показателя нет в справочнике или подходят две колонки — свои виды расхождений")
    void noLinkAndAmbiguousLink() {
        CuvLinkDto second = CuvLinkDto.builder().columnName("kol2").columnXbrlType("measure").measureId(KOL).build();
        DataContext data = ctx(List.of(context("c1", "R1")),
                List.of(value("purcb-dic:Neizvestno", "c1", "1"), value(KOL, "c1", "10")),
                List.of(row("R1", 10, null)), List.of(KEY, KOL_LINK, second));

        assertThat(rule.validate(data)).extracting(ValidationErrorDto::errorMessage).containsExactly(
                "В отчете id = 42 для параметра " + KOL
                        + " найдено несколько связей с data в справочнике t_adm_data_xbrl_link: 1. Примеры контекстов: c1.",
                "В отчете id = 42 для параметра purcb-dic:Neizvestno"
                        + " не найдена связь с data в справочнике t_adm_data_xbrl_link: 1. Примеры контекстов: c1.");
    }

    @Test
    @DisplayName("Обратная сверка: значение витрины без значения в отчёте — расхождение с ключом строки")
    void missingInReport() {
        DataContext data = standard(List.of(value(KOL, "c1", "10")), List.of(row("R1", 10, null), row("R3", 7, null)));

        assertThat(rule.validate(data)).extracting(ValidationErrorDto::errorMessage).containsExactly(
                "В отчете id = 42 для параметра " + KOL
                        + " отсутствуют значения витрины (колонка kol): 1. Примеры строк витрины: id_stroki=R3.");
    }

    @Test
    @DisplayName("Обратная сверка: 0 в витрине по умолчанию не расхождение, по параметру — расхождение")
    void zeroInData() {
        DataContext data = standard(List.of(value(KOL, "c1", "10")), List.of(row("R1", 10, null), row("R3", 0, null)));

        assertThat(rule.validate(data)).isEmpty();
        assertThat(new SummaryAnalyticsRule(new XmlParserService(), true).validate(data)).hasSize(1);
    }

    @Test
    @DisplayName("Нет справочника связей — проверка ничего не сверяет")
    void noLinks() {
        DataContext data = ctx(List.of(context("c1", "R1")), List.of(value(KOL, "c1", "10")), List.of(), List.of());

        assertThat(rule.validate(data)).isEmpty();
    }

    @Test
    @DisplayName("analytical_section: XML-фрагмент и текст с префиксами разбираются в имена осей и элементов")
    void sectionFormats() {
        assertThat(rule.sectionElements("dim-int:A=mem-int:B; dim-int:C = mem-int:D")).containsExactlyInAnyOrder("A", "B", "C", "D");
        assertThat(rule.sectionElements("A:B")).containsExactlyInAnyOrder("A", "B");
        assertThat(rule.sectionElements(
                "<xbrldi:explicitMember dimension=\"dim-int:A\">mem-int:B</xbrldi:explicitMember>"))
                .containsExactlyInAnyOrder("A", "B");
        assertThat(rule.sectionElements(null)).isEmpty();
    }

    @Test
    @DisplayName("Число расхождений читается из текста строки сводки; у обычной ошибки — 1")
    void deviationCountFromMessage() {
        assertThat(CuvErrors.deviationCount("... выявлено несовпадение значений в csv и detail: 12. Примеры контекстов: c1.")).isEqualTo(12);
        assertThat(CuvErrors.deviationCount("... не найдена строка в data: 3.")).isEqualTo(3);
        assertThat(CuvErrors.deviationCount("Обнаружены лишние context: [c1, c2].")).isEqualTo(1);
        assertThat(CuvErrors.deviationCount(null)).isEqualTo(1);
    }
}
