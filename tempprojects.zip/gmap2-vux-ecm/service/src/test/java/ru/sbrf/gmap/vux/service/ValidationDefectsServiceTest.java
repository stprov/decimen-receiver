package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationLogEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationResultViewEntity;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationLogRepository;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("ValidationDefectsService")
class ValidationDefectsServiceTest {

    private static final int DOC_ID = 100;

    @Mock
    private VuxDocumentValidationLogRepository logRepository;
    @Mock
    private VuxDocumentValidationResultViewRepository viewRepository;

    private static VuxDocumentValidationResultViewEntity defect(RuleTypeEnum ruleType) {
        VuxDocumentValidationResultViewEntity defect = mock(VuxDocumentValidationResultViewEntity.class);
        when(defect.getRuleType()).thenReturn(ruleType);
        return defect;
    }

    @Test
    @DisplayName("loadViewDefects: нарушения делятся на ошибки и предупреждения, проверки читаются из логов")
    void loadViewDefects_splitsByRuleType() {
        VuxDocumentValidationResultViewEntity error = defect(RuleTypeEnum.E);
        VuxDocumentValidationResultViewEntity warning = defect(RuleTypeEnum.W);
        VuxDocumentValidationLogEntity check = mock(VuxDocumentValidationLogEntity.class);
        when(viewRepository.findByDocIdWithRnLimit(eq(DOC_ID), any(), any())).thenReturn(List.of(error, warning));
        when(logRepository.findAllByDocIdOrderByErrorCountDesc(DOC_ID)).thenReturn(List.of(check));

        ValidationDefectsService.ViewDefects view = new ValidationDefectsService(logRepository, viewRepository).loadViewDefects(DOC_ID);

        assertThat(view.errors()).containsExactly(error);
        assertThat(view.warnings()).containsExactly(warning);
        assertThat(view.checks()).containsExactly(check);
        assertThat(view.hasErrors()).isTrue();
    }

    @Test
    @DisplayName("loadViewDefects: нарушений нет — пустые списки, ошибок нет")
    void loadViewDefects_empty() {
        when(viewRepository.findByDocIdWithRnLimit(eq(DOC_ID), any(), any())).thenReturn(List.of());
        when(logRepository.findAllByDocIdOrderByErrorCountDesc(DOC_ID)).thenReturn(List.of());

        ValidationDefectsService.ViewDefects view = new ValidationDefectsService(logRepository, viewRepository).loadViewDefects(DOC_ID);

        assertThat(view.errors()).isEmpty();
        assertThat(view.warnings()).isEmpty();
        assertThat(view.hasErrors()).isFalse();
    }
}
