package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import ru.sbrf.gmap.vux.config.FeatureToogleConfig;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationResultViewEntity;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Фаза 2 — существующий документ.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("FollowUpProcessingStrategy — доведение до конца: фаза 2 и legacy-путь")
class FollowUpProcessingStrategyTest {

    private static final int DOC_ID = 100;
    private static final String FORM = "0420415.1.3";
    private static final String PROTOCOL_ECM_ID = "protocol-ecm-id";
    private static final List<String> CSV_ECM_IDS = List.of("ctx-ecm", "unit-ecm", "value-ecm");

    @Mock
    private ProtocolBuildingService protocolBuildingService;
    @Mock
    private ValidationDefectsService validationDefectsService;
    @Mock
    private PostUploadActionsService postUploadActionsService;
    @Mock
    private DocumentEcmExportService documentEcmExportService;

    private final ProtocolModelDto protocol = ProtocolModelDto.builder().build();

    @BeforeEach
    void setUp() {
        when(validationDefectsService.loadViewDefects(DOC_ID))
                .thenReturn(new ValidationDefectsService.ViewDefects(List.of(), List.of(), List.of()));
        when(validationDefectsService.getCuvErrors(DOC_ID, FORM)).thenReturn(List.of());
        when(protocolBuildingService.createProtocolModelDto(anyList(), anyList(), anyList(), any())).thenReturn(protocol);
        when(protocolBuildingService.createCuvErrorProtocol(any(), anyList(), anyList(), anyList(), anyList())).thenReturn(protocol);
        when(documentEcmExportService.evaluateCuvCsvExport(10, DOC_ID))
                .thenReturn(new DocumentEcmExportService.ExportState(true, CSV_ECM_IDS));
        when(postUploadActionsService.protocolResultText(anyLong())).thenReturn("result");
        when(postUploadActionsService.createSupzTask(any(), anyList(), anyString())).thenReturn(true);
        when(postUploadActionsService.sendErrorMail(any(), any())).thenReturn(true);
        when(postUploadActionsService.isErrorMailSent(any())).thenReturn(false);
        when(postUploadActionsService.handlePostUploadActions(any(), any(), anyList())).thenReturn(true);
    }

    private FollowUpProcessingStrategy service(boolean cuvEnabled) {
        return new FollowUpProcessingStrategy(new FeatureToogleConfig(cuvEnabled), protocolBuildingService,
                validationDefectsService, postUploadActionsService, documentEcmExportService);
    }

    private static VuxDocumentScheduleViewEntity record(String checkMode, String ecmId) {
        VuxDocumentScheduleViewEntity record = new VuxDocumentScheduleViewEntity();
        record.setScheduleId(10);
        record.setResultDocumentId(DOC_ID);
        record.setDocTypeCode(FORM);
        record.setCheckMode(checkMode);
        record.setEcmId(ecmId);
        record.setWarningCount(3L);
        return record;
    }

    private void viewErrors() {
        when(validationDefectsService.loadViewDefects(DOC_ID)).thenReturn(new ValidationDefectsService.ViewDefects(
                List.of(mock(VuxDocumentValidationResultViewEntity.class)), List.of(), List.of()));
    }

    private void cuvErrors() {
        when(validationDefectsService.getCuvErrors(DOC_ID, FORM))
                .thenReturn(List.of(new ValidationErrorDto("t", "DCUV_0420415_1_3_005", "m")));
    }

    @Test
    @DisplayName("supports: только записи с id протокола в ecm_id; пустой ecm_id и метка '-1' — нет")
    void supports_onlyWithProtocolEcmId() {
        assertThat(service(true).supports(record("cuv", PROTOCOL_ECM_ID))).isTrue();
        assertThat(service(true).supports(record("cuv", null))).isFalse();
        assertThat(service(true).supports(record("cuv", "-1"))).isFalse();
    }

    @Test
    @DisplayName("Все CSV готовы — задача СУПЗ: CSV context, unit, value, затем протокол; закрытие")
    void allCsvReady_createsSupzTask() {
        VuxDocumentScheduleViewEntity record = record("cuv", PROTOCOL_ECM_ID);

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(postUploadActionsService).protocolResultText(3L);
        verify(postUploadActionsService).createSupzTask(record,
                List.of("ctx-ecm", "unit-ecm", "value-ecm", PROTOCOL_ECM_ID), "result");
    }

    @Test
    @DisplayName("CSV не готовы (ожидание или окончательный отказ) — без СУПЗ, расписание открыто")
    void csvNotReady_pending() {
        when(documentEcmExportService.evaluateCuvCsvExport(10, DOC_ID))
                .thenReturn(new DocumentEcmExportService.ExportState(false, List.of()));

        ProcessingResult result = service(true).process(record("cuv", PROTOCOL_ECM_ID));

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(postUploadActionsService, never()).createSupzTask(any(), anyList(), anyString());
    }

    @Test
    @DisplayName("Сбой СУПЗ — расписание открыто")
    void supzFailed_pending() {
        when(postUploadActionsService.createSupzTask(any(), anyList(), anyString())).thenReturn(false);

        assertThat(service(true).process(record("cuv", PROTOCOL_ECM_ID))).isEqualTo(ProcessingResult.PENDING);
    }

    @Test
    @DisplayName("supz_task_id заполнен (задача создана или флаг U) — закрытие без СУПЗ и без чтения выгрузки")
    void supzTaskAlreadySet_resolves() {
        VuxDocumentScheduleViewEntity record = record("cuv", PROTOCOL_ECM_ID);
        record.setSupzTaskId("1");

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(documentEcmExportService, never()).evaluateCuvCsvExport(any(), any());
        verify(postUploadActionsService, never()).createSupzTask(any(), anyList(), anyString());
    }

    @Test
    @DisplayName("Ошибки CUV, письма нет — письмо с CUV-ошибками, закрытие; без выгрузки и СУПЗ")
    void cuvErrors_noMail_sendsMail() {
        cuvErrors();
        VuxDocumentScheduleViewEntity record = record("cuv", PROTOCOL_ECM_ID);

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(protocolBuildingService).createCuvErrorProtocol(eq(record), anyList(), anyList(), anyList(), anyList());
        verify(postUploadActionsService).sendErrorMail(record, protocol);
        verify(documentEcmExportService, never()).evaluateCuvCsvExport(any(), any());
        verify(postUploadActionsService, never()).createSupzTask(any(), anyList(), anyString());
    }

    @Test
    @DisplayName("Только ошибки view, письма нет — протокол view, письмо, закрытие")
    void viewErrors_noMail_sendsMail() {
        viewErrors();
        VuxDocumentScheduleViewEntity record = record("cuv", PROTOCOL_ECM_ID);

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(protocolBuildingService).createProtocolModelDto(anyList(), anyList(), anyList(), eq(record));
        verify(protocolBuildingService, never()).createCuvErrorProtocol(any(), anyList(), anyList(), anyList(), anyList());
        verify(postUploadActionsService).sendErrorMail(record, protocol);
    }

    @Test
    @DisplayName("Ошибки есть, письмо уже в t_vux_mail — закрытие без письма")
    void errors_mailAlreadySent_resolvesWithoutMail() {
        cuvErrors();
        when(postUploadActionsService.isErrorMailSent(any())).thenReturn(true);

        ProcessingResult result = service(true).process(record("cuv", PROTOCOL_ECM_ID));

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(postUploadActionsService, never()).sendErrorMail(any(), any());
    }

    @Test
    @DisplayName("Ошибки есть, сбой отправки письма — расписание открыто")
    void errors_mailFailed_pending() {
        viewErrors();
        when(postUploadActionsService.sendErrorMail(any(), any())).thenReturn(false);

        assertThat(service(true).process(record("cuv", PROTOCOL_ECM_ID))).isEqualTo(ProcessingResult.PENDING);
    }

    @Test
    @DisplayName("Флаг U и ошибки — письмо всё равно отправляется")
    void flagU_withErrors_sendsMail() {
        cuvErrors();
        VuxDocumentScheduleViewEntity record = record("cuv", PROTOCOL_ECM_ID);
        record.setSupzTaskId("1");

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(postUploadActionsService).sendErrorMail(record, protocol);
    }

    @Test
    @DisplayName("Фича-флаг выключен — legacy-путь")
    void toggleOff_legacy() {
        VuxDocumentScheduleViewEntity record = record("cuv", PROTOCOL_ECM_ID);

        service(false).process(record);

        verify(postUploadActionsService).handlePostUploadActions(record, protocol, List.of(PROTOCOL_ECM_ID));
        verify(documentEcmExportService, never()).evaluateCuvCsvExport(any(), any());
    }

    @Test
    @DisplayName("Фаза 2 для любой формы с check_mode = cuv (без провайдера формы)")
    void anyForm_phase2() {
        VuxDocumentScheduleViewEntity record = record("cuv", PROTOCOL_ECM_ID);
        record.setDocTypeCode("0420415.3");
        when(validationDefectsService.getCuvErrors(DOC_ID, "0420415.3")).thenReturn(List.of());

        service(true).process(record);

        verify(documentEcmExportService).evaluateCuvCsvExport(any(), eq(DOC_ID));
        verify(postUploadActionsService, never()).handlePostUploadActions(any(), any(), anyList());
    }

    @Test
    @DisplayName("check_mode = null — legacy-путь, сбой пост-обработки оставляет расписание открытым")
    void checkModeNull_legacy() {
        when(postUploadActionsService.handlePostUploadActions(any(), any(), anyList())).thenReturn(false);

        ProcessingResult result = service(true).process(record(null, PROTOCOL_ECM_ID));

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(documentEcmExportService, never()).evaluateCuvCsvExport(any(), any());
    }

    @Test
    @DisplayName("Неожиданное исключение — расписание открыто")
    void unexpectedException_pending() {
        when(validationDefectsService.loadViewDefects(DOC_ID)).thenThrow(new IllegalStateException("boom"));

        assertThat(service(true).process(record("cuv", PROTOCOL_ECM_ID))).isEqualTo(ProcessingResult.PENDING);
    }
}
