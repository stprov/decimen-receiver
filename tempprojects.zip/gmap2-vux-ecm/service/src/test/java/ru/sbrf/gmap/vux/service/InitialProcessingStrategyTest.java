package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import ru.sbrf.gmap.vux.config.FeatureToogleConfig;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentValidationResultViewEntity;
import ru.sbrf.gmap.vux.entity.enums.ScheduleStatusEnum;
import ru.sbrf.gmap.vux.mapper.VuxDocumentValidationLogEnityMapper;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;
import ru.sbrf.gmap.vux.service.checks.ContextExistsRule;
import ru.sbrf.gmap.vux.service.checks.DataContext;
import ru.sbrf.gmap.vux.service.checks.CuvFormDataLoader;
import ru.sbrf.gmap.vux.service.checks.UnitExistsRule;
import ru.sbrf.gmap.vux.service.checks.ValueExistsRule;
import ru.sbrf.gmap.vux.service.checks.WorkflowRunIdRule;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Фаза 1 — новый документ.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("InitialProcessingStrategy — первый проход (фаза 1)")
class InitialProcessingStrategyTest {

    private static final int SCHEDULE_ID = 10;
    private static final int DOC_ID = 100;
    private static final String FORM = "0420415.1.3";

    @Mock
    private ValidationDataService validationDataService;
    @Mock
    private ProtocolBuildingService protocolBuildingService;
    @Mock
    private PostUploadActionsService postUploadActionsService;
    @Mock
    private ValidationDefectsService validationDefectsService;
    @Mock
    private DocumentEcmExportService documentEcmExportService;
    @Mock
    private CuvFormDataLoader loader;
    @Mock
    private VuxDocumentValidationLogEnityMapper logMapper;
    @Mock
    private VuxDocumentValidationResultViewRepository viewRepository;
    @Mock
    private CuvValidationStatusService cuvValidationStatusService;
    @Mock
    private MissingLinksService missingLinksService;

    private final ProtocolModelDto protocol = ProtocolModelDto.builder().build();
    private final DataContext context = DataContext.empty(DOC_ID, FORM, 5L);

    @BeforeEach
    void setUp() {
        when(loader.load(any())).thenReturn(context);
        when(validationDefectsService.loadViewDefects(DOC_ID))
                .thenReturn(new ValidationDefectsService.ViewDefects(List.of(), List.of(), List.of()));
        when(validationDataService.getChecks(anyList())).thenReturn(List.of());
        when(protocolBuildingService.createCuvSuccessProtocol(any(), anyList(), anyList())).thenReturn(protocol);
        when(protocolBuildingService.createCuvErrorProtocol(any(), anyList(), anyList(), anyList(), anyList())).thenReturn(protocol);
        when(protocolBuildingService.createProtocolModelDto(anyList(), anyList(), anyList(), any())).thenReturn(protocol);
        when(postUploadActionsService.uploadProtocol(any(), any())).thenReturn(Optional.of("protocol-ecm-id"));
        when(postUploadActionsService.sendErrorMail(any(), any())).thenReturn(true);
        when(postUploadActionsService.handlePostUploadActions(any(), any(), anyList())).thenReturn(true);
        when(documentEcmExportService.requestCuvCsvExport(SCHEDULE_ID, DOC_ID)).thenReturn(true);
    }

    private InitialProcessingStrategy service(boolean cuvEnabled) {
        return service(cuvEnabled, validationDataService);
    }

    private InitialProcessingStrategy service(boolean cuvEnabled, ValidationDataService validation) {
        return new InitialProcessingStrategy(new FeatureToogleConfig(cuvEnabled), validation, protocolBuildingService,
                postUploadActionsService, validationDefectsService, documentEcmExportService, loader,
                logMapper, viewRepository, cuvValidationStatusService, new CuvErrorStorageService(viewRepository, true),
                missingLinksService);
    }

    private static VuxDocumentScheduleViewEntity record(String checkMode) {
        VuxDocumentScheduleViewEntity record = new VuxDocumentScheduleViewEntity();
        record.setScheduleId(SCHEDULE_ID);
        record.setResultDocumentId(DOC_ID);
        record.setDocTypeCode(FORM);
        record.setCheckMode(checkMode);
        record.setScheduleStatus(ScheduleStatusEnum.VERIFIED_SUCCESSFULLY);
        record.setWorkflowRunId(5L);
        return record;
    }

    private void cuvErrors(int count) {
        List<ValidationErrorDto> errors = java.util.stream.IntStream.range(0, count)
                .mapToObj(i -> new ValidationErrorDto("t", "DCUV_0420415_1_3_00" + (5 + i), "msg " + i))
                .toList();
        when(validationDataService.validate(context)).thenReturn(errors);
        when(validationDataService.countExecutedChecks(errors)).thenReturn(9);
    }

    private void noCuvErrors() {
        when(validationDataService.validate(context)).thenReturn(List.of());
        when(validationDataService.countExecutedChecks(List.of())).thenReturn(9);
    }

    private void viewErrors() {
        List<VuxDocumentValidationResultViewEntity> errors = List.of(mock(VuxDocumentValidationResultViewEntity.class));
        when(validationDefectsService.loadViewDefects(DOC_ID))
                .thenReturn(new ValidationDefectsService.ViewDefects(errors, List.of(), List.of()));
    }

    @Test
    @DisplayName("supports: только записи без ecm_id")
    void supports_onlyWithoutEcmId() {
        VuxDocumentScheduleViewEntity record = record("cuv");
        assertThat(service(true).supports(record)).isTrue();
        record.setEcmId("x");
        assertThat(service(true).supports(record)).isFalse();
    }

    @Test
    @DisplayName("CUV и view без ошибок — протокол, статус CUV 1, 3 записи выгрузки, расписание открыто")
    void cuvSuccess_requestsCsvExportAndStaysOpen() {
        noCuvErrors();
        VuxDocumentScheduleViewEntity record = record("cuv");

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(postUploadActionsService).uploadProtocol(record, protocol);
        verify(cuvValidationStatusService).saveChecked(eq(record), eq(9), eq(0), any(), any());
        verify(documentEcmExportService).requestCuvCsvExport(SCHEDULE_ID, DOC_ID);
        verify(postUploadActionsService, never()).sendErrorMail(any(), any());
        verify(postUploadActionsService, never()).createSupzTask(any(), anyList(), anyString());
    }

    @Test
    @DisplayName("Флаг U — протокол загружается, записи выгрузки не создаются, расписание закрывается сразу")
    void cuvSuccess_flagU_noCsvExport() {
        noCuvErrors();
        VuxDocumentScheduleViewEntity record = record("cuv");
        record.setFlags("MU");
        record.setSupzTaskId("1");

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(postUploadActionsService).uploadProtocol(record, protocol);
        verify(cuvValidationStatusService).saveChecked(eq(record), eq(9), eq(0), any(), any());
        verify(documentEcmExportService, never()).requestCuvCsvExport(any(), any());
        verify(postUploadActionsService, never()).createSupzTask(any(), anyList(), anyString());
        verify(postUploadActionsService, never()).sendErrorMail(any(), any());
    }

    @Test
    @DisplayName("Протокол не загрузился — нет выгрузки, расписание открыто; статус CUV 1 уже записан")
    void cuvSuccess_protocolUploadFailed() {
        noCuvErrors();
        when(postUploadActionsService.uploadProtocol(any(), any())).thenReturn(Optional.empty());
        VuxDocumentScheduleViewEntity record = record("cuv");

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(documentEcmExportService, never()).requestCuvCsvExport(any(), any());
        verify(cuvValidationStatusService).saveChecked(eq(record), eq(9), eq(0), any(), any());
    }

    private void previousCuvErrors() {
        when(viewRepository.findCuvValidationErrors((long) DOC_ID)).thenReturn(List.<Object[]>of(new Object[]{"C1", "m1"}));
    }

    @Test
    @DisplayName("Повторная проверка без ошибок CUV — ошибки прошлой проверки удаляются до загрузки протокола")
    void cuvSuccess_previousErrorsCleared() {
        noCuvErrors();
        previousCuvErrors();
        VuxDocumentScheduleViewEntity record = record("cuv");

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        InOrder order = inOrder(viewRepository, postUploadActionsService);
        order.verify(viewRepository).flowCuvClearErrors((long) DOC_ID);
        order.verify(postUploadActionsService).uploadProtocol(record, protocol);
        verify(viewRepository, never()).flowCuvSetError(anyLong(), anyString(), anyString());
        verify(viewRepository, never()).flowUpdateSheduleStatus(any(), any());
        verify(documentEcmExportService).requestCuvCsvExport(SCHEDULE_ID, DOC_ID);
    }

    @Test
    @DisplayName("Прошлые ошибки CUV не подтвердились, статус расписания 2 — вернуть 1 до удаления ошибок и протокола")
    void cuvSuccess_previousErrors_status2_resetTo1() {
        noCuvErrors();
        previousCuvErrors();
        VuxDocumentScheduleViewEntity record = record("cuv");
        record.setScheduleStatus(ScheduleStatusEnum.CHECKED_WITH_ERRORS);

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        InOrder order = inOrder(viewRepository, postUploadActionsService);
        order.verify(viewRepository).flowUpdateSheduleStatus(SCHEDULE_ID, ScheduleStatusEnum.VERIFIED_SUCCESSFULLY.getCode());
        order.verify(viewRepository).flowCuvClearErrors((long) DOC_ID);
        order.verify(postUploadActionsService).uploadProtocol(record, protocol);
        verify(documentEcmExportService).requestCuvCsvExport(SCHEDULE_ID, DOC_ID);
    }

    @Test
    @DisplayName("Возврат статуса 1 отклонён — ошибки не удаляются, протокол не загружается, запись открыта")
    void cuvSuccess_resetRefused_pending() {
        noCuvErrors();
        previousCuvErrors();
        when(viewRepository.flowUpdateSheduleStatus(SCHEDULE_ID, ScheduleStatusEnum.VERIFIED_SUCCESSFULLY.getCode()))
                .thenReturn(Optional.of("Расписание не найдено"));
        VuxDocumentScheduleViewEntity record = record("cuv");
        record.setScheduleStatus(ScheduleStatusEnum.CHECKED_WITH_ERRORS);

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(viewRepository, never()).flowCuvClearErrors(anyLong());
        verify(postUploadActionsService, never()).uploadProtocol(any(), any());
    }

    @Test
    @DisplayName("Прошлые ошибки CUV, есть ошибки view — статус 2 не меняется, ошибки CUV удаляются, письмо об ошибках")
    void cuvSuccess_previousErrors_viewErrors_statusKept() {
        noCuvErrors();
        previousCuvErrors();
        viewErrors();
        VuxDocumentScheduleViewEntity record = record("cuv");
        record.setScheduleStatus(ScheduleStatusEnum.CHECKED_WITH_ERRORS);

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(viewRepository, never()).flowUpdateSheduleStatus(any(), any());
        verify(viewRepository).flowCuvClearErrors((long) DOC_ID);
        verify(postUploadActionsService).sendErrorMail(record, protocol);
    }

    @Test
    @DisplayName("Сбой удаления прежних ошибок CUV — протокол не загружается, расписание открыто")
    void cuvSuccess_clearFailed_pending() {
        noCuvErrors();
        previousCuvErrors();
        when(viewRepository.flowCuvClearErrors((long) DOC_ID)).thenThrow(new IllegalStateException("function does not exist"));
        VuxDocumentScheduleViewEntity record = record("cuv");

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(postUploadActionsService, never()).uploadProtocol(any(), any());
        verify(documentEcmExportService, never()).requestCuvCsvExport(any(), any());
    }

    @Test
    @DisplayName("CUV без ошибок, прежних ошибок нет — функция очистки и смена статуса не вызываются")
    void cuvSuccess_noPreviousErrors_noClear() {
        noCuvErrors();

        service(true).process(record("cuv"));

        verify(viewRepository, never()).flowCuvClearErrors(anyLong());
        verify(viewRepository, never()).flowUpdateSheduleStatus(any(), any());
    }

    @Test
    @DisplayName("CUV без ошибок, есть ошибки view — протокол с ошибками, письмо, закрытие, без выгрузки")
    void cuvSuccess_viewErrors_sendsMail() {
        noCuvErrors();
        viewErrors();
        VuxDocumentScheduleViewEntity record = record("cuv");

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(postUploadActionsService).sendErrorMail(record, protocol);
        verify(cuvValidationStatusService).saveChecked(eq(record), eq(9), eq(0), any(), any());
        verify(documentEcmExportService, never()).requestCuvCsvExport(any(), any());
    }

    @Test
    @DisplayName("Ошибки CUV — сохранение, статус расписания 2, протокол, письмо, статус CUV 2")
    void cuvErrors_savedMarkedAndMailed() {
        cuvErrors(2);
        VuxDocumentScheduleViewEntity record = record("cuv");

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(viewRepository).flowCuvClearErrors((long) DOC_ID);
        verify(viewRepository, times(2)).flowCuvSetError(eq((long) DOC_ID), anyString(), anyString());
        verify(viewRepository).flowUpdateSheduleStatus(SCHEDULE_ID, ScheduleStatusEnum.CHECKED_WITH_ERRORS.getCode());
        verify(postUploadActionsService).uploadProtocol(record, protocol);
        verify(postUploadActionsService).sendErrorMail(record, protocol);
        verify(cuvValidationStatusService).saveChecked(eq(record), eq(9), eq(2), any(), any());
        verify(documentEcmExportService, never()).requestCuvCsvExport(any(), any());
    }

    @Test
    @DisplayName("Ошибки CUV при статусе расписания 2 — fn_flow_update_shedule не вызывается")
    void cuvErrors_statusAlready2_noStatusUpdate() {
        cuvErrors(1);
        VuxDocumentScheduleViewEntity record = record("cuv");
        record.setScheduleStatus(ScheduleStatusEnum.CHECKED_WITH_ERRORS);

        service(true).process(record);

        verify(viewRepository, never()).flowUpdateSheduleStatus(any(), any());
    }

    @Test
    @DisplayName("Ошибки CUV, fn_flow_update_shedule вернула отказ — протокол и письмо не отправляются, запись открыта")
    void cuvErrors_statusUpdateRefused_pending() {
        cuvErrors(1);
        when(viewRepository.flowUpdateSheduleStatus(SCHEDULE_ID, ScheduleStatusEnum.CHECKED_WITH_ERRORS.getCode()))
                .thenReturn(Optional.of("Расписание не найдено"));
        VuxDocumentScheduleViewEntity record = record("cuv");

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(postUploadActionsService, never()).uploadProtocol(any(), any());
        verify(postUploadActionsService, never()).sendErrorMail(any(), any());
    }

    @Test
    @DisplayName("Ошибки CUV, сбой письма — расписание открыто, статус CUV 2 уже записан")
    void cuvErrors_mailFailed_pending() {
        cuvErrors(1);
        when(postUploadActionsService.sendErrorMail(any(), any())).thenReturn(false);
        VuxDocumentScheduleViewEntity record = record("cuv");

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(cuvValidationStatusService).saveChecked(eq(record), anyInt(), eq(1), any(), any());
    }

    @Test
    @DisplayName("Технический сбой при построении контекста — ничего не делается, расписание открыто")
    void loaderFailure_pending() {
        when(loader.load(any())).thenThrow(new IllegalStateException("db down"));

        ProcessingResult result = service(true).process(record("cuv"));

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(postUploadActionsService, never()).uploadProtocol(any(), any());
        verify(cuvValidationStatusService, never()).saveNotChecked(any());
    }

    @Test
    @DisplayName("Загрузчик вернул null — дефект, расписание открыто")
    void loaderReturnsNull_pending() {
        when(loader.load(any())).thenReturn(null);

        ProcessingResult result = service(true).process(record("cuv"));

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(postUploadActionsService, never()).uploadProtocol(any(), any());
    }

    @Test
    @DisplayName("Нет workflow_run_id — ошибка _001, статус 2, протокол, письмо, статус CUV 2")
    void noWorkflowRunId_error001AndMail() {
        ValidationDataService realValidation = new ValidationDataService(List.of(
                new WorkflowRunIdRule(), new ContextExistsRule(), new UnitExistsRule(), new ValueExistsRule()));
        DataContext empty = DataContext.empty(DOC_ID, FORM, null);
        when(loader.load(any())).thenReturn(empty);
        VuxDocumentScheduleViewEntity record = record("cuv");
        record.setWorkflowRunId(null);

        ProcessingResult result = service(true, realValidation).process(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(viewRepository).flowCuvSetError(eq((long) DOC_ID), anyString(), eq("DCUV_0420415_1_3_001"));
        verify(viewRepository, times(1)).flowCuvSetError(anyLong(), anyString(), anyString());
        verify(viewRepository).flowUpdateSheduleStatus(SCHEDULE_ID, 2);
        verify(postUploadActionsService).sendErrorMail(record, protocol);
        verify(cuvValidationStatusService).saveChecked(eq(record), eq(1), eq(1), any(), any());
    }

    @Test
    @DisplayName("Нет context, unit, value — ошибки _002…_004 с workflow_run_id")
    void noFormData_errors002to004() {
        ValidationDataService realValidation = new ValidationDataService(List.of(
                new WorkflowRunIdRule(), new ContextExistsRule(), new UnitExistsRule(), new ValueExistsRule()));
        when(loader.load(any())).thenReturn(DataContext.empty(DOC_ID, FORM, 5L));

        service(true, realValidation).process(record("cuv"));

        ArgumentCaptor<String> codes = ArgumentCaptor.forClass(String.class);
        verify(viewRepository, times(3)).flowCuvSetError(eq((long) DOC_ID), anyString(), codes.capture());
        assertThat(codes.getAllValues())
                .containsExactly("DCUV_0420415_1_3_002", "DCUV_0420415_1_3_003", "DCUV_0420415_1_3_004");
    }

    @Test
    @DisplayName("Фича-флаг выключен — стандартная проверка, статус CUV 0")
    void toggleOff_standardAndNotChecked() {
        VuxDocumentScheduleViewEntity record = record("cuv");

        ProcessingResult result = service(false).process(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(loader, never()).load(any());
        verify(postUploadActionsService).handlePostUploadActions(record, protocol, List.of("protocol-ecm-id"));
        verify(cuvValidationStatusService).saveNotChecked(record);
    }

    @Test
    @DisplayName("CUV-проверка общая — любая форма с check_mode = cuv проверяется, коды ошибок по коду формы")
    void anyForm_cuvChecked() {
        ValidationDataService realValidation = new ValidationDataService(List.of(new WorkflowRunIdRule()));
        when(loader.load(any())).thenReturn(DataContext.empty(DOC_ID, "0420415.3", null));
        VuxDocumentScheduleViewEntity record = record("cuv");
        record.setDocTypeCode("0420415.3");

        service(true, realValidation).process(record);

        verify(loader).load(record);
        verify(viewRepository).flowCuvSetError(eq((long) DOC_ID), anyString(), eq("DCUV_0420415_3_001"));
        verify(cuvValidationStatusService, never()).saveNotChecked(any());
    }

    @Test
    @DisplayName("Стандартная проверка не завершена (сбой СУПЗ) — статус CUV 0 уже записан")
    void toggleOff_postUploadFailed_statusSaved() {
        when(postUploadActionsService.handlePostUploadActions(any(), any(), anyList())).thenReturn(false);
        VuxDocumentScheduleViewEntity record = record("cuv");

        ProcessingResult result = service(false).process(record);

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(cuvValidationStatusService).saveNotChecked(record);
    }

    @Test
    @DisplayName("check_mode = null — стандартная проверка без статуса CUV")
    void checkModeNull_standard() {
        VuxDocumentScheduleViewEntity record = record(null);

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(loader, never()).load(any());
        verify(cuvValidationStatusService, never()).saveNotChecked(any());
    }

    @Test
    @DisplayName("check_mode = xml — стандартная проверка")
    void checkModeXml_standard() {
        ProcessingResult result = service(true).process(record("xml"));

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(loader, never()).load(any());
        verify(documentEcmExportService, never()).requestCuvCsvExport(any(), any());
    }

    @Test
    @DisplayName("Стандартная проверка: протокол не загрузился — расписание открыто")
    void standard_protocolUploadFailed_pending() {
        when(postUploadActionsService.uploadProtocol(any(), any())).thenReturn(Optional.empty());

        ProcessingResult result = service(true).process(record(null));

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(postUploadActionsService, never()).handlePostUploadActions(any(), any(), anyList());
    }

    @Test
    @DisplayName("isCuvCheckMode: только check_mode = cuv")
    void cuvCheckMode() {
        assertThat(record("cuv").isCuvCheckMode()).isTrue();
        assertThat(record(null).isCuvCheckMode()).isFalse();
        assertThat(record("xml").isCuvCheckMode()).isFalse();
        assertThat(record("CUV").isCuvCheckMode()).isFalse();
    }

    @Test
    @DisplayName("isSupzTaskCreatedOrDisabled: заполненный supz_task_id — задача СУПЗ создана или запрещена флагом U")
    void supzTaskCreatedOrDisabled() {
        VuxDocumentScheduleViewEntity record = record("cuv");
        assertThat(record.isSupzTaskCreatedOrDisabled()).isFalse();
        record.setSupzTaskId("");
        assertThat(record.isSupzTaskCreatedOrDisabled()).isFalse();
        record.setSupzTaskId(" ");
        assertThat(record.isSupzTaskCreatedOrDisabled()).isFalse();
        record.setSupzTaskId("1");
        assertThat(record.isSupzTaskCreatedOrDisabled()).isTrue();
    }

    @Test
    @DisplayName("Справочник связей не заполнен — CUV-проверка не выполняется, статус CUV не пишется, запись ждёт")
    void missingLinks_waitsWithoutCheck() {
        VuxDocumentScheduleViewEntity record = record("cuv");
        when(missingLinksService.detect(record, context)).thenReturn(Optional.of(MissingLinksService.Reason.LINKS_NOT_FOUND));
        when(missingLinksService.waitForReference(record, context, MissingLinksService.Reason.LINKS_NOT_FOUND))
                .thenReturn(ProcessingResult.PENDING);

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(missingLinksService).waitForReference(record, context, MissingLinksService.Reason.LINKS_NOT_FOUND);
        verify(validationDataService, never()).validate(any());
        verify(cuvValidationStatusService, never()).saveChecked(any(), anyInt(), anyInt(), any(), any());
        verify(postUploadActionsService, never()).uploadProtocol(any(), any());
        verify(viewRepository, never()).flowUpdateSheduleStatus(anyInt(), anyInt());
    }

    @Test
    @DisplayName("Статус CUV-проверки получает общее число расхождений, а не число строк сводки")
    void cuvStatusCountsDeviations() {
        List<ValidationErrorDto> errors = List.of(
                new ValidationErrorDto("t", "DCUV_0420415_1_3_010", "сводка: 7.", 7),
                new ValidationErrorDto("t", "DCUV_0420415_1_3_010", "сводка: 2.", 2));
        when(validationDataService.validate(context)).thenReturn(errors);
        when(validationDataService.countExecutedChecks(errors)).thenReturn(10);
        VuxDocumentScheduleViewEntity record = record("cuv");

        service(true).process(record);

        verify(cuvValidationStatusService).saveChecked(eq(record), eq(10), eq(9), any(), any());
    }
}
