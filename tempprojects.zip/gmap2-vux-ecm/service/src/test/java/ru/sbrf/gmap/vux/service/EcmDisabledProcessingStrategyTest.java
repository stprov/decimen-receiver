package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import ru.sbrf.gmap.vux.config.FeatureToogleConfig;
import ru.sbrf.gmap.vux.dto.templates.ProtocolModelDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Запись с меткой {@code ecm_id = '-1'} (флаг расписания {@code M}): обработка без CUV-проверки и без загрузки протокола в ECM.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("EcmDisabledProcessingStrategy — загрузка в ECM запрещена (ecm_id = '-1')")
class EcmDisabledProcessingStrategyTest {

    private static final int DOC_ID = 100;
    private static final String ECM_ID_UPLOAD_DISABLED = "-1";

    @Mock
    private ProtocolBuildingService protocolBuildingService;
    @Mock
    private ValidationDefectsService validationDefectsService;
    @Mock
    private PostUploadActionsService postUploadActionsService;

    private final ProtocolModelDto protocol = ProtocolModelDto.builder().build();

    @BeforeEach
    void setUp() {
        when(validationDefectsService.loadViewDefects(DOC_ID))
                .thenReturn(new ValidationDefectsService.ViewDefects(List.of(), List.of(), List.of()));
        when(protocolBuildingService.createProtocolModelDto(anyList(), anyList(), anyList(), any())).thenReturn(protocol);
        when(postUploadActionsService.handlePostUploadActions(any(), any(), anyList())).thenReturn(true);
    }

    private EcmDisabledProcessingStrategy service(boolean cuvEnabled) {
        return new EcmDisabledProcessingStrategy(new FeatureToogleConfig(cuvEnabled), protocolBuildingService,
                validationDefectsService, postUploadActionsService);
    }

    private static VuxDocumentScheduleViewEntity record(String checkMode, String ecmId) {
        VuxDocumentScheduleViewEntity record = new VuxDocumentScheduleViewEntity();
        record.setScheduleId(10);
        record.setResultDocumentId(DOC_ID);
        record.setDocTypeCode("0420415.1.3");
        record.setCheckMode(checkMode);
        record.setEcmId(ecmId);
        return record;
    }

    @Test
    @DisplayName("supports: только метка '-1'; пустой ecm_id и id протокола — нет")
    void supports_onlyEcmUploadDisabled() {
        assertThat(service(true).supports(record("cuv", ECM_ID_UPLOAD_DISABLED))).isTrue();
        assertThat(service(true).supports(record("cuv", null))).isFalse();
        assertThat(service(true).supports(record("cuv", "protocol-ecm-id"))).isFalse();
    }

    @Test
    @DisplayName("check_mode = cuv — без CUV-проверки, протокол из view, к задаче СУПЗ приложена метка '-1'; закрытие")
    void cuv_legacyWithMarker() {
        VuxDocumentScheduleViewEntity record = record("cuv", ECM_ID_UPLOAD_DISABLED);

        ProcessingResult result = service(true).process(record);

        assertThat(result).isEqualTo(ProcessingResult.COMPLETED);
        verify(postUploadActionsService).handlePostUploadActions(record, protocol, List.of(ECM_ID_UPLOAD_DISABLED));
        verify(postUploadActionsService, never()).uploadProtocol(any(), any());
        verify(validationDefectsService, never()).getCuvErrors(any(), any());
    }

    @Test
    @DisplayName("check_mode = null — тот же путь, что и для CUV-формы")
    void checkModeNull_legacyWithMarker() {
        VuxDocumentScheduleViewEntity record = record(null, ECM_ID_UPLOAD_DISABLED);

        assertThat(service(true).process(record)).isEqualTo(ProcessingResult.COMPLETED);
        verify(postUploadActionsService).handlePostUploadActions(record, protocol, List.of(ECM_ID_UPLOAD_DISABLED));
    }

    @Test
    @DisplayName("Сбой письма или задачи СУПЗ — расписание открыто")
    void postUploadFailed_pending() {
        when(postUploadActionsService.handlePostUploadActions(any(), any(), anyList())).thenReturn(false);

        assertThat(service(true).process(record("cuv", ECM_ID_UPLOAD_DISABLED))).isEqualTo(ProcessingResult.PENDING);
    }

    @Test
    @DisplayName("Неожиданное исключение — расписание открыто")
    void unexpectedException_pending() {
        when(validationDefectsService.loadViewDefects(DOC_ID)).thenThrow(new IllegalStateException("boom"));

        assertThat(service(true).process(record("cuv", ECM_ID_UPLOAD_DISABLED))).isEqualTo(ProcessingResult.PENDING);
    }
}
