package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.repository.VuxDocumentScheduleViewRepository;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

/**
 * Оркестратор: закрытие расписания только при завершённой обработке.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("OrchestratorService")
class OrchestratorServiceTest {

    @Mock
    private VuxDocumentScheduleViewRepository scheduleRepository;
    @Mock
    private VuxDocumentValidationResultViewRepository viewRepository;
    @Mock
    private ScheduleRecordStrategy initial;
    @Mock
    private ScheduleRecordStrategy followUp;

    private OrchestratorService service() {
        return new OrchestratorService(scheduleRepository, viewRepository, List.of(initial, followUp));
    }

    private static VuxDocumentScheduleViewEntity record(int scheduleId, String ecmId) {
        VuxDocumentScheduleViewEntity record = new VuxDocumentScheduleViewEntity();
        record.setScheduleId(scheduleId);
        record.setResultDocumentId(scheduleId * 10);
        record.setEcmId(ecmId);
        return record;
    }

    private void route(VuxDocumentScheduleViewEntity newRecord, VuxDocumentScheduleViewEntity existingRecord) {
        when(initial.supports(any())).thenAnswer(i -> i.getArgument(0) == newRecord);
        when(followUp.supports(any())).thenAnswer(i -> i.getArgument(0) == existingRecord);
    }

    @Test
    @DisplayName("Пустое расписание — функции загрузки вызваны, стратегии не вызываются")
    void emptySchedule() {
        when(scheduleRepository.findAll()).thenReturn(List.of());

        service().run();

        verify(viewRepository).fnLoadShedule();
        verify(viewRepository).processSchedule();
        verifyNoInteractions(initial, followUp);
    }

    @Test
    @DisplayName("COMPLETED — расписание закрывается, PENDING — нет")
    void resolvesOnlyCompleted() {
        VuxDocumentScheduleViewEntity first = record(1, null);
        VuxDocumentScheduleViewEntity second = record(2, "ecm");
        when(scheduleRepository.findAll()).thenReturn(List.of(first, second));
        route(first, second);
        when(initial.process(first)).thenReturn(ProcessingResult.PENDING);
        when(followUp.process(second)).thenReturn(ProcessingResult.COMPLETED);
        when(viewRepository.flowResolveShedule(2)).thenReturn(Optional.of("3"));

        service().run();

        verify(viewRepository, never()).flowResolveShedule(1);
        verify(viewRepository).flowResolveShedule(2);
        verify(initial, never()).process(second);
        verify(followUp, never()).process(first);
    }

    @Test
    @DisplayName("Сбой закрытия одной записи не прерывает обработку остальных")
    void resolveFailure_doesNotStopCycle() {
        VuxDocumentScheduleViewEntity first = record(1, null);
        VuxDocumentScheduleViewEntity second = record(2, null);
        when(scheduleRepository.findAll()).thenReturn(List.of(first, second));
        when(initial.supports(any())).thenReturn(true);
        when(followUp.supports(any())).thenReturn(false);
        when(initial.process(any())).thenReturn(ProcessingResult.COMPLETED);
        when(viewRepository.flowResolveShedule(1)).thenThrow(new IllegalStateException("db"));
        when(viewRepository.flowResolveShedule(2)).thenReturn(Optional.of("расписание должно быть в статусе 1 или 2"));

        service().run();

        verify(viewRepository).flowResolveShedule(1);
        verify(viewRepository).flowResolveShedule(2);
    }

    @Test
    @DisplayName("Запись без подходящей стратегии не обрабатывается, расписание не закрывается, цикл продолжается")
    void unsupportedRecord_skipped() {
        VuxDocumentScheduleViewEntity unsupported = record(1, null);
        VuxDocumentScheduleViewEntity supported = record(2, "ecm");
        when(scheduleRepository.findAll()).thenReturn(List.of(unsupported, supported));
        route(null, supported);
        when(followUp.process(supported)).thenReturn(ProcessingResult.COMPLETED);
        when(viewRepository.flowResolveShedule(2)).thenReturn(Optional.of("3"));

        service().run();

        verify(initial, never()).process(any());
        verify(followUp, never()).process(unsupported);
        verify(viewRepository, never()).flowResolveShedule(1);
        verify(viewRepository).flowResolveShedule(2);
    }

    @Test
    @DisplayName("Запись поддерживают обе стратегии — обрабатывает только первая по @Order, расписание закрывается один раз")
    void overlappingStrategies_firstWins() {
        VuxDocumentScheduleViewEntity record = record(1, null);
        when(scheduleRepository.findAll()).thenReturn(List.of(record));
        when(initial.supports(any())).thenReturn(true);
        when(followUp.supports(any())).thenReturn(true);
        when(initial.process(record)).thenReturn(ProcessingResult.COMPLETED);
        when(viewRepository.flowResolveShedule(1)).thenReturn(Optional.of("2"));

        service().run();

        verify(initial).process(record);
        verify(followUp, never()).process(any());
        verify(viewRepository, times(1)).flowResolveShedule(1);
    }

    @Test
    @DisplayName("Сбой загрузки расписания не выбрасывается наружу")
    void loadFailure_swallowed() {
        when(viewRepository.fnLoadShedule()).thenThrow(new IllegalStateException("db"));

        service().run();

        verifyNoInteractions(initial, followUp);
    }
}
