package ru.sbrf.gmap.vux.service.validation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.sbrf.gmap.vux.dto.ValidationErrorDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvContextDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvUnitDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvValueDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolCheckRecordDto;
import ru.sbrf.gmap.vux.service.ValidationDataService;
import ru.sbrf.gmap.vux.service.checks.ContextExistsRule;
import ru.sbrf.gmap.vux.service.checks.CuvErrors;
import ru.sbrf.gmap.vux.service.checks.DataContext;
import ru.sbrf.gmap.vux.service.checks.MissingContextDescriptionsRule;
import ru.sbrf.gmap.vux.service.checks.MissingUnitDescriptionsRule;
import ru.sbrf.gmap.vux.service.checks.OrphanContextIdsRule;
import ru.sbrf.gmap.vux.service.checks.OrphanUnitIdsRule;
import ru.sbrf.gmap.vux.service.checks.SummaryAnalyticsRule;
import ru.sbrf.gmap.vux.service.checks.TaxonomyMismatchRule;
import ru.sbrf.gmap.vux.service.checks.UnitExistsRule;
import ru.sbrf.gmap.vux.service.checks.ValueExistsRule;
import ru.sbrf.gmap.vux.service.checks.WorkflowRunIdRule;
import ru.sbrf.gmap.vux.service.parser.XmlParserService;

import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * CUV-правила 1–10 на общем контексте.
 */
@DisplayName("CUV-правила: общий механизм")
class CuvRulesTest {

    private static final String FORM = "0420415.1.3";
    private static final long WR = 42L;

    private static CuvContextDto context(String id) {
        return CuvContextDto.builder().contextId(id).taxonomy("7.1").workflowRunId(WR).build();
    }

    private static CuvUnitDto unit(String id) {
        return CuvUnitDto.builder().unitId(id).taxonomy("7.1").workflowRunId(WR).build();
    }

    private static CuvValueDto value(String contextId, String unitId) {
        return CuvValueDto.builder().elementName("e").value("1").contextId(contextId).unitId(unitId)
                .taxonomy("7.1").workflowRunId(WR).build();
    }

    private static DataContext ctx(String form, List<CuvContextDto> contexts, List<CuvUnitDto> units,
                                   List<CuvValueDto> values, Set<String> dataTaxonomies) {
        return new DataContext(1, form, WR, contexts, units, values, List.of(), dataTaxonomies);
    }

    private static DataContext ctx(List<CuvContextDto> contexts, List<CuvUnitDto> units, List<CuvValueDto> values) {
        return ctx(FORM, contexts, units, values, Set.of());
    }

    @Test
    @DisplayName("Код ошибки — по коду формы, заголовок — с кодом формы")
    void codesByForm() {
        assertThat(CuvErrors.code("0420415.1.3", "005")).isEqualTo("DCUV_0420415_1_3_005");
        assertThat(CuvErrors.code("0420415.3", "010")).isEqualTo("DCUV_0420415_3_010");
        assertThat(CuvErrors.code(null, "001")).isEqualTo("DCUV_UNKNOWN_001");
        assertThat(CuvErrors.title("0420415.3")).endsWith("по форме 0420415.3");
    }

    @Test
    @DisplayName("Проверка 1: workflow_run_id не заполнен или <= 0 — _001; задан — ошибки нет")
    void workflowRunId() {
        WorkflowRunIdRule rule = new WorkflowRunIdRule();
        assertThat(rule.validate(DataContext.empty(1, FORM, null)))
                .extracting(ValidationErrorDto::errorCode).containsExactly("DCUV_0420415_1_3_001");
        assertThat(rule.validate(DataContext.empty(1, FORM, 0L))).hasSize(1);
        assertThat(rule.validate(DataContext.empty(1, FORM, WR))).isEmpty();
    }

    @Test
    @DisplayName("Проверки 2–4: нет context, unit, value — тексты по постановке с workflow_run_id")
    void noData() {
        DataContext empty = DataContext.empty(1, FORM, WR);
        assertThat(new ContextExistsRule().validate(empty)).extracting(ValidationErrorDto::errorMessage)
                .containsExactly("По workflow_run_id = 42 НЕ получен context.");
        assertThat(new UnitExistsRule().validate(empty)).extracting(ValidationErrorDto::errorMessage)
                .containsExactly("По workflow_run_id = 42 НЕ получен набор единиц измерений unit.");
        assertThat(new ValueExistsRule().validate(empty)).extracting(ValidationErrorDto::errorMessage)
                .containsExactly("По workflow_run_id = 42 НЕ получен набор значений value.");
    }

    @Test
    @DisplayName("Проверки 5, 6: лишние context и unit; id в тексте отсортированы; пустой unit_id у value не мешает")
    void orphans() {
        DataContext data = ctx(List.of(context("c3"), context("c1"), context("c2")),
                List.of(unit("u2"), unit("u1")),
                List.of(value("c2", null), value("c2", "u1")));

        assertThat(new OrphanContextIdsRule().validate(data)).extracting(ValidationErrorDto::errorMessage)
                .containsExactly("Обнаружены лишние context: [c1, c3].");
        assertThat(new OrphanUnitIdsRule().validate(data)).extracting(ValidationErrorDto::errorMessage)
                .containsExactly("Обнаружены лишние unit: [u2].");
    }

    @Test
    @DisplayName("Проверка 7: context_id без описания, id отсортированы")
    void missingContexts() {
        DataContext data = ctx(List.of(context("c1")), List.of(unit("u1")),
                List.of(value("c1", "u1"), value("c9", "u1"), value("c5", "u1")));

        assertThat(new MissingContextDescriptionsRule().validate(data))
                .extracting(ValidationErrorDto::errorCode, ValidationErrorDto::errorMessage)
                .containsExactly(org.assertj.core.groups.Tuple.tuple("DCUV_0420415_1_3_007",
                        "Обнаружены context_id без описания: [c5, c9]."));
    }

    @Test
    @DisplayName("Проверка 8: пустой unit_id — не ошибка; в тексте все unit_id")
    void missingUnits() {
        DataContext data = ctx(List.of(context("c1")), List.of(unit("u1")),
                List.of(value("c1", null), value("c1", ""), value("c1", "u3"), value("c1", "u2")));

        assertThat(new MissingUnitDescriptionsRule().validate(data))
                .extracting(ValidationErrorDto::errorCode, ValidationErrorDto::errorMessage)
                .containsExactly(org.assertj.core.groups.Tuple.tuple("DCUV_0420415_1_3_008",
                        "Обнаружены unit_id без описания: [u2, u3]."));
        DataContext onlyEmpty = ctx(List.of(context("c1")), List.of(unit("u1")), List.of(value("c1", null)));
        assertThat(new MissingUnitDescriptionsRule().validate(onlyEmpty)).isEmpty();
    }

    @Test
    @DisplayName("Проверка 9: версия таксономии data (xbrlvers) участвует в сравнении")
    void taxonomy() {
        TaxonomyMismatchRule rule = new TaxonomyMismatchRule();
        List<CuvContextDto> contexts = List.of(context("c1"));
        List<CuvUnitDto> units = List.of(unit("u1"));
        List<CuvValueDto> values = List.of(value("c1", "u1"));

        assertThat(rule.validate(ctx(FORM, contexts, units, values, Set.of("7.1")))).isEmpty();
        assertThat(rule.validate(ctx(FORM, contexts, units, values, Set.of("7.2"))))
                .extracting(ValidationErrorDto::errorMessage)
                .containsExactly("По workflow_run_id = 42 выявлено несовпадение версий таксономий.");
    }

    @Test
    @DisplayName("Проверка 9: пустая таксономия не считается отдельной версией, пробелы по краям не учитываются")
    void taxonomy_blankIgnored() {
        TaxonomyMismatchRule rule = new TaxonomyMismatchRule();
        List<CuvContextDto> contexts = List.of(context("c1"),
                CuvContextDto.builder().contextId("c2").taxonomy(null).workflowRunId(WR).build());
        List<CuvUnitDto> units = List.of(CuvUnitDto.builder().unitId("u1").taxonomy(" 7.1 ").workflowRunId(WR).build());
        List<CuvValueDto> values = List.of(value("c1", "u1"),
                CuvValueDto.builder().elementName("e").value("1").contextId("c2").unitId("u1")
                        .taxonomy("  ").workflowRunId(WR).build());

        assertThat(rule.validate(ctx(FORM, contexts, units, values, Set.of("", "7.1")))).isEmpty();
    }

    @Test
    @DisplayName("Данные отчёта есть, версии таксономии нет ни в одной таблице — ошибка _009")
    void taxonomy_missing_error() {
        TaxonomyMismatchRule rule = new TaxonomyMismatchRule();
        List<CuvContextDto> contexts = List.of(CuvContextDto.builder().contextId("c1").taxonomy(" ").workflowRunId(WR).build());
        List<CuvUnitDto> units = List.of(CuvUnitDto.builder().unitId("u1").workflowRunId(WR).build());
        List<CuvValueDto> values = List.of(CuvValueDto.builder().elementName("e").value("1").contextId("c1").unitId("u1")
                .workflowRunId(WR).build());

        assertThat(rule.validate(ctx(FORM, contexts, units, values, Set.of())))
                .extracting(ValidationErrorDto::errorMessage)
                .containsExactly("По workflow_run_id = 42 не указана версия таксономии.");
    }

    @Test
    @DisplayName("Проверка 9: данных отчёта нет — ошибок нет (это ошибки 002–004)")
    void taxonomy_noReportData_noError() {
        assertThat(new TaxonomyMismatchRule().validate(ctx(FORM, List.of(), List.of(), List.of(), Set.of()))).isEmpty();
    }

    @Test
    @DisplayName("Проверка 10 включена; без справочника связей расхождений не выдаёт")
    void summaryEnabled() {
        SummaryAnalyticsRule rule = new SummaryAnalyticsRule(new XmlParserService(), false);

        assertThat(rule.isEnabled()).isTrue();
        assertThat(rule.validate(ctx(List.of(context("c1")), List.of(unit("u1")), List.of(value("c1", "u1"))))).isEmpty();
    }

    @Test
    @DisplayName("Нет workflow_run_id — только _001, шаг 2 не выполняется")
    void noWorkflowRunId_onlyError001() {
        ValidationDataService service = allRules();
        List<ValidationErrorDto> errors = service.validate(DataContext.empty(1, FORM, null));

        assertThat(errors).extracting(ValidationErrorDto::errorCode).containsExactly("DCUV_0420415_1_3_001");
        assertThat(service.countExecutedChecks(errors)).isEqualTo(1);
        assertThat(service.getChecks(errors)).extracting(ProtocolCheckRecordDto::getCheckResult)
                .containsExactly("Выявлено", "Не проверялось", "Не проверялось", "Не проверялось", "Не проверялось",
                        "Не проверялось", "Не проверялось", "Не проверялось", "Не проверялось", "Не проверялось");
    }

    @Test
    @DisplayName("workflow_run_id есть, данных нет — _002, _003, _004 другой формы с её кодом")
    void noData_errors002to004_otherForm() {
        ValidationDataService service = allRules();
        List<ValidationErrorDto> errors = service.validate(DataContext.empty(1, "0420415.3", WR));

        assertThat(errors).extracting(ValidationErrorDto::errorCode)
                .containsExactly("DCUV_0420415_3_002", "DCUV_0420415_3_003", "DCUV_0420415_3_004");
        assertThat(service.countExecutedChecks(errors)).isEqualTo(4);
    }

    @Test
    @DisplayName("Данные согласованы — ошибок нет, выполнено 10 проверок")
    void consistentData_noErrors() {
        ValidationDataService service = allRules();
        DataContext data = ctx(List.of(context("c1")), List.of(unit("u1")), List.of(value("c1", "u1")));

        List<ValidationErrorDto> errors = service.validate(data);

        assertThat(errors).isEmpty();
        assertThat(service.countExecutedChecks(errors)).isEqualTo(10);
    }

    private static ValidationDataService allRules() {
        return new ValidationDataService(List.of(new WorkflowRunIdRule(), new ContextExistsRule(), new UnitExistsRule(),
                new ValueExistsRule(), new OrphanContextIdsRule(), new OrphanUnitIdsRule(),
                new MissingContextDescriptionsRule(), new MissingUnitDescriptionsRule(), new TaxonomyMismatchRule(),
                new SummaryAnalyticsRule(new XmlParserService(), false)));
    }
}
