package ru.sbrf.gmap.vux.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import ru.sbrf.gmap.vux.dto.cuv.CuvContextDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvLinkDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvUnitDto;
import ru.sbrf.gmap.vux.dto.cuv.CuvValueDto;
import ru.sbrf.gmap.vux.entity.VuxDocumentScheduleViewEntity;
import ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository;
import ru.sbrf.gmap.vux.service.checks.DataContext;

import java.sql.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static ru.sbrf.gmap.vux.repository.VuxDocumentValidationResultViewRepository.MISSING_LINKS_MAIL_SUBJECT_MARKER;

/**
 * Ожидание справочника связей для проверки 10.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("MissingLinksService — справочник связей не заполнен")
class MissingLinksServiceTest {

    private static final int DOC_ID = 100;

    @Mock
    private PostUploadActionsService postUploadActionsService;
    @Mock
    private VuxDocumentValidationResultViewRepository repository;

    private MissingLinksService service;

    @BeforeEach
    void setUp() {
        service = new MissingLinksService(postUploadActionsService, repository, 24);
        when(repository.findLastMailTime(any(), anyString())).thenReturn(Optional.empty());
        when(postUploadActionsService.sendNotificationMail(any(), anyString(), anyString())).thenReturn(true);
    }

    private static VuxDocumentScheduleViewEntity record(String tableName) {
        VuxDocumentScheduleViewEntity record = new VuxDocumentScheduleViewEntity();
        record.setScheduleId(10);
        record.setResultDocumentId(DOC_ID);
        record.setDocTypeCode("0420415.1.3");
        record.setDocTypeName("Сведения <о ценных бумагах>");
        record.setReportDate(Date.valueOf("2026-10-01"));
        record.setTableName(tableName);
        return record;
    }

    private static DataContext context(Set<String> taxonomies, List<CuvLinkDto> links) {
        String taxonomy = taxonomies.isEmpty() ? null : taxonomies.iterator().next();
        return new DataContext(DOC_ID, "0420415.1.3", 5L,
                List.of(CuvContextDto.builder().contextId("c1").taxonomy(taxonomy).build()),
                List.of(CuvUnitDto.builder().unitId("u1").taxonomy(taxonomy).build()),
                List.of(CuvValueDto.builder().elementName("e").contextId("c1").unitId("u1").taxonomy(taxonomy).build()),
                List.of(), taxonomies.size() > 1 ? taxonomies : Set.of(), links, Map.of());
    }

    @Test
    @DisplayName("Ждать справочник нужно, только если данные формы есть и версия таксономии одна")
    void detect() {
        CuvLinkDto link = CuvLinkDto.builder().columnName("kol").columnXbrlType("measure").measureId("m").build();
        String table = "s_grnplm_as_cib_gm_vux.t_vux_form_0420415_1_3_data";

        assertThat(service.detect(record(table), context(Set.of("7.1"), List.of())))
                .contains(MissingLinksService.Reason.LINKS_NOT_FOUND);
        assertThat(service.detect(record(null), context(Set.of("7.1"), List.of())))
                .contains(MissingLinksService.Reason.DATA_TABLE_NOT_SET);
        assertThat(service.detect(record(table), context(Set.of("7.1"), List.of(link)))).isEmpty();
        assertThat(service.detect(record(table), context(Set.of("7.1", "7.2"), List.of()))).isEmpty();
        assertThat(service.detect(record(table), context(Set.of(), List.of()))).isEmpty();
        assertThat(service.detect(record(table), DataContext.empty(DOC_ID, "0420415.1.3", 5L))).isEmpty();
    }

    @Test
    @DisplayName("Письма за интервал не было — письмо с меткой в теме, расписание остаётся открытым")
    void sendsMailWhenNoRecentOne() {
        when(repository.existsMailSince(eq((long) DOC_ID), eq(MISSING_LINKS_MAIL_SUBJECT_MARKER), eq(24))).thenReturn(false);
        VuxDocumentScheduleViewEntity record = record("t_vux_form_0420415_1_3_data");

        ProcessingResult result = service.waitForReference(record, context(Set.of("7.1"), List.of()),
                MissingLinksService.Reason.LINKS_NOT_FOUND);

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        ArgumentCaptor<String> subject = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> body = ArgumentCaptor.forClass(String.class);
        verify(postUploadActionsService).sendNotificationMail(eq(record), subject.capture(), body.capture());
        assertThat(subject.getValue()).isEqualTo(
                "XBRL \\ 0420415.1.3 Проверка не выполнена: не заполнен справочник связей. Отчётная дата: 2026-10-01");
        assertThat(body.getValue())
                .contains("нет связей показателей отчёта с витриной t_vux_form_0420415_1_3_data для таксономии 7.1")
                .contains("DCUV_0420415_1_3_010")
                .contains("повторяется раз в сутки")
                .contains("&lt;о ценных бумагах&gt;")
                .contains("Документ: 100. Расписание: 10.");
    }

    @Test
    @DisplayName("Письмо уже было за интервал — повторно не отправляется")
    void skipsMailWithinInterval() {
        when(repository.existsMailSince(any(), anyString(), any())).thenReturn(true);

        ProcessingResult result = service.waitForReference(record("t"), context(Set.of("7.1"), List.of()),
                MissingLinksService.Reason.LINKS_NOT_FOUND);

        assertThat(result).isEqualTo(ProcessingResult.PENDING);
        verify(postUploadActionsService, never()).sendNotificationMail(any(), anyString(), anyString());
    }

    @Test
    @DisplayName("Не задана таблица data — отдельный текст причины")
    void dataTableNotSetText() {
        String body = service.body(record(null), "7.1", MissingLinksService.Reason.DATA_TABLE_NOT_SET);

        assertThat(body).contains("не задана таблица витрины data (table_name)")
                .contains("указать таблицу витрины data для формы 0420415.1.3");
    }
}
