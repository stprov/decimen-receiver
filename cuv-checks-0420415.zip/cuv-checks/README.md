# Проверки формы 0420415.1.3 — новая реализация

## Что в архиве

```
src/main/java/ru/sbrf/gmap/vux/service/checks/
  CheckStage, CheckStatus, RuleMeta, Violation, RuleResult   — модель: этап, статус, паспорт, нарушение, результат
  CheckRule                                                  — интерфейс проверки (вместо ValidationRule)
  CheckRunner                                                — запуск проверок (вместо ValidationDataService)
  CheckDataContext                                           — данные для проверок (+ workflowRunId, без null)
  CuvContextLoader                                           — загрузка данных (вместо buildCheckDataContext)
  CuvChecksConfig                                            — реестр всех 10 проверок
  CuvProtocolMapper                                          — результаты → строки протокола
  rules/
    WorkflowRunIdCheck   001
    PartPresentCheck     002–004 (один класс, три экземпляра)
    ReferenceCheck       005–008 (один класс, четыре экземпляра)
    TaxonomyCheck        009
  reconciliation/        010 — сверка «витрина ↔ отчёт» через ключ факта
    FactKey, Fact, FactSet, DimensionParser,
    ExpectedFactsBuilder (витрина), ActualFactsBuilder (отчёт),
    FactValueComparator, ReconciliationCheck
src/test/java/...        27 тестов: каждая проверка, запускалка, протокол
```

## Как внедрить

1. Удалить старое: `ValidationRule`, `ValidationDataService`, 10 классов `*Rule` в `service/checks`,
   `ValidateDataCommonUtil`, `ImageTypeEnum` оставить (он нужен для загрузки CSV).
2. Заменить `CheckDataContext` новым (добавлен `workflowRunId`).
3. Положить новые классы, удалить старые тесты `SummaryAnalyticsRuleTest`, `WorkflowRunIdRuleTest`,
   `ValidationDataServiceTest` (они на старый API и почти все `@Disabled`).
4. Переписать CUV-ветку `OrchestratorService` (ниже).
5. В конфиг добавить, если нужно что-то выключить:
   `config.cuv-checks.disabled-codes: DCUV_0420415_1_3_010`

## Изменения в OrchestratorService

### Расписание закрывается только после успешной обработки

```java
allRecords.stream().filter(r -> r.getEcmId() == null).forEach(record -> {
    if (processNewDocument(record)) {                       // было: всегда
        vuxDocumentValidationResultViewRepository.flowResolveShedule(record.getScheduleId());
    }
});

private boolean processNewDocument(VuxDocumentScheduleViewEntity record) {
    try {
        if (featureToggleConfig.isCuvValidationEnabled() && CUV_FORM_DOC_TYPES.contains(record.getDocTypeCode())) {
            processCuvFormValidation(record);
        } else {
            processStandardNewDocumentValidation(record);
        }
        return true;
    } catch (Exception e) {
        log.error("Technical failure for docId={}, schedule stays open for retry", record.getResultDocumentId(), e);
        return false;
    }
}
```

### CUV-ветка

```java
private void processCuvFormValidation(VuxDocumentScheduleViewEntity record) {
    Integer docId = record.getResultDocumentId();

    CheckDataContext ctx = cuvContextLoader.load(docId);    // никогда не null
    List<RuleResult> results = checkRunner.run(ctx);

    // стандартные дефекты из view — как и раньше
    var defects     = getResultsForDocWithRnLimit(docId);
    var viewErrors  = mapper.toProtocolTableRecordDtoList(getErrorsList(defects));
    var viewWarns   = mapper.toProtocolTableRecordDtoList(getWarningsList(defects));
    var viewChecks  = logMapper.toProtocolCheckRecordDtoList(
                          vuxDocumentValidationLogRepository.findAllByDocIdOrderByErrorCountDesc(docId));

    boolean blocked = CuvProtocolMapper.hasBlocking(results) || !viewErrors.isEmpty();

    if (blocked) {
        saveCuvViolations(docId, results);                   // fn_flow_cuv_set_error, с лимитом
    }

    ProtocolModelDto protocol = ProtocolModelDto.builder()
            .documentDate(String.valueOf(record.getReportDate()))
            .checkDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern(DATETIME_FORMAT_PROTOCOL_FIELD)))
            .reportType(record.getDocTypeName())
            .documentNumber(record.getDocNumber())
            .checksList(concat(viewChecks, CuvProtocolMapper.checks(results)))
            .objects(concat(viewErrors, CuvProtocolMapper.rows(results, RuleTypeEnum.E, errorSet)))
            .warnings(concat(viewWarns, CuvProtocolMapper.rows(results, RuleTypeEnum.W, errorSet)))
            .totalErrorCount(calculateTotalCount(viewChecks, RuleTypeEnum.E) + CuvProtocolMapper.total(results, RuleTypeEnum.E))
            .totalWarningCount(calculateTotalCount(viewChecks, RuleTypeEnum.W) + CuvProtocolMapper.total(results, RuleTypeEnum.W))
            .build();

    if (blocked) {
        uploadProtocolToEcmAndResolve(record, protocol);     // письмо с ошибками
        return;
    }

    List<String> csvIds = uploadAllCsvOrThrow(docId, ctx);   // все три CSV или исключение → повтор
    uploadProtocolToEcmAndResolve(record, protocol, csvIds); // задача в СУПЗ
}

private void saveCuvViolations(Integer docId, List<RuleResult> results) {
    for (RuleResult r : results) {
        if (r.status() == CheckStatus.ERROR) {
            repo.flowCuvSetError(docId.longValue(), "Проверка не выполнена: " + r.technicalError(), r.meta().code());
        }
        r.violations().stream().limit(errorSet).forEach(v ->
            repo.flowCuvSetError(docId.longValue(), v.message(), r.meta().code()));
    }
}
```

`uploadAllCsvOrThrow` — то же, что сейчас `uploadCsvToEcm` ×3, но при неудаче бросает исключение,
а не возвращает `null`: задача в СУПЗ без полного комплекта CSV создаваться не должна.

### Попутно (вне CUV, но мешает протоколу)

- `handlePostUploadActions`: предупреждения считать по `protocolModelDto.getWarnings()`, а не по `getObjects()`.
- `TASK_PROTOCOL_WARNING_RESULT` подставлять через `String.format(..., warningsCounter)`.

## Что нужно уточнить до включения проверки 010

1. **Справочник `t_adm_xbrl_enum_values`.** Код предполагает ключ (таксономия, enum_id, имя члена домена)
   и что в витрине лежит `enumValueText` или `enumValueCode`. Если не так — поправить
   `FactValueComparator.enumEquals` (один метод).
2. **Полнота `analytical_section`.** Предполагается, что в нём перечислены все explicit-оси контекста.
   Проверяется одним прогоном на реальном пакете: если нет — будут пары «потерян / лишний»
   с одинаковыми бумагой и строкой.
3. **Уровни 005 и 006.** Сделаны предупреждениями (W): неиспользуемое описание не портит отчёт.
   Если по постановке это ошибки — заменить `RuleMeta.warning` на `RuleMeta.error` в `CuvChecksConfig`.

## Как проверялось

Код скомпилирован и прогнан на JDK 21. Maven Central из среды проверки недоступен, поэтому классы
проекта (DTO, сущности, репозитории) и библиотеки (Lombok, JUnit, AssertJ) были заменены
эквивалентами с теми же именами и методами, а XML разбирался DOM-аналогом `XmlParserService`.
Сами проверки и тесты — без изменений. В проекте нужно прогнать `mvn test` штатно.
