package ru.sbrf.gmap.vux.service.checks.reconciliation;

import ru.sbrf.gmap.vux.entity.VuxDataXbrlLinkEntity;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V13DataEntity;
import ru.sbrf.gmap.vux.service.parser.XmlParserException;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Сторона «витрина»: каждая строка {@code t_vux_form_0420415_1_3_data}
 * разворачивается в набор фактов по настройке {@code t_adm_data_xbrl_link}.
 * <p>
 * Одна строка витрины × одна строка настройки = один ожидаемый факт:
 * <pre>
 *   строка data (бумага=X, строка=Y, kolcprinbuxuch=100)
 *   + link (column=kolcprinbuxuch, measure=KolCZB…, analytical_section=&lt;оси&gt;)
 *   = факт KolCZB… [бумага=X, строка=Y, оси] → 100
 * </pre>
 * Колонки типа {@code taxis} в факты не превращаются: это сами id бумаги и строки,
 * они уже входят в ключ.
 * <p>
 * Ошибки настройки (колонки нет в сущности, неразбираемый analytical_section,
 * неизвестный column_xbrl_type) не роняют сверку: они становятся нарушениями,
 * а проблемная строка настройки пропускается.
 */
public class ExpectedFactsBuilder {

    private final DimensionParser dimensionParser;

    public ExpectedFactsBuilder(DimensionParser dimensionParser) {
        this.dimensionParser = dimensionParser;
    }

    /** Строка настройки, уже проверенная и подготовленная к применению. */
    record PreparedLink(VuxDataXbrlLinkEntity link, String element, String explicitDims, Method getter) {
    }

    public FactSet build(List<VuxForm0420415V13DataEntity> rows, List<PreparedLink> links) {
        FactSet set = new FactSet("витрине");
        for (VuxForm0420415V13DataEntity row : rows) {
            for (PreparedLink pl : links) {
                String value = read(pl.getter(), row);
                if (value == null) {
                    continue; // пустая ячейка витрины → факта в отчёте быть не должно
                }
                FactKey key = new FactKey(pl.element(), trim(row.getIdCzennojbumagi()), trim(row.getIdStroki()), pl.explicitDims());
                set.add(Fact.expected(key, value, pl.link()));
            }
        }
        return set;
    }

    /**
     * Отбирает настройки для таблицы и таксономии и готовит их: имя показателя,
     * канонические оси, getter колонки. Проблемы настройки пишутся в {@code problems}.
     */
    public List<PreparedLink> prepare(List<VuxDataXbrlLinkEntity> allLinks, String taxonomy, String tableName, FactSet problems) {
        Map<String, Method> getterCache = new LinkedHashMap<>();
        return allLinks.stream()
                .filter(l -> l.getId() != null)
                .filter(l -> taxonomy.equals(l.getId().getTaxonomy()))
                .filter(l -> tableName.equals(l.getId().getTableName()))
                .filter(l -> !"taxis".equals(l.getColumnXbrlType()))
                .map(l -> prepareOne(l, getterCache, problems))
                .filter(java.util.Objects::nonNull)
                .toList();
    }

    private PreparedLink prepareOne(VuxDataXbrlLinkEntity link, Map<String, Method> cache, FactSet problems) {
        String column = link.getId().getColumnName();
        String ref = "t_adm_data_xbrl_link." + column;

        String element = DimensionParser.localName(elementOf(link));
        if (element == null) {
            problems.problem(ref, "Настройка сверки: для колонки %s (тип %s) не задан элемент XBRL"
                    .formatted(column, link.getColumnXbrlType()));
            return null;
        }

        Method getter = cache.computeIfAbsent(column, ExpectedFactsBuilder::findGetter);
        if (getter == null) {
            problems.problem(ref, "Настройка сверки: в витрине нет колонки %s".formatted(column));
            return null;
        }

        String dims;
        try {
            dims = dimensionParser.parseExplicit(link.getAnalyticalSection());
        } catch (XmlParserException e) {
            problems.problem(ref, "Настройка сверки: не разбирается analytical_section колонки %s".formatted(column));
            return null;
        }
        return new PreparedLink(link, element, dims, getter);
    }

    /** Какой элемент XBRL соответствует колонке — по типу колонки. */
    static String elementOf(VuxDataXbrlLinkEntity link) {
        String type = link.getColumnXbrlType();
        if (type == null) {
            return null;
        }
        return switch (type) {
            case "measure" -> link.getMeasureId();
            case "enumerator" -> link.getParameterId() != null ? link.getParameterId() : link.getAxisId();
            default -> null;
        };
    }

    /** snake_case колонки → getter сущности: {@code kol_zajm_peredan} → {@code getKolZajmPeredan}. */
    static Method findGetter(String column) {
        StringBuilder name = new StringBuilder("get");
        boolean upper = true;
        for (char c : column.toCharArray()) {
            if (c == '_') {
                upper = true;
            } else {
                name.append(upper ? Character.toUpperCase(c) : c);
                upper = false;
            }
        }
        try {
            return VuxForm0420415V13DataEntity.class.getMethod(name.toString());
        } catch (NoSuchMethodException e) {
            return null;
        }
    }

    private static String read(Method getter, VuxForm0420415V13DataEntity row) {
        try {
            Object v = getter.invoke(row);
            if (v == null) {
                return null;
            }
            return v instanceof BigDecimal bd ? bd.toPlainString() : v.toString().trim();
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Не удалось прочитать " + getter.getName(), e);
        }
    }

    private static String trim(String s) {
        return s == null ? null : s.trim();
    }
}
