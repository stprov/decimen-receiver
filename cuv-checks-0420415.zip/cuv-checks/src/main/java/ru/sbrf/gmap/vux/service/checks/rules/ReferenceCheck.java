package ru.sbrf.gmap.vux.service.checks.rules;

import ru.sbrf.gmap.vux.service.checks.CheckDataContext;
import ru.sbrf.gmap.vux.service.checks.CheckRule;
import ru.sbrf.gmap.vux.service.checks.RuleMeta;
import ru.sbrf.gmap.vux.service.checks.Violation;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;

/**
 * 005–008. Ссылочная целостность: каждый id из множества «источник»
 * должен присутствовать в множестве «цель».
 * <p>
 * Все четыре проверки — одна и та же операция «источник минус цель»,
 * отличаются только тем, что считать источником и целью:
 * <pre>
 *   005  источник = context_id из context,   цель = context_id из value  → «context никем не используется»
 *   006  источник = unit_id из unit,         цель = unit_id из value     → «unit никем не используется»
 *   007  источник = context_id из value,     цель = context_id из context → «ссылка на несуществующий context»
 *   008  источник = unit_id из value,        цель = unit_id из unit       → «ссылка на несуществующий unit»
 * </pre>
 * Пустые и {@code null} id отбрасываются: у нечисловых фактов нет unit_id, и это не ошибка.
 * На каждый «лишний» id — отдельное нарушение.
 */
public class ReferenceCheck implements CheckRule {

    private final RuleMeta meta;
    private final Function<CheckDataContext, Collection<String>> source;
    private final Function<CheckDataContext, Collection<String>> target;
    private final String messageTemplate;

    /**
     * @param messageTemplate шаблон сообщения с одним {@code %s} — туда подставится id
     */
    public ReferenceCheck(RuleMeta meta,
                          Function<CheckDataContext, Collection<String>> source,
                          Function<CheckDataContext, Collection<String>> target,
                          String messageTemplate) {
        this.meta = meta;
        this.source = source;
        this.target = target;
        this.messageTemplate = messageTemplate;
    }

    @Override
    public RuleMeta meta() {
        return meta;
    }

    @Override
    public List<Violation> check(CheckDataContext ctx) {
        Set<String> missing = ids(source.apply(ctx));
        missing.removeAll(ids(target.apply(ctx)));
        return missing.stream()
                .map(id -> Violation.of(id, messageTemplate.formatted(id)))
                .toList();
    }

    /** Множество непустых id с сохранением порядка (чтобы протокол был стабильным). */
    private static Set<String> ids(Collection<String> raw) {
        Set<String> result = new LinkedHashSet<>();
        raw.stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .forEach(result::add);
        return result;
    }
}
