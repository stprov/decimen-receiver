package ru.sbrf.gmap.vux.service.checks;

import ru.sbrf.gmap.vux.dto.templates.ProtocolCheckRecordDto;
import ru.sbrf.gmap.vux.dto.templates.ProtocolTableRecordDto;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;

import java.util.List;

/**
 * Перевод результатов проверок в строки протокола.
 * <p>
 * Всё считается из одного списка {@link RuleResult}, поэтому цифры в таблице
 * «Результат проверки», в баннере «Показано N из M» и в списке ошибок
 * не могут разойтись, как сейчас.
 */
public final class CuvProtocolMapper {

    private CuvProtocolMapper() {
    }

    /** Строки таблицы «Результат проверки»: по одной на проверку, со статусом и количеством. */
    public static List<ProtocolCheckRecordDto> checks(List<RuleResult> results) {
        return results.stream()
                .map(r -> ProtocolCheckRecordDto.builder()
                        .checkType(r.meta().title())
                        .checkResult(r.status().protocolText())
                        .countingDeviation(String.valueOf(r.count()))
                        .ruleType(r.meta().severity())
                        .build())
                .toList();
    }

    /**
     * Строки «Список ошибок» / «Список предупреждений».
     * Для каждой проверки показывается не больше {@code limitPerRule} нарушений —
     * полное количество всё равно видно в таблице проверок.
     * Упавшая проверка (ERROR) тоже попадает в список, чтобы её нельзя было не заметить.
     */
    public static List<ProtocolTableRecordDto> rows(List<RuleResult> results, RuleTypeEnum severity, int limitPerRule) {
        return results.stream()
                .filter(r -> r.meta().severity() == severity)
                .flatMap(r -> r.status() == CheckStatus.ERROR
                        ? List.of(row(r, "-", "Проверка не выполнена: " + r.technicalError())).stream()
                        : r.violations().stream().limit(limitPerRule).map(v -> row(r, v.objectRef(), v.message())))
                .toList();
    }

    /** Полное число нарушений заданного уровня — для «Показано N из M». */
    public static long total(List<RuleResult> results, RuleTypeEnum severity) {
        return results.stream()
                .filter(r -> r.meta().severity() == severity)
                .mapToLong(r -> r.status() == CheckStatus.ERROR ? 1 : r.count())
                .sum();
    }

    /** Есть ли что-то, что запрещает отправку отчёта. */
    public static boolean hasBlocking(List<RuleResult> results) {
        return results.stream().anyMatch(RuleResult::isBlocking);
    }

    private static ProtocolTableRecordDto row(RuleResult r, String objectRef, String message) {
        return ProtocolTableRecordDto.builder()
                .objectName(r.meta().title())
                .objectNumber(objectRef)
                .errorCode(r.meta().code())
                .errorMessage(message)
                .ruleType(r.meta().severity())
                .build();
    }
}
