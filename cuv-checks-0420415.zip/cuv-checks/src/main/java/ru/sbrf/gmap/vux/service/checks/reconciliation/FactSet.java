package ru.sbrf.gmap.vux.service.checks.reconciliation;

import ru.sbrf.gmap.vux.service.checks.Violation;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Набор фактов одной стороны сверки плюс проблемы, найденные при его построении
 * (дубли ключей, неразбираемый scenario, ошибки настройки).
 */
public final class FactSet {

    private final String sideName;
    private final Map<FactKey, Fact> facts = new LinkedHashMap<>();
    private final List<Violation> problems = new ArrayList<>();

    public FactSet(String sideName) {
        this.sideName = sideName;
    }

    /** Добавляет факт; повтор ключа — это отдельная ошибка, а не тихая перезапись. */
    public void add(Fact fact) {
        Fact previous = facts.putIfAbsent(fact.key(), fact);
        if (previous != null) {
            problems.add(Violation.of(fact.key().toString(),
                    "Дубль факта в %s: %s".formatted(sideName, fact.key())));
        }
    }

    public void problem(String objectRef, String message) {
        problems.add(Violation.of(objectRef, message));
    }

    public Map<FactKey, Fact> facts() {
        return facts;
    }

    public List<Violation> problems() {
        return problems;
    }
}
