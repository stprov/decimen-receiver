package ru.sbrf.gmap.vux.service.checks.reconciliation;

import ru.sbrf.gmap.vux.service.checks.CheckDataContext;
import ru.sbrf.gmap.vux.service.checks.CheckRule;
import ru.sbrf.gmap.vux.service.checks.CheckStage;
import ru.sbrf.gmap.vux.service.checks.RuleMeta;
import ru.sbrf.gmap.vux.service.checks.Violation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 010. Сверка «витрина ↔ отчёт».
 * <p>
 * Обе стороны превращаются в словари {@code ключ факта → значение}, затем:
 * <ul>
 *   <li>ключ есть только в витрине — «факт потерян при формировании отчёта»;</li>
 *   <li>ключ есть только в отчёте — «в отчёте лишний факт»;</li>
 *   <li>ключ есть в обоих, значения разные — «расхождение значений».</li>
 * </ul>
 * Сообщается о <b>каждом</b> расхождении, а не о первом найденном.
 * <p>
 * Если для таксономии документа нет ни одной настройки в {@code t_adm_data_xbrl_link},
 * это нарушение, а не «ошибок нет»: иначе проверка молча ничего не сверяет,
 * как сейчас.
 * <p>
 * Предположение, которое нужно подтвердить на реальном пакете: {@code analytical_section}
 * содержит полный набор explicit-осей контекста. Если в scenario есть оси, которых нет
 * в настройке, ключи не совпадут и сверка покажет пары «потерян / лишний» —
 * это будет видно сразу на первом тестовом прогоне.
 */
public class ReconciliationCheck implements CheckRule {

    static final String TABLE_NAME = "t_vux_form_0420415_1_3_data";

    private static final RuleMeta META = RuleMeta.error(
            "DCUV_0420415_1_3_010",
            "Значения отчёта совпадают с данными витрины",
            CheckStage.RECONCILIATION, 1);

    private final ExpectedFactsBuilder expectedBuilder;
    private final ActualFactsBuilder actualBuilder;
    private final FactValueComparator comparator;

    public ReconciliationCheck(ExpectedFactsBuilder expectedBuilder,
                               ActualFactsBuilder actualBuilder,
                               FactValueComparator comparator) {
        this.expectedBuilder = expectedBuilder;
        this.actualBuilder = actualBuilder;
        this.comparator = comparator;
    }

    @Override
    public RuleMeta meta() {
        return META;
    }

    @Override
    public List<Violation> check(CheckDataContext ctx) {
        // До этого этапа доходим, только если 009 прошла, — таксономия одна.
        String taxonomy = ctx.contextList().getFirst().taxonomy();

        FactSet config = new FactSet("настройке");
        List<ExpectedFactsBuilder.PreparedLink> links =
                expectedBuilder.prepare(ctx.xbrlLinks(), taxonomy, TABLE_NAME, config);
        if (links.isEmpty()) {
            List<Violation> v = new ArrayList<>(config.problems());
            v.add(Violation.of("t_adm_data_xbrl_link",
                    "Нет настроек сверки для таксономии %s и таблицы %s".formatted(taxonomy, TABLE_NAME)));
            return v;
        }
        if (ctx.dataList().isEmpty()) {
            return List.of(Violation.of(TABLE_NAME,
                    "Витрина пуста для workflow_run_id = %s, сверять не с чем".formatted(ctx.workflowRunId())));
        }

        Set<String> elements = links.stream()
                .map(ExpectedFactsBuilder.PreparedLink::element)
                .collect(Collectors.toSet());

        FactSet expected = expectedBuilder.build(ctx.dataList(), links);
        FactSet actual = actualBuilder.build(ctx.contextList(), ctx.valueList(), elements);

        List<Violation> violations = new ArrayList<>();
        violations.addAll(config.problems());
        violations.addAll(expected.problems());
        violations.addAll(actual.problems());
        compare(expected.facts(), actual.facts(), taxonomy, ctx, violations);
        return violations;
    }

    private void compare(Map<FactKey, Fact> expected, Map<FactKey, Fact> actual, String taxonomy,
                         CheckDataContext ctx, List<Violation> out) {
        for (Fact e : expected.values()) {
            Fact a = actual.get(e.key());
            if (a == null) {
                out.add(Violation.of(e.key().toString(),
                        "Факт есть в витрине (колонка %s = %s), но отсутствует в отчёте: %s"
                                .formatted(e.link().getId().getColumnName(), e.value(), e.key())));
            } else if (!comparator.matches(e, a, taxonomy, ctx.enumValuesMap())) {
                out.add(Violation.of(e.key().toString(),
                        "Расхождение: %s — витрина (%s) = %s, отчёт = %s"
                                .formatted(e.key(), e.link().getId().getColumnName(), e.value(),
                                        a.value() == null ? "nil" : a.value())));
            }
        }
        for (Fact a : actual.values()) {
            if (a.value() != null && !expected.containsKey(a.key())) {
                out.add(Violation.of(a.key().toString(),
                        "Факт есть в отчёте (= %s), но отсутствует в витрине: %s".formatted(a.value(), a.key())));
            }
        }
    }
}
