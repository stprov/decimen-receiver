package ru.sbrf.gmap.vux.service.checks.reconciliation;

import ru.sbrf.gmap.vux.entity.AdmXbrlEnumValuesEntity;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import java.util.Objects;

/**
 * Сравнение значения из витрины со значением из отчёта с учётом типа колонки.
 * <ul>
 *   <li><b>measure</b> — как числа. Если у факта отчёта есть {@code decimals}
 *       (например, 2), обе стороны округляются до этой точности: 100.004 и 100.00
 *       при decimals=2 считаются равными, как и по правилам XBRL.</li>
 *   <li><b>enumerator</b> — через справочник {@code t_adm_xbrl_enum_values}.</li>
 *   <li>остальное — как строки без учёта пробелов по краям.</li>
 * </ul>
 */
public class FactValueComparator {

    public boolean matches(Fact expected, Fact actual, String taxonomy, Map<String, AdmXbrlEnumValuesEntity> enumValues) {
        String exp = expected.value();
        String act = actual.value();
        if (act == null) {
            return false; // в витрине значение есть, в отчёте nil
        }
        String type = expected.link() == null ? null : expected.link().getColumnXbrlType();
        if ("measure".equals(type)) {
            return numbersEqual(exp, act, actual.decimals());
        }
        if ("enumerator".equals(type)) {
            return enumEquals(exp, act, taxonomy, expected.link().getEnumId(), enumValues);
        }
        return exp.trim().equals(act.trim());
    }

    static boolean numbersEqual(String exp, String act, String decimals) {
        try {
            BigDecimal e = new BigDecimal(exp.trim());
            BigDecimal a = new BigDecimal(act.trim());
            Integer scale = parseDecimals(decimals);
            if (scale != null) {
                e = e.setScale(scale, RoundingMode.HALF_UP);
                a = a.setScale(scale, RoundingMode.HALF_UP);
            }
            return e.compareTo(a) == 0;
        } catch (NumberFormatException ex) {
            return exp.trim().equals(act.trim());
        }
    }

    /** decimals="INF" или пусто — точное сравнение; число — округление до него. */
    static Integer parseDecimals(String decimals) {
        if (decimals == null || decimals.isBlank() || "INF".equalsIgnoreCase(decimals.trim())) {
            return null;
        }
        try {
            return Integer.parseInt(decimals.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * В отчёте enum-значение — это член домена, например {@code mem-int:Strana_643RusRossiyaMember},
     * в витрине — код, например {@code 643}.
     * <p>
     * ВНИМАНИЕ: смысл полей {@code t_adm_xbrl_enum_values} в коде проекта не описан.
     * Здесь предполагается, что ключ справочника — (таксономия, enum_id, имя члена домена),
     * а {@code enumValueText} или {@code enumValueCode} — то, что лежит в витрине.
     * Это нужно сверить с содержимым справочника до включения проверки.
     * Если запись не найдена, используется старое правило «цифры после первого подчёркивания».
     */
    static boolean enumEquals(String exp, String act, String taxonomy, String enumId,
                              Map<String, AdmXbrlEnumValuesEntity> enumValues) {
        String member = DimensionParser.localName(act);
        AdmXbrlEnumValuesEntity entry = enumValues.get(taxonomy + "|" + enumId + "|" + member);
        if (entry != null) {
            return Objects.equals(exp.trim(), trim(entry.getEnumValueText()))
                    || Objects.equals(exp.trim(), trim(entry.getId().getEnumValueCode()));
        }
        return Objects.equals(exp.trim(), legacyCode(member));
    }

    /** {@code Strana_643RusRossiyaMember} → {@code 643}. Оставлено как запасной вариант. */
    static String legacyCode(String member) {
        if (member == null) {
            return null;
        }
        int us = member.indexOf('_');
        if (us < 0) {
            return null;
        }
        StringBuilder digits = new StringBuilder();
        for (int i = us + 1; i < member.length() && Character.isDigit(member.charAt(i)); i++) {
            digits.append(member.charAt(i));
        }
        return digits.isEmpty() ? null : digits.toString();
    }

    private static String trim(String s) {
        return s == null ? null : s.trim();
    }
}
