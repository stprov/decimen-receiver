package ru.sbrf.gmap.vux.service.checks;

import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;

import java.util.Objects;

/**
 * Паспорт проверки: всё, что о ней нужно знать, кроме самой логики.
 *
 * @param code     код ошибки, например {@code DCUV_0420415_1_3_007}
 * @param title    название для таблицы «Результат проверки» в протоколе
 * @param stage    этап, на котором выполняется проверка
 * @param order    порядок внутри этапа
 * @param severity E — ошибка (блокирует следующие этапы и отправку), W — предупреждение
 */
public record RuleMeta(String code, String title, CheckStage stage, int order, RuleTypeEnum severity) {

    public RuleMeta {
        Objects.requireNonNull(code, "code");
        Objects.requireNonNull(title, "title");
        Objects.requireNonNull(stage, "stage");
        Objects.requireNonNull(severity, "severity");
    }

    public static RuleMeta error(String code, String title, CheckStage stage, int order) {
        return new RuleMeta(code, title, stage, order, RuleTypeEnum.E);
    }

    public static RuleMeta warning(String code, String title, CheckStage stage, int order) {
        return new RuleMeta(code, title, stage, order, RuleTypeEnum.W);
    }
}
