package ru.sbrf.gmap.vux.service.checks;

/**
 * Итог выполнения одной проверки.
 * <p>
 * {@link #protocolText} — то, что попадает в колонку «Отклонение» протокола.
 * Раньше протокол знал только «Выявлено / Не выявлено», из-за чего
 * выключенная или упавшая проверка выглядела как пройденная.
 */
public enum CheckStatus {
    PASSED("Не выявлено"),
    FAILED("Выявлено"),
    SKIPPED("Не выполнялась: не пройден предыдущий этап"),
    ERROR("Ошибка выполнения проверки"),
    DISABLED("Проверка отключена");

    private final String protocolText;

    CheckStatus(String protocolText) {
        this.protocolText = protocolText;
    }

    public String protocolText() {
        return protocolText;
    }
}
