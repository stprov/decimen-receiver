package ru.sbrf.gmap.vux.service.checks;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ContextDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13UnitDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;
import ru.sbrf.gmap.vux.service.checks.reconciliation.ActualFactsBuilder;
import ru.sbrf.gmap.vux.service.checks.reconciliation.DimensionParser;
import ru.sbrf.gmap.vux.service.checks.reconciliation.ExpectedFactsBuilder;
import ru.sbrf.gmap.vux.service.checks.reconciliation.FactValueComparator;
import ru.sbrf.gmap.vux.service.checks.reconciliation.ReconciliationCheck;
import ru.sbrf.gmap.vux.service.checks.rules.PartPresentCheck;
import ru.sbrf.gmap.vux.service.checks.rules.ReferenceCheck;
import ru.sbrf.gmap.vux.service.checks.rules.TaxonomyCheck;
import ru.sbrf.gmap.vux.service.checks.rules.WorkflowRunIdCheck;
import ru.sbrf.gmap.vux.service.parser.XmlParserService;

import java.util.Collection;
import java.util.List;
import java.util.function.Function;

import static ru.sbrf.gmap.vux.service.checks.CheckStage.PRESENCE;
import static ru.sbrf.gmap.vux.service.checks.CheckStage.REFERENCES;

/**
 * Реестр всех проверок формы 0420415.1.3 — все 10 в одном месте.
 * <p>
 * Чтобы понять, что проверяется, достаточно прочитать этот класс:
 * код, название, этап и что с чем сравнивается видны без перехода по десяти файлам.
 * Чтобы отключить проверку, не нужно комментировать код —
 * достаточно добавить её код в {@code config.cuv-checks.disabled-codes}.
 */
@Configuration
public class CuvChecksConfig {

    private static final String P = "DCUV_0420415_1_3_";

    // ---------- Этап 1. Есть ли что проверять ----------

    @Bean
    CheckRule check001WorkflowRunId() {
        return new WorkflowRunIdCheck();
    }

    @Bean
    CheckRule check002ContextPresent() {
        return new PartPresentCheck(RuleMeta.error(P + "002", "Получены описания контекстов (context)", PRESENCE, 2),
                "context", CheckDataContext::contextList);
    }

    @Bean
    CheckRule check003UnitPresent() {
        return new PartPresentCheck(RuleMeta.error(P + "003", "Получены единицы измерения (unit)", PRESENCE, 3),
                "unit", CheckDataContext::unitList);
    }

    @Bean
    CheckRule check004ValuePresent() {
        return new PartPresentCheck(RuleMeta.error(P + "004", "Получены значения (value)", PRESENCE, 4),
                "value", CheckDataContext::valueList);
    }

    // ---------- Этап 2. Сходятся ли ссылки ----------

    @Bean
    CheckRule check005UnusedContext() {
        return new ReferenceCheck(
                RuleMeta.warning(P + "005", "Нет описаний context, на которые не ссылается ни одно значение", REFERENCES, 5),
                contextIds(), valueContextIds(),
                "context_id = %s описан, но не используется ни одним значением");
    }

    @Bean
    CheckRule check006UnusedUnit() {
        return new ReferenceCheck(
                RuleMeta.warning(P + "006", "Нет описаний unit, на которые не ссылается ни одно значение", REFERENCES, 6),
                unitIds(), valueUnitIds(),
                "unit_id = %s описан, но не используется ни одним значением");
    }

    @Bean
    CheckRule check007MissingContext() {
        return new ReferenceCheck(
                RuleMeta.error(P + "007", "Все значения ссылаются на существующий context", REFERENCES, 7),
                valueContextIds(), contextIds(),
                "Значение ссылается на context_id = %s, которого нет в context");
    }

    @Bean
    CheckRule check008MissingUnit() {
        return new ReferenceCheck(
                RuleMeta.error(P + "008", "Все значения ссылаются на существующий unit", REFERENCES, 8),
                valueUnitIds(), unitIds(),
                "Значение ссылается на unit_id = %s, которого нет в unit");
    }

    // ---------- Этап 3. Согласованность ----------

    @Bean
    CheckRule check009Taxonomy() {
        return new TaxonomyCheck();
    }

    // ---------- Этап 4. Сверка с витриной ----------

    @Bean
    CheckRule check010Reconciliation(XmlParserService xmlParserService) {
        DimensionParser dims = new DimensionParser(xmlParserService);
        return new ReconciliationCheck(new ExpectedFactsBuilder(dims), new ActualFactsBuilder(dims), new FactValueComparator());
    }

    // ---------- Откуда брать id для проверок ссылок ----------

    private static Function<CheckDataContext, Collection<String>> contextIds() {
        return ctx -> ids(ctx.contextList(), VuxForm0420415V13ContextDto::contextId);
    }

    private static Function<CheckDataContext, Collection<String>> unitIds() {
        return ctx -> ids(ctx.unitList(), VuxForm0420415V13UnitDto::unitId);
    }

    private static Function<CheckDataContext, Collection<String>> valueContextIds() {
        return ctx -> ids(ctx.valueList(), VuxForm0420415V13ValueDto::contextId);
    }

    private static Function<CheckDataContext, Collection<String>> valueUnitIds() {
        return ctx -> ids(ctx.valueList(), VuxForm0420415V13ValueDto::unitId);
    }

    private static <T> List<String> ids(List<T> rows, Function<T, String> id) {
        return rows.stream().map(id).toList();
    }
}
