package ru.sbrf.gmap.vux.service.checks;

/**
 * Одно найденное нарушение.
 * <p>
 * Проверка возвращает столько нарушений, сколько нашла: пять «битых» ссылок —
 * пять записей, а не одна строка «найдены ошибки». Отсюда честная колонка
 * «Количество» в протоколе.
 *
 * @param objectRef на что указывает нарушение: context_id, unit_id, ключ факта и т.п.
 * @param message   человекочитаемое описание
 */
public record Violation(String objectRef, String message) {

    public static Violation of(String objectRef, String message) {
        return new Violation(objectRef, message);
    }
}
