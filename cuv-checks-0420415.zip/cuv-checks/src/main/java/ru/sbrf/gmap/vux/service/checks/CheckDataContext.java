package ru.sbrf.gmap.vux.service.checks;

import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ContextDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13UnitDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;
import ru.sbrf.gmap.vux.entity.AdmXbrlEnumValuesEntity;
import ru.sbrf.gmap.vux.entity.VuxDataXbrlLinkEntity;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V13DataEntity;

import java.util.List;
import java.util.Map;

/**
 * Всё, что нужно проверкам по одному документу.
 * <p>
 * Изменение относительно текущей версии: добавлен {@code workflowRunId} —
 * номер партии, взятый из {@code t_vux_document}. Раньше его не было, и проверка 001
 * доставала номер из первой строки context, то есть проверяла саму себя.
 * <p>
 * Списки никогда не {@code null}: если данных нет, список пустой, и об этом
 * сообщат проверки 002–004, а не молчаливый пропуск документа.
 *
 * @param docId         идентификатор документа (resultDocumentId)
 * @param workflowRunId номер партии из t_vux_document; может быть {@code null}, если не заполнен
 */
public record CheckDataContext(
        long docId,
        Long workflowRunId,
        List<VuxForm0420415V13ContextDto> contextList,
        List<VuxForm0420415V13UnitDto> unitList,
        List<VuxForm0420415V13ValueDto> valueList,
        List<VuxForm0420415V13DataEntity> dataList,
        List<VuxDataXbrlLinkEntity> xbrlLinks,
        Map<String, AdmXbrlEnumValuesEntity> enumValuesMap
) {
    public CheckDataContext {
        contextList = contextList == null ? List.of() : contextList;
        unitList = unitList == null ? List.of() : unitList;
        valueList = valueList == null ? List.of() : valueList;
        dataList = dataList == null ? List.of() : dataList;
        xbrlLinks = xbrlLinks == null ? List.of() : xbrlLinks;
        enumValuesMap = enumValuesMap == null ? Map.of() : enumValuesMap;
    }

    /** Контекст для документа, по которому не удалось загрузить данные. */
    public static CheckDataContext empty(long docId, Long workflowRunId) {
        return new CheckDataContext(docId, workflowRunId, null, null, null, null, null, null);
    }
}
