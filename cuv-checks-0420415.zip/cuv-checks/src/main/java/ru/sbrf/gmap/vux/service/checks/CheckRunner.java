package ru.sbrf.gmap.vux.service.checks;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/**
 * Запускает все проверки по одному документу. Заменяет {@code ValidationDataService}.
 * <p>
 * Порядок работы:
 * <ol>
 *   <li>Проверки сортируются по этапу, затем по {@code order} внутри этапа.</li>
 *   <li>Проверка из списка отключённых не выполняется и получает статус DISABLED
 *       (в протоколе видно «Проверка отключена», а не «Не выявлено»).</li>
 *   <li>Исключение внутри проверки не роняет обработку документа:
 *       проверка получает статус ERROR, остальные выполняются дальше.</li>
 *   <li>Если на этапе есть блокирующий результат (ошибка уровня E),
 *       все проверки следующих этапов получают SKIPPED.</li>
 * </ol>
 */
@Slf4j
@Service
public class CheckRunner {

    private final List<CheckRule> rules;
    private final Set<String> disabledCodes;

    public CheckRunner(List<CheckRule> rules,
                       @Value("${config.cuv-checks.disabled-codes:}") Set<String> disabledCodes) {
        this.rules = rules.stream()
                .sorted(Comparator.comparing((CheckRule r) -> r.meta().stage())
                        .thenComparingInt(r -> r.meta().order()))
                .toList();
        this.disabledCodes = Set.copyOf(disabledCodes);
        log.info("CUV checks registered: {}, disabled: {}",
                this.rules.stream().map(r -> r.meta().code()).toList(), this.disabledCodes);
    }

    public List<RuleResult> run(CheckDataContext ctx) {
        List<RuleResult> results = new ArrayList<>(rules.size());
        CheckStage blockedAfter = null;

        for (CheckRule rule : rules) {
            RuleMeta meta = rule.meta();

            if (disabledCodes.contains(meta.code())) {
                results.add(RuleResult.disabled(meta));
                continue;
            }
            if (blockedAfter != null && meta.stage().compareTo(blockedAfter) > 0) {
                results.add(RuleResult.skipped(meta));
                continue;
            }

            RuleResult result = execute(rule, ctx);
            results.add(result);

            if (result.isBlocking() && blockedAfter == null) {
                blockedAfter = meta.stage();
            }
        }
        return results;
    }

    private RuleResult execute(CheckRule rule, CheckDataContext ctx) {
        try {
            return RuleResult.of(rule.meta(), rule.check(ctx));
        } catch (Exception e) {
            log.error("Check {} failed with exception for docId={}", rule.meta().code(), ctx.docId(), e);
            return RuleResult.error(rule.meta(), e);
        }
    }
}
