package ru.sbrf.gmap.vux.service.checks.reconciliation;

/**
 * Ключ факта — «адрес ячейки» отчёта, одинаковый для витрины и для XBRL.
 * <p>
 * Идея сверки: обе стороны переводятся в набор {@code ключ → значение},
 * после чего сравниваются как два словаря. Без общего ключа приходится
 * «искать строку витрины по контексту», что и делала старая проверка 010.
 *
 * @param element         показатель (локальное имя, без префикса пространства имён)
 * @param idCzennojBumagi typedMember ID_CzennojBumagiTaxis / колонка id_czennojbumagi
 * @param idStroki        typedMember ID_strokiTaxis / колонка id_stroki
 * @param explicitDims    explicit-измерения в каноническом виде: {@code ось=член;ось=член}, отсортировано
 */
public record FactKey(String element, String idCzennojBumagi, String idStroki, String explicitDims) {

    @Override
    public String toString() {
        return "%s [бумага=%s, строка=%s%s]".formatted(
                element, idCzennojBumagi, idStroki,
                explicitDims.isEmpty() ? "" : ", " + explicitDims);
    }
}
