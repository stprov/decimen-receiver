package ru.sbrf.gmap.vux.service.checks;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.sbrf.gmap.vux.entity.AdmXbrlEnumValuesEntity;
import ru.sbrf.gmap.vux.entity.VuxDocumentEntity;
import ru.sbrf.gmap.vux.mapper.VuxForm0420415V13ContextMapper;
import ru.sbrf.gmap.vux.mapper.VuxForm0420415V13UnitMapper;
import ru.sbrf.gmap.vux.mapper.VuxForm0420415V13ValueMapper;
import ru.sbrf.gmap.vux.repository.AdmXbrlEnumValuesRepository;
import ru.sbrf.gmap.vux.repository.VuxDataXbrlLinkRepository;
import ru.sbrf.gmap.vux.repository.VuxDocumentRepository;
import ru.sbrf.gmap.vux.repository.VuxForm0420415V13ContextRepository;
import ru.sbrf.gmap.vux.repository.VuxForm0420415V13DataRepository;
import ru.sbrf.gmap.vux.repository.VuxForm0420415V13UnitRepository;
import ru.sbrf.gmap.vux.repository.VuxForm0420415V13ValueRepository;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Загрузка данных для проверок. Заменяет {@code OrchestratorService.buildCheckDataContext}.
 * <p>
 * Главное отличие: <b>никогда не возвращает {@code null}</b>.
 * <ul>
 *   <li>Нет документа или не заполнен workflow_run_id → пустой контекст,
 *       проверка 001 сообщит об этом в протоколе.</li>
 *   <li>Нет context / unit / value → пустые списки, об этом сообщат проверки 002–004.</li>
 *   <li>Ошибка БД → исключение летит наверх. Это технический сбой, а не результат проверки:
 *       оркестратор не должен закрывать расписание, документ нужно обработать повторно.</li>
 * </ul>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CuvContextLoader {

    private final VuxDocumentRepository documentRepository;
    private final VuxForm0420415V13ContextRepository contextRepository;
    private final VuxForm0420415V13UnitRepository unitRepository;
    private final VuxForm0420415V13ValueRepository valueRepository;
    private final VuxForm0420415V13DataRepository dataRepository;
    private final VuxDataXbrlLinkRepository xbrlLinkRepository;
    private final AdmXbrlEnumValuesRepository enumValuesRepository;
    private final VuxForm0420415V13ContextMapper contextMapper;
    private final VuxForm0420415V13UnitMapper unitMapper;
    private final VuxForm0420415V13ValueMapper valueMapper;

    @Transactional(readOnly = true)
    public CheckDataContext load(long docId) {
        Long workflowRunId = documentRepository.findByDocId(docId)
                .map(VuxDocumentEntity::getWorkflowRunId)
                .orElse(null);

        if (workflowRunId == null || workflowRunId <= 0) {
            log.warn("docId={}: workflow_run_id is not set ({}), checks will report it", docId, workflowRunId);
            return CheckDataContext.empty(docId, workflowRunId);
        }

        // TODO: справочники меняются редко — кешировать, а не читать целиком на каждый документ
        Map<String, AdmXbrlEnumValuesEntity> enumValues = enumValuesRepository.findAll().stream()
                .collect(Collectors.toMap(
                        e -> e.getId().getTaxonomy_id() + "|" + e.getId().getEnumId() + "|" + e.getId().getEnumValueCode(),
                        Function.identity(),
                        (a, b) -> a));

        return new CheckDataContext(
                docId,
                workflowRunId,
                contextRepository.findByWorkflowRunId(workflowRunId).stream().map(contextMapper::entityToDto).toList(),
                unitRepository.findByWorkflowRunId(workflowRunId).stream().map(unitMapper::entityToDto).toList(),
                valueRepository.findByWorkflowRunId(workflowRunId).stream().map(valueMapper::entityToDto).toList(),
                dataRepository.findByWorkflowRunId(workflowRunId),
                xbrlLinkRepository.findAll(),
                enumValues);
    }
}
