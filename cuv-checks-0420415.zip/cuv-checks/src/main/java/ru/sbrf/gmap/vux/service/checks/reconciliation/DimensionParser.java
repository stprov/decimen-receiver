package ru.sbrf.gmap.vux.service.checks.reconciliation;

import ru.sbrf.gmap.vux.dto.scenario.full.ExplicitMemberDto;
import ru.sbrf.gmap.vux.dto.scenario.full.FullXmlDto;
import ru.sbrf.gmap.vux.dto.scenario.full.TypedMemberDto;
import ru.sbrf.gmap.vux.service.parser.XmlParserService;

import java.util.List;
import java.util.Objects;
import java.util.TreeMap;
import java.util.stream.Collectors;

/**
 * Разбор XML-фрагментов scenario / analytical_section в то, что нужно ключу факта.
 * Общий для обеих сторон сверки, чтобы измерения приводились к одному виду.
 */
public class DimensionParser {

    static final String DIM_CZENNOJ_BUMAGI = "ID_CzennojBumagiTaxis";
    static final String DIM_STROKI = "ID_strokiTaxis";

    private final XmlParserService xmlParserService;

    public DimensionParser(XmlParserService xmlParserService) {
        this.xmlParserService = xmlParserService;
    }

    /** Измерения контекста: две typed-оси и все explicit-оси. */
    public record Dimensions(String idCzennojBumagi, String idStroki, String explicitDims) {
    }

    /**
     * @throws ru.sbrf.gmap.vux.service.parser.XmlParserException если XML не разбирается
     */
    public Dimensions parse(String xml) {
        FullXmlDto dto = xmlParserService.parse(xml, FullXmlDto.class);
        List<Object> members = dto == null || dto.getMembers() == null ? List.of() : dto.getMembers();
        return new Dimensions(
                typed(members, DIM_CZENNOJ_BUMAGI),
                typed(members, DIM_STROKI),
                canonicalExplicit(members));
    }

    /** Только explicit-оси в каноническом виде (для analytical_section). */
    public String parseExplicit(String xml) {
        if (xml == null || xml.isBlank()) {
            return "";
        }
        return parse(xml).explicitDims();
    }

    private static String typed(List<Object> members, String dimensionLocalName) {
        return members.stream()
                .filter(TypedMemberDto.class::isInstance)
                .map(TypedMemberDto.class::cast)
                .filter(t -> dimensionLocalName.equals(localName(t.getDimension())))
                .map(TypedMemberDto::getTypedName)
                .filter(Objects::nonNull)
                .map(String::trim)
                .findFirst()
                .orElse(null);
    }

    private static String canonicalExplicit(List<Object> members) {
        TreeMap<String, String> sorted = new TreeMap<>();
        members.stream()
                .filter(ExplicitMemberDto.class::isInstance)
                .map(ExplicitMemberDto.class::cast)
                .forEach(e -> sorted.put(localName(e.getDimension()), localName(e.getValue())));
        return sorted.entrySet().stream()
                .map(e -> e.getKey() + "=" + e.getValue())
                .collect(Collectors.joining(";"));
    }

    /** {@code "dim-int:ID_strokiTaxis"} → {@code "ID_strokiTaxis"}. Префиксы на двух сторонах могут отличаться. */
    public static String localName(String qName) {
        if (qName == null) {
            return null;
        }
        String trimmed = qName.trim();
        int colon = trimmed.lastIndexOf(':');
        return colon < 0 ? trimmed : trimmed.substring(colon + 1);
    }
}
