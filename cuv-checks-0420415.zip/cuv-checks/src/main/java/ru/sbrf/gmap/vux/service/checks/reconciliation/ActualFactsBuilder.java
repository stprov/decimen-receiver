package ru.sbrf.gmap.vux.service.checks.reconciliation;

import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ContextDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;
import ru.sbrf.gmap.vux.service.parser.XmlParserException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Сторона «отчёт»: каждое value + его context превращается в факт с тем же ключом,
 * что и у витрины.
 * <p>
 * Берутся только показатели, которые вообще настроены для сверки
 * ({@code elements}): остальные факты отчёта к этой проверке не относятся.
 * Value со ссылкой на несуществующий context пропускаются — это уже
 * поймала проверка 007, дублировать не нужно.
 */
public class ActualFactsBuilder {

    private final DimensionParser dimensionParser;

    public ActualFactsBuilder(DimensionParser dimensionParser) {
        this.dimensionParser = dimensionParser;
    }

    public FactSet build(List<VuxForm0420415V13ContextDto> contexts,
                         List<VuxForm0420415V13ValueDto> values,
                         Set<String> elements) {
        FactSet set = new FactSet("отчёте");
        Map<String, DimensionParser.Dimensions> dims = parseContexts(contexts, set);

        for (VuxForm0420415V13ValueDto v : values) {
            String element = DimensionParser.localName(v.elementName());
            if (element == null || !elements.contains(element)) {
                continue;
            }
            DimensionParser.Dimensions d = dims.get(v.contextId());
            if (d == null) {
                continue;
            }
            String value = "true".equalsIgnoreCase(v.nil()) ? null : trim(v.value());
            FactKey key = new FactKey(element, d.idCzennojBumagi(), d.idStroki(), d.explicitDims());
            set.add(Fact.actual(key, value, v.decimals()));
        }
        return set;
    }

    /** Каждый scenario разбирается один раз, а не на каждое value. */
    private Map<String, DimensionParser.Dimensions> parseContexts(List<VuxForm0420415V13ContextDto> contexts, FactSet set) {
        Map<String, DimensionParser.Dimensions> result = new HashMap<>();
        for (VuxForm0420415V13ContextDto c : contexts) {
            try {
                result.put(c.contextId(), dimensionParser.parse(c.scenario()));
            } catch (XmlParserException e) {
                set.problem(c.contextId(), "Не разбирается scenario у context_id = %s".formatted(c.contextId()));
            }
        }
        return result;
    }

    private static String trim(String s) {
        return s == null ? null : s.trim();
    }
}
