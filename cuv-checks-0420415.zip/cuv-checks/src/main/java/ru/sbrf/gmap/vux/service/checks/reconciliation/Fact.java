package ru.sbrf.gmap.vux.service.checks.reconciliation;

import ru.sbrf.gmap.vux.entity.VuxDataXbrlLinkEntity;

/**
 * Один факт: ключ, значение и откуда он взялся.
 *
 * @param value    значение строкой; {@code null} у XBRL-факта с nil="true"
 * @param link     строка настройки t_adm_data_xbrl_link (только у фактов из витрины)
 * @param decimals атрибут decimals (только у фактов из XBRL)
 */
public record Fact(FactKey key, String value, VuxDataXbrlLinkEntity link, String decimals) {

    public static Fact expected(FactKey key, String value, VuxDataXbrlLinkEntity link) {
        return new Fact(key, value, link, null);
    }

    public static Fact actual(FactKey key, String value, String decimals) {
        return new Fact(key, value, null, decimals);
    }
}
