package ru.sbrf.gmap.vux.service.checks.rules;

import ru.sbrf.gmap.vux.service.checks.CheckDataContext;
import ru.sbrf.gmap.vux.service.checks.CheckRule;
import ru.sbrf.gmap.vux.service.checks.RuleMeta;
import ru.sbrf.gmap.vux.service.checks.Violation;

import java.util.List;
import java.util.function.Function;

/**
 * 002–004. Часть отчёта (context, unit или value) присутствует.
 * <p>
 * Один класс на три проверки: отличаются только паспорт и то, какой список смотреть.
 * Экземпляры создаются в {@code CuvChecksConfig}.
 */
public class PartPresentCheck implements CheckRule {

    private final RuleMeta meta;
    private final String partName;
    private final Function<CheckDataContext, List<?>> part;

    public PartPresentCheck(RuleMeta meta, String partName, Function<CheckDataContext, List<?>> part) {
        this.meta = meta;
        this.partName = partName;
        this.part = part;
    }

    @Override
    public RuleMeta meta() {
        return meta;
    }

    @Override
    public List<Violation> check(CheckDataContext ctx) {
        if (part.apply(ctx).isEmpty()) {
            return List.of(Violation.of(partName,
                    "По workflow_run_id = %s не получены данные %s".formatted(ctx.workflowRunId(), partName)));
        }
        return List.of();
    }
}
