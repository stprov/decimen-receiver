package ru.sbrf.gmap.vux.service.checks.rules;

import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ContextDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13UnitDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;
import ru.sbrf.gmap.vux.service.checks.CheckDataContext;
import ru.sbrf.gmap.vux.service.checks.CheckRule;
import ru.sbrf.gmap.vux.service.checks.CheckStage;
import ru.sbrf.gmap.vux.service.checks.RuleMeta;
import ru.sbrf.gmap.vux.service.checks.Violation;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.Function;

/**
 * 009. Все строки context / unit / value собраны по одной версии таксономии.
 * <p>
 * Если версий несколько, нарушение одно, но в тексте перечислены все версии
 * с количеством строк — сразу видно, какая из них «чужая».
 * Пустая таксономия считается отдельной версией «(не заполнена)».
 */
public class TaxonomyCheck implements CheckRule {

    private static final String EMPTY = "(не заполнена)";

    private static final RuleMeta META = RuleMeta.error(
            "DCUV_0420415_1_3_009",
            "Все части отчёта собраны по одной версии таксономии",
            CheckStage.CONSISTENCY, 1);

    @Override
    public RuleMeta meta() {
        return META;
    }

    @Override
    public List<Violation> check(CheckDataContext ctx) {
        Map<String, Long> counts = new TreeMap<>();
        add(counts, ctx.contextList(), VuxForm0420415V13ContextDto::taxonomy);
        add(counts, ctx.unitList(), VuxForm0420415V13UnitDto::taxonomy);
        add(counts, ctx.valueList(), VuxForm0420415V13ValueDto::taxonomy);

        if (counts.size() <= 1) {
            return List.of();
        }
        return List.of(Violation.of("taxonomy",
                "Найдено несколько версий таксономии (версия = число строк): " + counts));
    }

    private static <T> void add(Map<String, Long> counts, List<T> rows, Function<T, String> taxonomy) {
        for (T row : rows) {
            String t = taxonomy.apply(row);
            counts.merge(t == null || t.isBlank() ? EMPTY : t.trim(), 1L, Long::sum);
        }
    }
}
