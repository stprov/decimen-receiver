package ru.sbrf.gmap.vux.service.checks;

import java.util.List;

/**
 * Одна проверка. Заменяет прежний {@code ValidationRule}.
 * <p>
 * Отличия от старого интерфейса:
 * <ul>
 *   <li>возвращает <b>все</b> нарушения, а не первое ({@code List} вместо {@code Optional});</li>
 *   <li>код, название, этап и серьёзность лежат в {@link RuleMeta}, а не в разрозненных константах;</li>
 *   <li>проверке можно бросить исключение: {@link CheckRunner} его поймает и пометит
 *       проверку статусом ERROR, остальные проверки продолжат работу.</li>
 * </ul>
 */
public interface CheckRule {

    RuleMeta meta();

    /**
     * @return пустой список, если нарушений нет
     */
    List<Violation> check(CheckDataContext ctx);
}
