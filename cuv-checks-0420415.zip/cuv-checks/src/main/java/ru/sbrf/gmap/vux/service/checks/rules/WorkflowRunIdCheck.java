package ru.sbrf.gmap.vux.service.checks.rules;

import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ContextDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13UnitDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;
import ru.sbrf.gmap.vux.service.checks.CheckDataContext;
import ru.sbrf.gmap.vux.service.checks.CheckRule;
import ru.sbrf.gmap.vux.service.checks.CheckStage;
import ru.sbrf.gmap.vux.service.checks.RuleMeta;
import ru.sbrf.gmap.vux.service.checks.Violation;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

/**
 * 001. Номер партии заполнен, и все строки context / unit / value относятся к этой партии.
 * <p>
 * Эталон — номер из {@code t_vux_document}, а не из самих строк.
 */
public class WorkflowRunIdCheck implements CheckRule {

    private static final RuleMeta META = RuleMeta.error(
            "DCUV_0420415_1_3_001",
            "Заполнен номер партии workflow_run_id, все части отчёта относятся к ней",
            CheckStage.PRESENCE, 1);

    @Override
    public RuleMeta meta() {
        return META;
    }

    @Override
    public List<Violation> check(CheckDataContext ctx) {
        Long expected = ctx.workflowRunId();
        if (expected == null || expected <= 0) {
            return List.of(Violation.of("doc_id=" + ctx.docId(),
                    "Не заполнен workflow_run_id документа (значение: %s)".formatted(expected)));
        }

        List<Violation> violations = new ArrayList<>();
        countForeign(violations, "context", ctx.contextList(), VuxForm0420415V13ContextDto::workflowRunId, expected);
        countForeign(violations, "unit", ctx.unitList(), VuxForm0420415V13UnitDto::workflowRunId, expected);
        countForeign(violations, "value", ctx.valueList(), VuxForm0420415V13ValueDto::workflowRunId, expected);
        return violations;
    }

    private static <T> void countForeign(List<Violation> out, String part, List<T> rows,
                                         Function<T, Long> runId, long expected) {
        long foreign = rows.stream().filter(r -> !Objects.equals(runId.apply(r), expected)).count();
        if (foreign > 0) {
            out.add(Violation.of(part,
                    "В %s найдено %d строк с workflow_run_id, отличным от %d".formatted(part, foreign, expected)));
        }
    }
}
