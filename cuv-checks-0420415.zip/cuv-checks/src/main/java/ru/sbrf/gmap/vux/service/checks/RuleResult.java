package ru.sbrf.gmap.vux.service.checks;

import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;

import java.util.List;

/**
 * Результат выполнения одной проверки: паспорт, статус и все найденные нарушения.
 *
 * @param technicalError текст исключения, если проверка упала (статус {@link CheckStatus#ERROR})
 */
public record RuleResult(RuleMeta meta, CheckStatus status, List<Violation> violations, String technicalError) {

    public RuleResult {
        violations = violations == null ? List.of() : List.copyOf(violations);
    }

    public static RuleResult of(RuleMeta meta, List<Violation> violations) {
        return new RuleResult(meta, violations.isEmpty() ? CheckStatus.PASSED : CheckStatus.FAILED, violations, null);
    }

    public static RuleResult skipped(RuleMeta meta) {
        return new RuleResult(meta, CheckStatus.SKIPPED, List.of(), null);
    }

    public static RuleResult disabled(RuleMeta meta) {
        return new RuleResult(meta, CheckStatus.DISABLED, List.of(), null);
    }

    public static RuleResult error(RuleMeta meta, Exception e) {
        return new RuleResult(meta, CheckStatus.ERROR, List.of(), e.getClass().getSimpleName() + ": " + e.getMessage());
    }

    /** Блокирует ли этот результат отправку отчёта и следующие этапы. */
    public boolean isBlocking() {
        return meta.severity() == RuleTypeEnum.E
                && (status == CheckStatus.FAILED || status == CheckStatus.ERROR);
    }

    public int count() {
        return violations.size();
    }
}
