package ru.sbrf.gmap.vux.service.checks;

import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ContextDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13UnitDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;
import ru.sbrf.gmap.vux.entity.VuxDataXbrlLinkEntity;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V13DataEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * Построитель тестовых данных: собрать «пакет» отчёта в одну строку кода.
 * <pre>
 *   CheckDataContext ctx = TestPackage.run(7)
 *       .context("c1").unit("u1")
 *       .value("Kol", "100", "c1", "u1")
 *       .build();
 * </pre>
 */
public final class TestPackage {

    public static final String TAXONOMY = "tax-1";

    private final Long runId;
    private final List<VuxForm0420415V13ContextDto> contexts = new ArrayList<>();
    private final List<VuxForm0420415V13UnitDto> units = new ArrayList<>();
    private final List<VuxForm0420415V13ValueDto> values = new ArrayList<>();
    private final List<VuxForm0420415V13DataEntity> data = new ArrayList<>();
    private final List<VuxDataXbrlLinkEntity> links = new ArrayList<>();

    private TestPackage(Long runId) {
        this.runId = runId;
    }

    public static TestPackage run(long runId) {
        return new TestPackage(runId);
    }

    public TestPackage context(String id) {
        return context(id, null, TAXONOMY);
    }

    public TestPackage context(String id, String scenario, String taxonomy) {
        contexts.add(VuxForm0420415V13ContextDto.builder()
                .contextId(id).scenario(scenario).taxonomy(taxonomy).workflowRunId(runId).build());
        return this;
    }

    public TestPackage unit(String id) {
        return unit(id, TAXONOMY);
    }

    public TestPackage unit(String id, String taxonomy) {
        units.add(VuxForm0420415V13UnitDto.builder().unitId(id).taxonomy(taxonomy).workflowRunId(runId).build());
        return this;
    }

    public TestPackage value(String element, String value, String contextId, String unitId) {
        values.add(VuxForm0420415V13ValueDto.builder()
                .elementName(element).value(value).contextId(contextId).unitId(unitId)
                .taxonomy(TAXONOMY).workflowRunId(runId).build());
        return this;
    }

    public TestPackage value(VuxForm0420415V13ValueDto dto) {
        values.add(dto);
        return this;
    }

    public TestPackage data(VuxForm0420415V13DataEntity row) {
        data.add(row);
        return this;
    }

    public TestPackage link(VuxDataXbrlLinkEntity link) {
        links.add(link);
        return this;
    }

    public CheckDataContext build() {
        return new CheckDataContext(1L, runId, contexts, units, values, data, links, null);
    }
}
