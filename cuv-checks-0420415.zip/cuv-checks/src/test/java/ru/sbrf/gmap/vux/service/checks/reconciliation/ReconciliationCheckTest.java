package ru.sbrf.gmap.vux.service.checks.reconciliation;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;
import ru.sbrf.gmap.vux.entity.VuxDataXbrlLinkEntity;
import ru.sbrf.gmap.vux.entity.VuxForm0420415V13DataEntity;
import ru.sbrf.gmap.vux.service.checks.CheckDataContext;
import ru.sbrf.gmap.vux.service.checks.TestPackage;
import ru.sbrf.gmap.vux.service.checks.Violation;
import ru.sbrf.gmap.vux.service.parser.XmlParserService;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Проверка 010 на настоящем разборе XML (реальный {@link XmlParserService}, без моков):
 * так тест ловит и ошибки в работе с измерениями, а не только в сравнении.
 */
class ReconciliationCheckTest {

    private static final String TABLE = "t_vux_form_0420415_1_3_data";
    private static final String AXIS = "dim-int:Tip_czenBum_naPravSobstvAxis";
    private static final String MEMBER = "mem-int:KolCZenBumagPrinadOrgMember";

    private final DimensionParser dims = new DimensionParser(new XmlParserService());
    private final ReconciliationCheck check = new ReconciliationCheck(
            new ExpectedFactsBuilder(dims), new ActualFactsBuilder(dims), new FactValueComparator());

    // ---------- фикстуры ----------

    /** scenario контекста: бумага, строка и одна explicit-ось. */
    private static String scenario(String bumaga, String stroka) {
        return """
                <xbrldi:explicitMember dimension="%s">%s</xbrldi:explicitMember>
                <xbrldi:typedMember dimension="dim-int:ID_CzennojBumagiTaxis"><dim-int:ID_CzennojBumagiTypedname>%s</dim-int:ID_CzennojBumagiTypedname></xbrldi:typedMember>
                <xbrldi:typedMember dimension="dim-int:ID_strokiTaxis"><dim-int:ID_strokiTypedname>%s</dim-int:ID_strokiTypedname></xbrldi:typedMember>
                """.formatted(AXIS, MEMBER, bumaga, stroka);
    }

    private static VuxDataXbrlLinkEntity measureLink(String column, String element) {
        var link = new VuxDataXbrlLinkEntity();
        link.setId(new VuxDataXbrlLinkEntity.DataXbrlLinkId(TestPackage.TAXONOMY, TABLE, column));
        link.setColumnXbrlType("measure");
        link.setMeasureId(element);
        link.setDocTypeId(1);
        link.setAnalyticalSection("<xbrldi:explicitMember dimension=\"%s\">%s</xbrldi:explicitMember>".formatted(AXIS, MEMBER));
        return link;
    }

    private static VuxForm0420415V13DataEntity row(String bumaga, String stroka, String kol) {
        var r = new VuxForm0420415V13DataEntity();
        r.setIdCzennojbumagi(bumaga);
        r.setIdStroki(stroka);
        r.setKolcprinbuxuch(kol == null ? null : new BigDecimal(kol));
        return r;
    }

    private static VuxForm0420415V13ValueDto value(String contextId, String v, String decimals) {
        return VuxForm0420415V13ValueDto.builder()
                .elementName("purcb-dic:KolCZB").value(v).decimals(decimals)
                .contextId(contextId).unitId("u1").taxonomy(TestPackage.TAXONOMY).workflowRunId(7L).build();
    }

    private static TestPackage base() {
        return TestPackage.run(7)
                .context("c1", scenario("B1", "S1"), TestPackage.TAXONOMY)
                .unit("u1")
                .link(measureLink("kolcprinbuxuch", "KolCZB"));
    }

    // ---------- тесты ----------

    @Test
    @DisplayName("Значения совпадают → нарушений нет (префиксы элементов на сторонах разные)")
    void match() {
        CheckDataContext ctx = base().data(row("B1", "S1", "100")).value(value("c1", "100.00", "2")).build();
        assertThat(check.check(ctx)).isEmpty();
    }

    @Test
    @DisplayName("Разные значения → расхождение с обоими значениями в тексте")
    void mismatch() {
        CheckDataContext ctx = base().data(row("B1", "S1", "100")).value(value("c1", "200", "0")).build();

        assertThat(check.check(ctx)).singleElement()
                .extracting(Violation::message).asString()
                .contains("Расхождение").contains("100").contains("200");
    }

    @Test
    @DisplayName("decimals учитывается: 100.004 и 100.00 при decimals=2 равны")
    void decimalsRounding() {
        CheckDataContext ctx = base().data(row("B1", "S1", "100.004")).value(value("c1", "100.00", "2")).build();
        assertThat(check.check(ctx)).isEmpty();
    }

    @Test
    @DisplayName("Факт есть в витрине, нет в отчёте → «отсутствует в отчёте»")
    void missingInReport() {
        CheckDataContext ctx = base().data(row("B1", "S1", "100")).data(row("B2", "S1", "5"))
                .value(value("c1", "100", "0")).build();

        assertThat(check.check(ctx)).singleElement()
                .extracting(Violation::message).asString()
                .contains("отсутствует в отчёте").contains("B2");
    }

    @Test
    @DisplayName("Факт есть в отчёте, нет в витрине → «отсутствует в витрине»")
    void extraInReport() {
        CheckDataContext ctx = base()
                .context("c2", scenario("B9", "S9"), TestPackage.TAXONOMY)
                .data(row("B1", "S1", "100"))
                .value(value("c1", "100", "0"))
                .value(value("c2", "7", "0"))
                .build();

        assertThat(check.check(ctx)).singleElement()
                .extracting(Violation::message).asString()
                .contains("отсутствует в витрине").contains("B9");
    }

    @Test
    @DisplayName("Сообщается о каждом расхождении, а не о первом")
    void allMismatches() {
        CheckDataContext ctx = base()
                .context("c2", scenario("B2", "S1"), TestPackage.TAXONOMY)
                .data(row("B1", "S1", "1")).data(row("B2", "S1", "2"))
                .value(value("c1", "10", "0")).value(value("c2", "20", "0"))
                .build();

        assertThat(check.check(ctx)).hasSize(2);
    }

    @Test
    @DisplayName("Нет настроек для таксономии → нарушение, а не «ошибок нет»")
    void noConfig() {
        CheckDataContext ctx = TestPackage.run(7)
                .context("c1", scenario("B1", "S1"), TestPackage.TAXONOMY)
                .data(row("B1", "S1", "100")).value(value("c1", "100", "0"))
                .build();

        assertThat(check.check(ctx)).extracting(Violation::message)
                .anySatisfy(m -> assertThat(m).contains("Нет настроек сверки"));
    }

    @Test
    @DisplayName("В настройке колонка, которой нет в витрине → понятная ошибка настройки")
    void badColumnInConfig() {
        CheckDataContext ctx = base().link(measureLink("no_such_column", "Other"))
                .data(row("B1", "S1", "100")).value(value("c1", "100", "0")).build();

        assertThat(check.check(ctx)).singleElement()
                .extracting(Violation::message).asString()
                .contains("нет колонки no_such_column");
    }

    @Test
    @DisplayName("Пустая ячейка витрины и nil в отчёте → совпадение")
    void nullAndNil() {
        var nil = VuxForm0420415V13ValueDto.builder()
                .elementName("KolCZB").nil("true").contextId("c1").unitId("u1")
                .taxonomy(TestPackage.TAXONOMY).workflowRunId(7L).build();
        CheckDataContext ctx = base().data(row("B1", "S1", null)).value(nil).build();

        assertThat(check.check(ctx)).isEmpty();
    }

    @Test
    @DisplayName("Дубль строки в витрине → отдельное нарушение")
    void duplicateInData() {
        CheckDataContext ctx = base().data(row("B1", "S1", "100")).data(row("B1", "S1", "100"))
                .value(value("c1", "100", "0")).build();

        assertThat(check.check(ctx)).extracting(Violation::message)
                .anySatisfy(m -> assertThat(m).contains("Дубль факта в витрине"));
    }

    @Test
    @DisplayName("Код enum: справочник не найден → запасное правило «цифры после подчёркивания»")
    void enumLegacy() {
        assertThat(FactValueComparator.legacyCode("Strana_643RusRossiyaMember")).isEqualTo("643");
        assertThat(FactValueComparator.enumEquals("643", "mem-int:Strana_643RusRossiyaMember", "t", "e", java.util.Map.of()))
                .isTrue();
    }

    @Test
    @DisplayName("Числа сравниваются как числа, а не как строки")
    void numbers() {
        assertThat(FactValueComparator.numbersEqual("1.50", "1.5", null)).isTrue();
        assertThat(FactValueComparator.numbersEqual("1.5", "1.6", "INF")).isFalse();
        assertThat(FactValueComparator.parseDecimals("INF")).isNull();
        assertThat(FactValueComparator.parseDecimals("-3")).isEqualTo(-3);
    }
}
