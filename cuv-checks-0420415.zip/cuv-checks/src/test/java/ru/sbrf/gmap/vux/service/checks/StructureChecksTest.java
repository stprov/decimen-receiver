package ru.sbrf.gmap.vux.service.checks;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13UnitDto;
import ru.sbrf.gmap.vux.dto.csv.VuxForm0420415V13ValueDto;
import ru.sbrf.gmap.vux.service.checks.rules.PartPresentCheck;
import ru.sbrf.gmap.vux.service.checks.rules.ReferenceCheck;
import ru.sbrf.gmap.vux.service.checks.rules.TaxonomyCheck;
import ru.sbrf.gmap.vux.service.checks.rules.WorkflowRunIdCheck;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Проверки 001–009. Каждая — минимум «чисто» и «есть нарушение»,
 * плюс случаи, на которых ломалась старая реализация.
 */
class StructureChecksTest {

    private final CuvChecksConfig config = new CuvChecksConfig();

    @Test
    @DisplayName("001: номер партии не заполнен → нарушение")
    void workflowRunId_missing() {
        var ctx = CheckDataContext.empty(1L, null);
        assertThat(new WorkflowRunIdCheck().check(ctx)).hasSize(1);
    }

    @Test
    @DisplayName("001: строки чужой партии считаются по каждой части")
    void workflowRunId_foreignRows() {
        var ctx = TestPackage.run(7).context("c1").unit("u1").build();
        var foreignUnit = VuxForm0420415V13UnitDto.builder().unitId("u2").taxonomy(TestPackage.TAXONOMY).workflowRunId(8L).build();
        var withForeign = new CheckDataContext(1L, 7L, ctx.contextList(), List.of(ctx.unitList().getFirst(), foreignUnit),
                List.of(), List.of(), List.of(), null);

        var violations = new WorkflowRunIdCheck().check(withForeign);

        assertThat(violations).singleElement()
                .satisfies(v -> assertThat(v.message()).contains("unit").contains("1 строк"));
    }

    @Test
    @DisplayName("002–004: пустая часть отчёта → нарушение")
    void partPresent() {
        var ctx = TestPackage.run(7).context("c1").build(); // нет unit и value

        assertThat(((PartPresentCheck) config.check002ContextPresent()).check(ctx)).isEmpty();
        assertThat(((PartPresentCheck) config.check003UnitPresent()).check(ctx)).hasSize(1);
        assertThat(((PartPresentCheck) config.check004ValuePresent()).check(ctx)).hasSize(1);
    }

    @Test
    @DisplayName("007: каждая битая ссылка на context — отдельное нарушение")
    void missingContext_reportsEachId() {
        var ctx = TestPackage.run(7).context("c1").unit("u1")
                .value("A", "1", "c1", "u1")
                .value("B", "2", "c2", "u1")
                .value("C", "3", "c3", "u1")
                .build();

        var violations = ((ReferenceCheck) config.check007MissingContext()).check(ctx);

        assertThat(violations).extracting(Violation::objectRef).containsExactly("c2", "c3");
    }

    @Test
    @DisplayName("008: value без unit_id (нечисловой факт) — не ошибка и не NPE")
    void missingUnit_ignoresNullUnitId() {
        var nonNumeric = VuxForm0420415V13ValueDto.builder()
                .elementName("Naim").value("ООО Ромашка").contextId("c1").unitId(null)
                .taxonomy(TestPackage.TAXONOMY).workflowRunId(7L).build();
        var ctx = TestPackage.run(7).context("c1").unit("u1")
                .value("Kol", "100", "c1", "u1")
                .value(nonNumeric)
                .build();

        assertThat(((ReferenceCheck) config.check008MissingUnit()).check(ctx)).isEmpty();
    }

    @Test
    @DisplayName("008: в сообщение попадают все отсутствующие unit_id, а не только первый")
    void missingUnit_allIds() {
        var ctx = TestPackage.run(7).context("c1").unit("u1")
                .value("A", "1", "c1", "uX")
                .value("B", "2", "c1", "uY")
                .build();

        var violations = ((ReferenceCheck) config.check008MissingUnit()).check(ctx);

        assertThat(violations).extracting(Violation::objectRef).containsExactly("uX", "uY");
        assertThat(config.check008MissingUnit().meta().code()).isEqualTo("DCUV_0420415_1_3_008");
    }

    @Test
    @DisplayName("005/006: описанные, но неиспользуемые context и unit")
    void unusedDescriptions() {
        var ctx = TestPackage.run(7).context("c1").context("c-unused").unit("u1").unit("u-unused")
                .value("A", "1", "c1", "u1")
                .build();

        assertThat(((ReferenceCheck) config.check005UnusedContext()).check(ctx))
                .extracting(Violation::objectRef).containsExactly("c-unused");
        assertThat(((ReferenceCheck) config.check006UnusedUnit()).check(ctx))
                .extracting(Violation::objectRef).containsExactly("u-unused");
    }

    @Test
    @DisplayName("009: разные версии таксономии → нарушение с перечнем версий")
    void taxonomy_mismatch() {
        var ctx = TestPackage.run(7).context("c1", null, "tax-1").unit("u1", "tax-2")
                .value("A", "1", "c1", "u1")
                .build();

        var violations = new TaxonomyCheck().check(ctx);

        assertThat(violations).singleElement()
                .satisfies(v -> assertThat(v.message()).contains("tax-1").contains("tax-2"));
    }

    @Test
    @DisplayName("009: одна версия → нарушений нет")
    void taxonomy_single() {
        var ctx = TestPackage.run(7).context("c1").unit("u1").value("A", "1", "c1", "u1").build();
        assertThat(new TaxonomyCheck().check(ctx)).isEmpty();
    }
}
