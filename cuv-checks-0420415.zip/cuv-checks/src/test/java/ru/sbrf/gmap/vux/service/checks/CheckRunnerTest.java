package ru.sbrf.gmap.vux.service.checks;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.sbrf.gmap.vux.entity.enums.RuleTypeEnum;

import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Поведение запускалки: этапы, отключение, падение проверки, протокол.
 */
class CheckRunnerTest {

    /** Проверка-заглушка: возвращает заданное число нарушений или бросает исключение. */
    private static CheckRule rule(String code, CheckStage stage, RuleTypeEnum severity, int violations, boolean fail) {
        RuleMeta meta = new RuleMeta(code, "Проверка " + code, stage, 1, severity);
        return new CheckRule() {
            @Override
            public RuleMeta meta() {
                return meta;
            }

            @Override
            public List<Violation> check(CheckDataContext ctx) {
                if (fail) {
                    throw new IllegalStateException("boom");
                }
                return java.util.stream.IntStream.range(0, violations)
                        .mapToObj(i -> Violation.of("obj" + i, "msg" + i)).toList();
            }
        };
    }

    private static final CheckDataContext CTX = CheckDataContext.empty(1L, 7L);

    @Test
    @DisplayName("Ошибка на этапе блокирует следующие этапы, но не соседей по этапу")
    void blockingStage() {
        var runner = new CheckRunner(List.of(
                rule("A", CheckStage.PRESENCE, RuleTypeEnum.E, 1, false),
                rule("B", CheckStage.PRESENCE, RuleTypeEnum.E, 0, false),
                rule("C", CheckStage.REFERENCES, RuleTypeEnum.E, 0, false)), Set.of());

        var results = runner.run(CTX);

        assertThat(results).extracting(RuleResult::status)
                .containsExactly(CheckStatus.FAILED, CheckStatus.PASSED, CheckStatus.SKIPPED);
    }

    @Test
    @DisplayName("Предупреждение не блокирует следующие этапы")
    void warningDoesNotBlock() {
        var runner = new CheckRunner(List.of(
                rule("A", CheckStage.REFERENCES, RuleTypeEnum.W, 3, false),
                rule("B", CheckStage.CONSISTENCY, RuleTypeEnum.E, 0, false)), Set.of());

        assertThat(runner.run(CTX)).extracting(RuleResult::status)
                .containsExactly(CheckStatus.FAILED, CheckStatus.PASSED);
    }

    @Test
    @DisplayName("Исключение в проверке → ERROR, остальные выполняются")
    void exceptionIsolated() {
        var runner = new CheckRunner(List.of(
                rule("A", CheckStage.REFERENCES, RuleTypeEnum.E, 0, true),
                rule("B", CheckStage.REFERENCES, RuleTypeEnum.E, 2, false)), Set.of());

        var results = runner.run(CTX);

        assertThat(results.get(0).status()).isEqualTo(CheckStatus.ERROR);
        assertThat(results.get(0).technicalError()).contains("boom");
        assertThat(results.get(1).status()).isEqualTo(CheckStatus.FAILED);
    }

    @Test
    @DisplayName("Отключённая проверка видна в протоколе как отключённая, а не как пройденная")
    void disabled() {
        var runner = new CheckRunner(List.of(rule("X", CheckStage.RECONCILIATION, RuleTypeEnum.E, 5, false)), Set.of("X"));

        var checks = CuvProtocolMapper.checks(runner.run(CTX));

        assertThat(checks).singleElement()
                .satisfies(c -> assertThat(c.getCheckResult()).isEqualTo("Проверка отключена"));
    }

    @Test
    @DisplayName("Проверки сортируются по этапу независимо от порядка бинов")
    void ordering() {
        var runner = new CheckRunner(List.of(
                rule("LATE", CheckStage.RECONCILIATION, RuleTypeEnum.E, 0, false),
                rule("EARLY", CheckStage.PRESENCE, RuleTypeEnum.E, 0, false)), Set.of());

        assertThat(runner.run(CTX)).extracting(r -> r.meta().code()).containsExactly("EARLY", "LATE");
    }

    @Test
    @DisplayName("Протокол: количество = число нарушений, итог и строки считаются из одних данных")
    void protocolCounts() {
        var results = new CheckRunner(List.of(
                rule("E1", CheckStage.REFERENCES, RuleTypeEnum.E, 5, false),
                rule("W1", CheckStage.REFERENCES, RuleTypeEnum.W, 2, false)), Set.of()).run(CTX);

        assertThat(CuvProtocolMapper.checks(results)).extracting(c -> c.getCountingDeviation())
                .containsExactly("5", "2");
        assertThat(CuvProtocolMapper.total(results, RuleTypeEnum.E)).isEqualTo(5);
        assertThat(CuvProtocolMapper.rows(results, RuleTypeEnum.E, 3)).hasSize(3); // показано 3 из 5
        assertThat(CuvProtocolMapper.rows(results, RuleTypeEnum.W, 3)).hasSize(2);
        assertThat(CuvProtocolMapper.hasBlocking(results)).isTrue();
    }
}
